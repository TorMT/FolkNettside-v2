"""Dykkelykt rev A0 - enkle startmodeller i typiske storrelser (CadQuery).

Alle mal i mm. Malene er FORELOPIGE (se kravspesifikasjon rev 3 og design rev A0):
O-ringspor er plassholdere og skal dimensjoneres etter Parker ORD 5700,
TIR-linse og driver er generiske og byttes nar konkrete deler er valgt.

Koordinater: kanisteren star med bunnen i z = 0. Hodet har bakenden i z = 0 og
glasset fremst (z = 75). Hodet er flyttet ved siden av kanisteren i sammenstillingen.

Kjor:  python3 dykkelykt_reva0.py [utmappe]
"""
import json
import math
import sys
from pathlib import Path

import cadquery as cq

OUT = Path(sys.argv[1] if len(sys.argv) > 1 else "dykkelykt-reva0")
OUT.mkdir(parents=True, exist_ok=True)

# ---------------- parametre ----------------
# Kanister (POM)
K_OD, K_BORE, K_BUNN, K_INN = 67.0, 55.0, 10.0, 100.0     # ytre, boring, bunn, innvendig lengde
K_L = K_BUNN + K_INN                                        # 110
K_GJENGE_D, K_GJENGE_L = 66.0, 15.0                        # dreid band for M66x1,5 (gjenge ikke modellert)
# Lokk
L_FLENS_D, L_FLENS_T = 64.0, 12.0
L_PLUGG_D, L_PLUGG_L = K_BORE - 0.1, 20.0
L_BOSS_D, L_BOSS_H = 22.0, 13.0                             # stopelengde 12 + 13 = 25
STOP_D = 10.0                                               # stopeboring for kabel
AVL_D, AVL_R = 8.0, 20.0                                    # avlastningsplugg, radius fra senter
# O-ringspor (plassholder for 2,62 mm tverrsnitt)
SPOR_B, SPOR_DYP = 3.6, 2.1
# Mutter
M_OD, M_LEPPE_ID, M_LEPPE_T = 76.0, 58.0, 4.0
# Celler 21700
C_D, C_L = 21.7, 70.0
C_SENTER = C_D / 2 + 0.3
HOLDER_D, HOLDER_T = 54.0, 4.0
# Hode (Al 6061)
H_OD, H_L = 50.0, 75.0
GLASS_D, GLASS_T = 46.0, 4.5
GLASS_BORE = GLASS_D + 0.4
TIR_BORE = 40.5
HYLLE_T = 8.0
DRIVER_BORE, DRIVER_DYP = 24.0, 17.5
BAK_T = 25.0                                                # massivt bakstykke med stopeboring
FRONT_BAND_D, FRONT_BAND_L = 48.0, 8.0                      # dreid band for frontring
# Frontring
F_OD, F_LEPPE_ID, F_LEPPE_T = 52.0, 41.0, 2.0
# Bryterkrage (POM)
B_ID, B_OD, B_B = H_OD + 0.5, 60.0, 12.0
B_Z = 34.0                                                  # senter i z, ved hall-lomma

z_hylle_bunn = BAK_T + DRIVER_DYP                           # 42,5
z_hylle_topp = z_hylle_bunn + HYLLE_T                       # 50,5
z_glass_bunn = H_L - GLASS_T                                # 70,5
TIR_H = z_glass_bunn - (z_hylle_topp + 3.0)                 # 17, over LED


def kanister():
    body = cq.Workplane("XY").circle(K_OD / 2).extrude(K_L)
    # dreid gjengeband i toppen
    band = (cq.Workplane("XY").workplane(offset=K_L - K_GJENGE_L)
            .circle(K_OD / 2 + 1).circle(K_GJENGE_D / 2).extrude(K_GJENGE_L))
    body = body.cut(band)
    bore = cq.Workplane("XY").workplane(offset=K_BUNN).circle(K_BORE / 2).extrude(K_INN)
    body = body.cut(bore)
    # innforingsfas i boringen
    body = body.faces(">Z").edges("not %LINE").edges(cq.selectors.RadiusNthSelector(0)).chamfer(2.0)
    return body


def lokk():
    flens = cq.Workplane("XY").circle(L_FLENS_D / 2).extrude(L_FLENS_T)
    plugg = cq.Workplane("XY").circle(L_PLUGG_D / 2).extrude(-L_PLUGG_L)
    boss = cq.Workplane("XY").workplane(offset=L_FLENS_T).circle(L_BOSS_D / 2).extrude(L_BOSS_H)
    lid = flens.union(plugg).union(boss)
    # to radielle O-ringspor i pluggen
    for zc in (-6.0, -14.0):
        spor = (cq.Workplane("XY").workplane(offset=zc - SPOR_B / 2)
                .circle(L_PLUGG_D / 2 + 1).circle(L_PLUGG_D / 2 - SPOR_DYP).extrude(SPOR_B))
        lid = lid.cut(spor)
    # stopeboring for kabel med tre ringspor for epoksylas
    lid = lid.cut(cq.Workplane("XY").workplane(offset=-L_PLUGG_L).circle(STOP_D / 2)
                  .extrude(L_PLUGG_L + L_FLENS_T + L_BOSS_H))
    for zc in (4.0, 12.0, 20.0):
        lid = lid.cut(cq.Workplane("XY").workplane(offset=zc - 0.75)
                      .circle(STOP_D / 2 + 1.0).extrude(1.5))
    # avlastningsplugg: boring med indre skulder (stempel presses inn mot skulderen av ytre trykk)
    avl_ytre = (cq.Workplane("XY").workplane(offset=-L_PLUGG_L + 4).center(AVL_R, 0)
                .circle(AVL_D / 2).extrude(L_PLUGG_L - 4 + L_FLENS_T))
    avl_indre = cq.Workplane("XY").workplane(offset=-L_PLUGG_L).center(AVL_R, 0).circle(2.0).extrude(4)
    return lid.cut(avl_ytre).cut(avl_indre)


def mutter():
    h_gjenge = K_GJENGE_L + L_FLENS_T                       # band + flens
    ring = (cq.Workplane("XY").circle(M_OD / 2).circle(K_GJENGE_D / 2).extrude(h_gjenge))
    leppe = (cq.Workplane("XY").workplane(offset=h_gjenge)
             .circle(M_OD / 2).circle(M_LEPPE_ID / 2).extrude(M_LEPPE_T))
    return ring.union(leppe)


def celle():
    return cq.Workplane("XY").circle(C_D / 2).extrude(C_L)


def celleholder_plate():
    p = cq.Workplane("XY").circle(HOLDER_D / 2).extrude(HOLDER_T)
    pts = [(sx * C_SENTER, sy * C_SENTER) for sx in (-1, 1) for sy in (-1, 1)]
    p = p.cut(cq.Workplane("XY").workplane(offset=1.5).pushPoints(pts).circle(C_D / 2 + 0.2).extrude(HOLDER_T))
    # kodingsnokkel (polaritet): en utsparing pa en side
    return p.cut(cq.Workplane("XY").center(HOLDER_D / 2, 0).rect(6, 6).extrude(HOLDER_T))


def vernekort():
    return cq.Workplane("XY").rect(40, 18).extrude(3.0)


def hode():
    body = cq.Workplane("XY").circle(H_OD / 2).extrude(H_L)
    band = (cq.Workplane("XY").workplane(offset=H_L - FRONT_BAND_L)
            .circle(H_OD / 2 + 1).circle(FRONT_BAND_D / 2).extrude(FRONT_BAND_L))
    body = body.cut(band)
    # glass-forsenkning, TIR- og hylleboring, driverlomme
    body = body.cut(cq.Workplane("XY").workplane(offset=z_glass_bunn).circle(GLASS_BORE / 2).extrude(GLASS_T + 1))
    body = body.cut(cq.Workplane("XY").workplane(offset=z_hylle_bunn).circle(TIR_BORE / 2)
                    .extrude(z_glass_bunn - z_hylle_bunn))
    body = body.cut(cq.Workplane("XY").workplane(offset=BAK_T).circle(DRIVER_BORE / 2).extrude(DRIVER_DYP))
    # O-ringspor i skulderflaten under glasset (plassholder)
    body = body.cut(cq.Workplane("XY").workplane(offset=z_glass_bunn - 1.8)
                    .circle(44.5 / 2).circle(41.5 / 2).extrude(1.8))
    # stopeboring bak med ringspor
    body = body.cut(cq.Workplane("XY").circle(STOP_D / 2).extrude(BAK_T))
    for zc in (6.0, 13.0, 20.0):
        body = body.cut(cq.Workplane("XY").workplane(offset=zc - 0.75).circle(STOP_D / 2 + 1.0).extrude(1.5))
    # hall-lomme: radiell blindboring fra driverlomma, 2,5 mm restvegg
    rest = 2.5
    hall = (cq.Workplane("YZ").workplane(offset=DRIVER_BORE / 2 - 1).center(0, B_Z)
            .circle(3.0).extrude(H_OD / 2 - rest - (DRIVER_BORE / 2 - 1)))
    return body.cut(hall)


def hylle():
    p = cq.Workplane("XY").circle(TIR_BORE / 2 - 0.05).extrude(HYLLE_T)
    p = p.cut(cq.Workplane("XY").pushPoints([(0, 7), (0, -7)]).circle(1.5).extrude(HYLLE_T))     # ledninger
    p = p.cut(cq.Workplane("XY").pushPoints([(7.5, 0), (-7.5, 0)]).circle(0.8).extrude(HYLLE_T)) # M2
    return p


def mcpcb():
    return cq.Workplane("XY").circle(10.0).extrude(1.6)


def led():
    return cq.Workplane("XY").rect(5.0, 5.0).extrude(1.2)


def tir():
    return cq.Workplane("XY").circle(7.0).workplane(offset=TIR_H).circle(20.0).loft()


def glass():
    return cq.Workplane("XY").circle(GLASS_D / 2).extrude(GLASS_T)


def frontring():
    ring = cq.Workplane("XY").circle(F_OD / 2).circle(FRONT_BAND_D / 2).extrude(FRONT_BAND_L)
    leppe = (cq.Workplane("XY").workplane(offset=FRONT_BAND_L)
             .circle(F_OD / 2).circle(F_LEPPE_ID / 2).extrude(F_LEPPE_T))
    return ring.union(leppe)


def driver():
    return cq.Workplane("XY").circle(11.0).extrude(4.0)


def bryterkrage():
    ring = cq.Workplane("XY").circle(B_OD / 2).circle(B_ID / 2).extrude(B_B)
    # fore for skyveren
    return ring.cut(cq.Workplane("XY").center(B_OD / 2 - 2, 0).rect(8, 14).extrude(B_B))


def skyver():
    # radielt 25,5-29,5 mm fra hodets akse; innkapslet magnetlomme
    s = cq.Workplane("XY").rect(4.0, 10).extrude(B_B)
    lomme = cq.Workplane("YZ").workplane(offset=-1.7).center(0, B_B / 2).circle(3.05).extrude(3.1)
    return s.cut(lomme)


def magnet():
    return cq.Workplane("YZ").circle(3.0).extrude(3.0)


def kabel_stump():
    return cq.Workplane("XY").circle(3.5).extrude(60)


DELER = {
    "kanister": (kanister, "POM-C", 1.41),
    "lokk": (lokk, "POM-C", 1.41),
    "mutter": (mutter, "POM-C", 1.41),
    "celleholder-plate": (celleholder_plate, "PETG", 1.27),
    "vernekort": (vernekort, "FR4 (forenklet)", 1.85),
    "hode": (hode, "Al 6061-T6", 2.70),
    "hylle": (hylle, "Al 6061-T6", 2.70),
    "frontring": (frontring, "Al 6061-T6", 2.70),
    "glass": (glass, "Borosilikat", 2.23),
    "tir-linse": (tir, "PMMA (generisk)", 1.18),
    "mcpcb": (mcpcb, "Kobber-MCPCB (forenklet)", 8.9),
    "led-sst40": (led, "LED (forenklet)", 3.0),
    "driver": (driver, "Driver 22 mm (forenklet)", 2.0),
    "bryterkrage": (bryterkrage, "POM-C", 1.41),
    "skyver": (skyver, "POM-C", 1.41),
    "magnet": (magnet, "NdFeB", 7.5),
    "celle-21700": (celle, "Li-ion 21700 (ca. 70 g)", None),
}

solids = {}
rapport = {}
for navn, (fn, mat, rho) in DELER.items():
    wp = fn()
    solids[navn] = wp
    cq.exporters.export(wp, str(OUT / f"{navn}.step"))
    vol_mm3 = wp.val().Volume()
    masse = 70.0 if navn == "celle-21700" else vol_mm3 / 1000 * rho
    rapport[navn] = {"materiale": mat, "volum_cm3": round(vol_mm3 / 1000, 2), "masse_g": round(masse, 1)}

# ---------------- sammenstilling ----------------
asm = cq.Assembly(name="dykkelykt-reva0")
farge = {
    "pom": cq.Color(0.15, 0.15, 0.16), "al": cq.Color(0.55, 0.58, 0.62), "celle": cq.Color(0.95, 0.62, 0.15),
    "glass": cq.Color(0.7, 0.85, 0.95, 0.4), "pcb": cq.Color(0.1, 0.45, 0.2), "rod": cq.Color(0.8, 0.2, 0.15),
}
loc = cq.Location
asm.add(solids["kanister"], name="kanister", color=farge["pom"])
asm.add(solids["celleholder-plate"], name="holder-bunn", loc=loc((0, 0, K_BUNN)), color=cq.Color(0.9, 0.9, 0.9))
asm.add(solids["celleholder-plate"], name="holder-topp",
        loc=loc((0, 0, K_BUNN + 1.5 + C_L + 2.5), (1, 0, 0), 180), color=cq.Color(0.9, 0.9, 0.9))
for i, (sx, sy) in enumerate([(-1, -1), (-1, 1), (1, -1), (1, 1)]):
    asm.add(solids["celle-21700"], name=f"celle-{i + 1}",
            loc=loc((sx * C_SENTER, sy * C_SENTER, K_BUNN + 1.5)), color=farge["celle"])
asm.add(solids["vernekort"], name="vernekort", loc=loc((0, 0, K_BUNN + C_L + 6)), color=farge["pcb"])
asm.add(solids["lokk"], name="lokk", loc=loc((0, 0, K_L)), color=farge["pom"])
asm.add(solids["mutter"], name="mutter", loc=loc((0, 0, K_L - K_GJENGE_L)), color=cq.Color(0.25, 0.25, 0.27))
asm.add(solids["kabel_stump"] if "kabel_stump" in solids else kabel_stump(), name="kabel-kanister",
        loc=loc((0, 0, K_L + L_FLENS_T + L_BOSS_H)), color=cq.Color(0.05, 0.05, 0.05))

HX = 140.0                                                   # hodet plasseres ved siden av kanisteren
asm.add(solids["hode"], name="hode", loc=loc((HX, 0, 0)), color=farge["al"])
asm.add(solids["driver"], name="driver", loc=loc((HX, 0, BAK_T + 2)), color=farge["pcb"])
asm.add(solids["hylle"], name="hylle", loc=loc((HX, 0, z_hylle_bunn)), color=farge["al"])
asm.add(solids["mcpcb"], name="mcpcb", loc=loc((HX, 0, z_hylle_topp)), color=cq.Color(0.85, 0.85, 0.85))
asm.add(solids["led-sst40"], name="led", loc=loc((HX, 0, z_hylle_topp + 1.6)), color=cq.Color(1, 0.9, 0.5))
asm.add(solids["tir-linse"], name="tir", loc=loc((HX, 0, z_glass_bunn - TIR_H)), color=cq.Color(0.9, 0.95, 1, 0.5))
asm.add(solids["glass"], name="glass", loc=loc((HX, 0, z_glass_bunn)), color=farge["glass"])
asm.add(solids["frontring"], name="frontring", loc=loc((HX, 0, H_L - FRONT_BAND_L)), color=cq.Color(0.2, 0.2, 0.22))
asm.add(solids["bryterkrage"], name="bryterkrage", loc=loc((HX, 0, B_Z - B_B / 2)), color=farge["pom"])
asm.add(solids["skyver"], name="skyver", loc=loc((HX + 27.5, 0, B_Z - B_B / 2)), color=farge["rod"])
asm.add(solids["magnet"], name="magnet", loc=loc((HX + 25.8, 0, B_Z)), color=cq.Color(0.6, 0.6, 0.65))
asm.add(kabel_stump(), name="kabel-hode", loc=loc((HX, 0, 0), (1, 0, 0), 180), color=cq.Color(0.05, 0.05, 0.05))

asm.save(str(OUT / "dykkelykt-reva0-sammenstilling.step"))
try:
    asm.save(str(OUT / "dykkelykt-reva0-sammenstilling.glb"))
except Exception as exc:                                       # GLB er valgfritt
    print("GLB-eksport hoppet over:", exc)


# ---------------- oppdrift ----------------
def ytre_volum_sylinder(d, l):
    return math.pi * (d / 2) ** 2 * l / 1000.0


kan_deler = ["kanister", "lokk", "mutter", "vernekort"]
kan_masse = sum(rapport[n]["masse_g"] for n in kan_deler) + 2 * rapport["celleholder-plate"]["masse_g"] + 4 * 70.0
kan_v = ytre_volum_sylinder(K_OD, K_L) + ytre_volum_sylinder(L_BOSS_D, L_BOSS_H) \
    + (ytre_volum_sylinder(M_OD, K_GJENGE_L + L_FLENS_T + M_LEPPE_T) - ytre_volum_sylinder(K_GJENGE_D, K_GJENGE_L))
hode_deler = ["hode", "hylle", "frontring", "glass", "tir-linse", "mcpcb", "led-sst40", "driver",
              "bryterkrage", "skyver", "magnet"]
hode_masse = sum(rapport[n]["masse_g"] for n in hode_deler)
hode_v = ytre_volum_sylinder(H_OD, H_L) + rapport["frontring"]["volum_cm3"] + rapport["bryterkrage"]["volum_cm3"] \
    + rapport["skyver"]["volum_cm3"]
RHO_SJO = 1.025
oppdrift = {
    "kanister": {"masse_g": round(kan_masse), "ytre_volum_cm3": round(kan_v),
                 "netto_i_sjovann_g": round(kan_v * RHO_SJO - kan_masse)},
    "hode": {"masse_g": round(hode_masse), "ytre_volum_cm3": round(hode_v),
             "netto_i_sjovann_g": round(hode_v * RHO_SJO - hode_masse)},
    "merknad": "Negativ netto = synker. Kabel, handtak og festeband er ikke med. Ytre volum er grovt.",
}
(OUT / "masse-og-oppdrift.json").write_text(json.dumps({"deler": rapport, "oppdrift": oppdrift},
                                                       ensure_ascii=False, indent=2))
print(json.dumps(oppdrift, ensure_ascii=False, indent=2))
