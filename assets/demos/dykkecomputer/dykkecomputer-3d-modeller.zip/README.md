# Dive computer CAD — prototype 1

Four builds, each in its own folder. Housing sizes are for a **100 m design depth** (proof test at 150 m, 1.51 MPa) with a tempered-glass lens.

| Folder | Screen | Housing W × L × H (mm) | Lens (glass) | Back plate | Back screws | O-ring length | Housing mass |
|---|---|---|---|---|---|---|---|
| `dc-2in41-wrist` | 2.41" AMOLED, RM690B0 | 64 × 78 × 27.8 | 5.5 mm | 5.0 mm | 8 × M2 | 228 mm | 201 g |
| `dc-3in5-forearm` | 3.5" IPS, ST7796S (Waveshare) | 78 × 106 × 30.7 | 7.0 mm | 5.0 mm | 10 × M2 | 312 mm | 368 g |
| `dc-5in0-budget` | 5.0" IPS 800 × 480 RGB (generic) | 90 × 138 × 34.2 | 9.0 mm | 5.0 mm | 14 × M2 | 399 mm | 599 g |
| `dc-5in5-forearm` | 5.44" AMOLED, RM67199 | 92 × 150 × 32.9 | 10.0 mm | 5.5 mm | 14 × M2 | 427 mm | 691 g |

Mass is frame, bezel, back plate (aluminium), lens and charging window only. `sizing.json` has every number.

## What changed from prototype 0

Prototype 0 was a layout model. Three things in it would not have worked, and are fixed here:

1. **The back screws were inside the O-ring**, so each screw hole was a leak path. The frame now has an 8.5 mm sealing flange: blind tapped holes on the outside, the O-ring groove (2.0 × 1.1 mm for a 1.5 mm cord) inside them. Screws are at most 40 mm apart all round instead of four in the corners.
2. **Wireless charging does not work through an aluminium back plate.** The plate now has a 40 mm PEEK window (5 mm thick) under the coil. It is seated from the outside with its own O-ring, so water pressure presses it onto the seal. Check on the bench that your Qi pair still charges through a 5 mm spacer before machining.
3. **Lens, lens ledge and back plate were too thin for the depth.** A 4.5 mm glass lens over the 5.5" window is good for roughly 20 m. They are now sized from the design depth (see below), and the housings are 6–10 mm thicker for it.

Also new: the 5.0" budget build, wet-contact pins through the end wall, and the component blocks now match the firmware's parts (CH32V003, PCM1808, QMI8658, MMC5603, MAX17048, TCA9548A, VEML7700, ATGM336H, piezo buzzer).

## Sizing

Flat-plate formulas (Roark), uniform pressure, simply supported edges; stress = β·p·b²/t² for rectangles and 3(3+ν)/8·p·r²/t² for the round window. The lens ledge is sized as a cantilever carrying the lens edge load. Allowable stresses used (MPa): tempered glass 45, sapphire 100, aluminium 6061-T6 184, PEEK 35.

Lens thickness (mm) for other depths, glass / sapphire:

| Build | 40 m | 60 m | 100 m | 150 m |
|---|---|---|---|---|
| 2.41" | 3.5 / 2.5 | 4.5 / 3.0 | 5.5 / 4.0 | 7.0 / 4.5 |
| 3.5" | 4.5 / 3.0 | 5.5 / 3.5 | 7.0 / 4.5 | 8.5 / 5.5 |
| 5.0" budget | 6.0 / 4.0 | 7.0 / 5.0 | 9.0 / 6.0 | 11.0 / 7.5 |
| 5.44" | 6.5 / 4.5 | 7.5 / 5.0 | 10.0 / 6.5 | 12.0 / 8.0 |

To size for another depth or material, change `DESIGN_DEPTH_M`, `LENS_MATERIAL` or the allowables at the top of `gen.py` and run it again.

**This is a first sizing, not a verification.** Not covered by the hand calculations: the frame walls and corners, the back plate around the charging-window hole, the screw threads, glass edge quality, and creep in the PEEK window. Before anyone dives a housing: run FEA on the frame and back plate, confirm the allowables with your supervisor for the actual materials, and pressure-test every housing empty to 1.5 × its depth.

## Files in each folder

**This download holds the STEP files only** (the assembly and every part). The STL and 3MF folders described below are made by running `python gen.py out`.

- `*_assembly.step` — the whole assembly, one named and coloured body per part. **Use this in Fusion.**
- `*_assembly.3mf` — the whole assembly as one mesh, for a quick look or a print-fit test.
- `step/`, `stl/` — every part on its own.
- `3mf/` — the housing parts for printing a fit model (frame, bezel, back plate, lens dummy, charging window, button levers).

`section.png` shows a cross-section of each build. `check.py` confirms that no two parts overlap in any build (it passes for all four).

## Conventions

- Millimetres. Z is up: the outside of the back plate is Z = 0 and the display faces +Z. Origin at the centre of the housing.
- Left wall (−X): the two depth-sensor ports and one button. Right wall (+X): two buttons. End wall (−Y): the two wet-contact pins.

## Importing into Fusion

1. **File → Open → Open from my computer**, pick `*_assembly.step`. Fusion makes one component per part.
2. STL and 3MF come in as meshes (**Insert → Insert Mesh**): use them for printing or reference, not for editing.

## What is real and what is a placeholder

- **From datasheets or listings:** display outlines and active areas of the 2.41", 3.5" and 5.44" panels, ESP32-S3-WROOM-1, ESP32-C6-MINI-1, MS5837-30BA, IC packages, LiPo cell sizes.
- **Approximate:** the 5.0" panel (generic 75.8 × 120.7 × 3.0 mm outline: check the drawing of the panel you buy), the ESP32-P4 block, Qi coil and ferrite, ferrite rod antenna, button levers.
- **Not modelled:** the lens gasket, the display carrier (the thin AMOLED needs one), a light path to the light sensor, the GNSS antenna, wiring and flex cables, button springs and pivots, strap hardware.
- **Machining:** all pockets are open from the top or bottom (3-axis); the sensor ports, button features and wet-contact holes are drilled from the side. Inside corners need a radius to suit your cutter; the O-ring groove corners are 3 mm or more.

## Regenerating

```
pip install cadquery trimesh matplotlib
python gen.py out          # models + sizing.json
python check.py out        # interference check
python section.py out section.png
```
