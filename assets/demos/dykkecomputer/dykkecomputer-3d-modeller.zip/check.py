"""Interference check: every pair of parts in every build must not overlap. python check.py out"""
import cadquery as cq, glob, os, itertools, sys
ok = True
for d in sorted(glob.glob(sys.argv[1] + '/*/')):
    sh = {os.path.basename(f)[:-5]: cq.importers.importStep(f).val() for f in glob.glob(d + 'step/*.step')}
    bb = {k: v.BoundingBox() for k, v in sh.items()}
    bad = []
    for a, b in itertools.combinations(sorted(sh), 2):
        A, B = bb[a], bb[b]
        if A.xmax < B.xmin or B.xmax < A.xmin or A.ymax < B.ymin or B.ymax < A.ymin or A.zmax < B.zmin or B.zmax < A.zmin:
            continue
        try:
            v = sh[a].intersect(sh[b]).Volume()
        except Exception:
            v = -1
        if abs(v) > 0.01:
            bad.append((a, b, round(v, 2)))
    ok &= not bad
    print(os.path.basename(d[:-1]), len(sh), 'parts; overlaps:', bad if bad else 'none')
sys.exit(0 if ok else 1)
