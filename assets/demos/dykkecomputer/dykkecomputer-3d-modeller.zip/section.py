"""Cross-sections of each build (cut at y = 0, looking along the arm) to check the stack-up. python section.py out section.png"""
import trimesh, glob, os, sys, numpy as np, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
col = {'housing': '#9aa6b0', 'bezel': '#5f6b76', 'lens': '#9cc7e8', 'back': '#6f7b86', 'button': '#cc3a2e', 'display': '#3c3489', 'main_pcb': '#1f5e3a',
       'lipo': '#4f7aa8', 'qi_window': '#d9cfae', 'qi': '#b8733e', 'rx': '#b8733e'}
dirs = sorted(glob.glob(sys.argv[1] + '/*/'))
fig, axes = plt.subplots(len(dirs), 1, figsize=(11, 3.1 * len(dirs)))
for ax, d in zip(axes, dirs):
    for f in sorted(glob.glob(d + 'stl/*.stl')):
        n = os.path.basename(f)[:-4]
        m = trimesh.load(f)
        sec = m.section(plane_origin=[0, 0.01, 0], plane_normal=[0, 1, 0])
        if sec is None: continue
        c = next((v for k, v in col.items() if n.startswith(k)), '#2a2f35')
        for ent in sec.discrete:
            ax.fill(ent[:, 0], ent[:, 2], facecolor=c, edgecolor='black', linewidth=0.4, alpha=0.9)
    ax.set_aspect('equal'); ax.set_title(os.path.basename(d[:-1]) + ' — section across the arm (mm)', fontsize=10); ax.grid(alpha=0.2)
plt.tight_layout(); plt.savefig(sys.argv[2], dpi=110)
