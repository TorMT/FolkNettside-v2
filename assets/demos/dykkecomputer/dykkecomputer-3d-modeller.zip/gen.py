"""
Dive computer housing generator (CadQuery 2.x):  python gen.py out

Lens, back plate and charging window are sized from the design depth with flat-plate formulas
(Roark, uniform pressure, simply supported edges). That is a first sizing, not a verification:
run FEA on the frame and pressure-test every housing before anyone dives it.
"""
import cadquery as cq, os, json, sys, math

OUT = sys.argv[1]

# ---------- sizing ----------
DESIGN_DEPTH_M = 100.0        # deepest planned dive
TEST_FACTOR = 1.5             # proof-test pressure = 1.5 x design depth
P_TEST = DESIGN_DEPTH_M * TEST_FACTOR * 0.01005   # MPa gauge, sea water
# Allowable working stress, MPa (strength with a safety factor already taken; confirm for your material batch)
ALLOW = {"tempered glass": 45.0, "sapphire": 100.0, "aluminium 6061-T6": 184.0, "PEEK": 35.0, "POM-C": 20.0}
LENS_MATERIAL = "tempered glass"
BACK_MATERIAL = "aluminium 6061-T6"
WINDOW_MATERIAL = "PEEK"     # the wireless-charging window: Qi does not work through metal

def beta_rect(a, b):
    """Roark: max stress coefficient, rectangular plate, all edges simply supported, a >= b."""
    r = max(a, b) / min(a, b)
    tab = [(1.0, 0.2874), (1.2, 0.3762), (1.4, 0.4530), (1.6, 0.5172), (1.8, 0.5688), (2.0, 0.6102), (3.0, 0.7134), (9.9, 0.7500)]
    for (r0, b0), (r1, b1) in zip(tab, tab[1:]):
        if r <= r1:
            return b0 + (b1 - b0) * (r - r0) / (r1 - r0)
    return 0.75

def plate_t(a, b, p, allow):
    """Thickness so that stress = allow: sigma = beta p b^2 / t^2 (b = short span)."""
    return min(a, b) * math.sqrt(beta_rect(a, b) * p / allow)

def disc_t(d, p, allow, nu=0.38):
    """Circular plate, simply supported: sigma = 3(3+nu)/8 p r^2 / t^2."""
    return d / 2 * math.sqrt(3 * (3 + nu) / 8 * p / allow)

def up(t, step=0.5):
    return math.ceil(t / step - 1e-9) * step

CFG = {
  "dc-2in41-wrist": dict(W=64, L=78, R=7, along=False, mcu="s3",
      disp=dict(w=42, l=56, t=1.6, aw=37, al=49), lens=dict(w=50, l=62, t=3.0), win=(46, 58),
      bat=dict(w=34, l=50, t=6)),
  "dc-3in5-forearm": dict(W=78, L=106, R=8, along=True, mcu="s3",
      disp=dict(w=61, l=92.4, t=2.5, aw=48.96, al=73.44), lens=dict(w=66, l=96, t=3.5), win=(52, 78),
      bat=dict(w=50, l=80, t=6)),
  "dc-5in5-forearm": dict(W=92, L=150, R=10, along=True, mcu="p4",
      disp=dict(w=69.74, l=126.6, t=0.82, aw=67.82, al=120.58), lens=dict(w=78, l=135, t=4.5), win=(70, 123),
      bat=dict(w=60, l=100, t=6)),
  # Budget build: generic 5.0 in 800 x 480 IPS RGB panel (outline 75.8 x 120.7 x 3.0, active 64.8 x 108.0: check your panel's drawing)
  "dc-5in0-budget": dict(W=90, L=138, R=10, along=True, mcu="s3",
      disp=dict(w=75.8, l=120.7, t=3.0, aw=64.8, al=108.0), lens=dict(w=74, l=118, t=4.5), win=(67, 111),
      bat=dict(w=60, l=100, t=6)),
}

FLANGE = 8.5     # width of the sealing flange at the bottom of the frame
SCREW_IN = 3.2   # back screws: centre distance from the outer edge (outside the O-ring)
RING_IN = 6.3    # O-ring centre line from the outer edge (inside the screws)
CORD = 1.5       # O-ring cord diameter; groove 2.0 wide x 1.1 deep

def edge_points(n_max_gap, half, inset):
    """Evenly spaced positions along an edge of half-length `half`, ends at +-(half-inset-1.3), gap <= n_max_gap."""
    end = half - inset - 1.3
    n = max(1, math.ceil(2 * end / n_max_gap))
    return [-end + 2 * end * i / n for i in range(n + 1)]

def rr(w, l, r):
    return cq.Workplane("XY").sketch().rect(w, l).vertices().fillet(r).finalize()

def slab(w, l, t, r, z=0):
    return rr(w, l, r).extrude(t).translate((0, 0, z))

def box(w, l, h, x=0, y=0, z=0):
    return cq.Workplane("XY").box(w, l, h, centered=(True, True, False)).translate((x, y, z))

def cylz(d, h, x=0, y=0, z=0):
    return cq.Workplane("XY").circle(d / 2).extrude(h).translate((x, y, z))

def cyly(d, h, x=0, y=0, z=0):
    return cq.Workplane("XZ").circle(d / 2).extrude(h).translate((x, y + h / 2, z))

def cylx(d, h, x=0, y=0, z=0):
    return cq.Workplane("YZ").circle(d / 2).extrude(h).translate((x - h / 2, y, z))

def build(name, c):
    W, L, R = c["W"], c["L"], c["R"]
    iw, il = W - 7, L - 7
    bt = c["bat"]["t"]
    ww, wl = c["win"]
    # sizing from the design depth
    lens_t = up(plate_t(wl, ww, P_TEST, ALLOW[LENS_MATERIAL]))
    lens_t_sapphire = up(plate_t(wl, ww, P_TEST, ALLOW["sapphire"]))
    # at least 5 mm: the charging-window seat needs 2 mm for the window flange, 1.1 mm for its O-ring groove and metal under it
    BP = max(5.0, up(plate_t(L - 2 * FLANGE, W - 2 * FLANGE, P_TEST, ALLOW[BACK_MATERIAL])))
    WIN_D = 40.0
    win_t = max(3.0, up(disc_t(WIN_D, P_TEST, ALLOW[WINDOW_MATERIAL])))
    c = dict(c, lens=dict(c["lens"], t=lens_t))
    # the charging coil and its ferrite lie on the window; the battery sits just above them
    floor = max(4.0, (3 - BP) + win_t + 1.1)
    pcbZ = floor + bt + 0.2
    top = pcbZ + 1
    dispZ = top + 3.2
    # The lens rests on a ledge that is a cantilever from the wall: size it for the lens edge load.
    q_edge = P_TEST * ww / 2                                           # N per mm of long edge
    arm = max(iw / 2 - (ww / 2 + c["lens"]["w"] / 2) / 2, il / 2 - (wl / 2 + c["lens"]["l"] / 2) / 2)
    ledge_t = max(1.5, up(math.sqrt(6 * q_edge * arm / ALLOW[BACK_MATERIAL])))
    lensZ = dispZ + c["disp"]["t"] + 0.2 + ledge_t
    ledgeZ = lensZ - ledge_t
    frameTop = lensZ + c["lens"]["t"]
    bosses = [(sx * (W / 2 - 5), sy * (L / 2 - 5)) for sx in (-1, 1) for sy in (-1, 1)]
    lw, ll = c["lens"]["w"] + 0.4, c["lens"]["l"] + 0.4
    parts = {}
    # back screws all round, at most 40 mm apart, outside the O-ring
    xs = edge_points(40, W / 2, SCREW_IN)
    ys = edge_points(40, L / 2, SCREW_IN)
    back_screws = sorted({(round(x, 2), round(s * (L / 2 - SCREW_IN), 2)) for x in xs[1:-1] for s in (-1, 1)} |
                         {(round(s * (W / 2 - SCREW_IN), 2), round(y, 2)) for y in ys[1:-1] for s in (-1, 1)} |
                         {(round(sx * (W / 2 - 4.6), 2), round(sy * (L / 2 - 4.6), 2)) for sx in (-1, 1) for sy in (-1, 1)})
    # depth-sensor ports: two, 10 mm apart, on the left wall
    port_y = (-4, -14)

    # ---- housing frame
    f = slab(W, L, frameTop - 3, R, 3)
    f = f.cut(slab(iw, il, ledgeZ - 3, R - 2.5, 3))
    f = f.cut(slab(ww, wl, frameTop - ledgeZ + 1, 5, ledgeZ))
    f = f.cut(slab(lw, ll, frameTop - lensZ + 1, 5.2, lensZ))
    # sealing flange at the bottom: O-ring land inside, blind tapped holes for the back screws outside it
    f = f.union(slab(W, L, 4, R, 3).cut(slab(W - 2 * FLANGE, L - 2 * FLANGE, 5, max(R - FLANGE, 1.5), 2.5)))
    for (x, y) in bosses:
        f = f.union(cylz(7, ledgeZ - 3, x, y, 3).intersect(slab(W - 0.2, L - 0.2, ledgeZ - 3, R, 3)))
        f = f.cut(cylz(1.6, 4, x, y, frameTop - 4))           # M2 tap, bezel
    for (x, y) in back_screws:
        f = f.cut(cylz(1.6, 3.5, x, y, 3))                    # M2 tap, blind, 3.5 deep: must not break into the housing
    # depth-sensor ports through the left wall (counterbore for membrane)
    for y in port_y:
        f = f.cut(cylx(3.0, 8, -W / 2 + 2, y, top + 2.0))
        f = f.cut(cylx(6.0, 2.0, -W / 2 + 0.5, y, top + 2.0))
    # wet contacts: two sealed stainless pins through the end wall
    for x in (-8, 8):
        f = f.cut(cyly(2.0, 8, x, -L / 2 + 2, top + 2.0))
    # strap lugs / slots
    if c["along"]:
        sw = 34
        for s in (-1, 1):
            for yc in (-0.3 * L, 0.3 * L):
                for dy in (-(sw / 2 - 2), sw / 2 - 2):
                    f = f.union(box(7.5, 4, 6, s * (W / 2 + 3.5), yc + dy, 5))
                f = f.union(box(3, sw, 6, s * (W / 2 + 6), yc, 5))
    else:
        lwid = round(W * 0.62)
        for s in (-1, 1):
            for dx in (-(lwid / 2 - 2), lwid / 2 - 2):
                f = f.union(box(4, 7.5, 6, dx, s * (L / 2 + 3.5), 5))
            f = f.union(box(lwid, 3, 6, 0, s * (L / 2 + 6), 5))
    # button pivot bosses on the side walls
    by = min(0.09 * L, 0.3 * L - 25.5)
    bpos = ([(1, -by), (1, by), (-1, 0)] if c["along"] else [(1, 0.18 * L), (1, -0.13 * L), (-1, 0.03 * L)])
    for s, y in bpos:
        f = f.union(box(1.5, 16, 8, s * (W / 2 + 0.6), y, 7))
    parts["housing_frame"] = (f, (154, 166, 176))

    # ---- bezel
    bz = slab(W, L, 1.5, R, frameTop).cut(slab(ww, wl, 2, 5, frameTop - 0.2))
    for (x, y) in bosses:
        bz = bz.cut(cylz(2.2, 2, x, y, frameTop - 0.2))
    parts["bezel"] = (bz, (95, 107, 118))

    # ---- lens
    parts["lens"] = (slab(c["lens"]["w"], c["lens"]["l"], c["lens"]["t"], 5, lensZ), (156, 199, 232))

    # ---- back plate with O-ring face groove and counterbored screw holes
    z0 = 3 - BP                                   # outside face of the back plate
    bp = slab(W, L, BP, R, z0)
    go, gi = RING_IN - 1.0, RING_IN + 1.0         # groove 2.0 wide for a 1.5 mm cord, 1.1 deep
    groove = slab(W - 2 * go, L - 2 * go, 1.2, max(R - go, 3.0), 3 - 1.1).cut(slab(W - 2 * gi, L - 2 * gi, 1.4, max(R - gi, 1.5), 3 - 1.2))
    bp = bp.cut(groove)
    for (x, y) in back_screws:
        bp = bp.cut(cylz(2.2, BP + 1, x, y, z0 - 0.5)).cut(cylz(4.0, 1.5, x, y, z0 - 0.01))
    # wireless-charging window: a plastic disc seated from outside, so water pressure presses it onto its seal
    fl = 2.0                                      # flange thickness of the window
    bp = bp.cut(cylz(WIN_D + 0.2, BP + 1, 0, 0, z0 - 0.5)).cut(cylz(WIN_D + 8.2, fl + 0.05, 0, 0, z0 - 0.01))
    seat_z = z0 + fl                              # face the window flange seals against
    bp = bp.cut(cylz(WIN_D + 5.6, 1.1, 0, 0, seat_z - 0.01).cut(cylz(WIN_D + 1.6, 1.3, 0, 0, seat_z - 0.1)))   # O-ring groove in the seat
    parts["back_plate"] = (bp, (126, 138, 149))
    qw = cylz(WIN_D + 8.0, fl, 0, 0, z0).union(cylz(WIN_D, win_t - fl, 0, 0, z0 + fl))
    parts["qi_window"] = (qw, (222, 214, 190))

    # ---- buttons (levers with magnet pocket)
    for i, (s, y) in enumerate(bpos):
        lv = box(4, 12, 6, s * (W / 2 + 3.4), y, 8)
        lv = lv.cut(cylx(6.2, 3.2, s * (W / 2 + 1.4 + 1.6), y, 11))
        parts[f"button_lever_{i+1}"] = (lv, (204, 58, 46))
        parts[f"button_magnet_{i+1}"] = (cylx(6, 3, s * (W / 2 + 3.0), y, 11), (192, 198, 204))

    # ---- display
    d = c["disp"]
    parts["display_module"] = (slab(d["w"], d["l"], d["t"], 1.5, dispZ), (26, 29, 36))
    parts["display_active_area"] = (box(d["aw"], d["al"], 0.02, 0, 0, dispZ + d["t"]), (60, 52, 137))

    # ---- PCB with corner notches for the bosses
    pw, pl = W - 9, L - 10
    pcb = slab(pw, pl, 1.0, 4, pcbZ)
    for (x, y) in bosses:
        pcb = pcb.cut(cylz(8, 2, x, y, pcbZ - 0.5))
    parts["main_pcb"] = (pcb, (31, 94, 58))

    # ---- components on the PCB (positions: x, y in CAD, y = -z of the web model)
    if c["mcu"] == "s3":
        parts["esp32_s3_wroom_1"] = (box(18, 25.5, 3.1, -12, 6, top), (196, 204, 211))
    else:
        parts["esp32_p4_module_approx"] = (box(25, 30, 3.0, -12, 8, top), (196, 204, 211))
        parts["esp32_c6_mini_1"] = (box(13.2, 16.6, 2.4, 14, 30, top), (196, 204, 211))
        parts["microsd_socket"] = (box(14, 15, 1.9, 14, -30, top), (180, 180, 180))
    if name == "dc-3in5-forearm":
        parts["microsd_socket"] = (box(14, 15, 1.9, 14, -30, top), (180, 180, 180))
    if name == "dc-5in0-budget":
        parts["microsd_socket"] = (box(14, 15, 1.9, 14, -30, top), (180, 180, 180))
    # Same parts as the firmware drivers and the budget parts list
    parts["safety_mcu_ch32v003_tssop20"] = (box(4.4, 6.5, 1.2, 12, 18, top), (42, 47, 53))
    parts["adc_pcm1808_tssop14"] = (box(4.4, 5.0, 1.2, 14, -10, top), (42, 47, 53))
    parts["fram_mb85rc256_sop8"] = (box(4, 5, 1.5, 12, 8, top), (42, 47, 53))
    parts["rtc_pcf85063a"] = (box(2, 3, 0.8, 18, 8, top), (138, 147, 155))
    parts["imu_qmi8658"] = (box(2.5, 3, 0.86, -12, -16, top), (42, 47, 53))
    parts["mag_mmc5603"] = (box(0.8, 0.8, 0.4, -6, -16, top), (42, 47, 53))
    parts["fuel_gauge_max17048"] = (box(2, 2, 0.8, 6, 8, top), (42, 47, 53))
    parts["i2c_mux_tca9548a"] = (box(4.4, 7.8, 1.2, 4, 18, top), (42, 47, 53))
    parts["light_sensor_veml7700"] = (box(2.35, 4.0, 0.8, 16, -18, top), (42, 47, 53))
    bzx, bzy = ((-14, -40) if c["mcu"] == "p4" else (14, 28))
    parts["piezo_buzzer_9mm"] = (box(9, 9, 1.9, bzx, bzy, top), (30, 30, 30))
    parts["gnss_atgm336h"] = (box(9.7, 10.1, 2.4, *((14, -48) if c["mcu"] == "p4" else (2, -6)), top), (196, 204, 211))
    for i, x in enumerate((-8, 8)):
        parts[f"wet_contact_pin_{i+1}"] = (cyly(2.0, 9, x, -L / 2 + 3.0, top + 2.0), (200, 205, 210))
    dx = -(iw / 2) + 3
    for i, y in enumerate(port_y):
        parts[f"depth_sensor_ms5837_{'ab'[i]}"] = (box(3.3, 3.3, 2.75, dx, y, top), (217, 222, 226))
    coilX = c["bat"]["w"] / 2 + 3.0              # beside the battery, inside the sealing flange
    parts["rx_ferrite_rod"] = (cyly(4, 25, coilX, 0, floor + 3), (58, 54, 51))
    parts["rx_coil_winding"] = (cyly(4.8, 14, coilX, 0, floor + 3).cut(cyly(4, 15, coilX, 0, floor + 3)), (184, 115, 62))
    parts["vibration_motor_1027"] = (cylz(10, 2.7, -14, 28.5 if c["mcu"] == "p4" else 24, top), (168, 175, 181))

    # ---- power
    b = c["bat"]
    parts["lipo_battery"] = (slab(b["w"], b["l"], b["t"], 3, floor), (79, 122, 168))
    wtop = z0 + win_t                              # inner face of the charging window
    parts["qi_coil"] = (cylz(36, 0.5, 0, 0, wtop + 0.05).cut(cylz(14, 1, 0, 0, wtop)), (184, 115, 62))
    parts["qi_ferrite_sheet"] = (cylz(37, 0.35, 0, 0, wtop + 0.6), (44, 44, 42))

    # ---- export
    d_out = os.path.join(OUT, name)
    os.makedirs(os.path.join(d_out, "step"), exist_ok=True)
    os.makedirs(os.path.join(d_out, "stl"), exist_ok=True)
    os.makedirs(os.path.join(d_out, "3mf"), exist_ok=True)
    parts = {k: (wp.translate((0, 0, -z0)), rgb) for k, (wp, rgb) in parts.items()}   # outside of the back plate at Z = 0
    assy = cq.Assembly(name=name)
    for pname, (wp, rgb) in parts.items():
        assy.add(wp, name=pname, color=cq.Color(*(v / 255 for v in rgb)))
        cq.exporters.export(wp, os.path.join(d_out, "step", pname + ".step"))
        cq.exporters.export(wp, os.path.join(d_out, "stl", pname + ".stl"), tolerance=0.02, angularTolerance=0.1)
    for pname in ("housing_frame", "bezel", "back_plate", "lens", "qi_window", "button_lever_1", "button_lever_2", "button_lever_3"):
        cq.exporters.export(parts[pname][0], os.path.join(d_out, "3mf", pname + ".3mf"), tolerance=0.02, angularTolerance=0.1)
    assy.save(os.path.join(d_out, name + "_assembly.step"))
    comp = cq.Compound.makeCompound([wp.val() for wp, _ in parts.values()])
    cq.exporters.export(cq.Workplane().add(comp), os.path.join(d_out, name + "_assembly.3mf"), tolerance=0.05, angularTolerance=0.2)
    bb = comp.BoundingBox()
    vol = lambda n: parts[n][0].val().Volume() / 1000.0     # cm3
    mass = vol("housing_frame") * 2.70 + vol("bezel") * 2.70 + vol("back_plate") * 2.70 + vol("lens") * 2.5 + vol("qi_window") * 1.31
    return dict(parts=len(parts), bbox=[round(bb.xlen, 1), round(bb.ylen, 1), round(bb.zlen, 1)],
                housing=[W, L, round(frameTop + 1.5 - z0, 1)], window=[ww, wl],
                lens_mm=lens_t, lens_ledge_mm=ledge_t, lens_sapphire_mm=lens_t_sapphire, back_plate_mm=BP, charge_window_mm=win_t,
                back_screws=len(back_screws), oring_length_mm=round(2 * (W - 2 * RING_IN) + 2 * (L - 2 * RING_IN) - (8 - 2 * math.pi) * max(R - RING_IN, 3.0)),
                housing_mass_g=round(mass), valid=all(wp.val().isValid() for wp, _ in parts.values()))

info = {n: build(n, c) for n, c in CFG.items()}
info["_sizing"] = dict(design_depth_m=DESIGN_DEPTH_M, test_pressure_MPa=round(P_TEST, 3), lens=LENS_MATERIAL, back=BACK_MATERIAL,
                       charge_window=WINDOW_MATERIAL, allowable_MPa=ALLOW)
json.dump(info, open(os.path.join(OUT, "sizing.json"), "w"), indent=1)
print(json.dumps(info, indent=1))
