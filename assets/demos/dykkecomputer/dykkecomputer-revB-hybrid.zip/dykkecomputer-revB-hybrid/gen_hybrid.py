"""Dive computer 3.5 in, rev B: hybrid housing (aluminium top ring + back plate, POM-C mid ring),
thinner inside (package A) and everything fastened. python gen_hybrid.py out"""
import cadquery as cq, os, sys, json, math
HERE = os.path.dirname(os.path.abspath(__file__))
src = open(os.path.join(HERE, "..", "cad", "gen.py")).read().split("def build")[0].replace("OUT = sys.argv[1]", "OUT = None")
exec(src)
OUT = sys.argv[1] if len(sys.argv) > 1 else "out"

c = CFG["dc-3in5-forearm"]
W, L, R = c["W"], c["L"], c["R"]
iw, il = W - 7, L - 7                     # 3.5 mm walls
ww, wl = c["win"]
ALLOW["POM-C"] = 20.0
lens_t = up(plate_t(wl, ww, P_TEST, ALLOW[LENS_MATERIAL]))
BP = 5.0
WIN_D = 40.0
win_t = max(3.0, up(disc_t(WIN_D, P_TEST, ALLOW[WINDOW_MATERIAL])))
z0 = 3 - BP                               # outside face of the back plate
floor = max(4.0, z0 + win_t + 1.1)        # charging coil and ferrite under the battery
BAT = dict(w=48, l=60, t=6, y=-13)        # package A: shorter battery, tall parts beside it
PCB_T = 0.8
pcbZ = floor + BAT["t"] + 0.2
pcbTop = pcbZ + PCB_T
TOPSIDE = 1.0                              # only parts under 1.0 mm on the top side
dispZ = pcbTop + TOPSIDE + 0.2
d = c["disp"]
q_edge = P_TEST * ww / 2
arm = max(iw / 2 - (ww / 2 + c["lens"]["w"] / 2) / 2, il / 2 - (wl / 2 + c["lens"]["l"] / 2) / 2)
ledge_t = max(1.5, up(math.sqrt(6 * q_edge * arm / ALLOW[BACK_MATERIAL])))
lensZ = dispZ + d["t"] + 0.2 + ledge_t
ledgeZ = lensZ - ledge_t
frameTop = lensZ + lens_t
splitZ = ledgeZ - 1.0                      # aluminium top ring above, POM-C mid ring below
wall_min_pom = (splitZ - 7.0) * math.sqrt(0.75 * P_TEST / ALLOW["POM-C"])
lw, ll = c["lens"]["w"] + 0.4, c["lens"]["l"] + 0.4
corner = [(sx * (W / 2 - 5), sy * (L / 2 - 5)) for sx in (-1, 1) for sy in (-1, 1)]       # top ring bolts
PCBX = 32.8
pcb_mounts = [(sx * PCBX, sy * 40.0) for sx in (-1, 1) for sy in (-1, 1)]                  # outside the display
xs = edge_points(40, W / 2, SCREW_IN); ys = edge_points(40, L / 2, SCREW_IN)
back_screws = sorted({(round(x, 2), round(s * (L / 2 - SCREW_IN), 2)) for x in xs[1:-1] for s in (-1, 1)} |
                     {(round(s * (W / 2 - SCREW_IN), 2), round(y, 2)) for y in ys[1:-1] for s in (-1, 1)} |
                     {(round(sx * (W / 2 - 4.6), 2), round(sy * (L / 2 - 4.6), 2)) for sx in (-1, 1) for sy in (-1, 1)})
port_y = (-2, -10)
SX = -(W / 2) + FLANGE / 2 + 2.0          # sensor centre on the exposed top of the flange (x = -33)
FLT = 7.0                                  # top face of the sealing flange
parts = {}

def ring_groove(z_face, inset, depth=1.1, width=2.0, down=True):
    """O-ring face groove following the outline, centre `inset` from the outer edge."""
    go, gi = inset - width / 2, inset + width / 2
    zz = z_face - depth if down else z_face
    return slab(W - 2 * go, L - 2 * go, depth + 0.01, max(R - go, 2.0), zz).cut(
        slab(W - 2 * gi, L - 2 * gi, depth + 0.2, max(R - gi, 1.0), zz - 0.1))

# ---------------- mid ring, POM-C: flange, walls, bosses, ports, strap lugs, button pivots
m = slab(W, L, splitZ - 3, R, 3).cut(slab(iw, il, splitZ - 3 + 1, R - 2.5, 2.5))
m = m.union(slab(W, L, 4, R, 3).cut(slab(W - 2 * FLANGE, L - 2 * FLANGE, 5, max(R - FLANGE, 1.5), 2.5)))
for (x, y) in corner:                       # bolt bosses for the top ring, brass M2.5 inserts from the top
    m = m.union(cylz(7, splitZ - 3, x, y, 3).intersect(slab(W - 0.2, L - 0.2, splitZ - 3, R, 3)))
    m = m.cut(cylz(3.5, 5.5, x, y, splitZ - 5.5))
for (x, y) in pcb_mounts:                   # PCB standoffs from the flange, M2 inserts from the top
    m = m.union(cylz(6, pcbZ - 3, x, y, 3)).union(box(2.8, 6, pcbZ - 3, math.copysign(iw / 2 - 1.2, x), y, 3))
    m = m.cut(cylz(3.2, 4.0, x, y, pcbZ - 4.0))
for (x, y) in back_screws:                  # M2 inserts for the back plate
    m = m.cut(cylz(3.2, 3.6, x, y, 3))
for y in port_y:                            # depth sensor sits upside down in a bore in the flange top,
    m = m.cut(cylz(4.6, FLT - 3.7 + 0.01, SX, y, 3.7))              # O-ring counterbore at the top, L-shaped port to the outside
    m = m.cut(cylz(6.2, 1.0, SX, y, FLT - 1.0))
    m = m.cut(cylx(2.0, W / 2 + SX + 2.3, (-W / 2 + SX) / 2 - 1.0, y, 4.6))
for yy in (min(port_y) - 5.0, max(port_y) + 5.0):   # M1.6 inserts for the shared sensor board
    m = m.cut(cylz(2.2, 3.0, SX, yy, FLT - 3.0))
for x in (-8.5, 8.5):                       # wet contacts through the +y end wall (POM insulates them)
    m = m.cut(cyly(2.0, 8, x, L / 2 - 2, pcbZ - 2.0))
sw = 34
for s in (-1, 1):
    for yc in (-0.3 * L, 0.3 * L):
        for dy in (-(sw / 2 - 2), sw / 2 - 2):
            m = m.union(box(7.5, 4, 6, s * (W / 2 + 3.5), yc + dy, 5))
        m = m.union(box(3, sw, 6, s * (W / 2 + 6), yc, 5))
by = min(0.09 * L, 0.3 * L - 25.5)
bpos = [(1, -by), (1, by), (-1, 0)]
btn_z = pcbTop + 0.5                        # magnets level with the hall sensors on the PCB edge
for s, y in bpos:
    m = m.union(box(1.5, 16, 6, s * (W / 2 + 0.6), y, btn_z - 4))
parts["mid_ring_pom"] = (m, (232, 228, 214))

# ---------------- top ring, aluminium: lens ledge and seat, O-ring groove underneath
t = slab(W, L, frameTop - splitZ, R, splitZ)
t = t.cut(slab(iw, il, ledgeZ - splitZ + 0.01, R - 2.5, splitZ - 0.005))
t = t.cut(slab(ww, wl, frameTop - ledgeZ + 1, 5, ledgeZ))
t = t.cut(slab(lw, ll, frameTop - lensZ + 1, 5.2, lensZ))
t = t.cut(ring_groove(splitZ + 1.1, 1.6, down=True))     # groove opens downwards onto the POM face
for (x, y) in corner:
    t = t.cut(cylz(2.8, frameTop - splitZ + 1, x, y, splitZ - 0.5))
parts["top_ring_al"] = (t, (154, 166, 176))

# ---------------- bezel, lens, back plate, charging window
bz = slab(W, L, 1.5, R, frameTop).cut(slab(ww, wl, 2, 5, frameTop - 0.2))
for (x, y) in corner:
    bz = bz.cut(cylz(2.8, 2, x, y, frameTop - 0.2)).cut(cylz(5.0, 0.8, x, y, frameTop + 0.75))
parts["bezel"] = (bz, (95, 107, 118))
parts["lens"] = (slab(c["lens"]["w"], c["lens"]["l"], lens_t, 5, lensZ), (156, 199, 232))
bp = slab(W, L, BP, R, z0)
go, gi = RING_IN - 1.0, RING_IN + 1.0
bp = bp.cut(slab(W - 2 * go, L - 2 * go, 1.2, max(R - go, 3.0), 3 - 1.1).cut(slab(W - 2 * gi, L - 2 * gi, 1.4, max(R - gi, 1.5), 3 - 1.2)))
for (x, y) in back_screws:
    bp = bp.cut(cylz(2.2, BP + 1, x, y, z0 - 0.5)).cut(cylz(4.0, 1.5, x, y, z0 - 0.01))
fl = 2.0
bp = bp.cut(cylz(WIN_D + 0.2, BP + 1, 0, 0, z0 - 0.5)).cut(cylz(WIN_D + 8.2, fl + 0.05, 0, 0, z0 - 0.01))
seat_z = z0 + fl
bp = bp.cut(cylz(WIN_D + 5.6, 1.1, 0, 0, seat_z - 0.01).cut(cylz(WIN_D + 1.6, 1.3, 0, 0, seat_z - 0.1)))
parts["back_plate"] = (bp, (126, 138, 149))
parts["qi_window"] = (cylz(WIN_D + 8.0, fl, 0, 0, z0).union(cylz(WIN_D, win_t - fl, 0, 0, z0 + fl)), (222, 214, 190))

# ---------------- O-rings (modelled as rectangular-section stand-ins at the compressed height)
def oring_rect(z, inset, h, cord=1.5):
    o, i = inset - cord / 2, inset + cord / 2
    return slab(W - 2 * o, L - 2 * o, h, max(R - o, 2.0), z).cut(slab(W - 2 * i, L - 2 * i, h + 0.2, max(R - i, 1.0), z - 0.1))
parts["oring_back_plate"] = (oring_rect(3 - 1.1, RING_IN, 1.1), (20, 20, 20))
parts["oring_top_ring"] = (oring_rect(splitZ, 1.6, 1.1), (20, 20, 20))
parts["oring_qi_window"] = (cylz(WIN_D + 4.6, 1.05, 0, 0, seat_z + 0.01).cut(cylz(WIN_D + 2.6, 1.3, 0, 0, seat_z - 0.1)), (20, 20, 20))

# ---------------- buttons
for i, (s, y) in enumerate(bpos):
    lv = box(4, 12, 6, s * (W / 2 + 3.4), y, btn_z - 3)
    lv = lv.cut(cylx(6.2, 3.2, s * (W / 2 + 3.0), y, btn_z))
    parts[f"button_lever_{i+1}"] = (lv, (204, 58, 46))
    parts[f"button_magnet_{i+1}"] = (cylx(6, 3, s * (W / 2 + 3.0), y, btn_z), (192, 198, 204))

# ---------------- display and foam
parts["display_module"] = (slab(d["w"], d["l"], d["t"], 1.5, dispZ), (26, 29, 36))
parts["display_active_area"] = (box(d["aw"], d["al"], 0.02, 0, 0, dispZ + d["t"]), (60, 52, 137))
for i, (x, y) in enumerate([(-26, -42), (26, -42), (-26, 42), (26, 42)]):
    parts[f"foam_display_{i+1}"] = (box(6, 6, TOPSIDE + 0.2, x, y, pcbTop), (240, 240, 240))

# ---------------- PCB 70 x 96 x 0.8, M2 holes at the four mounts, notches at the corner bosses
pw, pl = 70, 96
pcb = slab(pw, pl, PCB_T, 4, pcbZ)
for (x, y) in pcb_mounts:
    pcb = pcb.cut(cylz(2.4, 2, x, y, pcbZ - 0.5))
for (x, y) in corner:
    pcb = pcb.cut(cylz(8, 2, x, y, pcbZ - 0.5))
for y in port_y:
    pass
parts["main_pcb"] = (pcb, (31, 94, 58))
for i, (x, y) in enumerate(pcb_mounts):
    parts[f"screw_pcb_m2x4_{i+1}"] = (cylz(3.8, 1.3, x, y, pcbTop).union(cylz(2.0, 4.0, x, y, pcbTop - 4.0)), (190, 190, 195))

# ---------------- components: top side (all under 1 mm) ...
top = pcbTop
parts["imu_qmi8658"] = (box(2.5, 3, 0.86, -12, -16, top), (42, 47, 53))
parts["mag_mmc5603"] = (box(0.8, 0.8, 0.4, -6, -16, top), (42, 47, 53))
parts["fuel_gauge_max17048"] = (box(2, 2, 0.8, 6, 8, top), (42, 47, 53))
parts["rtc_pcf85063a"] = (box(2, 3, 0.8, 18, 8, top), (138, 147, 155))
parts["light_sensor_veml7700"] = (box(2.35, 4.0, 0.8, 0, -44, top), (42, 47, 53))   # under the lens margin
for i, (s, y) in enumerate(bpos):          # TMAG5273 hall sensors at the PCB edge, opposite each lever
    parts[f"hall_tmag5273_{i+1}"] = (box(1.6, 2.9, 0.9, s * 33.2, y, top), (42, 47, 53))
# ... bottom side (hang below the PCB, beside the shorter battery)
bot = lambda h: pcbZ - h
parts["esp32_s3_wroom_1"] = (box(18, 25.5, 3.1, -19, 31.2, bot(3.1)), (196, 204, 211))
parts["microsd_socket"] = (box(14, 15, 1.9, 0, 37, bot(1.9)), (180, 180, 180))
parts["gnss_atgm336h"] = (box(9.7, 10.1, 2.4, 16, 27, bot(2.4)), (196, 204, 211))
parts["gnss_patch_antenna_12mm"] = (box(12, 12, 4.0, 16, 38.4, bot(4.0)), (210, 190, 120))
parts["piezo_buzzer_9mm"] = (box(9, 9, 1.9, 28, 29.5, bot(1.9)), (30, 30, 30))
parts["vibration_motor_1027"] = (cylz(10, 2.7, 0, 23.6, bot(2.7)), (168, 175, 181))
parts["safety_mcu_ch32v003_tssop20"] = (box(4.4, 6.5, 1.2, 28, 21.6, bot(1.2)), (42, 47, 53))
parts["adc_pcm1808_tssop14"] = (box(4.4, 5.0, 1.2, 8, 22.0, bot(1.2)), (42, 47, 53))
parts["fram_mb85rc256_sop8"] = (box(4, 5, 1.5, 24.5, 41.5, bot(1.5)), (42, 47, 53))
parts["i2c_mux_tca9548a"] = (box(4.4, 7.8, 1.2, -29, 10, bot(1.2)), (42, 47, 53))
for i, x in enumerate((-8.5, 8.5)):
    parts[f"wet_contact_pin_{i+1}"] = (cyly(2.0, 9, x, L / 2 - 3.0, pcbZ - 2.0), (200, 205, 210))
    parts[f"pogo_wet_{i+1}"] = (box(2.5, 3, 2.0, x, L / 2 - 3.5 - 4.5 - 1.5, bot(2.0)), (212, 175, 55))

# ---------------- depth sensors: one small board lying on the flange top, both sensors hanging into sealed bores
yb0, yb1 = min(port_y) - 7.5, max(port_y) + 7.5
board = box(4.6, yb1 - yb0, 1.0, SX, (yb0 + yb1) / 2, FLT)
for yy in (min(port_y) - 5.0, max(port_y) + 5.0):
    board = board.cut(cylz(1.8, 2, SX, yy, FLT - 0.5))
    parts[f"screw_sensor_m16_{'ab'[int(yy > 0)]}"] = (cylz(3.0, 0.9, SX, yy, FLT + 1.0).union(cylz(1.6, 3.0, SX, yy, FLT + 1.0 - 3.0)), (190, 190, 195))
parts["sensor_board"] = (board, (31, 94, 58))
for i, y in enumerate(port_y):
    k = "ab"[i]
    parts[f"depth_sensor_ms5837_{k}"] = (box(3.3, 3.3, 2.75, SX, y, FLT - 2.75), (217, 222, 226))
    parts[f"oring_sensor_{k}"] = (cylz(6.0, 0.95, SX, y, FLT - 0.98).cut(cylz(4.8, 1.2, SX, y, FLT - 1.1)), (20, 20, 20))

# ---------------- power and receiver: battery in a printed tray, ferrite rod beside it
b = BAT
parts["lipo_battery"] = (slab(b["w"], b["l"], b["t"], 3, floor).translate((0, b["y"], 0)), (79, 122, 168))
tray = slab(b["w"] + 2.4, b["l"] + 2.4, b["t"], 4, floor).cut(slab(b["w"] + 0.2, b["l"] + 0.2, b["t"] + 1, 3, floor - 0.5)).translate((0, b["y"], 0))
coilX = 27.8
tray = tray.union(box(5.0, 27, 3.0, coilX, -17, floor)).cut(cyly(5.0, 26, coilX, -17, floor + 3))
parts["battery_tray_pa12"] = (tray, (110, 110, 110))
parts["rx_ferrite_rod"] = (cyly(4, 25, coilX, -17, floor + 3), (58, 54, 51))
parts["rx_coil_winding"] = (cyly(4.8, 14, coilX, -17, floor + 3).cut(cyly(4, 15, coilX, -17, floor + 3)), (184, 115, 62))
wtop = z0 + win_t
parts["qi_coil"] = (cylz(36, 0.5, 0, 0, wtop + 0.05).cut(cylz(14, 1, 0, 0, wtop)), (184, 115, 62))
parts["qi_ferrite_sheet"] = (cylz(37, 0.35, 0, 0, wtop + 0.6), (44, 44, 42))

# ---------------- fasteners
for i, (x, y) in enumerate(corner):
    parts[f"screw_top_m25x16_{i+1}"] = (cylz(4.5, 0.75, x, y, frameTop + 0.75).union(cylz(2.5, 16, x, y, frameTop + 0.75 - 16)), (190, 190, 195))
for i, (x, y) in enumerate(back_screws):
    parts[f"screw_back_m2x6_{i+1}"] = (cylz(3.8, 1.4, x, y, z0 - 0.0).union(cylz(2.0, 6.0, x, y, z0 + 1.4 - 0.01)), (190, 190, 195))

os.makedirs(os.path.join(OUT, "step"), exist_ok=True)
info = dict(height_mm=round(frameTop + 1.5 - z0, 2), floor=floor, pcbZ=pcbZ, dispZ=dispZ, ledgeZ=ledgeZ, lensZ=lensZ, splitZ=splitZ,
            frameTop=frameTop, lens_mm=lens_t, ledge_mm=ledge_t, pom_wall_min_mm=round(wall_min_pom, 2), wall_mm=3.5,
            back_screws=len(back_screws), parts=len(parts), bat=BAT, pcb_t=PCB_T)
bad = []
for k, (wp, rgb) in parts.items():
    wp2 = wp.translate((0, 0, -z0))
    if not wp2.val().isValid():
        bad.append(k)
    cq.exporters.export(wp2, os.path.join(OUT, "step", k + ".step"))
info["invalid"] = bad
json.dump(info, open(os.path.join(OUT, "sizing_hybrid.json"), "w"), indent=1)
print(json.dumps(info, indent=1))
