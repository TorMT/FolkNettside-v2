# Dykkecomputer 3.5 in, rev B hybrid (STEP)

Hybridhus: toppring og bakplate i aluminium 6061, midtring i POM-C. Innmaten etter pakke A (28,5 mm høyt hus):
kretskort 0,8 mm skrudd i fire standoffs, høye komponenter på undersiden ved et 48 × 60 mm batteri i en printet holder,
begge dybdesensorene på ett lite kort på flensen med O-ring rundt hver sensor, O-ringer i begge skjøter, alle skruer modellert.
Kollisjonssjekk: 0 overlapp (75 deler). Mål i mm, bakplatens utside ved Z = 0.

Ekte komponentmodeller: ESP32-S3-WROOM-1 (Espressif KiCad Libraries) og IC-pakker, microSD og summer fra KiCads 3D-bibliotek,
begge CC-BY-SA 4.0. `gen_hybrid.py` lager geometrien; `bygg_hybrid.py` legger alt inn i Fusion.
Ikke validert for dykking: FEA og trykktest gjenstår.
