# Testrigg for koblingsbrett-prototypen

Lett 3D-print som holder koblingsbrett-demoen ryddig før huset finnes. Alle deler printes uten støtte i PLA eller PETG.

| Fil | Hva | Mål (mm) |
|---|---|---|
| rigg_plate_A | To 830-punkts koblingsbrett (ESP32-S3-DevKitC + moduler), kabelkanal med strips-hull, USB-utgang | 210 x 190 x 9 |
| rigg_plate_B | 10 mm rutenett med M3-hull for moduler, LiPo-lomme med borrelåshull, Qi-lomme med 1 mm bunn, to sprøyteklemmer, to klemmer for ferrittstaven | 210 x 190 x 17 |
| rigg_skjermstativ | 3,5" skjermmodul på skrå (60 grader), hull 92 x 49,5; print liggende på siden | 104 x 53 x 57 |
| rigg_lask (x 2) | Skrur platene sammen (2 x 2 M3) | 40 x 30 x 4 |
| rigg_knappetest + slede | TMAG5273-modul bak en 3 mm vegg, magnetslede i skinner: tester hall-knappene som i huset | 54 x 30 x 17 |
| rigg_vaatkopp | Kopp med 2 x M3 A4-skruer gjennom veggen: tester våtkontakt-målingen med vann | Ø40 x 28 |

Hullene er 2,6 mm: M3 selvgjengende skruer eller M3 nylon-avstandsstykker rett i plasten. Begge platene passer på en 220 x 220-plate.
Hold ferrittstaven minst 10 cm fra ESP32 og skjermen; 38 kHz-signalet er svakt. Fire 10 mm gummiføtter under hver plate.
`rig.py` (CadQuery) lager alt på nytt.
