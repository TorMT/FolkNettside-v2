"""Printable test rig for the dive computer breadboard demo: two base plates (each fits a 220 x 220 bed),
a tilted display stand and two link bars. python rig.py out   ->  out/*.stl, out/*.step, out/rig_info.json
All mounting holes are 2.6 mm: M3 self-tapping screws or M3 nylon standoffs straight into PLA/PETG."""
import cadquery as cq, os, sys, json, math
OUT = sys.argv[1] if len(sys.argv) > 1 else "out"
os.makedirs(OUT, exist_ok=True)
T = 3.0          # plate thickness
PW, PL = 210.0, 190.0
HOLE = 2.6
FONT = 5.0

def box(w, l, h, x, y, z):
    return cq.Workplane("XY").box(w, l, h, centered=(True, True, False)).translate((x, y, z))
def cyl(d, h, x, y, z):
    return cq.Workplane("XY").circle(d / 2).extrude(h).translate((x, y, z))
def label(p, txt, x, y, size=FONT, depth=0.6, z=T, angle=0):
    try:
        t = cq.Workplane("XY").text(txt, size, depth, combine=False, halign="center", valign="center")
        if angle:
            t = t.rotate((0, 0, 0), (0, 0, 1), angle)
        return p.cut(t.translate((x, y, z - depth)))
    except Exception as e:
        print("label skipped:", txt, e); return p
def base(w, l):
    p = cq.Workplane("XY").box(w, l, T, centered=False).edges("|Z").fillet(6)
    rim = cq.Workplane("XY").box(w, l, 6, centered=False).edges("|Z").fillet(6).cut(
        cq.Workplane("XY").box(w - 6, l - 6, 8, centered=False).edges("|Z").fillet(3).translate((3, 3, -1))).translate((0, 0, T))
    p = p.union(rim)
    for (x, y) in ((10, 10), (w - 10, 10), (10, l - 10), (w - 10, l - 10)):   # recesses for 10 mm rubber feet
        p = p.cut(cyl(10.4, 1.2, x, y, -0.01))
    return p
def holes(p, pts):
    for (x, y) in pts:
        p = p.cut(cyl(HOLE, T + 2, x, y, -1))
    return p
def rib(p, x0, y0, x1, y1, h=3.0, t=1.6):
    L = math.hypot(x1 - x0, y1 - y0); a = math.degrees(math.atan2(y1 - y0, x1 - x0))
    r = cq.Workplane("XY").box(L, t, h, centered=(True, True, False)).rotate((0, 0, 0), (0, 0, 1), a).translate(((x0 + x1) / 2, (y0 + y1) / 2, T))
    return p.union(r)
def link_holes(p, side):
    """Two hole pairs on the edge where the plates meet; the link bars bolt across."""
    x = PW - 12 if side == "right" else 12
    xe = PW - 1.5 if side == "right" else 1.5
    for yc in (47.5, 122.5):                 # notch the rim so the bar lies flat on both floors
        p = p.cut(box(3.2, 32, 8, xe, yc, T))
    return holes(p, [(x, 40), (x, 55), (x, 115), (x, 130)])

info = {}
# ---------------- plate A: breadboards, ESP32, display, buttons
A = base(PW, PL)
bbx, bby, bbw, bbl = 8, 8, 166.5, 111.0          # two 830-point breadboards side by side (165 x 55 each)
A = A.cut(box(bbw, bbl, 1.6, bbx + bbw / 2, bby + bbl / 2, T - 1.6))
A = label(A, "KOBLINGSBRETT 1", bbx + bbw / 2, bby + 27.5, 6, 0.4, T - 1.6)
A = label(A, "KOBLINGSBRETT 2", bbx + bbw / 2, bby + 83, 6, 0.4, T - 1.6)
# display stand footprint (separate part) behind the breadboards, 2 screws
dsx, dsy = 90, 152
A = holes(A, [(dsx - 40, dsy - 12), (dsx + 40, dsy - 12)])
A = label(A, "SKJERM 3,5\" (stativ)", dsx, dsy + 22, 4.5)
# cable strip on the right: zip-tie slots and USB exit
for y in (30, 70, 110, 150):
    A = A.cut(box(3, 6, T + 2, PW - 22, y, -1)).cut(box(3, 6, T + 2, PW - 14, y, -1))
A = A.cut(box(16, 8, 8, PW - 18, PL - 1, T))            # notch in the rim for the USB cable
A = label(A, "USB", PW - 18, PL - 12, 4.5)
A = label(A, "KABLER", PW - 18, 90, 4.5, angle=90)
A = link_holes(A, "right")
A = rib(A, 8, 124, 174, 124)
A = label(A, "DYKKECOMPUTER  TESTRIGG  A", 75, PL - 9, 5)
info["plate_A"] = dict(size_mm=[PW, PL, T + 6], breadboard_pocket=[bbw, bbl])

# ---------------- plate B: sensors, receiver, power
B = base(PW, PL)
gx0, gy0, nx, ny = 15, 15, 12, 8                     # universal 10 mm grid for modules
grid = [(gx0 + 10 * i, gy0 + 10 * j) for i in range(nx) for j in range(ny)]
B = holes(B, grid)
B = label(B, "MODULER  (10 mm rutenett, M3)", gx0 + 55, gy0 + 10 * ny + 2, 4.5)
B = rib(B, 8, 102, 132, 102)
# battery bay with velcro strap slots
bx, by = 172, 38
B = B.cut(box(64, 54, 1.2, bx, by, T - 1.2))
for x in (bx - 16, bx + 16):
    B = B.cut(box(22, 3, T + 2, x, by - 30, -1)).cut(box(22, 3, T + 2, x, by + 30, -1))
B = label(B, "LIPO", bx, by, 6, 0.4, T - 1.2)
# Qi receiver coil pocket with thin floor, so the transmitter can sit under the plate
qx, qy = 172, 108
B = B.cut(cyl(56, T - 1.0, qx, qy, 1.0))
B = label(B, "QI RX", qx, qy, 5, 0.3, 1.0)
# two syringe clips for the depth-sensor test (20 ml syringe, about 21 mm barrel)
for x in (112, 140):
    c = cyl(27, 14, x, 150, T).cut(cyl(21.2, 16, x, 150, T - 1)).cut(box(12, 14, 16, x, 150 + 12, T - 1))
    B = B.union(c)
B = label(B, "SPRØYTE (trykktest)", 126, 128, 4)
# ferrite rod clips for the 38 kHz receiver, far from the ESP32 side
for x in (20, 80):
    cl = box(8, 14, 12, x, 150, T).cut(cyl(10.3, 16, x, 150, T + 7).rotate((x, 150, T + 7), (x + 1, 150, T + 7), 90) if False else
                                    cq.Workplane("YZ").circle(5.15).extrude(10).translate((x - 5, 150, T + 9)))
    cl = cl.cut(box(9, 9.2, 6, x, 150, T + 9.5))
    B = B.union(cl)
B = label(B, "FERRITTSTAV 38 kHz  (hold 10 cm fra ESP32)", 50, 168, 3.6)
B = link_holes(B, "left")
B = label(B, "DYKKECOMPUTER  TESTRIGG  B", 105, PL - 9, 5)
info["plate_B"] = dict(size_mm=[PW, PL, T + 14], module_grid=[nx, ny, 10], battery_bay=[64, 54], qi_pocket_d=56)

# ---------------- display stand (print on its side): foot with two screws, panel tilted 60 deg, ST7796 module holes 49.5 x 92
ang = 60
pw_, ph_ = 104, 62
panel = cq.Workplane("XY").box(pw_, 3, ph_, centered=(True, True, False))
for sx in (-1, 1):
    for sz in (-1, 1):
        panel = panel.cut(cq.Workplane("XZ").circle(1.3).extrude(10, both=True).translate((sx * 46, 0, ph_ / 2 + sz * 24.75)))
panel = panel.cut(cq.Workplane("XZ").rect(70, 30).extrude(10, both=True).translate((0, 0, ph_ / 2)))     # window for the FPC and wiring
panel = panel.rotate((0, 0, 0), (1, 0, 0), -(90 - ang)).translate((0, 0, 3))
foot = cq.Workplane("XY").box(pw_, 26, 3, centered=(True, True, False)).translate((0, -8, 0))
foot = foot.cut(cyl(3.2, 5, -40, -12, -1)).cut(cyl(3.2, 5, 40, -12, -1))
stand = foot.union(panel)
dy, dz = ph_ * math.cos(math.radians(ang)), ph_ * math.sin(math.radians(ang))
for x in (-pw_ / 2, pw_ / 2 - 3):          # gussets behind the panel
    gus = cq.Workplane("YZ").polyline([(0.5, 3), (dy * 0.8 + 1.5, 3), (dy * 0.8 + 1.5, 3 + dz * 0.8)]).close().extrude(3).translate((x, 0, 0))
    stand = stand.union(gus)
info["display_stand"] = dict(tilt_deg=ang, module_holes_mm=[92, 49.5], hole_d=2.6)

# ---------------- button tester: TMAG5273 breakout on a post, magnet on a slider with the housing's 0.8 mm travel
bt = cq.Workplane("XY").box(46, 30, 3, centered=(True, True, False)).edges("|Z").fillet(3)
bt = bt.union(box(22, 3, 14, 20, 10.5, 3))                           # wall at the end of the slide: screw the TMAG5273 breakout to its far side
bt = bt.cut(cq.Workplane("XZ").circle(1.3).extrude(10, both=True).translate((12, 10.5, 12))).cut(
     cq.Workplane("XZ").circle(1.3).extrude(10, both=True).translate((28, 10.5, 12)))
bt = bt.union(box(3, 18, 8, 16, -2, 3)).union(box(3, 18, 8, 24, -2, 3))   # rails for the slider
bt = bt.union(box(11, 2, 8, 20, -12, 3))                             # end stop
bt = bt.cut(cyl(3.3, 5, -20, -10, -1)).cut(cyl(3.3, 5, 0, 10, -1))   # two M3 on the 10 mm grid
bt = label(bt, "KNAPP-TEST", -6, 0, 4, 0.4, 3)
slider = cq.Workplane("XY").box(4.8, 14, 7, centered=(True, True, False))
slider = slider.cut(cq.Workplane("XZ").circle(2.05).extrude(2.2).translate((0, 7.01, 3.5)))   # pocket for the 4 x 2 mm magnet
slider = slider.union(box(8, 3, 2, 0, -7.5, 5))                      # finger tab
info["button_tester"] = dict(note="the magnet slider runs between the rails towards the wall; the TMAG5273 breakout sits on the other side of the 3 mm wall, like the 3.5 mm POM wall in the housing")

# ---------------- wet-contact cup: two M3 A4 screws through the wall, fill with tap or salt water
cup = cyl(40, 28, 0, 0, 0).cut(cyl(34, 28, 0, 0, 2))
for x in (-6, 6):
    cup = cup.cut(cq.Workplane("XZ").circle(1.6).extrude(25).translate((x, 0, 10)))   # M3 through the wall on one side
cup = cup.union(box(52, 12, 3, 0, 0, 0).cut(cyl(3.3, 5, -20, 0, -1)).cut(cyl(3.3, 5, 20, 0, -1)))
cup = label(cup, "VAAT", 0, -14, 4, 0.4, 3) if False else cup
info["wet_cup"] = dict(inner_d=34, depth=26, contacts="2 x M3 A4, 12 mm apart, 8 mm over the bottom")

# ---------------- link bars (x2)
link = cq.Workplane("XY").box(40, 30, 4, centered=(True, True, False)).edges("|Z").fillet(3)
for x in (-12, 12):
    for y in (-7.5, 7.5):
        link = link.cut(cyl(3.3, 6, x, y, -1)).cut(cyl(6.2, 2, x, y, 2.5))

parts = {"rigg_plate_A": A, "rigg_plate_B": B, "rigg_skjermstativ": stand, "rigg_lask": link,
         "rigg_knappetest": bt, "rigg_knappetest_slede": slider, "rigg_vaatkopp": cup}
for n, p in parts.items():
    assert all(v.isValid() for v in p.vals()), n
    cq.exporters.export(p, os.path.join(OUT, n + ".stl"), tolerance=0.05, angularTolerance=0.2)
    cq.exporters.export(p, os.path.join(OUT, n + ".step"))
    bb = p.val().BoundingBox(); info.setdefault("bbox", {})[n] = [round(bb.xlen, 1), round(bb.ylen, 1), round(bb.zlen, 1)]
    info.setdefault("volume_cm3", {})[n] = round(p.val().Volume() / 1000, 1)
json.dump(info, open(os.path.join(OUT, "rig_info.json"), "w"), indent=1)
print(json.dumps(info, indent=1))
