<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE eagle SYSTEM "eagle.dtd">
<eagle version="9.6.2">
<drawing>
<settings><setting alwaysvectorfont="no"/><setting verticaltext="up"/></settings>
<grid distance="0.1" unitdist="inch" unit="inch" style="lines" multiple="1" display="no" altdistance="0.01" altunitdist="inch" altunit="inch"/>
<layers>
<layer number="1" name="Top" color="4" fill="1" visible="yes" active="yes"/>
<layer number="2" name="Route2" color="1" fill="3" visible="yes" active="yes"/>
<layer number="15" name="Route15" color="23" fill="5" visible="yes" active="yes"/>
<layer number="16" name="Bottom" color="1" fill="1" visible="yes" active="yes"/>
<layer number="17" name="Pads" color="2" fill="1" visible="yes" active="yes"/>
<layer number="18" name="Vias" color="2" fill="1" visible="yes" active="yes"/>
<layer number="19" name="Unrouted" color="6" fill="1" visible="yes" active="yes"/>
<layer number="20" name="Dimension" color="15" fill="1" visible="yes" active="yes"/>
<layer number="21" name="tPlace" color="7" fill="1" visible="yes" active="yes"/>
<layer number="22" name="bPlace" color="7" fill="1" visible="yes" active="yes"/>
<layer number="25" name="tNames" color="7" fill="1" visible="yes" active="yes"/>
<layer number="26" name="bNames" color="7" fill="1" visible="yes" active="yes"/>
<layer number="27" name="tValues" color="7" fill="1" visible="yes" active="yes"/>
<layer number="28" name="bValues" color="7" fill="1" visible="yes" active="yes"/>
<layer number="29" name="tStop" color="7" fill="3" visible="no" active="yes"/>
<layer number="30" name="bStop" color="7" fill="6" visible="no" active="yes"/>
<layer number="31" name="tCream" color="7" fill="4" visible="no" active="yes"/>
<layer number="32" name="bCream" color="7" fill="5" visible="no" active="yes"/>
<layer number="39" name="tKeepout" color="4" fill="11" visible="yes" active="yes"/>
<layer number="40" name="bKeepout" color="1" fill="11" visible="yes" active="yes"/>
<layer number="41" name="tRestrict" color="4" fill="10" visible="yes" active="yes"/>
<layer number="42" name="bRestrict" color="1" fill="10" visible="yes" active="yes"/>
<layer number="43" name="vRestrict" color="2" fill="10" visible="yes" active="yes"/>
<layer number="44" name="Drills" color="7" fill="1" visible="no" active="yes"/>
<layer number="45" name="Holes" color="7" fill="1" visible="no" active="yes"/>
<layer number="47" name="Measures" color="7" fill="1" visible="no" active="yes"/>
<layer number="51" name="tDocu" color="7" fill="1" visible="yes" active="yes"/>
<layer number="52" name="bDocu" color="7" fill="1" visible="yes" active="yes"/>
<layer number="91" name="Nets" color="2" fill="1" visible="yes" active="yes"/>
<layer number="92" name="Busses" color="1" fill="1" visible="yes" active="yes"/>
<layer number="93" name="Pins" color="2" fill="1" visible="no" active="yes"/>
<layer number="94" name="Symbols" color="4" fill="1" visible="yes" active="yes"/>
<layer number="95" name="Names" color="7" fill="1" visible="yes" active="yes"/>
<layer number="96" name="Values" color="7" fill="1" visible="yes" active="yes"/>
<layer number="97" name="Info" color="7" fill="1" visible="yes" active="yes"/>
</layers>
<schematic xreflabel="%F%N/%S.%C%R" xrefpart="/%S.%C%R">
<description>Dykkecomputer rev D, hovedkort. Net-label schematic generated from the routed board; the drawn schematic (rev C sheets) explains the circuit.</description>
<libraries><library name="dive_revd"><description>Dykkecomputer rev D, hovedkort: packages generated from the routed board</description><packages><package name="C_0402_1005Metric">
<smd name="1" x="-0.48" y="0.0" dx="0.56" dy="0.62" layer="1" roundness="50"/>
<smd name="2" x="0.48" y="0.0" dx="0.56" dy="0.62" layer="1" roundness="50"/>
<text x="0" y="1" size="0.6" layer="25">&gt;NAME</text>
</package>
<package name="R_0402_1005Metric">
<smd name="1" x="-0.51" y="-0.0" dx="0.54" dy="0.64" layer="1" roundness="50"/>
<smd name="2" x="0.51" y="0.0" dx="0.54" dy="0.64" layer="1" roundness="50"/>
<text x="0" y="1" size="0.6" layer="25">&gt;NAME</text>
</package>
<package name="C_0603_1608Metric">
<smd name="1" x="-0.775" y="0.0" dx="0.9" dy="0.95" layer="1" roundness="50"/>
<smd name="2" x="0.775" y="0.0" dx="0.9" dy="0.95" layer="1" roundness="50"/>
<text x="0" y="1" size="0.6" layer="25">&gt;NAME</text>
</package>
<package name="R_0603_1608Metric">
<smd name="1" x="-0.825" y="-0.0" dx="0.8" dy="0.95" layer="1" roundness="50"/>
<smd name="2" x="0.825" y="0.0" dx="0.8" dy="0.95" layer="1" roundness="50"/>
<text x="0" y="1" size="0.6" layer="25">&gt;NAME</text>
</package>
<package name="SOT-23-6">
<smd name="1" x="-1.1375" y="0.95" dx="1.325" dy="0.6" layer="1" roundness="50"/>
<smd name="2" x="-1.1375" y="-0.0" dx="1.325" dy="0.6" layer="1" roundness="50"/>
<smd name="3" x="-1.1375" y="-0.95" dx="1.325" dy="0.6" layer="1" roundness="50"/>
<smd name="4" x="1.1375" y="-0.95" dx="1.325" dy="0.6" layer="1" roundness="50"/>
<smd name="5" x="1.1375" y="0.0" dx="1.325" dy="0.6" layer="1" roundness="50"/>
<smd name="6" x="1.1375" y="0.95" dx="1.325" dy="0.6" layer="1" roundness="50"/>
<text x="0" y="1" size="0.6" layer="25">&gt;NAME</text>
</package>
<package name="SERVICE_2x4">
<smd name="1" x="-1.25" y="3.0" dx="1.3" dy="1.3" layer="1" roundness="100"/>
<smd name="2" x="-1.25" y="1.0" dx="1.3" dy="1.3" layer="1" roundness="100"/>
<smd name="3" x="-1.25" y="-1.0" dx="1.3" dy="1.3" layer="1" roundness="100"/>
<smd name="4" x="-1.25" y="-3.0" dx="1.3" dy="1.3" layer="1" roundness="100"/>
<smd name="5" x="1.25" y="3.0" dx="1.3" dy="1.3" layer="1" roundness="100"/>
<smd name="6" x="1.25" y="1.0" dx="1.3" dy="1.3" layer="1" roundness="100"/>
<smd name="7" x="1.25" y="-1.0" dx="1.3" dy="1.3" layer="1" roundness="100"/>
<smd name="8" x="1.25" y="-3.0" dx="1.3" dy="1.3" layer="1" roundness="100"/>
<text x="0" y="1" size="0.6" layer="25">&gt;NAME</text>
</package>
<package name="Crystal_SMD_3215-2Pin_3.2x1.5mm">
<smd name="1" x="1.25" y="0.0" dx="1.0" dy="1.8" layer="1" roundness="0"/>
<smd name="2" x="-1.25" y="0.0" dx="1.0" dy="1.8" layer="1" roundness="0"/>
<text x="0" y="1" size="0.6" layer="25">&gt;NAME</text>
</package>
<package name="TDFN-8-1EP_2x2mm_P0.5mm_EP0.8x1.2mm">
<smd name="1" x="-0.9875" y="0.75" dx="0.775" dy="0.25" layer="1" roundness="50"/>
<smd name="2" x="-0.9875" y="0.25" dx="0.775" dy="0.25" layer="1" roundness="50"/>
<smd name="3" x="-0.9875" y="-0.25" dx="0.775" dy="0.25" layer="1" roundness="50"/>
<smd name="4" x="-0.9875" y="-0.75" dx="0.775" dy="0.25" layer="1" roundness="50"/>
<smd name="5" x="0.9875" y="-0.75" dx="0.775" dy="0.25" layer="1" roundness="50"/>
<smd name="6" x="0.9875" y="-0.25" dx="0.775" dy="0.25" layer="1" roundness="50"/>
<smd name="7" x="0.9875" y="0.25" dx="0.775" dy="0.25" layer="1" roundness="50"/>
<smd name="8" x="0.9875" y="0.75" dx="0.775" dy="0.25" layer="1" roundness="50"/>
<smd name="9" x="0.0" y="0.0" dx="0.8" dy="1.2" layer="1" roundness="0" cream="no"/>
<text x="0" y="1" size="0.6" layer="25">&gt;NAME</text>
</package>
<package name="SOIC-8_3.9x4.9mm_P1.27mm">
<smd name="1" x="-2.475" y="1.905" dx="1.95" dy="0.6" layer="1" roundness="50"/>
<smd name="2" x="-2.475" y="0.635" dx="1.95" dy="0.6" layer="1" roundness="50"/>
<smd name="3" x="-2.475" y="-0.635" dx="1.95" dy="0.6" layer="1" roundness="50"/>
<smd name="4" x="-2.475" y="-1.905" dx="1.95" dy="0.6" layer="1" roundness="50"/>
<smd name="5" x="2.475" y="-1.905" dx="1.95" dy="0.6" layer="1" roundness="50"/>
<smd name="6" x="2.475" y="-0.635" dx="1.95" dy="0.6" layer="1" roundness="50"/>
<smd name="7" x="2.475" y="0.635" dx="1.95" dy="0.6" layer="1" roundness="50"/>
<smd name="8" x="2.475" y="1.905" dx="1.95" dy="0.6" layer="1" roundness="50"/>
<text x="0" y="1" size="0.6" layer="25">&gt;NAME</text>
</package>
<package name="FPC_50_P0.5">
<smd name="1" x="-12.25" y="0.0" dx="0.3" dy="1.0" layer="1" roundness="30"/>
<smd name="2" x="-11.75" y="0.0" dx="0.3" dy="1.0" layer="1" roundness="30"/>
<smd name="3" x="-11.25" y="0.0" dx="0.3" dy="1.0" layer="1" roundness="30"/>
<smd name="4" x="-10.75" y="0.0" dx="0.3" dy="1.0" layer="1" roundness="30"/>
<smd name="5" x="-10.25" y="0.0" dx="0.3" dy="1.0" layer="1" roundness="30"/>
<smd name="6" x="-9.75" y="0.0" dx="0.3" dy="1.0" layer="1" roundness="30"/>
<smd name="7" x="-9.25" y="0.0" dx="0.3" dy="1.0" layer="1" roundness="30"/>
<smd name="8" x="-8.75" y="0.0" dx="0.3" dy="1.0" layer="1" roundness="30"/>
<smd name="9" x="-8.25" y="0.0" dx="0.3" dy="1.0" layer="1" roundness="30"/>
<smd name="10" x="-7.75" y="0.0" dx="0.3" dy="1.0" layer="1" roundness="30"/>
<smd name="11" x="-7.25" y="0.0" dx="0.3" dy="1.0" layer="1" roundness="30"/>
<smd name="12" x="-6.75" y="0.0" dx="0.3" dy="1.0" layer="1" roundness="30"/>
<smd name="13" x="-6.25" y="0.0" dx="0.3" dy="1.0" layer="1" roundness="30"/>
<smd name="14" x="-5.75" y="0.0" dx="0.3" dy="1.0" layer="1" roundness="30"/>
<smd name="15" x="-5.25" y="0.0" dx="0.3" dy="1.0" layer="1" roundness="30"/>
<smd name="16" x="-4.75" y="0.0" dx="0.3" dy="1.0" layer="1" roundness="30"/>
<smd name="17" x="-4.25" y="0.0" dx="0.3" dy="1.0" layer="1" roundness="30"/>
<smd name="18" x="-3.75" y="0.0" dx="0.3" dy="1.0" layer="1" roundness="30"/>
<smd name="19" x="-3.25" y="0.0" dx="0.3" dy="1.0" layer="1" roundness="30"/>
<smd name="20" x="-2.75" y="0.0" dx="0.3" dy="1.0" layer="1" roundness="30"/>
<smd name="21" x="-2.25" y="0.0" dx="0.3" dy="1.0" layer="1" roundness="30"/>
<smd name="22" x="-1.75" y="0.0" dx="0.3" dy="1.0" layer="1" roundness="30"/>
<smd name="23" x="-1.25" y="0.0" dx="0.3" dy="1.0" layer="1" roundness="30"/>
<smd name="24" x="-0.75" y="0.0" dx="0.3" dy="1.0" layer="1" roundness="30"/>
<smd name="25" x="-0.25" y="0.0" dx="0.3" dy="1.0" layer="1" roundness="30"/>
<smd name="26" x="0.25" y="0.0" dx="0.3" dy="1.0" layer="1" roundness="30"/>
<smd name="27" x="0.75" y="0.0" dx="0.3" dy="1.0" layer="1" roundness="30"/>
<smd name="28" x="1.25" y="0.0" dx="0.3" dy="1.0" layer="1" roundness="30"/>
<smd name="29" x="1.75" y="0.0" dx="0.3" dy="1.0" layer="1" roundness="30"/>
<smd name="30" x="2.25" y="0.0" dx="0.3" dy="1.0" layer="1" roundness="30"/>
<smd name="31" x="2.75" y="0.0" dx="0.3" dy="1.0" layer="1" roundness="30"/>
<smd name="32" x="3.25" y="0.0" dx="0.3" dy="1.0" layer="1" roundness="30"/>
<smd name="33" x="3.75" y="0.0" dx="0.3" dy="1.0" layer="1" roundness="30"/>
<smd name="34" x="4.25" y="0.0" dx="0.3" dy="1.0" layer="1" roundness="30"/>
<smd name="35" x="4.75" y="0.0" dx="0.3" dy="1.0" layer="1" roundness="30"/>
<smd name="36" x="5.25" y="0.0" dx="0.3" dy="1.0" layer="1" roundness="30"/>
<smd name="37" x="5.75" y="0.0" dx="0.3" dy="1.0" layer="1" roundness="30"/>
<smd name="38" x="6.25" y="0.0" dx="0.3" dy="1.0" layer="1" roundness="30"/>
<smd name="39" x="6.75" y="0.0" dx="0.3" dy="1.0" layer="1" roundness="30"/>
<smd name="40" x="7.25" y="0.0" dx="0.3" dy="1.0" layer="1" roundness="30"/>
<smd name="41" x="7.75" y="0.0" dx="0.3" dy="1.0" layer="1" roundness="30"/>
<smd name="42" x="8.25" y="0.0" dx="0.3" dy="1.0" layer="1" roundness="30"/>
<smd name="43" x="8.75" y="0.0" dx="0.3" dy="1.0" layer="1" roundness="30"/>
<smd name="44" x="9.25" y="0.0" dx="0.3" dy="1.0" layer="1" roundness="30"/>
<smd name="45" x="9.75" y="0.0" dx="0.3" dy="1.0" layer="1" roundness="30"/>
<smd name="46" x="10.25" y="0.0" dx="0.3" dy="1.0" layer="1" roundness="30"/>
<smd name="47" x="10.75" y="0.0" dx="0.3" dy="1.0" layer="1" roundness="30"/>
<smd name="48" x="11.25" y="0.0" dx="0.3" dy="1.0" layer="1" roundness="30"/>
<smd name="49" x="11.75" y="0.0" dx="0.3" dy="1.0" layer="1" roundness="30"/>
<smd name="50" x="12.25" y="0.0" dx="0.3" dy="1.0" layer="1" roundness="30"/>
<smd name="MP" x="-14.15" y="-2.0" dx="1.6" dy="2.2" layer="1" roundness="30"/>
<smd name="MP@2" x="14.15" y="-2.0" dx="1.6" dy="2.2" layer="1" roundness="30"/>
<text x="0" y="1" size="0.6" layer="25">&gt;NAME</text>
</package>
<package name="MountingHole_2.2mm_M2">
<text x="0" y="1" size="0.6" layer="25">&gt;NAME</text>
</package>
<package name="TSSOP-8_4.4x3mm_P0.65mm">
<smd name="1" x="-2.8625" y="0.975" dx="1.475" dy="0.4" layer="1" roundness="50"/>
<smd name="2" x="-2.8625" y="0.325" dx="1.475" dy="0.4" layer="1" roundness="50"/>
<smd name="3" x="-2.8625" y="-0.325" dx="1.475" dy="0.4" layer="1" roundness="50"/>
<smd name="4" x="-2.8625" y="-0.975" dx="1.475" dy="0.4" layer="1" roundness="50"/>
<smd name="5" x="2.8625" y="-0.975" dx="1.475" dy="0.4" layer="1" roundness="50"/>
<smd name="6" x="2.8625" y="-0.325" dx="1.475" dy="0.4" layer="1" roundness="50"/>
<smd name="7" x="2.8625" y="0.325" dx="1.475" dy="0.4" layer="1" roundness="50"/>
<smd name="8" x="2.8625" y="0.975" dx="1.475" dy="0.4" layer="1" roundness="50"/>
<text x="0" y="1" size="0.6" layer="25">&gt;NAME</text>
</package>
<package name="SOT-23">
<smd name="1" x="-0.9375" y="0.95" dx="1.475" dy="0.6" layer="1" roundness="50"/>
<smd name="2" x="-0.9375" y="-0.95" dx="1.475" dy="0.6" layer="1" roundness="50"/>
<smd name="3" x="0.9375" y="0.0" dx="1.475" dy="0.6" layer="1" roundness="50"/>
<text x="0" y="1" size="0.6" layer="25">&gt;NAME</text>
</package>
<package name="SOT-563">
<smd name="1" x="-0.75" y="0.5" dx="0.7" dy="0.34" layer="1" roundness="50"/>
<smd name="2" x="-0.75" y="0.0" dx="0.7" dy="0.34" layer="1" roundness="50"/>
<smd name="3" x="-0.75" y="-0.5" dx="0.7" dy="0.34" layer="1" roundness="50"/>
<smd name="4" x="0.75" y="-0.5" dx="0.7" dy="0.34" layer="1" roundness="50"/>
<smd name="5" x="0.75" y="0.0" dx="0.7" dy="0.34" layer="1" roundness="50"/>
<smd name="6" x="0.75" y="0.5" dx="0.7" dy="0.34" layer="1" roundness="50"/>
<text x="0" y="1" size="0.6" layer="25">&gt;NAME</text>
</package>
<package name="L_0603_1608Metric">
<smd name="1" x="-0.7875" y="0.0" dx="0.875" dy="0.95" layer="1" roundness="50"/>
<smd name="2" x="0.7875" y="0.0" dx="0.875" dy="0.95" layer="1" roundness="50"/>
<text x="0" y="1" size="0.6" layer="25">&gt;NAME</text>
</package>
<package name="PADS_4_0.8">
<smd name="1" x="-1.5" y="0.0" dx="0.6" dy="1.4" layer="1" roundness="30"/>
<smd name="2" x="-0.5" y="0.0" dx="0.6" dy="1.4" layer="1" roundness="30"/>
<smd name="3" x="0.5" y="0.0" dx="0.6" dy="1.4" layer="1" roundness="30"/>
<smd name="4" x="1.5" y="0.0" dx="0.6" dy="1.4" layer="1" roundness="30"/>
<text x="0" y="1" size="0.6" layer="25">&gt;NAME</text>
</package>
<package name="D_SOD-323">
<smd name="1" x="-1.05" y="0.0" dx="0.6" dy="0.45" layer="1" roundness="50"/>
<smd name="2" x="1.05" y="0.0" dx="0.6" dy="0.45" layer="1" roundness="50"/>
<text x="0" y="1" size="0.6" layer="25">&gt;NAME</text>
</package>
<package name="L_1008_2520Metric">
<smd name="1" x="-1.075" y="-0.0" dx="1.25" dy="2.2" layer="1" roundness="40"/>
<smd name="2" x="1.075" y="0.0" dx="1.25" dy="2.2" layer="1" roundness="40"/>
<text x="0" y="1" size="0.6" layer="25">&gt;NAME</text>
</package>
<package name="WLP-4_0.83x0.83mm_P0.4mm">
<smd name="A1" x="-0.2" y="0.2" dx="0.25" dy="0.25" layer="1" roundness="100"/>
<smd name="A2" x="0.2" y="0.2" dx="0.25" dy="0.25" layer="1" roundness="100"/>
<smd name="B1" x="-0.2" y="-0.2" dx="0.25" dy="0.25" layer="1" roundness="100"/>
<smd name="B2" x="0.2" y="-0.2" dx="0.25" dy="0.25" layer="1" roundness="100"/>
<text x="0" y="1" size="0.6" layer="25">&gt;NAME</text>
</package>
<package name="SOT-23-5">
<smd name="1" x="-1.1375" y="0.95" dx="1.325" dy="0.6" layer="1" roundness="50"/>
<smd name="2" x="-1.1375" y="-0.0" dx="1.325" dy="0.6" layer="1" roundness="50"/>
<smd name="3" x="-1.1375" y="-0.95" dx="1.325" dy="0.6" layer="1" roundness="50"/>
<smd name="4" x="1.1375" y="-0.95" dx="1.325" dy="0.6" layer="1" roundness="50"/>
<smd name="5" x="1.1375" y="0.95" dx="1.325" dy="0.6" layer="1" roundness="50"/>
<text x="0" y="1" size="0.6" layer="25">&gt;NAME</text>
</package>
<package name="LGA-14_3x2.5mm_P0.5mm_LayoutBorder3x4y">
<smd name="1" x="-1.1625" y="0.75" dx="0.625" dy="0.35" layer="1" roundness="50"/>
<smd name="2" x="-1.1625" y="0.25" dx="0.625" dy="0.35" layer="1" roundness="50"/>
<smd name="3" x="-1.1625" y="-0.25" dx="0.625" dy="0.35" layer="1" roundness="50"/>
<smd name="4" x="-1.1625" y="-0.75" dx="0.625" dy="0.35" layer="1" roundness="50"/>
<smd name="5" x="-0.5" y="-0.9125" dx="0.35" dy="0.625" layer="1" roundness="50"/>
<smd name="6" x="0.0" y="-0.9125" dx="0.35" dy="0.625" layer="1" roundness="50"/>
<smd name="7" x="0.5" y="-0.9125" dx="0.35" dy="0.625" layer="1" roundness="50"/>
<smd name="8" x="1.1625" y="-0.75" dx="0.625" dy="0.35" layer="1" roundness="50"/>
<smd name="9" x="1.1625" y="-0.25" dx="0.625" dy="0.35" layer="1" roundness="50"/>
<smd name="10" x="1.1625" y="0.25" dx="0.625" dy="0.35" layer="1" roundness="50"/>
<smd name="11" x="1.1625" y="0.75" dx="0.625" dy="0.35" layer="1" roundness="50"/>
<smd name="12" x="0.5" y="0.9125" dx="0.35" dy="0.625" layer="1" roundness="50"/>
<smd name="13" x="0.0" y="0.9125" dx="0.35" dy="0.625" layer="1" roundness="50"/>
<smd name="14" x="-0.5" y="0.9125" dx="0.35" dy="0.625" layer="1" roundness="50"/>
<text x="0" y="1" size="0.6" layer="25">&gt;NAME</text>
</package>
<package name="ESP32-S3-WROOM-1">
<smd name="1" x="8.75" y="-5.26" dx="1.5" dy="0.9" layer="1" roundness="0"/>
<smd name="2" x="8.75" y="-3.99" dx="1.5" dy="0.9" layer="1" roundness="0"/>
<smd name="3" x="8.75" y="-2.72" dx="1.5" dy="0.9" layer="1" roundness="0"/>
<smd name="4" x="8.75" y="-1.45" dx="1.5" dy="0.9" layer="1" roundness="0"/>
<smd name="5" x="8.75" y="-0.18" dx="1.5" dy="0.9" layer="1" roundness="0"/>
<smd name="6" x="8.75" y="1.09" dx="1.5" dy="0.9" layer="1" roundness="0"/>
<smd name="7" x="8.75" y="2.36" dx="1.5" dy="0.9" layer="1" roundness="0"/>
<smd name="8" x="8.75" y="3.63" dx="1.5" dy="0.9" layer="1" roundness="0"/>
<smd name="9" x="8.75" y="4.9" dx="1.5" dy="0.9" layer="1" roundness="0"/>
<smd name="10" x="8.75" y="6.17" dx="1.5" dy="0.9" layer="1" roundness="0"/>
<smd name="11" x="8.75" y="7.44" dx="1.5" dy="0.9" layer="1" roundness="0"/>
<smd name="12" x="8.75" y="8.71" dx="1.5" dy="0.9" layer="1" roundness="0"/>
<smd name="13" x="8.75" y="9.98" dx="1.5" dy="0.9" layer="1" roundness="0"/>
<smd name="14" x="8.75" y="11.25" dx="1.5" dy="0.9" layer="1" roundness="0" rot="R180.0"/>
<smd name="15" x="6.985" y="12.5" dx="1.5" dy="0.9" layer="1" roundness="0" rot="R270.0"/>
<smd name="16" x="5.715" y="12.5" dx="1.5" dy="0.9" layer="1" roundness="0" rot="R270.0"/>
<smd name="17" x="4.445" y="12.5" dx="1.5" dy="0.9" layer="1" roundness="0" rot="R270.0"/>
<smd name="18" x="3.175" y="12.5" dx="1.5" dy="0.9" layer="1" roundness="0" rot="R270.0"/>
<smd name="19" x="1.905" y="12.5" dx="1.5" dy="0.9" layer="1" roundness="0" rot="R270.0"/>
<smd name="20" x="0.635" y="12.5" dx="1.5" dy="0.9" layer="1" roundness="0" rot="R270.0"/>
<smd name="21" x="-0.635" y="12.5" dx="1.5" dy="0.9" layer="1" roundness="0" rot="R270.0"/>
<smd name="22" x="-1.905" y="12.5" dx="1.5" dy="0.9" layer="1" roundness="0" rot="R270.0"/>
<smd name="23" x="-3.175" y="12.5" dx="1.5" dy="0.9" layer="1" roundness="0" rot="R270.0"/>
<smd name="24" x="-4.445" y="12.5" dx="1.5" dy="0.9" layer="1" roundness="0" rot="R270.0"/>
<smd name="25" x="-5.715" y="12.5" dx="1.5" dy="0.9" layer="1" roundness="0" rot="R270.0"/>
<smd name="26" x="-6.985" y="12.5" dx="1.5" dy="0.9" layer="1" roundness="0" rot="R270.0"/>
<smd name="27" x="-8.75" y="11.25" dx="1.5" dy="0.9" layer="1" roundness="0"/>
<smd name="28" x="-8.75" y="9.98" dx="1.5" dy="0.9" layer="1" roundness="0"/>
<smd name="29" x="-8.75" y="8.71" dx="1.5" dy="0.9" layer="1" roundness="0"/>
<smd name="30" x="-8.75" y="7.44" dx="1.5" dy="0.9" layer="1" roundness="0"/>
<smd name="31" x="-8.75" y="6.17" dx="1.5" dy="0.9" layer="1" roundness="0"/>
<smd name="32" x="-8.75" y="4.9" dx="1.5" dy="0.9" layer="1" roundness="0"/>
<smd name="33" x="-8.75" y="3.63" dx="1.5" dy="0.9" layer="1" roundness="0"/>
<smd name="34" x="-8.75" y="2.36" dx="1.5" dy="0.9" layer="1" roundness="0"/>
<smd name="35" x="-8.75" y="1.09" dx="1.5" dy="0.9" layer="1" roundness="0"/>
<smd name="36" x="-8.75" y="-0.18" dx="1.5" dy="0.9" layer="1" roundness="0"/>
<smd name="37" x="-8.75" y="-1.45" dx="1.5" dy="0.9" layer="1" roundness="0"/>
<smd name="38" x="-8.75" y="-2.72" dx="1.5" dy="0.9" layer="1" roundness="0"/>
<smd name="39" x="-8.75" y="-3.99" dx="1.5" dy="0.9" layer="1" roundness="0"/>
<smd name="40" x="-8.75" y="-5.26" dx="1.5" dy="0.9" layer="1" roundness="0"/>
<pad name="41" x="2.9" y="3.16" drill="0.2" diameter="0.6" shape="round"/>
<pad name="41@2" x="2.9" y="1.76" drill="0.2" diameter="0.6" shape="round"/>
<pad name="41@3" x="2.2" y="3.86" drill="0.2" diameter="0.6" shape="round"/>
<pad name="41@4" x="2.2" y="2.46" drill="0.2" diameter="0.6" shape="round"/>
<pad name="41@5" x="2.2" y="1.06" drill="0.2" diameter="0.6" shape="round"/>
<pad name="41@6" x="1.5" y="3.16" drill="0.2" diameter="0.6" shape="round"/>
<smd name="41@7" x="1.5" y="2.46" dx="3.9" dy="3.9" layer="1" roundness="0" rot="R270.0" cream="no"/>
<pad name="41@8" x="1.5" y="1.76" drill="0.2" diameter="0.6" shape="round"/>
<pad name="41@9" x="0.8" y="3.86" drill="0.2" diameter="0.6" shape="round"/>
<pad name="41@10" x="0.8" y="2.46" drill="0.2" diameter="0.6" shape="round"/>
<pad name="41@11" x="0.8" y="1.06" drill="0.2" diameter="0.6" shape="round"/>
<pad name="41@12" x="0.1" y="3.16" drill="0.2" diameter="0.6" shape="round"/>
<pad name="41@13" x="0.1" y="1.76" drill="0.2" diameter="0.6" shape="round"/>
<text x="0" y="1" size="0.6" layer="25">&gt;NAME</text>
</package>
<package name="TSSOP-20_4.4x6.5mm_P0.65mm">
<smd name="1" x="2.8625" y="-2.925" dx="1.475" dy="0.4" layer="1" roundness="50"/>
<smd name="2" x="2.8625" y="-2.275" dx="1.475" dy="0.4" layer="1" roundness="50"/>
<smd name="3" x="2.8625" y="-1.625" dx="1.475" dy="0.4" layer="1" roundness="50"/>
<smd name="4" x="2.8625" y="-0.975" dx="1.475" dy="0.4" layer="1" roundness="50"/>
<smd name="5" x="2.8625" y="-0.325" dx="1.475" dy="0.4" layer="1" roundness="50"/>
<smd name="6" x="2.8625" y="0.325" dx="1.475" dy="0.4" layer="1" roundness="50"/>
<smd name="7" x="2.8625" y="0.975" dx="1.475" dy="0.4" layer="1" roundness="50"/>
<smd name="8" x="2.8625" y="1.625" dx="1.475" dy="0.4" layer="1" roundness="50"/>
<smd name="9" x="2.8625" y="2.275" dx="1.475" dy="0.4" layer="1" roundness="50"/>
<smd name="10" x="2.8625" y="2.925" dx="1.475" dy="0.4" layer="1" roundness="50"/>
<smd name="11" x="-2.8625" y="2.925" dx="1.475" dy="0.4" layer="1" roundness="50"/>
<smd name="12" x="-2.8625" y="2.275" dx="1.475" dy="0.4" layer="1" roundness="50"/>
<smd name="13" x="-2.8625" y="1.625" dx="1.475" dy="0.4" layer="1" roundness="50"/>
<smd name="14" x="-2.8625" y="0.975" dx="1.475" dy="0.4" layer="1" roundness="50"/>
<smd name="15" x="-2.8625" y="0.325" dx="1.475" dy="0.4" layer="1" roundness="50"/>
<smd name="16" x="-2.8625" y="-0.325" dx="1.475" dy="0.4" layer="1" roundness="50"/>
<smd name="17" x="-2.8625" y="-0.975" dx="1.475" dy="0.4" layer="1" roundness="50"/>
<smd name="18" x="-2.8625" y="-1.625" dx="1.475" dy="0.4" layer="1" roundness="50"/>
<smd name="19" x="-2.8625" y="-2.275" dx="1.475" dy="0.4" layer="1" roundness="50"/>
<smd name="20" x="-2.8625" y="-2.925" dx="1.475" dy="0.4" layer="1" roundness="50"/>
<text x="0" y="1" size="0.6" layer="25">&gt;NAME</text>
</package>
<package name="TestPoint_Pad_D1.0mm">
<smd name="1" x="0.0" y="0.0" dx="1.0" dy="1.0" layer="1" roundness="100" cream="no"/>
<text x="0" y="1" size="0.6" layer="25">&gt;NAME</text>
</package>
<package name="C_0402_1005Metric_24">
<smd name="1" x="-0.48" y="-0.0" dx="0.56" dy="0.62" layer="1" roundness="50" rot="R180.0"/>
<smd name="2" x="0.48" y="0.0" dx="0.56" dy="0.62" layer="1" roundness="50" rot="R180.0"/>
<text x="0" y="1" size="0.6" layer="25">&gt;NAME</text>
</package>
<package name="ANT_7x2">
<smd name="1" x="3.05" y="0.0" dx="0.9" dy="2.2" layer="1" roundness="30"/>
<smd name="2" x="-3.05" y="0.0" dx="0.9" dy="2.2" layer="1" roundness="30"/>
<text x="0" y="1" size="0.6" layer="25">&gt;NAME</text>
</package>
<package name="D_SOD-323_26">
<smd name="1" x="-1.05" y="-0.0" dx="0.6" dy="0.45" layer="1" roundness="50" rot="R180.0"/>
<smd name="2" x="1.05" y="0.0" dx="0.6" dy="0.45" layer="1" roundness="50" rot="R180.0"/>
<text x="0" y="1" size="0.6" layer="25">&gt;NAME</text>
</package>
<package name="TSSOP-24_4.4x7.8mm_P0.65mm">
<smd name="1" x="-2.8625" y="3.575" dx="1.475" dy="0.4" layer="1" roundness="50" rot="R180.0"/>
<smd name="2" x="-2.8625" y="2.925" dx="1.475" dy="0.4" layer="1" roundness="50" rot="R180.0"/>
<smd name="3" x="-2.8625" y="2.275" dx="1.475" dy="0.4" layer="1" roundness="50" rot="R180.0"/>
<smd name="4" x="-2.8625" y="1.625" dx="1.475" dy="0.4" layer="1" roundness="50" rot="R180.0"/>
<smd name="5" x="-2.8625" y="0.975" dx="1.475" dy="0.4" layer="1" roundness="50" rot="R180.0"/>
<smd name="6" x="-2.8625" y="0.325" dx="1.475" dy="0.4" layer="1" roundness="50" rot="R180.0"/>
<smd name="7" x="-2.8625" y="-0.325" dx="1.475" dy="0.4" layer="1" roundness="50" rot="R180.0"/>
<smd name="8" x="-2.8625" y="-0.975" dx="1.475" dy="0.4" layer="1" roundness="50" rot="R180.0"/>
<smd name="9" x="-2.8625" y="-1.625" dx="1.475" dy="0.4" layer="1" roundness="50" rot="R180.0"/>
<smd name="10" x="-2.8625" y="-2.275" dx="1.475" dy="0.4" layer="1" roundness="50" rot="R180.0"/>
<smd name="11" x="-2.8625" y="-2.925" dx="1.475" dy="0.4" layer="1" roundness="50" rot="R180.0"/>
<smd name="12" x="-2.8625" y="-3.575" dx="1.475" dy="0.4" layer="1" roundness="50" rot="R180.0"/>
<smd name="13" x="2.8625" y="-3.575" dx="1.475" dy="0.4" layer="1" roundness="50" rot="R180.0"/>
<smd name="14" x="2.8625" y="-2.925" dx="1.475" dy="0.4" layer="1" roundness="50" rot="R180.0"/>
<smd name="15" x="2.8625" y="-2.275" dx="1.475" dy="0.4" layer="1" roundness="50" rot="R180.0"/>
<smd name="16" x="2.8625" y="-1.625" dx="1.475" dy="0.4" layer="1" roundness="50" rot="R180.0"/>
<smd name="17" x="2.8625" y="-0.975" dx="1.475" dy="0.4" layer="1" roundness="50" rot="R180.0"/>
<smd name="18" x="2.8625" y="-0.325" dx="1.475" dy="0.4" layer="1" roundness="50" rot="R180.0"/>
<smd name="19" x="2.8625" y="0.325" dx="1.475" dy="0.4" layer="1" roundness="50" rot="R180.0"/>
<smd name="20" x="2.8625" y="0.975" dx="1.475" dy="0.4" layer="1" roundness="50" rot="R180.0"/>
<smd name="21" x="2.8625" y="1.625" dx="1.475" dy="0.4" layer="1" roundness="50" rot="R180.0"/>
<smd name="22" x="2.8625" y="2.275" dx="1.475" dy="0.4" layer="1" roundness="50" rot="R180.0"/>
<smd name="23" x="2.8625" y="2.925" dx="1.475" dy="0.4" layer="1" roundness="50" rot="R180.0"/>
<smd name="24" x="2.8625" y="3.575" dx="1.475" dy="0.4" layer="1" roundness="50" rot="R180.0"/>
<text x="0" y="1" size="0.6" layer="25">&gt;NAME</text>
</package>
<package name="PADS_2_1.2">
<smd name="1" x="-1.2" y="-0.0" dx="1.2" dy="1.68" layer="1" roundness="30" rot="R180.0"/>
<smd name="2" x="1.2" y="0.0" dx="1.2" dy="1.68" layer="1" roundness="30" rot="R180.0"/>
<text x="0" y="1" size="0.6" layer="25">&gt;NAME</text>
</package>
<package name="microSD_HC_Hirose_DM3D-SF">
<smd name="1" x="-3.175" y="5.35" dx="0.7" dy="1.75" layer="1" roundness="0"/>
<smd name="2" x="-2.075" y="5.35" dx="0.7" dy="1.75" layer="1" roundness="0"/>
<smd name="3" x="-0.975" y="5.35" dx="0.7" dy="1.75" layer="1" roundness="0"/>
<smd name="4" x="0.125" y="5.35" dx="0.7" dy="1.75" layer="1" roundness="0"/>
<smd name="5" x="1.225" y="5.35" dx="0.7" dy="1.75" layer="1" roundness="0"/>
<smd name="6" x="2.325" y="5.35" dx="0.7" dy="1.75" layer="1" roundness="0"/>
<smd name="7" x="3.425" y="5.35" dx="0.7" dy="1.75" layer="1" roundness="0"/>
<smd name="8" x="4.525" y="5.35" dx="0.7" dy="1.75" layer="1" roundness="0"/>
<smd name="9" x="5.65" y="-3.875" dx="1.45" dy="1.0" layer="1" roundness="0"/>
<smd name="10" x="-5.575" y="-5.45" dx="1.0" dy="1.55" layer="1" roundness="0"/>
<smd name="11" x="5.975" y="-2.375" dx="0.8" dy="1.5" layer="1" roundness="0"/>
<smd name="11@2" x="5.725" y="5.225" dx="1.3" dy="1.5" layer="1" roundness="0"/>
<smd name="11@3" x="-5.625" y="5.225" dx="1.5" dy="1.5" layer="1" roundness="0"/>
<smd name="11@4" x="-5.975" y="-3.025" dx="0.8" dy="1.4" layer="1" roundness="0"/>
<text x="0" y="1" size="0.6" layer="25">&gt;NAME</text>
</package>
<package name="SOIC-8_3.9x4.9mm_P1.27mm_30">
<smd name="1" x="-2.475" y="1.905" dx="1.95" dy="0.6" layer="1" roundness="50" rot="R180.0"/>
<smd name="2" x="-2.475" y="0.635" dx="1.95" dy="0.6" layer="1" roundness="50" rot="R180.0"/>
<smd name="3" x="-2.475" y="-0.635" dx="1.95" dy="0.6" layer="1" roundness="50" rot="R180.0"/>
<smd name="4" x="-2.475" y="-1.905" dx="1.95" dy="0.6" layer="1" roundness="50" rot="R180.0"/>
<smd name="5" x="2.475" y="-1.905" dx="1.95" dy="0.6" layer="1" roundness="50" rot="R180.0"/>
<smd name="6" x="2.475" y="-0.635" dx="1.95" dy="0.6" layer="1" roundness="50" rot="R180.0"/>
<smd name="7" x="2.475" y="0.635" dx="1.95" dy="0.6" layer="1" roundness="50" rot="R180.0"/>
<smd name="8" x="2.475" y="1.905" dx="1.95" dy="0.6" layer="1" roundness="50" rot="R180.0"/>
<text x="0" y="1" size="0.6" layer="25">&gt;NAME</text>
</package>
<package name="R_0402_1005Metric_31">
<smd name="1" x="-0.51" y="-0.0" dx="0.54" dy="0.64" layer="1" roundness="50" rot="R180.0"/>
<smd name="2" x="0.51" y="0.0" dx="0.54" dy="0.64" layer="1" roundness="50" rot="R180.0"/>
<text x="0" y="1" size="0.6" layer="25">&gt;NAME</text>
</package>
<package name="SOT-23_32">
<smd name="1" x="0.9375" y="-0.95" dx="1.475" dy="0.6" layer="1" roundness="50"/>
<smd name="2" x="0.9375" y="0.95" dx="1.475" dy="0.6" layer="1" roundness="50"/>
<smd name="3" x="-0.9375" y="0.0" dx="1.475" dy="0.6" layer="1" roundness="50"/>
<text x="0" y="1" size="0.6" layer="25">&gt;NAME</text>
</package>
<package name="SOT-23-6_33">
<smd name="1" x="1.1375" y="-0.95" dx="1.325" dy="0.6" layer="1" roundness="50"/>
<smd name="2" x="1.1375" y="0.0" dx="1.325" dy="0.6" layer="1" roundness="50"/>
<smd name="3" x="1.1375" y="0.95" dx="1.325" dy="0.6" layer="1" roundness="50"/>
<smd name="4" x="-1.1375" y="0.95" dx="1.325" dy="0.6" layer="1" roundness="50"/>
<smd name="5" x="-1.1375" y="0.0" dx="1.325" dy="0.6" layer="1" roundness="50"/>
<smd name="6" x="-1.1375" y="-0.95" dx="1.325" dy="0.6" layer="1" roundness="50"/>
<text x="0" y="1" size="0.6" layer="25">&gt;NAME</text>
</package>
<package name="ublox_MAX">
<smd name="1" x="4.75" y="-4.4" dx="1.8" dy="0.7" layer="1" roundness="50"/>
<smd name="2" x="4.75" y="-3.3" dx="1.8" dy="0.8" layer="1" roundness="50"/>
<smd name="3" x="4.75" y="-2.2" dx="1.8" dy="0.8" layer="1" roundness="50"/>
<smd name="4" x="4.75" y="-1.1" dx="1.8" dy="0.8" layer="1" roundness="50"/>
<smd name="5" x="4.75" y="0.0" dx="1.8" dy="0.8" layer="1" roundness="50"/>
<smd name="6" x="4.75" y="1.1" dx="1.8" dy="0.8" layer="1" roundness="50"/>
<smd name="7" x="4.75" y="2.2" dx="1.8" dy="0.8" layer="1" roundness="50"/>
<smd name="8" x="4.75" y="3.3" dx="1.8" dy="0.8" layer="1" roundness="50"/>
<smd name="9" x="4.75" y="4.4" dx="1.8" dy="0.7" layer="1" roundness="50"/>
<smd name="10" x="-4.75" y="4.4" dx="1.8" dy="0.7" layer="1" roundness="50"/>
<smd name="11" x="-4.75" y="3.3" dx="1.8" dy="0.8" layer="1" roundness="50"/>
<smd name="12" x="-4.75" y="2.2" dx="1.8" dy="0.8" layer="1" roundness="50"/>
<smd name="13" x="-4.75" y="1.1" dx="1.8" dy="0.8" layer="1" roundness="50"/>
<smd name="14" x="-4.75" y="0.0" dx="1.8" dy="0.8" layer="1" roundness="50"/>
<smd name="15" x="-4.75" y="-1.1" dx="1.8" dy="0.8" layer="1" roundness="50"/>
<smd name="16" x="-4.75" y="-2.2" dx="1.8" dy="0.8" layer="1" roundness="50"/>
<smd name="17" x="-4.75" y="-3.3" dx="1.8" dy="0.8" layer="1" roundness="50"/>
<smd name="18" x="-4.75" y="-4.4" dx="1.8" dy="0.7" layer="1" roundness="50"/>
<text x="0" y="1" size="0.6" layer="25">&gt;NAME</text>
</package>
<package name="POGO_6">
<smd name="1" x="0.0" y="5.0" dx="1.6" dy="1.6" layer="1" roundness="100"/>
<smd name="2" x="0.0" y="3.0" dx="1.6" dy="1.6" layer="1" roundness="100"/>
<smd name="3" x="0.0" y="1.0" dx="1.6" dy="1.6" layer="1" roundness="100"/>
<smd name="4" x="-0.0" y="-1.0" dx="1.6" dy="1.6" layer="1" roundness="100"/>
<smd name="5" x="-0.0" y="-3.0" dx="1.6" dy="1.6" layer="1" roundness="100"/>
<smd name="6" x="-0.0" y="-5.0" dx="1.6" dy="1.6" layer="1" roundness="100"/>
<text x="0" y="1" size="0.6" layer="25">&gt;NAME</text>
</package>
<package name="PAD_1.5">
<smd name="1" x="0.0" y="0.0" dx="1.6" dy="1.6" layer="1" roundness="100"/>
<text x="0" y="1" size="0.6" layer="25">&gt;NAME</text>
</package>
<package name="PADS_2_1.5">
<smd name="1" x="-1.35" y="-0.0" dx="1.5" dy="2.1" layer="1" roundness="30" rot="R180.0"/>
<smd name="2" x="1.35" y="0.0" dx="1.5" dy="2.1" layer="1" roundness="30" rot="R180.0"/>
<text x="0" y="1" size="0.6" layer="25">&gt;NAME</text>
</package>
<package name="JST_SH_BM02B-SRSS-TB_1x02-1MP_P1.00mm_Vertical">
<smd name="1" x="-0.5" y="-1.325" dx="0.6" dy="1.55" layer="1" roundness="50" rot="R180.0"/>
<smd name="2" x="0.5" y="-1.325" dx="0.6" dy="1.55" layer="1" roundness="50" rot="R180.0"/>
<smd name="MP" x="-1.8" y="1.2" dx="1.2" dy="1.8" layer="1" roundness="41" rot="R180.0"/>
<smd name="MP@2" x="1.8" y="1.2" dx="1.2" dy="1.8" layer="1" roundness="41" rot="R180.0"/>
<text x="0" y="1" size="0.6" layer="25">&gt;NAME</text>
</package>
<package name="MSOP-8_3x3mm_P0.65mm">
<smd name="1" x="-2.1125" y="0.975" dx="1.625" dy="0.4" layer="1" roundness="50" rot="R180.0"/>
<smd name="2" x="-2.1125" y="0.325" dx="1.625" dy="0.4" layer="1" roundness="50" rot="R180.0"/>
<smd name="3" x="-2.1125" y="-0.325" dx="1.625" dy="0.4" layer="1" roundness="50" rot="R180.0"/>
<smd name="4" x="-2.1125" y="-0.975" dx="1.625" dy="0.4" layer="1" roundness="50" rot="R180.0"/>
<smd name="5" x="2.1125" y="-0.975" dx="1.625" dy="0.4" layer="1" roundness="50" rot="R180.0"/>
<smd name="6" x="2.1125" y="-0.325" dx="1.625" dy="0.4" layer="1" roundness="50" rot="R180.0"/>
<smd name="7" x="2.1125" y="0.325" dx="1.625" dy="0.4" layer="1" roundness="50" rot="R180.0"/>
<smd name="8" x="2.1125" y="0.975" dx="1.625" dy="0.4" layer="1" roundness="50" rot="R180.0"/>
<text x="0" y="1" size="0.6" layer="25">&gt;NAME</text>
</package>
<package name="BUZZER_9x9">
<smd name="1" x="3.6" y="0.0" dx="1.6" dy="2.4" layer="1" roundness="30"/>
<smd name="2" x="-3.6" y="0.0" dx="1.6" dy="2.4" layer="1" roundness="30"/>
<text x="0" y="1" size="0.6" layer="25">&gt;NAME</text>
</package>
<package name="PADS_2_1.5_41">
<smd name="1" x="1.35" y="0.0" dx="1.5" dy="2.1" layer="1" roundness="30"/>
<smd name="2" x="-1.35" y="0.0" dx="1.5" dy="2.1" layer="1" roundness="30"/>
<text x="0" y="1" size="0.6" layer="25">&gt;NAME</text>
</package>
<package name="TSSOP-14_4.4x5mm_P0.65mm">
<smd name="1" x="-2.8625" y="1.95" dx="1.475" dy="0.4" layer="1" roundness="50" rot="R180.0"/>
<smd name="2" x="-2.8625" y="1.3" dx="1.475" dy="0.4" layer="1" roundness="50" rot="R180.0"/>
<smd name="3" x="-2.8625" y="0.65" dx="1.475" dy="0.4" layer="1" roundness="50" rot="R180.0"/>
<smd name="4" x="-2.8625" y="-0.0" dx="1.475" dy="0.4" layer="1" roundness="50" rot="R180.0"/>
<smd name="5" x="-2.8625" y="-0.65" dx="1.475" dy="0.4" layer="1" roundness="50" rot="R180.0"/>
<smd name="6" x="-2.8625" y="-1.3" dx="1.475" dy="0.4" layer="1" roundness="50" rot="R180.0"/>
<smd name="7" x="-2.8625" y="-1.95" dx="1.475" dy="0.4" layer="1" roundness="50" rot="R180.0"/>
<smd name="8" x="2.8625" y="-1.95" dx="1.475" dy="0.4" layer="1" roundness="50" rot="R180.0"/>
<smd name="9" x="2.8625" y="-1.3" dx="1.475" dy="0.4" layer="1" roundness="50" rot="R180.0"/>
<smd name="10" x="2.8625" y="-0.65" dx="1.475" dy="0.4" layer="1" roundness="50" rot="R180.0"/>
<smd name="11" x="2.8625" y="0.0" dx="1.475" dy="0.4" layer="1" roundness="50" rot="R180.0"/>
<smd name="12" x="2.8625" y="0.65" dx="1.475" dy="0.4" layer="1" roundness="50" rot="R180.0"/>
<smd name="13" x="2.8625" y="1.3" dx="1.475" dy="0.4" layer="1" roundness="50" rot="R180.0"/>
<smd name="14" x="2.8625" y="1.95" dx="1.475" dy="0.4" layer="1" roundness="50" rot="R180.0"/>
<text x="0" y="1" size="0.6" layer="25">&gt;NAME</text>
</package>
<package name="D_SOD-123">
<smd name="1" x="1.65" y="0.0" dx="0.9" dy="1.2" layer="1" roundness="50"/>
<smd name="2" x="-1.65" y="0.0" dx="0.9" dy="1.2" layer="1" roundness="50"/>
<text x="0" y="1" size="0.6" layer="25">&gt;NAME</text>
</package></packages><symbols><symbol name="P1_C04021005Metric">
<wire x1="-7.62" y1="2.54" x2="7.62" y2="2.54" width="0.254" layer="94"/>
<wire x1="7.62" y1="2.54" x2="7.62" y2="-2.54" width="0.254" layer="94"/>
<wire x1="7.62" y1="-2.54" x2="-7.62" y2="-2.54" width="0.254" layer="94"/>
<wire x1="-7.62" y1="-2.54" x2="-7.62" y2="2.54" width="0.254" layer="94"/>
<text x="-7.62" y="3.81" size="1.778" layer="95">&gt;NAME</text>
<text x="-7.62" y="-5.08" size="1.778" layer="96">&gt;VALUE</text>
<pin name="1" x="-12.7" y="0.0" length="short" rot="R0"/>
<pin name="2" x="12.7" y="0.0" length="short" rot="R180"/>
</symbol><symbol name="P2_R04021005Metric">
<wire x1="-7.62" y1="2.54" x2="7.62" y2="2.54" width="0.254" layer="94"/>
<wire x1="7.62" y1="2.54" x2="7.62" y2="-2.54" width="0.254" layer="94"/>
<wire x1="7.62" y1="-2.54" x2="-7.62" y2="-2.54" width="0.254" layer="94"/>
<wire x1="-7.62" y1="-2.54" x2="-7.62" y2="2.54" width="0.254" layer="94"/>
<text x="-7.62" y="3.81" size="1.778" layer="95">&gt;NAME</text>
<text x="-7.62" y="-5.08" size="1.778" layer="96">&gt;VALUE</text>
<pin name="1" x="-12.7" y="0.0" length="short" rot="R0"/>
<pin name="2" x="12.7" y="0.0" length="short" rot="R180"/>
</symbol><symbol name="P3_C06031608Metric">
<wire x1="-7.62" y1="2.54" x2="7.62" y2="2.54" width="0.254" layer="94"/>
<wire x1="7.62" y1="2.54" x2="7.62" y2="-2.54" width="0.254" layer="94"/>
<wire x1="7.62" y1="-2.54" x2="-7.62" y2="-2.54" width="0.254" layer="94"/>
<wire x1="-7.62" y1="-2.54" x2="-7.62" y2="2.54" width="0.254" layer="94"/>
<text x="-7.62" y="3.81" size="1.778" layer="95">&gt;NAME</text>
<text x="-7.62" y="-5.08" size="1.778" layer="96">&gt;VALUE</text>
<pin name="1" x="-12.7" y="0.0" length="short" rot="R0"/>
<pin name="2" x="12.7" y="0.0" length="short" rot="R180"/>
</symbol><symbol name="P4_R06031608Metric">
<wire x1="-7.62" y1="2.54" x2="7.62" y2="2.54" width="0.254" layer="94"/>
<wire x1="7.62" y1="2.54" x2="7.62" y2="-2.54" width="0.254" layer="94"/>
<wire x1="7.62" y1="-2.54" x2="-7.62" y2="-2.54" width="0.254" layer="94"/>
<wire x1="-7.62" y1="-2.54" x2="-7.62" y2="2.54" width="0.254" layer="94"/>
<text x="-7.62" y="3.81" size="1.778" layer="95">&gt;NAME</text>
<text x="-7.62" y="-5.08" size="1.778" layer="96">&gt;VALUE</text>
<pin name="1" x="-12.7" y="0.0" length="short" rot="R0"/>
<pin name="2" x="12.7" y="0.0" length="short" rot="R180"/>
</symbol><symbol name="P5_SOT236">
<wire x1="-7.62" y1="5.08" x2="7.62" y2="5.08" width="0.254" layer="94"/>
<wire x1="7.62" y1="5.08" x2="7.62" y2="-5.08" width="0.254" layer="94"/>
<wire x1="7.62" y1="-5.08" x2="-7.62" y2="-5.08" width="0.254" layer="94"/>
<wire x1="-7.62" y1="-5.08" x2="-7.62" y2="5.08" width="0.254" layer="94"/>
<text x="-7.62" y="6.35" size="1.778" layer="95">&gt;NAME</text>
<text x="-7.62" y="-7.62" size="1.778" layer="96">&gt;VALUE</text>
<pin name="1" x="-12.7" y="2.54" length="short" rot="R0"/>
<pin name="2" x="-12.7" y="0.0" length="short" rot="R0"/>
<pin name="3" x="-12.7" y="-2.54" length="short" rot="R0"/>
<pin name="4" x="12.7" y="2.54" length="short" rot="R180"/>
<pin name="5" x="12.7" y="0.0" length="short" rot="R180"/>
<pin name="6" x="12.7" y="-2.54" length="short" rot="R180"/>
</symbol><symbol name="P6_SERVICE2x4">
<wire x1="-7.62" y1="6.35" x2="7.62" y2="6.35" width="0.254" layer="94"/>
<wire x1="7.62" y1="6.35" x2="7.62" y2="-6.35" width="0.254" layer="94"/>
<wire x1="7.62" y1="-6.35" x2="-7.62" y2="-6.35" width="0.254" layer="94"/>
<wire x1="-7.62" y1="-6.35" x2="-7.62" y2="6.35" width="0.254" layer="94"/>
<text x="-7.62" y="7.619999999999999" size="1.778" layer="95">&gt;NAME</text>
<text x="-7.62" y="-8.89" size="1.778" layer="96">&gt;VALUE</text>
<pin name="1" x="-12.7" y="3.81" length="short" rot="R0"/>
<pin name="2" x="-12.7" y="1.27" length="short" rot="R0"/>
<pin name="3" x="-12.7" y="-1.27" length="short" rot="R0"/>
<pin name="4" x="-12.7" y="-3.81" length="short" rot="R0"/>
<pin name="5" x="12.7" y="3.81" length="short" rot="R180"/>
<pin name="6" x="12.7" y="1.27" length="short" rot="R180"/>
<pin name="7" x="12.7" y="-1.27" length="short" rot="R180"/>
<pin name="8" x="12.7" y="-3.81" length="short" rot="R180"/>
</symbol><symbol name="P7_CrystalSMD32152Pin32x15m">
<wire x1="-7.62" y1="2.54" x2="7.62" y2="2.54" width="0.254" layer="94"/>
<wire x1="7.62" y1="2.54" x2="7.62" y2="-2.54" width="0.254" layer="94"/>
<wire x1="7.62" y1="-2.54" x2="-7.62" y2="-2.54" width="0.254" layer="94"/>
<wire x1="-7.62" y1="-2.54" x2="-7.62" y2="2.54" width="0.254" layer="94"/>
<text x="-7.62" y="3.81" size="1.778" layer="95">&gt;NAME</text>
<text x="-7.62" y="-5.08" size="1.778" layer="96">&gt;VALUE</text>
<pin name="1" x="-12.7" y="0.0" length="short" rot="R0"/>
<pin name="2" x="12.7" y="0.0" length="short" rot="R180"/>
</symbol><symbol name="P8_TDFN81EP2x2mmP05mmEP08x1">
<wire x1="-7.62" y1="7.619999999999999" x2="7.62" y2="7.619999999999999" width="0.254" layer="94"/>
<wire x1="7.62" y1="7.619999999999999" x2="7.62" y2="-7.619999999999999" width="0.254" layer="94"/>
<wire x1="7.62" y1="-7.619999999999999" x2="-7.62" y2="-7.619999999999999" width="0.254" layer="94"/>
<wire x1="-7.62" y1="-7.619999999999999" x2="-7.62" y2="7.619999999999999" width="0.254" layer="94"/>
<text x="-7.62" y="8.889999999999999" size="1.778" layer="95">&gt;NAME</text>
<text x="-7.62" y="-10.16" size="1.778" layer="96">&gt;VALUE</text>
<pin name="1" x="-12.7" y="5.08" length="short" rot="R0"/>
<pin name="2" x="-12.7" y="2.54" length="short" rot="R0"/>
<pin name="3" x="-12.7" y="-0.0" length="short" rot="R0"/>
<pin name="4" x="-12.7" y="-2.54" length="short" rot="R0"/>
<pin name="5" x="-12.7" y="-5.08" length="short" rot="R0"/>
<pin name="6" x="12.7" y="5.08" length="short" rot="R180"/>
<pin name="7" x="12.7" y="2.54" length="short" rot="R180"/>
<pin name="8" x="12.7" y="-0.0" length="short" rot="R180"/>
<pin name="9" x="12.7" y="-2.54" length="short" rot="R180"/>
</symbol><symbol name="P9_SOIC839x49mmP127mm">
<wire x1="-7.62" y1="6.35" x2="7.62" y2="6.35" width="0.254" layer="94"/>
<wire x1="7.62" y1="6.35" x2="7.62" y2="-6.35" width="0.254" layer="94"/>
<wire x1="7.62" y1="-6.35" x2="-7.62" y2="-6.35" width="0.254" layer="94"/>
<wire x1="-7.62" y1="-6.35" x2="-7.62" y2="6.35" width="0.254" layer="94"/>
<text x="-7.62" y="7.619999999999999" size="1.778" layer="95">&gt;NAME</text>
<text x="-7.62" y="-8.89" size="1.778" layer="96">&gt;VALUE</text>
<pin name="1" x="-12.7" y="3.81" length="short" rot="R0"/>
<pin name="2" x="-12.7" y="1.27" length="short" rot="R0"/>
<pin name="3" x="-12.7" y="-1.27" length="short" rot="R0"/>
<pin name="4" x="-12.7" y="-3.81" length="short" rot="R0"/>
<pin name="5" x="12.7" y="3.81" length="short" rot="R180"/>
<pin name="6" x="12.7" y="1.27" length="short" rot="R180"/>
<pin name="7" x="12.7" y="-1.27" length="short" rot="R180"/>
<pin name="8" x="12.7" y="-3.81" length="short" rot="R180"/>
</symbol><symbol name="P10_FPC50P05">
<wire x1="-7.62" y1="34.290000000000006" x2="7.62" y2="34.290000000000006" width="0.254" layer="94"/>
<wire x1="7.62" y1="34.290000000000006" x2="7.62" y2="-34.290000000000006" width="0.254" layer="94"/>
<wire x1="7.62" y1="-34.290000000000006" x2="-7.62" y2="-34.290000000000006" width="0.254" layer="94"/>
<wire x1="-7.62" y1="-34.290000000000006" x2="-7.62" y2="34.290000000000006" width="0.254" layer="94"/>
<text x="-7.62" y="35.56000000000001" size="1.778" layer="95">&gt;NAME</text>
<text x="-7.62" y="-36.830000000000005" size="1.778" layer="96">&gt;VALUE</text>
<pin name="1" x="-12.7" y="31.75" length="short" rot="R0"/>
<pin name="2" x="-12.7" y="29.21" length="short" rot="R0"/>
<pin name="3" x="-12.7" y="26.67" length="short" rot="R0"/>
<pin name="4" x="-12.7" y="24.13" length="short" rot="R0"/>
<pin name="5" x="-12.7" y="21.59" length="short" rot="R0"/>
<pin name="6" x="-12.7" y="19.05" length="short" rot="R0"/>
<pin name="7" x="-12.7" y="16.51" length="short" rot="R0"/>
<pin name="8" x="-12.7" y="13.97" length="short" rot="R0"/>
<pin name="9" x="-12.7" y="11.43" length="short" rot="R0"/>
<pin name="10" x="-12.7" y="8.89" length="short" rot="R0"/>
<pin name="11" x="-12.7" y="6.35" length="short" rot="R0"/>
<pin name="12" x="-12.7" y="3.81" length="short" rot="R0"/>
<pin name="13" x="-12.7" y="1.27" length="short" rot="R0"/>
<pin name="14" x="-12.7" y="-1.27" length="short" rot="R0"/>
<pin name="15" x="-12.7" y="-3.81" length="short" rot="R0"/>
<pin name="16" x="-12.7" y="-6.35" length="short" rot="R0"/>
<pin name="17" x="-12.7" y="-8.89" length="short" rot="R0"/>
<pin name="18" x="-12.7" y="-11.43" length="short" rot="R0"/>
<pin name="19" x="-12.7" y="-13.97" length="short" rot="R0"/>
<pin name="20" x="-12.7" y="-16.51" length="short" rot="R0"/>
<pin name="21" x="-12.7" y="-19.05" length="short" rot="R0"/>
<pin name="22" x="-12.7" y="-21.59" length="short" rot="R0"/>
<pin name="23" x="-12.7" y="-24.13" length="short" rot="R0"/>
<pin name="24" x="-12.7" y="-26.67" length="short" rot="R0"/>
<pin name="25" x="-12.7" y="-29.21" length="short" rot="R0"/>
<pin name="26" x="-12.7" y="-31.75" length="short" rot="R0"/>
<pin name="27" x="12.7" y="31.75" length="short" rot="R180"/>
<pin name="28" x="12.7" y="29.21" length="short" rot="R180"/>
<pin name="29" x="12.7" y="26.67" length="short" rot="R180"/>
<pin name="30" x="12.7" y="24.13" length="short" rot="R180"/>
<pin name="31" x="12.7" y="21.59" length="short" rot="R180"/>
<pin name="32" x="12.7" y="19.05" length="short" rot="R180"/>
<pin name="33" x="12.7" y="16.51" length="short" rot="R180"/>
<pin name="34" x="12.7" y="13.97" length="short" rot="R180"/>
<pin name="35" x="12.7" y="11.43" length="short" rot="R180"/>
<pin name="36" x="12.7" y="8.89" length="short" rot="R180"/>
<pin name="37" x="12.7" y="6.35" length="short" rot="R180"/>
<pin name="38" x="12.7" y="3.81" length="short" rot="R180"/>
<pin name="39" x="12.7" y="1.27" length="short" rot="R180"/>
<pin name="40" x="12.7" y="-1.27" length="short" rot="R180"/>
<pin name="41" x="12.7" y="-3.81" length="short" rot="R180"/>
<pin name="42" x="12.7" y="-6.35" length="short" rot="R180"/>
<pin name="43" x="12.7" y="-8.89" length="short" rot="R180"/>
<pin name="44" x="12.7" y="-11.43" length="short" rot="R180"/>
<pin name="45" x="12.7" y="-13.97" length="short" rot="R180"/>
<pin name="46" x="12.7" y="-16.51" length="short" rot="R180"/>
<pin name="47" x="12.7" y="-19.05" length="short" rot="R180"/>
<pin name="48" x="12.7" y="-21.59" length="short" rot="R180"/>
<pin name="49" x="12.7" y="-24.13" length="short" rot="R180"/>
<pin name="50" x="12.7" y="-26.67" length="short" rot="R180"/>
<pin name="MP" x="12.7" y="-29.21" length="short" rot="R180"/>
<pin name="MP@2" x="12.7" y="-31.75" length="short" rot="R180"/>
</symbol><symbol name="P11_TSSOP844x3mmP065mm">
<wire x1="-7.62" y1="6.35" x2="7.62" y2="6.35" width="0.254" layer="94"/>
<wire x1="7.62" y1="6.35" x2="7.62" y2="-6.35" width="0.254" layer="94"/>
<wire x1="7.62" y1="-6.35" x2="-7.62" y2="-6.35" width="0.254" layer="94"/>
<wire x1="-7.62" y1="-6.35" x2="-7.62" y2="6.35" width="0.254" layer="94"/>
<text x="-7.62" y="7.619999999999999" size="1.778" layer="95">&gt;NAME</text>
<text x="-7.62" y="-8.89" size="1.778" layer="96">&gt;VALUE</text>
<pin name="1" x="-12.7" y="3.81" length="short" rot="R0"/>
<pin name="2" x="-12.7" y="1.27" length="short" rot="R0"/>
<pin name="3" x="-12.7" y="-1.27" length="short" rot="R0"/>
<pin name="4" x="-12.7" y="-3.81" length="short" rot="R0"/>
<pin name="5" x="12.7" y="3.81" length="short" rot="R180"/>
<pin name="6" x="12.7" y="1.27" length="short" rot="R180"/>
<pin name="7" x="12.7" y="-1.27" length="short" rot="R180"/>
<pin name="8" x="12.7" y="-3.81" length="short" rot="R180"/>
</symbol><symbol name="P12_SOT23">
<wire x1="-7.62" y1="3.81" x2="7.62" y2="3.81" width="0.254" layer="94"/>
<wire x1="7.62" y1="3.81" x2="7.62" y2="-3.81" width="0.254" layer="94"/>
<wire x1="7.62" y1="-3.81" x2="-7.62" y2="-3.81" width="0.254" layer="94"/>
<wire x1="-7.62" y1="-3.81" x2="-7.62" y2="3.81" width="0.254" layer="94"/>
<text x="-7.62" y="5.08" size="1.778" layer="95">&gt;NAME</text>
<text x="-7.62" y="-6.35" size="1.778" layer="96">&gt;VALUE</text>
<pin name="1" x="-12.7" y="1.27" length="short" rot="R0"/>
<pin name="2" x="-12.7" y="-1.27" length="short" rot="R0"/>
<pin name="3" x="12.7" y="1.27" length="short" rot="R180"/>
</symbol><symbol name="P13_SOT563">
<wire x1="-7.62" y1="5.08" x2="7.62" y2="5.08" width="0.254" layer="94"/>
<wire x1="7.62" y1="5.08" x2="7.62" y2="-5.08" width="0.254" layer="94"/>
<wire x1="7.62" y1="-5.08" x2="-7.62" y2="-5.08" width="0.254" layer="94"/>
<wire x1="-7.62" y1="-5.08" x2="-7.62" y2="5.08" width="0.254" layer="94"/>
<text x="-7.62" y="6.35" size="1.778" layer="95">&gt;NAME</text>
<text x="-7.62" y="-7.62" size="1.778" layer="96">&gt;VALUE</text>
<pin name="1" x="-12.7" y="2.54" length="short" rot="R0"/>
<pin name="2" x="-12.7" y="0.0" length="short" rot="R0"/>
<pin name="3" x="-12.7" y="-2.54" length="short" rot="R0"/>
<pin name="4" x="12.7" y="2.54" length="short" rot="R180"/>
<pin name="5" x="12.7" y="0.0" length="short" rot="R180"/>
<pin name="6" x="12.7" y="-2.54" length="short" rot="R180"/>
</symbol><symbol name="P14_L06031608Metric">
<wire x1="-7.62" y1="2.54" x2="7.62" y2="2.54" width="0.254" layer="94"/>
<wire x1="7.62" y1="2.54" x2="7.62" y2="-2.54" width="0.254" layer="94"/>
<wire x1="7.62" y1="-2.54" x2="-7.62" y2="-2.54" width="0.254" layer="94"/>
<wire x1="-7.62" y1="-2.54" x2="-7.62" y2="2.54" width="0.254" layer="94"/>
<text x="-7.62" y="3.81" size="1.778" layer="95">&gt;NAME</text>
<text x="-7.62" y="-5.08" size="1.778" layer="96">&gt;VALUE</text>
<pin name="1" x="-12.7" y="0.0" length="short" rot="R0"/>
<pin name="2" x="12.7" y="0.0" length="short" rot="R180"/>
</symbol><symbol name="P15_PADS408">
<wire x1="-7.62" y1="3.81" x2="7.62" y2="3.81" width="0.254" layer="94"/>
<wire x1="7.62" y1="3.81" x2="7.62" y2="-3.81" width="0.254" layer="94"/>
<wire x1="7.62" y1="-3.81" x2="-7.62" y2="-3.81" width="0.254" layer="94"/>
<wire x1="-7.62" y1="-3.81" x2="-7.62" y2="3.81" width="0.254" layer="94"/>
<text x="-7.62" y="5.08" size="1.778" layer="95">&gt;NAME</text>
<text x="-7.62" y="-6.35" size="1.778" layer="96">&gt;VALUE</text>
<pin name="1" x="-12.7" y="1.27" length="short" rot="R0"/>
<pin name="2" x="-12.7" y="-1.27" length="short" rot="R0"/>
<pin name="3" x="12.7" y="1.27" length="short" rot="R180"/>
<pin name="4" x="12.7" y="-1.27" length="short" rot="R180"/>
</symbol><symbol name="P16_DSOD323">
<wire x1="-7.62" y1="2.54" x2="7.62" y2="2.54" width="0.254" layer="94"/>
<wire x1="7.62" y1="2.54" x2="7.62" y2="-2.54" width="0.254" layer="94"/>
<wire x1="7.62" y1="-2.54" x2="-7.62" y2="-2.54" width="0.254" layer="94"/>
<wire x1="-7.62" y1="-2.54" x2="-7.62" y2="2.54" width="0.254" layer="94"/>
<text x="-7.62" y="3.81" size="1.778" layer="95">&gt;NAME</text>
<text x="-7.62" y="-5.08" size="1.778" layer="96">&gt;VALUE</text>
<pin name="1" x="-12.7" y="0.0" length="short" rot="R0"/>
<pin name="2" x="12.7" y="0.0" length="short" rot="R180"/>
</symbol><symbol name="P17_L10082520Metric">
<wire x1="-7.62" y1="2.54" x2="7.62" y2="2.54" width="0.254" layer="94"/>
<wire x1="7.62" y1="2.54" x2="7.62" y2="-2.54" width="0.254" layer="94"/>
<wire x1="7.62" y1="-2.54" x2="-7.62" y2="-2.54" width="0.254" layer="94"/>
<wire x1="-7.62" y1="-2.54" x2="-7.62" y2="2.54" width="0.254" layer="94"/>
<text x="-7.62" y="3.81" size="1.778" layer="95">&gt;NAME</text>
<text x="-7.62" y="-5.08" size="1.778" layer="96">&gt;VALUE</text>
<pin name="1" x="-12.7" y="0.0" length="short" rot="R0"/>
<pin name="2" x="12.7" y="0.0" length="short" rot="R180"/>
</symbol><symbol name="P18_WLP4083x083mmP04mm">
<wire x1="-7.62" y1="3.81" x2="7.62" y2="3.81" width="0.254" layer="94"/>
<wire x1="7.62" y1="3.81" x2="7.62" y2="-3.81" width="0.254" layer="94"/>
<wire x1="7.62" y1="-3.81" x2="-7.62" y2="-3.81" width="0.254" layer="94"/>
<wire x1="-7.62" y1="-3.81" x2="-7.62" y2="3.81" width="0.254" layer="94"/>
<text x="-7.62" y="5.08" size="1.778" layer="95">&gt;NAME</text>
<text x="-7.62" y="-6.35" size="1.778" layer="96">&gt;VALUE</text>
<pin name="A1" x="-12.7" y="1.27" length="short" rot="R0"/>
<pin name="A2" x="-12.7" y="-1.27" length="short" rot="R0"/>
<pin name="B1" x="12.7" y="1.27" length="short" rot="R180"/>
<pin name="B2" x="12.7" y="-1.27" length="short" rot="R180"/>
</symbol><symbol name="P19_SOT235">
<wire x1="-7.62" y1="5.08" x2="7.62" y2="5.08" width="0.254" layer="94"/>
<wire x1="7.62" y1="5.08" x2="7.62" y2="-5.08" width="0.254" layer="94"/>
<wire x1="7.62" y1="-5.08" x2="-7.62" y2="-5.08" width="0.254" layer="94"/>
<wire x1="-7.62" y1="-5.08" x2="-7.62" y2="5.08" width="0.254" layer="94"/>
<text x="-7.62" y="6.35" size="1.778" layer="95">&gt;NAME</text>
<text x="-7.62" y="-7.62" size="1.778" layer="96">&gt;VALUE</text>
<pin name="1" x="-12.7" y="2.54" length="short" rot="R0"/>
<pin name="2" x="-12.7" y="0.0" length="short" rot="R0"/>
<pin name="3" x="-12.7" y="-2.54" length="short" rot="R0"/>
<pin name="4" x="12.7" y="2.54" length="short" rot="R180"/>
<pin name="5" x="12.7" y="0.0" length="short" rot="R180"/>
</symbol><symbol name="P20_LGA143x25mmP05mmLayoutBo">
<wire x1="-7.62" y1="10.16" x2="7.62" y2="10.16" width="0.254" layer="94"/>
<wire x1="7.62" y1="10.16" x2="7.62" y2="-10.16" width="0.254" layer="94"/>
<wire x1="7.62" y1="-10.16" x2="-7.62" y2="-10.16" width="0.254" layer="94"/>
<wire x1="-7.62" y1="-10.16" x2="-7.62" y2="10.16" width="0.254" layer="94"/>
<text x="-7.62" y="11.43" size="1.778" layer="95">&gt;NAME</text>
<text x="-7.62" y="-12.7" size="1.778" layer="96">&gt;VALUE</text>
<pin name="1" x="-12.7" y="7.62" length="short" rot="R0"/>
<pin name="2" x="-12.7" y="5.08" length="short" rot="R0"/>
<pin name="3" x="-12.7" y="2.54" length="short" rot="R0"/>
<pin name="4" x="-12.7" y="0.0" length="short" rot="R0"/>
<pin name="5" x="-12.7" y="-2.54" length="short" rot="R0"/>
<pin name="6" x="-12.7" y="-5.08" length="short" rot="R0"/>
<pin name="7" x="-12.7" y="-7.62" length="short" rot="R0"/>
<pin name="8" x="12.7" y="7.62" length="short" rot="R180"/>
<pin name="9" x="12.7" y="5.08" length="short" rot="R180"/>
<pin name="10" x="12.7" y="2.54" length="short" rot="R180"/>
<pin name="11" x="12.7" y="0.0" length="short" rot="R180"/>
<pin name="12" x="12.7" y="-2.54" length="short" rot="R180"/>
<pin name="13" x="12.7" y="-5.08" length="short" rot="R180"/>
<pin name="14" x="12.7" y="-7.62" length="short" rot="R180"/>
</symbol><symbol name="P21_ESP32S3WROOM1">
<wire x1="-7.62" y1="35.56" x2="7.62" y2="35.56" width="0.254" layer="94"/>
<wire x1="7.62" y1="35.56" x2="7.62" y2="-35.56" width="0.254" layer="94"/>
<wire x1="7.62" y1="-35.56" x2="-7.62" y2="-35.56" width="0.254" layer="94"/>
<wire x1="-7.62" y1="-35.56" x2="-7.62" y2="35.56" width="0.254" layer="94"/>
<text x="-7.62" y="36.830000000000005" size="1.778" layer="95">&gt;NAME</text>
<text x="-7.62" y="-38.1" size="1.778" layer="96">&gt;VALUE</text>
<pin name="1" x="-12.7" y="33.02" length="short" rot="R0"/>
<pin name="2" x="-12.7" y="30.48" length="short" rot="R0"/>
<pin name="3" x="-12.7" y="27.94" length="short" rot="R0"/>
<pin name="4" x="-12.7" y="25.4" length="short" rot="R0"/>
<pin name="5" x="-12.7" y="22.86" length="short" rot="R0"/>
<pin name="6" x="-12.7" y="20.32" length="short" rot="R0"/>
<pin name="7" x="-12.7" y="17.78" length="short" rot="R0"/>
<pin name="8" x="-12.7" y="15.24" length="short" rot="R0"/>
<pin name="9" x="-12.7" y="12.7" length="short" rot="R0"/>
<pin name="10" x="-12.7" y="10.16" length="short" rot="R0"/>
<pin name="11" x="-12.7" y="7.62" length="short" rot="R0"/>
<pin name="12" x="-12.7" y="5.08" length="short" rot="R0"/>
<pin name="13" x="-12.7" y="2.54" length="short" rot="R0"/>
<pin name="14" x="-12.7" y="0.0" length="short" rot="R0"/>
<pin name="15" x="-12.7" y="-2.54" length="short" rot="R0"/>
<pin name="16" x="-12.7" y="-5.08" length="short" rot="R0"/>
<pin name="17" x="-12.7" y="-7.62" length="short" rot="R0"/>
<pin name="18" x="-12.7" y="-10.16" length="short" rot="R0"/>
<pin name="19" x="-12.7" y="-12.7" length="short" rot="R0"/>
<pin name="20" x="-12.7" y="-15.24" length="short" rot="R0"/>
<pin name="21" x="-12.7" y="-17.78" length="short" rot="R0"/>
<pin name="22" x="-12.7" y="-20.32" length="short" rot="R0"/>
<pin name="23" x="-12.7" y="-22.86" length="short" rot="R0"/>
<pin name="24" x="-12.7" y="-25.4" length="short" rot="R0"/>
<pin name="25" x="-12.7" y="-27.94" length="short" rot="R0"/>
<pin name="26" x="-12.7" y="-30.48" length="short" rot="R0"/>
<pin name="27" x="-12.7" y="-33.02" length="short" rot="R0"/>
<pin name="28" x="12.7" y="33.02" length="short" rot="R180"/>
<pin name="29" x="12.7" y="30.48" length="short" rot="R180"/>
<pin name="30" x="12.7" y="27.94" length="short" rot="R180"/>
<pin name="31" x="12.7" y="25.4" length="short" rot="R180"/>
<pin name="32" x="12.7" y="22.86" length="short" rot="R180"/>
<pin name="33" x="12.7" y="20.32" length="short" rot="R180"/>
<pin name="34" x="12.7" y="17.78" length="short" rot="R180"/>
<pin name="35" x="12.7" y="15.24" length="short" rot="R180"/>
<pin name="36" x="12.7" y="12.7" length="short" rot="R180"/>
<pin name="37" x="12.7" y="10.16" length="short" rot="R180"/>
<pin name="38" x="12.7" y="7.62" length="short" rot="R180"/>
<pin name="39" x="12.7" y="5.08" length="short" rot="R180"/>
<pin name="40" x="12.7" y="2.54" length="short" rot="R180"/>
<pin name="41" x="12.7" y="0.0" length="short" rot="R180"/>
<pin name="41@2" x="12.7" y="-2.54" length="short" rot="R180"/>
<pin name="41@3" x="12.7" y="-5.08" length="short" rot="R180"/>
<pin name="41@4" x="12.7" y="-7.62" length="short" rot="R180"/>
<pin name="41@5" x="12.7" y="-10.16" length="short" rot="R180"/>
<pin name="41@6" x="12.7" y="-12.7" length="short" rot="R180"/>
<pin name="41@7" x="12.7" y="-15.24" length="short" rot="R180"/>
<pin name="41@8" x="12.7" y="-17.78" length="short" rot="R180"/>
<pin name="41@9" x="12.7" y="-20.32" length="short" rot="R180"/>
<pin name="41@10" x="12.7" y="-22.86" length="short" rot="R180"/>
<pin name="41@11" x="12.7" y="-25.4" length="short" rot="R180"/>
<pin name="41@12" x="12.7" y="-27.94" length="short" rot="R180"/>
<pin name="41@13" x="12.7" y="-30.48" length="short" rot="R180"/>
</symbol><symbol name="P22_TSSOP2044x65mmP065mm">
<wire x1="-7.62" y1="13.969999999999999" x2="7.62" y2="13.969999999999999" width="0.254" layer="94"/>
<wire x1="7.62" y1="13.969999999999999" x2="7.62" y2="-13.969999999999999" width="0.254" layer="94"/>
<wire x1="7.62" y1="-13.969999999999999" x2="-7.62" y2="-13.969999999999999" width="0.254" layer="94"/>
<wire x1="-7.62" y1="-13.969999999999999" x2="-7.62" y2="13.969999999999999" width="0.254" layer="94"/>
<text x="-7.62" y="15.239999999999998" size="1.778" layer="95">&gt;NAME</text>
<text x="-7.62" y="-16.509999999999998" size="1.778" layer="96">&gt;VALUE</text>
<pin name="1" x="-12.7" y="11.43" length="short" rot="R0"/>
<pin name="2" x="-12.7" y="8.89" length="short" rot="R0"/>
<pin name="3" x="-12.7" y="6.35" length="short" rot="R0"/>
<pin name="4" x="-12.7" y="3.81" length="short" rot="R0"/>
<pin name="5" x="-12.7" y="1.27" length="short" rot="R0"/>
<pin name="6" x="-12.7" y="-1.27" length="short" rot="R0"/>
<pin name="7" x="-12.7" y="-3.81" length="short" rot="R0"/>
<pin name="8" x="-12.7" y="-6.35" length="short" rot="R0"/>
<pin name="9" x="-12.7" y="-8.89" length="short" rot="R0"/>
<pin name="10" x="-12.7" y="-11.43" length="short" rot="R0"/>
<pin name="11" x="12.7" y="11.43" length="short" rot="R180"/>
<pin name="12" x="12.7" y="8.89" length="short" rot="R180"/>
<pin name="13" x="12.7" y="6.35" length="short" rot="R180"/>
<pin name="14" x="12.7" y="3.81" length="short" rot="R180"/>
<pin name="15" x="12.7" y="1.27" length="short" rot="R180"/>
<pin name="16" x="12.7" y="-1.27" length="short" rot="R180"/>
<pin name="17" x="12.7" y="-3.81" length="short" rot="R180"/>
<pin name="18" x="12.7" y="-6.35" length="short" rot="R180"/>
<pin name="19" x="12.7" y="-8.89" length="short" rot="R180"/>
<pin name="20" x="12.7" y="-11.43" length="short" rot="R180"/>
</symbol><symbol name="P23_TestPointPadD10mm">
<wire x1="-7.62" y1="2.54" x2="7.62" y2="2.54" width="0.254" layer="94"/>
<wire x1="7.62" y1="2.54" x2="7.62" y2="-2.54" width="0.254" layer="94"/>
<wire x1="7.62" y1="-2.54" x2="-7.62" y2="-2.54" width="0.254" layer="94"/>
<wire x1="-7.62" y1="-2.54" x2="-7.62" y2="2.54" width="0.254" layer="94"/>
<text x="-7.62" y="3.81" size="1.778" layer="95">&gt;NAME</text>
<text x="-7.62" y="-5.08" size="1.778" layer="96">&gt;VALUE</text>
<pin name="1" x="-12.7" y="0.0" length="short" rot="R0"/>
</symbol><symbol name="P24_C04021005Metric24">
<wire x1="-7.62" y1="2.54" x2="7.62" y2="2.54" width="0.254" layer="94"/>
<wire x1="7.62" y1="2.54" x2="7.62" y2="-2.54" width="0.254" layer="94"/>
<wire x1="7.62" y1="-2.54" x2="-7.62" y2="-2.54" width="0.254" layer="94"/>
<wire x1="-7.62" y1="-2.54" x2="-7.62" y2="2.54" width="0.254" layer="94"/>
<text x="-7.62" y="3.81" size="1.778" layer="95">&gt;NAME</text>
<text x="-7.62" y="-5.08" size="1.778" layer="96">&gt;VALUE</text>
<pin name="1" x="-12.7" y="0.0" length="short" rot="R0"/>
<pin name="2" x="12.7" y="0.0" length="short" rot="R180"/>
</symbol><symbol name="P25_ANT7x2">
<wire x1="-7.62" y1="2.54" x2="7.62" y2="2.54" width="0.254" layer="94"/>
<wire x1="7.62" y1="2.54" x2="7.62" y2="-2.54" width="0.254" layer="94"/>
<wire x1="7.62" y1="-2.54" x2="-7.62" y2="-2.54" width="0.254" layer="94"/>
<wire x1="-7.62" y1="-2.54" x2="-7.62" y2="2.54" width="0.254" layer="94"/>
<text x="-7.62" y="3.81" size="1.778" layer="95">&gt;NAME</text>
<text x="-7.62" y="-5.08" size="1.778" layer="96">&gt;VALUE</text>
<pin name="1" x="-12.7" y="0.0" length="short" rot="R0"/>
<pin name="2" x="12.7" y="0.0" length="short" rot="R180"/>
</symbol><symbol name="P26_DSOD32326">
<wire x1="-7.62" y1="2.54" x2="7.62" y2="2.54" width="0.254" layer="94"/>
<wire x1="7.62" y1="2.54" x2="7.62" y2="-2.54" width="0.254" layer="94"/>
<wire x1="7.62" y1="-2.54" x2="-7.62" y2="-2.54" width="0.254" layer="94"/>
<wire x1="-7.62" y1="-2.54" x2="-7.62" y2="2.54" width="0.254" layer="94"/>
<text x="-7.62" y="3.81" size="1.778" layer="95">&gt;NAME</text>
<text x="-7.62" y="-5.08" size="1.778" layer="96">&gt;VALUE</text>
<pin name="1" x="-12.7" y="0.0" length="short" rot="R0"/>
<pin name="2" x="12.7" y="0.0" length="short" rot="R180"/>
</symbol><symbol name="P27_TSSOP2444x78mmP065mm">
<wire x1="-7.62" y1="16.51" x2="7.62" y2="16.51" width="0.254" layer="94"/>
<wire x1="7.62" y1="16.51" x2="7.62" y2="-16.51" width="0.254" layer="94"/>
<wire x1="7.62" y1="-16.51" x2="-7.62" y2="-16.51" width="0.254" layer="94"/>
<wire x1="-7.62" y1="-16.51" x2="-7.62" y2="16.51" width="0.254" layer="94"/>
<text x="-7.62" y="17.78" size="1.778" layer="95">&gt;NAME</text>
<text x="-7.62" y="-19.05" size="1.778" layer="96">&gt;VALUE</text>
<pin name="1" x="-12.7" y="13.97" length="short" rot="R0"/>
<pin name="2" x="-12.7" y="11.43" length="short" rot="R0"/>
<pin name="3" x="-12.7" y="8.89" length="short" rot="R0"/>
<pin name="4" x="-12.7" y="6.35" length="short" rot="R0"/>
<pin name="5" x="-12.7" y="3.81" length="short" rot="R0"/>
<pin name="6" x="-12.7" y="1.27" length="short" rot="R0"/>
<pin name="7" x="-12.7" y="-1.27" length="short" rot="R0"/>
<pin name="8" x="-12.7" y="-3.81" length="short" rot="R0"/>
<pin name="9" x="-12.7" y="-6.35" length="short" rot="R0"/>
<pin name="10" x="-12.7" y="-8.89" length="short" rot="R0"/>
<pin name="11" x="-12.7" y="-11.43" length="short" rot="R0"/>
<pin name="12" x="-12.7" y="-13.97" length="short" rot="R0"/>
<pin name="13" x="12.7" y="13.97" length="short" rot="R180"/>
<pin name="14" x="12.7" y="11.43" length="short" rot="R180"/>
<pin name="15" x="12.7" y="8.89" length="short" rot="R180"/>
<pin name="16" x="12.7" y="6.35" length="short" rot="R180"/>
<pin name="17" x="12.7" y="3.81" length="short" rot="R180"/>
<pin name="18" x="12.7" y="1.27" length="short" rot="R180"/>
<pin name="19" x="12.7" y="-1.27" length="short" rot="R180"/>
<pin name="20" x="12.7" y="-3.81" length="short" rot="R180"/>
<pin name="21" x="12.7" y="-6.35" length="short" rot="R180"/>
<pin name="22" x="12.7" y="-8.89" length="short" rot="R180"/>
<pin name="23" x="12.7" y="-11.43" length="short" rot="R180"/>
<pin name="24" x="12.7" y="-13.97" length="short" rot="R180"/>
</symbol><symbol name="P28_PADS212">
<wire x1="-7.62" y1="2.54" x2="7.62" y2="2.54" width="0.254" layer="94"/>
<wire x1="7.62" y1="2.54" x2="7.62" y2="-2.54" width="0.254" layer="94"/>
<wire x1="7.62" y1="-2.54" x2="-7.62" y2="-2.54" width="0.254" layer="94"/>
<wire x1="-7.62" y1="-2.54" x2="-7.62" y2="2.54" width="0.254" layer="94"/>
<text x="-7.62" y="3.81" size="1.778" layer="95">&gt;NAME</text>
<text x="-7.62" y="-5.08" size="1.778" layer="96">&gt;VALUE</text>
<pin name="1" x="-12.7" y="0.0" length="short" rot="R0"/>
<pin name="2" x="12.7" y="0.0" length="short" rot="R180"/>
</symbol><symbol name="P29_microSDHCHiroseDM3DSF">
<wire x1="-7.62" y1="10.16" x2="7.62" y2="10.16" width="0.254" layer="94"/>
<wire x1="7.62" y1="10.16" x2="7.62" y2="-10.16" width="0.254" layer="94"/>
<wire x1="7.62" y1="-10.16" x2="-7.62" y2="-10.16" width="0.254" layer="94"/>
<wire x1="-7.62" y1="-10.16" x2="-7.62" y2="10.16" width="0.254" layer="94"/>
<text x="-7.62" y="11.43" size="1.778" layer="95">&gt;NAME</text>
<text x="-7.62" y="-12.7" size="1.778" layer="96">&gt;VALUE</text>
<pin name="1" x="-12.7" y="7.62" length="short" rot="R0"/>
<pin name="2" x="-12.7" y="5.08" length="short" rot="R0"/>
<pin name="3" x="-12.7" y="2.54" length="short" rot="R0"/>
<pin name="4" x="-12.7" y="0.0" length="short" rot="R0"/>
<pin name="5" x="-12.7" y="-2.54" length="short" rot="R0"/>
<pin name="6" x="-12.7" y="-5.08" length="short" rot="R0"/>
<pin name="7" x="-12.7" y="-7.62" length="short" rot="R0"/>
<pin name="8" x="12.7" y="7.62" length="short" rot="R180"/>
<pin name="9" x="12.7" y="5.08" length="short" rot="R180"/>
<pin name="10" x="12.7" y="2.54" length="short" rot="R180"/>
<pin name="11" x="12.7" y="0.0" length="short" rot="R180"/>
<pin name="11@2" x="12.7" y="-2.54" length="short" rot="R180"/>
<pin name="11@3" x="12.7" y="-5.08" length="short" rot="R180"/>
<pin name="11@4" x="12.7" y="-7.62" length="short" rot="R180"/>
</symbol><symbol name="P30_SOIC839x49mmP127mm30">
<wire x1="-7.62" y1="6.35" x2="7.62" y2="6.35" width="0.254" layer="94"/>
<wire x1="7.62" y1="6.35" x2="7.62" y2="-6.35" width="0.254" layer="94"/>
<wire x1="7.62" y1="-6.35" x2="-7.62" y2="-6.35" width="0.254" layer="94"/>
<wire x1="-7.62" y1="-6.35" x2="-7.62" y2="6.35" width="0.254" layer="94"/>
<text x="-7.62" y="7.619999999999999" size="1.778" layer="95">&gt;NAME</text>
<text x="-7.62" y="-8.89" size="1.778" layer="96">&gt;VALUE</text>
<pin name="1" x="-12.7" y="3.81" length="short" rot="R0"/>
<pin name="2" x="-12.7" y="1.27" length="short" rot="R0"/>
<pin name="3" x="-12.7" y="-1.27" length="short" rot="R0"/>
<pin name="4" x="-12.7" y="-3.81" length="short" rot="R0"/>
<pin name="5" x="12.7" y="3.81" length="short" rot="R180"/>
<pin name="6" x="12.7" y="1.27" length="short" rot="R180"/>
<pin name="7" x="12.7" y="-1.27" length="short" rot="R180"/>
<pin name="8" x="12.7" y="-3.81" length="short" rot="R180"/>
</symbol><symbol name="P31_R04021005Metric31">
<wire x1="-7.62" y1="2.54" x2="7.62" y2="2.54" width="0.254" layer="94"/>
<wire x1="7.62" y1="2.54" x2="7.62" y2="-2.54" width="0.254" layer="94"/>
<wire x1="7.62" y1="-2.54" x2="-7.62" y2="-2.54" width="0.254" layer="94"/>
<wire x1="-7.62" y1="-2.54" x2="-7.62" y2="2.54" width="0.254" layer="94"/>
<text x="-7.62" y="3.81" size="1.778" layer="95">&gt;NAME</text>
<text x="-7.62" y="-5.08" size="1.778" layer="96">&gt;VALUE</text>
<pin name="1" x="-12.7" y="0.0" length="short" rot="R0"/>
<pin name="2" x="12.7" y="0.0" length="short" rot="R180"/>
</symbol><symbol name="P32_SOT2332">
<wire x1="-7.62" y1="3.81" x2="7.62" y2="3.81" width="0.254" layer="94"/>
<wire x1="7.62" y1="3.81" x2="7.62" y2="-3.81" width="0.254" layer="94"/>
<wire x1="7.62" y1="-3.81" x2="-7.62" y2="-3.81" width="0.254" layer="94"/>
<wire x1="-7.62" y1="-3.81" x2="-7.62" y2="3.81" width="0.254" layer="94"/>
<text x="-7.62" y="5.08" size="1.778" layer="95">&gt;NAME</text>
<text x="-7.62" y="-6.35" size="1.778" layer="96">&gt;VALUE</text>
<pin name="1" x="-12.7" y="1.27" length="short" rot="R0"/>
<pin name="2" x="-12.7" y="-1.27" length="short" rot="R0"/>
<pin name="3" x="12.7" y="1.27" length="short" rot="R180"/>
</symbol><symbol name="P33_SOT23633">
<wire x1="-7.62" y1="5.08" x2="7.62" y2="5.08" width="0.254" layer="94"/>
<wire x1="7.62" y1="5.08" x2="7.62" y2="-5.08" width="0.254" layer="94"/>
<wire x1="7.62" y1="-5.08" x2="-7.62" y2="-5.08" width="0.254" layer="94"/>
<wire x1="-7.62" y1="-5.08" x2="-7.62" y2="5.08" width="0.254" layer="94"/>
<text x="-7.62" y="6.35" size="1.778" layer="95">&gt;NAME</text>
<text x="-7.62" y="-7.62" size="1.778" layer="96">&gt;VALUE</text>
<pin name="1" x="-12.7" y="2.54" length="short" rot="R0"/>
<pin name="2" x="-12.7" y="0.0" length="short" rot="R0"/>
<pin name="3" x="-12.7" y="-2.54" length="short" rot="R0"/>
<pin name="4" x="12.7" y="2.54" length="short" rot="R180"/>
<pin name="5" x="12.7" y="0.0" length="short" rot="R180"/>
<pin name="6" x="12.7" y="-2.54" length="short" rot="R180"/>
</symbol><symbol name="P34_ubloxMAX">
<wire x1="-7.62" y1="12.7" x2="7.62" y2="12.7" width="0.254" layer="94"/>
<wire x1="7.62" y1="12.7" x2="7.62" y2="-12.7" width="0.254" layer="94"/>
<wire x1="7.62" y1="-12.7" x2="-7.62" y2="-12.7" width="0.254" layer="94"/>
<wire x1="-7.62" y1="-12.7" x2="-7.62" y2="12.7" width="0.254" layer="94"/>
<text x="-7.62" y="13.969999999999999" size="1.778" layer="95">&gt;NAME</text>
<text x="-7.62" y="-15.239999999999998" size="1.778" layer="96">&gt;VALUE</text>
<pin name="1" x="-12.7" y="10.16" length="short" rot="R0"/>
<pin name="2" x="-12.7" y="7.62" length="short" rot="R0"/>
<pin name="3" x="-12.7" y="5.08" length="short" rot="R0"/>
<pin name="4" x="-12.7" y="2.54" length="short" rot="R0"/>
<pin name="5" x="-12.7" y="0.0" length="short" rot="R0"/>
<pin name="6" x="-12.7" y="-2.54" length="short" rot="R0"/>
<pin name="7" x="-12.7" y="-5.08" length="short" rot="R0"/>
<pin name="8" x="-12.7" y="-7.62" length="short" rot="R0"/>
<pin name="9" x="-12.7" y="-10.16" length="short" rot="R0"/>
<pin name="10" x="12.7" y="10.16" length="short" rot="R180"/>
<pin name="11" x="12.7" y="7.62" length="short" rot="R180"/>
<pin name="12" x="12.7" y="5.08" length="short" rot="R180"/>
<pin name="13" x="12.7" y="2.54" length="short" rot="R180"/>
<pin name="14" x="12.7" y="0.0" length="short" rot="R180"/>
<pin name="15" x="12.7" y="-2.54" length="short" rot="R180"/>
<pin name="16" x="12.7" y="-5.08" length="short" rot="R180"/>
<pin name="17" x="12.7" y="-7.62" length="short" rot="R180"/>
<pin name="18" x="12.7" y="-10.16" length="short" rot="R180"/>
</symbol><symbol name="P35_POGO6">
<wire x1="-7.62" y1="5.08" x2="7.62" y2="5.08" width="0.254" layer="94"/>
<wire x1="7.62" y1="5.08" x2="7.62" y2="-5.08" width="0.254" layer="94"/>
<wire x1="7.62" y1="-5.08" x2="-7.62" y2="-5.08" width="0.254" layer="94"/>
<wire x1="-7.62" y1="-5.08" x2="-7.62" y2="5.08" width="0.254" layer="94"/>
<text x="-7.62" y="6.35" size="1.778" layer="95">&gt;NAME</text>
<text x="-7.62" y="-7.62" size="1.778" layer="96">&gt;VALUE</text>
<pin name="1" x="-12.7" y="2.54" length="short" rot="R0"/>
<pin name="2" x="-12.7" y="0.0" length="short" rot="R0"/>
<pin name="3" x="-12.7" y="-2.54" length="short" rot="R0"/>
<pin name="4" x="12.7" y="2.54" length="short" rot="R180"/>
<pin name="5" x="12.7" y="0.0" length="short" rot="R180"/>
<pin name="6" x="12.7" y="-2.54" length="short" rot="R180"/>
</symbol><symbol name="P36_PAD15">
<wire x1="-7.62" y1="2.54" x2="7.62" y2="2.54" width="0.254" layer="94"/>
<wire x1="7.62" y1="2.54" x2="7.62" y2="-2.54" width="0.254" layer="94"/>
<wire x1="7.62" y1="-2.54" x2="-7.62" y2="-2.54" width="0.254" layer="94"/>
<wire x1="-7.62" y1="-2.54" x2="-7.62" y2="2.54" width="0.254" layer="94"/>
<text x="-7.62" y="3.81" size="1.778" layer="95">&gt;NAME</text>
<text x="-7.62" y="-5.08" size="1.778" layer="96">&gt;VALUE</text>
<pin name="1" x="-12.7" y="0.0" length="short" rot="R0"/>
</symbol><symbol name="P37_PADS215">
<wire x1="-7.62" y1="2.54" x2="7.62" y2="2.54" width="0.254" layer="94"/>
<wire x1="7.62" y1="2.54" x2="7.62" y2="-2.54" width="0.254" layer="94"/>
<wire x1="7.62" y1="-2.54" x2="-7.62" y2="-2.54" width="0.254" layer="94"/>
<wire x1="-7.62" y1="-2.54" x2="-7.62" y2="2.54" width="0.254" layer="94"/>
<text x="-7.62" y="3.81" size="1.778" layer="95">&gt;NAME</text>
<text x="-7.62" y="-5.08" size="1.778" layer="96">&gt;VALUE</text>
<pin name="1" x="-12.7" y="0.0" length="short" rot="R0"/>
<pin name="2" x="12.7" y="0.0" length="short" rot="R180"/>
</symbol><symbol name="P38_JSTSHBM02BSRSSTB1x021MPP">
<wire x1="-7.62" y1="3.81" x2="7.62" y2="3.81" width="0.254" layer="94"/>
<wire x1="7.62" y1="3.81" x2="7.62" y2="-3.81" width="0.254" layer="94"/>
<wire x1="7.62" y1="-3.81" x2="-7.62" y2="-3.81" width="0.254" layer="94"/>
<wire x1="-7.62" y1="-3.81" x2="-7.62" y2="3.81" width="0.254" layer="94"/>
<text x="-7.62" y="5.08" size="1.778" layer="95">&gt;NAME</text>
<text x="-7.62" y="-6.35" size="1.778" layer="96">&gt;VALUE</text>
<pin name="1" x="-12.7" y="1.27" length="short" rot="R0"/>
<pin name="2" x="-12.7" y="-1.27" length="short" rot="R0"/>
<pin name="MP" x="12.7" y="1.27" length="short" rot="R180"/>
<pin name="MP@2" x="12.7" y="-1.27" length="short" rot="R180"/>
</symbol><symbol name="P39_MSOP83x3mmP065mm">
<wire x1="-7.62" y1="6.35" x2="7.62" y2="6.35" width="0.254" layer="94"/>
<wire x1="7.62" y1="6.35" x2="7.62" y2="-6.35" width="0.254" layer="94"/>
<wire x1="7.62" y1="-6.35" x2="-7.62" y2="-6.35" width="0.254" layer="94"/>
<wire x1="-7.62" y1="-6.35" x2="-7.62" y2="6.35" width="0.254" layer="94"/>
<text x="-7.62" y="7.619999999999999" size="1.778" layer="95">&gt;NAME</text>
<text x="-7.62" y="-8.89" size="1.778" layer="96">&gt;VALUE</text>
<pin name="1" x="-12.7" y="3.81" length="short" rot="R0"/>
<pin name="2" x="-12.7" y="1.27" length="short" rot="R0"/>
<pin name="3" x="-12.7" y="-1.27" length="short" rot="R0"/>
<pin name="4" x="-12.7" y="-3.81" length="short" rot="R0"/>
<pin name="5" x="12.7" y="3.81" length="short" rot="R180"/>
<pin name="6" x="12.7" y="1.27" length="short" rot="R180"/>
<pin name="7" x="12.7" y="-1.27" length="short" rot="R180"/>
<pin name="8" x="12.7" y="-3.81" length="short" rot="R180"/>
</symbol><symbol name="P40_BUZZER9x9">
<wire x1="-7.62" y1="2.54" x2="7.62" y2="2.54" width="0.254" layer="94"/>
<wire x1="7.62" y1="2.54" x2="7.62" y2="-2.54" width="0.254" layer="94"/>
<wire x1="7.62" y1="-2.54" x2="-7.62" y2="-2.54" width="0.254" layer="94"/>
<wire x1="-7.62" y1="-2.54" x2="-7.62" y2="2.54" width="0.254" layer="94"/>
<text x="-7.62" y="3.81" size="1.778" layer="95">&gt;NAME</text>
<text x="-7.62" y="-5.08" size="1.778" layer="96">&gt;VALUE</text>
<pin name="1" x="-12.7" y="0.0" length="short" rot="R0"/>
<pin name="2" x="12.7" y="0.0" length="short" rot="R180"/>
</symbol><symbol name="P41_PADS21541">
<wire x1="-7.62" y1="2.54" x2="7.62" y2="2.54" width="0.254" layer="94"/>
<wire x1="7.62" y1="2.54" x2="7.62" y2="-2.54" width="0.254" layer="94"/>
<wire x1="7.62" y1="-2.54" x2="-7.62" y2="-2.54" width="0.254" layer="94"/>
<wire x1="-7.62" y1="-2.54" x2="-7.62" y2="2.54" width="0.254" layer="94"/>
<text x="-7.62" y="3.81" size="1.778" layer="95">&gt;NAME</text>
<text x="-7.62" y="-5.08" size="1.778" layer="96">&gt;VALUE</text>
<pin name="1" x="-12.7" y="0.0" length="short" rot="R0"/>
<pin name="2" x="12.7" y="0.0" length="short" rot="R180"/>
</symbol><symbol name="P42_TSSOP1444x5mmP065mm">
<wire x1="-7.62" y1="10.16" x2="7.62" y2="10.16" width="0.254" layer="94"/>
<wire x1="7.62" y1="10.16" x2="7.62" y2="-10.16" width="0.254" layer="94"/>
<wire x1="7.62" y1="-10.16" x2="-7.62" y2="-10.16" width="0.254" layer="94"/>
<wire x1="-7.62" y1="-10.16" x2="-7.62" y2="10.16" width="0.254" layer="94"/>
<text x="-7.62" y="11.43" size="1.778" layer="95">&gt;NAME</text>
<text x="-7.62" y="-12.7" size="1.778" layer="96">&gt;VALUE</text>
<pin name="1" x="-12.7" y="7.62" length="short" rot="R0"/>
<pin name="2" x="-12.7" y="5.08" length="short" rot="R0"/>
<pin name="3" x="-12.7" y="2.54" length="short" rot="R0"/>
<pin name="4" x="-12.7" y="0.0" length="short" rot="R0"/>
<pin name="5" x="-12.7" y="-2.54" length="short" rot="R0"/>
<pin name="6" x="-12.7" y="-5.08" length="short" rot="R0"/>
<pin name="7" x="-12.7" y="-7.62" length="short" rot="R0"/>
<pin name="8" x="12.7" y="7.62" length="short" rot="R180"/>
<pin name="9" x="12.7" y="5.08" length="short" rot="R180"/>
<pin name="10" x="12.7" y="2.54" length="short" rot="R180"/>
<pin name="11" x="12.7" y="0.0" length="short" rot="R180"/>
<pin name="12" x="12.7" y="-2.54" length="short" rot="R180"/>
<pin name="13" x="12.7" y="-5.08" length="short" rot="R180"/>
<pin name="14" x="12.7" y="-7.62" length="short" rot="R180"/>
</symbol><symbol name="P43_DSOD123">
<wire x1="-7.62" y1="2.54" x2="7.62" y2="2.54" width="0.254" layer="94"/>
<wire x1="7.62" y1="2.54" x2="7.62" y2="-2.54" width="0.254" layer="94"/>
<wire x1="7.62" y1="-2.54" x2="-7.62" y2="-2.54" width="0.254" layer="94"/>
<wire x1="-7.62" y1="-2.54" x2="-7.62" y2="2.54" width="0.254" layer="94"/>
<text x="-7.62" y="3.81" size="1.778" layer="95">&gt;NAME</text>
<text x="-7.62" y="-5.08" size="1.778" layer="96">&gt;VALUE</text>
<pin name="1" x="-12.7" y="0.0" length="short" rot="R0"/>
<pin name="2" x="12.7" y="0.0" length="short" rot="R180"/>
</symbol></symbols><devicesets><deviceset name="P1_C04021005Metric" prefix="X"><gates><gate name="G$1" symbol="P1_C04021005Metric" x="0" y="0"/></gates><devices><device name="" package="C_0402_1005Metric"><connects><connect gate="G$1" pin="1" pad="1"/><connect gate="G$1" pin="2" pad="2"/></connects><technologies><technology name=""/></technologies></device></devices></deviceset><deviceset name="P2_R04021005Metric" prefix="X"><gates><gate name="G$1" symbol="P2_R04021005Metric" x="0" y="0"/></gates><devices><device name="" package="R_0402_1005Metric"><connects><connect gate="G$1" pin="1" pad="1"/><connect gate="G$1" pin="2" pad="2"/></connects><technologies><technology name=""/></technologies></device></devices></deviceset><deviceset name="P3_C06031608Metric" prefix="X"><gates><gate name="G$1" symbol="P3_C06031608Metric" x="0" y="0"/></gates><devices><device name="" package="C_0603_1608Metric"><connects><connect gate="G$1" pin="1" pad="1"/><connect gate="G$1" pin="2" pad="2"/></connects><technologies><technology name=""/></technologies></device></devices></deviceset><deviceset name="P4_R06031608Metric" prefix="X"><gates><gate name="G$1" symbol="P4_R06031608Metric" x="0" y="0"/></gates><devices><device name="" package="R_0603_1608Metric"><connects><connect gate="G$1" pin="1" pad="1"/><connect gate="G$1" pin="2" pad="2"/></connects><technologies><technology name=""/></technologies></device></devices></deviceset><deviceset name="P5_SOT236" prefix="X"><gates><gate name="G$1" symbol="P5_SOT236" x="0" y="0"/></gates><devices><device name="" package="SOT-23-6"><connects><connect gate="G$1" pin="1" pad="1"/><connect gate="G$1" pin="2" pad="2"/><connect gate="G$1" pin="3" pad="3"/><connect gate="G$1" pin="4" pad="4"/><connect gate="G$1" pin="5" pad="5"/><connect gate="G$1" pin="6" pad="6"/></connects><technologies><technology name=""/></technologies></device></devices></deviceset><deviceset name="P6_SERVICE2x4" prefix="X"><gates><gate name="G$1" symbol="P6_SERVICE2x4" x="0" y="0"/></gates><devices><device name="" package="SERVICE_2x4"><connects><connect gate="G$1" pin="1" pad="1"/><connect gate="G$1" pin="2" pad="2"/><connect gate="G$1" pin="3" pad="3"/><connect gate="G$1" pin="4" pad="4"/><connect gate="G$1" pin="5" pad="5"/><connect gate="G$1" pin="6" pad="6"/><connect gate="G$1" pin="7" pad="7"/><connect gate="G$1" pin="8" pad="8"/></connects><technologies><technology name=""/></technologies></device></devices></deviceset><deviceset name="P7_CrystalSMD32152Pin32x15m" prefix="X"><gates><gate name="G$1" symbol="P7_CrystalSMD32152Pin32x15m" x="0" y="0"/></gates><devices><device name="" package="Crystal_SMD_3215-2Pin_3.2x1.5mm"><connects><connect gate="G$1" pin="1" pad="1"/><connect gate="G$1" pin="2" pad="2"/></connects><technologies><technology name=""/></technologies></device></devices></deviceset><deviceset name="P8_TDFN81EP2x2mmP05mmEP08x1" prefix="X"><gates><gate name="G$1" symbol="P8_TDFN81EP2x2mmP05mmEP08x1" x="0" y="0"/></gates><devices><device name="" package="TDFN-8-1EP_2x2mm_P0.5mm_EP0.8x1.2mm"><connects><connect gate="G$1" pin="1" pad="1"/><connect gate="G$1" pin="2" pad="2"/><connect gate="G$1" pin="3" pad="3"/><connect gate="G$1" pin="4" pad="4"/><connect gate="G$1" pin="5" pad="5"/><connect gate="G$1" pin="6" pad="6"/><connect gate="G$1" pin="7" pad="7"/><connect gate="G$1" pin="8" pad="8"/><connect gate="G$1" pin="9" pad="9"/></connects><technologies><technology name=""/></technologies></device></devices></deviceset><deviceset name="P9_SOIC839x49mmP127mm" prefix="X"><gates><gate name="G$1" symbol="P9_SOIC839x49mmP127mm" x="0" y="0"/></gates><devices><device name="" package="SOIC-8_3.9x4.9mm_P1.27mm"><connects><connect gate="G$1" pin="1" pad="1"/><connect gate="G$1" pin="2" pad="2"/><connect gate="G$1" pin="3" pad="3"/><connect gate="G$1" pin="4" pad="4"/><connect gate="G$1" pin="5" pad="5"/><connect gate="G$1" pin="6" pad="6"/><connect gate="G$1" pin="7" pad="7"/><connect gate="G$1" pin="8" pad="8"/></connects><technologies><technology name=""/></technologies></device></devices></deviceset><deviceset name="P10_FPC50P05" prefix="X"><gates><gate name="G$1" symbol="P10_FPC50P05" x="0" y="0"/></gates><devices><device name="" package="FPC_50_P0.5"><connects><connect gate="G$1" pin="1" pad="1"/><connect gate="G$1" pin="2" pad="2"/><connect gate="G$1" pin="3" pad="3"/><connect gate="G$1" pin="4" pad="4"/><connect gate="G$1" pin="5" pad="5"/><connect gate="G$1" pin="6" pad="6"/><connect gate="G$1" pin="7" pad="7"/><connect gate="G$1" pin="8" pad="8"/><connect gate="G$1" pin="9" pad="9"/><connect gate="G$1" pin="10" pad="10"/><connect gate="G$1" pin="11" pad="11"/><connect gate="G$1" pin="12" pad="12"/><connect gate="G$1" pin="13" pad="13"/><connect gate="G$1" pin="14" pad="14"/><connect gate="G$1" pin="15" pad="15"/><connect gate="G$1" pin="16" pad="16"/><connect gate="G$1" pin="17" pad="17"/><connect gate="G$1" pin="18" pad="18"/><connect gate="G$1" pin="19" pad="19"/><connect gate="G$1" pin="20" pad="20"/><connect gate="G$1" pin="21" pad="21"/><connect gate="G$1" pin="22" pad="22"/><connect gate="G$1" pin="23" pad="23"/><connect gate="G$1" pin="24" pad="24"/><connect gate="G$1" pin="25" pad="25"/><connect gate="G$1" pin="26" pad="26"/><connect gate="G$1" pin="27" pad="27"/><connect gate="G$1" pin="28" pad="28"/><connect gate="G$1" pin="29" pad="29"/><connect gate="G$1" pin="30" pad="30"/><connect gate="G$1" pin="31" pad="31"/><connect gate="G$1" pin="32" pad="32"/><connect gate="G$1" pin="33" pad="33"/><connect gate="G$1" pin="34" pad="34"/><connect gate="G$1" pin="35" pad="35"/><connect gate="G$1" pin="36" pad="36"/><connect gate="G$1" pin="37" pad="37"/><connect gate="G$1" pin="38" pad="38"/><connect gate="G$1" pin="39" pad="39"/><connect gate="G$1" pin="40" pad="40"/><connect gate="G$1" pin="41" pad="41"/><connect gate="G$1" pin="42" pad="42"/><connect gate="G$1" pin="43" pad="43"/><connect gate="G$1" pin="44" pad="44"/><connect gate="G$1" pin="45" pad="45"/><connect gate="G$1" pin="46" pad="46"/><connect gate="G$1" pin="47" pad="47"/><connect gate="G$1" pin="48" pad="48"/><connect gate="G$1" pin="49" pad="49"/><connect gate="G$1" pin="50" pad="50"/><connect gate="G$1" pin="MP" pad="MP"/><connect gate="G$1" pin="MP@2" pad="MP@2"/></connects><technologies><technology name=""/></technologies></device></devices></deviceset><deviceset name="P11_TSSOP844x3mmP065mm" prefix="X"><gates><gate name="G$1" symbol="P11_TSSOP844x3mmP065mm" x="0" y="0"/></gates><devices><device name="" package="TSSOP-8_4.4x3mm_P0.65mm"><connects><connect gate="G$1" pin="1" pad="1"/><connect gate="G$1" pin="2" pad="2"/><connect gate="G$1" pin="3" pad="3"/><connect gate="G$1" pin="4" pad="4"/><connect gate="G$1" pin="5" pad="5"/><connect gate="G$1" pin="6" pad="6"/><connect gate="G$1" pin="7" pad="7"/><connect gate="G$1" pin="8" pad="8"/></connects><technologies><technology name=""/></technologies></device></devices></deviceset><deviceset name="P12_SOT23" prefix="X"><gates><gate name="G$1" symbol="P12_SOT23" x="0" y="0"/></gates><devices><device name="" package="SOT-23"><connects><connect gate="G$1" pin="1" pad="1"/><connect gate="G$1" pin="2" pad="2"/><connect gate="G$1" pin="3" pad="3"/></connects><technologies><technology name=""/></technologies></device></devices></deviceset><deviceset name="P13_SOT563" prefix="X"><gates><gate name="G$1" symbol="P13_SOT563" x="0" y="0"/></gates><devices><device name="" package="SOT-563"><connects><connect gate="G$1" pin="1" pad="1"/><connect gate="G$1" pin="2" pad="2"/><connect gate="G$1" pin="3" pad="3"/><connect gate="G$1" pin="4" pad="4"/><connect gate="G$1" pin="5" pad="5"/><connect gate="G$1" pin="6" pad="6"/></connects><technologies><technology name=""/></technologies></device></devices></deviceset><deviceset name="P14_L06031608Metric" prefix="X"><gates><gate name="G$1" symbol="P14_L06031608Metric" x="0" y="0"/></gates><devices><device name="" package="L_0603_1608Metric"><connects><connect gate="G$1" pin="1" pad="1"/><connect gate="G$1" pin="2" pad="2"/></connects><technologies><technology name=""/></technologies></device></devices></deviceset><deviceset name="P15_PADS408" prefix="X"><gates><gate name="G$1" symbol="P15_PADS408" x="0" y="0"/></gates><devices><device name="" package="PADS_4_0.8"><connects><connect gate="G$1" pin="1" pad="1"/><connect gate="G$1" pin="2" pad="2"/><connect gate="G$1" pin="3" pad="3"/><connect gate="G$1" pin="4" pad="4"/></connects><technologies><technology name=""/></technologies></device></devices></deviceset><deviceset name="P16_DSOD323" prefix="X"><gates><gate name="G$1" symbol="P16_DSOD323" x="0" y="0"/></gates><devices><device name="" package="D_SOD-323"><connects><connect gate="G$1" pin="1" pad="1"/><connect gate="G$1" pin="2" pad="2"/></connects><technologies><technology name=""/></technologies></device></devices></deviceset><deviceset name="P17_L10082520Metric" prefix="X"><gates><gate name="G$1" symbol="P17_L10082520Metric" x="0" y="0"/></gates><devices><device name="" package="L_1008_2520Metric"><connects><connect gate="G$1" pin="1" pad="1"/><connect gate="G$1" pin="2" pad="2"/></connects><technologies><technology name=""/></technologies></device></devices></deviceset><deviceset name="P18_WLP4083x083mmP04mm" prefix="X"><gates><gate name="G$1" symbol="P18_WLP4083x083mmP04mm" x="0" y="0"/></gates><devices><device name="" package="WLP-4_0.83x0.83mm_P0.4mm"><connects><connect gate="G$1" pin="A1" pad="A1"/><connect gate="G$1" pin="A2" pad="A2"/><connect gate="G$1" pin="B1" pad="B1"/><connect gate="G$1" pin="B2" pad="B2"/></connects><technologies><technology name=""/></technologies></device></devices></deviceset><deviceset name="P19_SOT235" prefix="X"><gates><gate name="G$1" symbol="P19_SOT235" x="0" y="0"/></gates><devices><device name="" package="SOT-23-5"><connects><connect gate="G$1" pin="1" pad="1"/><connect gate="G$1" pin="2" pad="2"/><connect gate="G$1" pin="3" pad="3"/><connect gate="G$1" pin="4" pad="4"/><connect gate="G$1" pin="5" pad="5"/></connects><technologies><technology name=""/></technologies></device></devices></deviceset><deviceset name="P20_LGA143x25mmP05mmLayoutBo" prefix="X"><gates><gate name="G$1" symbol="P20_LGA143x25mmP05mmLayoutBo" x="0" y="0"/></gates><devices><device name="" package="LGA-14_3x2.5mm_P0.5mm_LayoutBorder3x4y"><connects><connect gate="G$1" pin="1" pad="1"/><connect gate="G$1" pin="2" pad="2"/><connect gate="G$1" pin="3" pad="3"/><connect gate="G$1" pin="4" pad="4"/><connect gate="G$1" pin="5" pad="5"/><connect gate="G$1" pin="6" pad="6"/><connect gate="G$1" pin="7" pad="7"/><connect gate="G$1" pin="8" pad="8"/><connect gate="G$1" pin="9" pad="9"/><connect gate="G$1" pin="10" pad="10"/><connect gate="G$1" pin="11" pad="11"/><connect gate="G$1" pin="12" pad="12"/><connect gate="G$1" pin="13" pad="13"/><connect gate="G$1" pin="14" pad="14"/></connects><technologies><technology name=""/></technologies></device></devices></deviceset><deviceset name="P21_ESP32S3WROOM1" prefix="X"><gates><gate name="G$1" symbol="P21_ESP32S3WROOM1" x="0" y="0"/></gates><devices><device name="" package="ESP32-S3-WROOM-1"><connects><connect gate="G$1" pin="1" pad="1"/><connect gate="G$1" pin="2" pad="2"/><connect gate="G$1" pin="3" pad="3"/><connect gate="G$1" pin="4" pad="4"/><connect gate="G$1" pin="5" pad="5"/><connect gate="G$1" pin="6" pad="6"/><connect gate="G$1" pin="7" pad="7"/><connect gate="G$1" pin="8" pad="8"/><connect gate="G$1" pin="9" pad="9"/><connect gate="G$1" pin="10" pad="10"/><connect gate="G$1" pin="11" pad="11"/><connect gate="G$1" pin="12" pad="12"/><connect gate="G$1" pin="13" pad="13"/><connect gate="G$1" pin="14" pad="14"/><connect gate="G$1" pin="15" pad="15"/><connect gate="G$1" pin="16" pad="16"/><connect gate="G$1" pin="17" pad="17"/><connect gate="G$1" pin="18" pad="18"/><connect gate="G$1" pin="19" pad="19"/><connect gate="G$1" pin="20" pad="20"/><connect gate="G$1" pin="21" pad="21"/><connect gate="G$1" pin="22" pad="22"/><connect gate="G$1" pin="23" pad="23"/><connect gate="G$1" pin="24" pad="24"/><connect gate="G$1" pin="25" pad="25"/><connect gate="G$1" pin="26" pad="26"/><connect gate="G$1" pin="27" pad="27"/><connect gate="G$1" pin="28" pad="28"/><connect gate="G$1" pin="29" pad="29"/><connect gate="G$1" pin="30" pad="30"/><connect gate="G$1" pin="31" pad="31"/><connect gate="G$1" pin="32" pad="32"/><connect gate="G$1" pin="33" pad="33"/><connect gate="G$1" pin="34" pad="34"/><connect gate="G$1" pin="35" pad="35"/><connect gate="G$1" pin="36" pad="36"/><connect gate="G$1" pin="37" pad="37"/><connect gate="G$1" pin="38" pad="38"/><connect gate="G$1" pin="39" pad="39"/><connect gate="G$1" pin="40" pad="40"/><connect gate="G$1" pin="41" pad="41"/><connect gate="G$1" pin="41@2" pad="41@2"/><connect gate="G$1" pin="41@3" pad="41@3"/><connect gate="G$1" pin="41@4" pad="41@4"/><connect gate="G$1" pin="41@5" pad="41@5"/><connect gate="G$1" pin="41@6" pad="41@6"/><connect gate="G$1" pin="41@7" pad="41@7"/><connect gate="G$1" pin="41@8" pad="41@8"/><connect gate="G$1" pin="41@9" pad="41@9"/><connect gate="G$1" pin="41@10" pad="41@10"/><connect gate="G$1" pin="41@11" pad="41@11"/><connect gate="G$1" pin="41@12" pad="41@12"/><connect gate="G$1" pin="41@13" pad="41@13"/></connects><technologies><technology name=""/></technologies></device></devices></deviceset><deviceset name="P22_TSSOP2044x65mmP065mm" prefix="X"><gates><gate name="G$1" symbol="P22_TSSOP2044x65mmP065mm" x="0" y="0"/></gates><devices><device name="" package="TSSOP-20_4.4x6.5mm_P0.65mm"><connects><connect gate="G$1" pin="1" pad="1"/><connect gate="G$1" pin="2" pad="2"/><connect gate="G$1" pin="3" pad="3"/><connect gate="G$1" pin="4" pad="4"/><connect gate="G$1" pin="5" pad="5"/><connect gate="G$1" pin="6" pad="6"/><connect gate="G$1" pin="7" pad="7"/><connect gate="G$1" pin="8" pad="8"/><connect gate="G$1" pin="9" pad="9"/><connect gate="G$1" pin="10" pad="10"/><connect gate="G$1" pin="11" pad="11"/><connect gate="G$1" pin="12" pad="12"/><connect gate="G$1" pin="13" pad="13"/><connect gate="G$1" pin="14" pad="14"/><connect gate="G$1" pin="15" pad="15"/><connect gate="G$1" pin="16" pad="16"/><connect gate="G$1" pin="17" pad="17"/><connect gate="G$1" pin="18" pad="18"/><connect gate="G$1" pin="19" pad="19"/><connect gate="G$1" pin="20" pad="20"/></connects><technologies><technology name=""/></technologies></device></devices></deviceset><deviceset name="P23_TestPointPadD10mm" prefix="X"><gates><gate name="G$1" symbol="P23_TestPointPadD10mm" x="0" y="0"/></gates><devices><device name="" package="TestPoint_Pad_D1.0mm"><connects><connect gate="G$1" pin="1" pad="1"/></connects><technologies><technology name=""/></technologies></device></devices></deviceset><deviceset name="P24_C04021005Metric24" prefix="X"><gates><gate name="G$1" symbol="P24_C04021005Metric24" x="0" y="0"/></gates><devices><device name="" package="C_0402_1005Metric_24"><connects><connect gate="G$1" pin="1" pad="1"/><connect gate="G$1" pin="2" pad="2"/></connects><technologies><technology name=""/></technologies></device></devices></deviceset><deviceset name="P25_ANT7x2" prefix="X"><gates><gate name="G$1" symbol="P25_ANT7x2" x="0" y="0"/></gates><devices><device name="" package="ANT_7x2"><connects><connect gate="G$1" pin="1" pad="1"/><connect gate="G$1" pin="2" pad="2"/></connects><technologies><technology name=""/></technologies></device></devices></deviceset><deviceset name="P26_DSOD32326" prefix="X"><gates><gate name="G$1" symbol="P26_DSOD32326" x="0" y="0"/></gates><devices><device name="" package="D_SOD-323_26"><connects><connect gate="G$1" pin="1" pad="1"/><connect gate="G$1" pin="2" pad="2"/></connects><technologies><technology name=""/></technologies></device></devices></deviceset><deviceset name="P27_TSSOP2444x78mmP065mm" prefix="X"><gates><gate name="G$1" symbol="P27_TSSOP2444x78mmP065mm" x="0" y="0"/></gates><devices><device name="" package="TSSOP-24_4.4x7.8mm_P0.65mm"><connects><connect gate="G$1" pin="1" pad="1"/><connect gate="G$1" pin="2" pad="2"/><connect gate="G$1" pin="3" pad="3"/><connect gate="G$1" pin="4" pad="4"/><connect gate="G$1" pin="5" pad="5"/><connect gate="G$1" pin="6" pad="6"/><connect gate="G$1" pin="7" pad="7"/><connect gate="G$1" pin="8" pad="8"/><connect gate="G$1" pin="9" pad="9"/><connect gate="G$1" pin="10" pad="10"/><connect gate="G$1" pin="11" pad="11"/><connect gate="G$1" pin="12" pad="12"/><connect gate="G$1" pin="13" pad="13"/><connect gate="G$1" pin="14" pad="14"/><connect gate="G$1" pin="15" pad="15"/><connect gate="G$1" pin="16" pad="16"/><connect gate="G$1" pin="17" pad="17"/><connect gate="G$1" pin="18" pad="18"/><connect gate="G$1" pin="19" pad="19"/><connect gate="G$1" pin="20" pad="20"/><connect gate="G$1" pin="21" pad="21"/><connect gate="G$1" pin="22" pad="22"/><connect gate="G$1" pin="23" pad="23"/><connect gate="G$1" pin="24" pad="24"/></connects><technologies><technology name=""/></technologies></device></devices></deviceset><deviceset name="P28_PADS212" prefix="X"><gates><gate name="G$1" symbol="P28_PADS212" x="0" y="0"/></gates><devices><device name="" package="PADS_2_1.2"><connects><connect gate="G$1" pin="1" pad="1"/><connect gate="G$1" pin="2" pad="2"/></connects><technologies><technology name=""/></technologies></device></devices></deviceset><deviceset name="P29_microSDHCHiroseDM3DSF" prefix="X"><gates><gate name="G$1" symbol="P29_microSDHCHiroseDM3DSF" x="0" y="0"/></gates><devices><device name="" package="microSD_HC_Hirose_DM3D-SF"><connects><connect gate="G$1" pin="1" pad="1"/><connect gate="G$1" pin="2" pad="2"/><connect gate="G$1" pin="3" pad="3"/><connect gate="G$1" pin="4" pad="4"/><connect gate="G$1" pin="5" pad="5"/><connect gate="G$1" pin="6" pad="6"/><connect gate="G$1" pin="7" pad="7"/><connect gate="G$1" pin="8" pad="8"/><connect gate="G$1" pin="9" pad="9"/><connect gate="G$1" pin="10" pad="10"/><connect gate="G$1" pin="11" pad="11"/><connect gate="G$1" pin="11@2" pad="11@2"/><connect gate="G$1" pin="11@3" pad="11@3"/><connect gate="G$1" pin="11@4" pad="11@4"/></connects><technologies><technology name=""/></technologies></device></devices></deviceset><deviceset name="P30_SOIC839x49mmP127mm30" prefix="X"><gates><gate name="G$1" symbol="P30_SOIC839x49mmP127mm30" x="0" y="0"/></gates><devices><device name="" package="SOIC-8_3.9x4.9mm_P1.27mm_30"><connects><connect gate="G$1" pin="1" pad="1"/><connect gate="G$1" pin="2" pad="2"/><connect gate="G$1" pin="3" pad="3"/><connect gate="G$1" pin="4" pad="4"/><connect gate="G$1" pin="5" pad="5"/><connect gate="G$1" pin="6" pad="6"/><connect gate="G$1" pin="7" pad="7"/><connect gate="G$1" pin="8" pad="8"/></connects><technologies><technology name=""/></technologies></device></devices></deviceset><deviceset name="P31_R04021005Metric31" prefix="X"><gates><gate name="G$1" symbol="P31_R04021005Metric31" x="0" y="0"/></gates><devices><device name="" package="R_0402_1005Metric_31"><connects><connect gate="G$1" pin="1" pad="1"/><connect gate="G$1" pin="2" pad="2"/></connects><technologies><technology name=""/></technologies></device></devices></deviceset><deviceset name="P32_SOT2332" prefix="X"><gates><gate name="G$1" symbol="P32_SOT2332" x="0" y="0"/></gates><devices><device name="" package="SOT-23_32"><connects><connect gate="G$1" pin="1" pad="1"/><connect gate="G$1" pin="2" pad="2"/><connect gate="G$1" pin="3" pad="3"/></connects><technologies><technology name=""/></technologies></device></devices></deviceset><deviceset name="P33_SOT23633" prefix="X"><gates><gate name="G$1" symbol="P33_SOT23633" x="0" y="0"/></gates><devices><device name="" package="SOT-23-6_33"><connects><connect gate="G$1" pin="1" pad="1"/><connect gate="G$1" pin="2" pad="2"/><connect gate="G$1" pin="3" pad="3"/><connect gate="G$1" pin="4" pad="4"/><connect gate="G$1" pin="5" pad="5"/><connect gate="G$1" pin="6" pad="6"/></connects><technologies><technology name=""/></technologies></device></devices></deviceset><deviceset name="P34_ubloxMAX" prefix="X"><gates><gate name="G$1" symbol="P34_ubloxMAX" x="0" y="0"/></gates><devices><device name="" package="ublox_MAX"><connects><connect gate="G$1" pin="1" pad="1"/><connect gate="G$1" pin="2" pad="2"/><connect gate="G$1" pin="3" pad="3"/><connect gate="G$1" pin="4" pad="4"/><connect gate="G$1" pin="5" pad="5"/><connect gate="G$1" pin="6" pad="6"/><connect gate="G$1" pin="7" pad="7"/><connect gate="G$1" pin="8" pad="8"/><connect gate="G$1" pin="9" pad="9"/><connect gate="G$1" pin="10" pad="10"/><connect gate="G$1" pin="11" pad="11"/><connect gate="G$1" pin="12" pad="12"/><connect gate="G$1" pin="13" pad="13"/><connect gate="G$1" pin="14" pad="14"/><connect gate="G$1" pin="15" pad="15"/><connect gate="G$1" pin="16" pad="16"/><connect gate="G$1" pin="17" pad="17"/><connect gate="G$1" pin="18" pad="18"/></connects><technologies><technology name=""/></technologies></device></devices></deviceset><deviceset name="P35_POGO6" prefix="X"><gates><gate name="G$1" symbol="P35_POGO6" x="0" y="0"/></gates><devices><device name="" package="POGO_6"><connects><connect gate="G$1" pin="1" pad="1"/><connect gate="G$1" pin="2" pad="2"/><connect gate="G$1" pin="3" pad="3"/><connect gate="G$1" pin="4" pad="4"/><connect gate="G$1" pin="5" pad="5"/><connect gate="G$1" pin="6" pad="6"/></connects><technologies><technology name=""/></technologies></device></devices></deviceset><deviceset name="P36_PAD15" prefix="X"><gates><gate name="G$1" symbol="P36_PAD15" x="0" y="0"/></gates><devices><device name="" package="PAD_1.5"><connects><connect gate="G$1" pin="1" pad="1"/></connects><technologies><technology name=""/></technologies></device></devices></deviceset><deviceset name="P37_PADS215" prefix="X"><gates><gate name="G$1" symbol="P37_PADS215" x="0" y="0"/></gates><devices><device name="" package="PADS_2_1.5"><connects><connect gate="G$1" pin="1" pad="1"/><connect gate="G$1" pin="2" pad="2"/></connects><technologies><technology name=""/></technologies></device></devices></deviceset><deviceset name="P38_JSTSHBM02BSRSSTB1x021MPP" prefix="X"><gates><gate name="G$1" symbol="P38_JSTSHBM02BSRSSTB1x021MPP" x="0" y="0"/></gates><devices><device name="" package="JST_SH_BM02B-SRSS-TB_1x02-1MP_P1.00mm_Vertical"><connects><connect gate="G$1" pin="1" pad="1"/><connect gate="G$1" pin="2" pad="2"/><connect gate="G$1" pin="MP" pad="MP"/><connect gate="G$1" pin="MP@2" pad="MP@2"/></connects><technologies><technology name=""/></technologies></device></devices></deviceset><deviceset name="P39_MSOP83x3mmP065mm" prefix="X"><gates><gate name="G$1" symbol="P39_MSOP83x3mmP065mm" x="0" y="0"/></gates><devices><device name="" package="MSOP-8_3x3mm_P0.65mm"><connects><connect gate="G$1" pin="1" pad="1"/><connect gate="G$1" pin="2" pad="2"/><connect gate="G$1" pin="3" pad="3"/><connect gate="G$1" pin="4" pad="4"/><connect gate="G$1" pin="5" pad="5"/><connect gate="G$1" pin="6" pad="6"/><connect gate="G$1" pin="7" pad="7"/><connect gate="G$1" pin="8" pad="8"/></connects><technologies><technology name=""/></technologies></device></devices></deviceset><deviceset name="P40_BUZZER9x9" prefix="X"><gates><gate name="G$1" symbol="P40_BUZZER9x9" x="0" y="0"/></gates><devices><device name="" package="BUZZER_9x9"><connects><connect gate="G$1" pin="1" pad="1"/><connect gate="G$1" pin="2" pad="2"/></connects><technologies><technology name=""/></technologies></device></devices></deviceset><deviceset name="P41_PADS21541" prefix="X"><gates><gate name="G$1" symbol="P41_PADS21541" x="0" y="0"/></gates><devices><device name="" package="PADS_2_1.5_41"><connects><connect gate="G$1" pin="1" pad="1"/><connect gate="G$1" pin="2" pad="2"/></connects><technologies><technology name=""/></technologies></device></devices></deviceset><deviceset name="P42_TSSOP1444x5mmP065mm" prefix="X"><gates><gate name="G$1" symbol="P42_TSSOP1444x5mmP065mm" x="0" y="0"/></gates><devices><device name="" package="TSSOP-14_4.4x5mm_P0.65mm"><connects><connect gate="G$1" pin="1" pad="1"/><connect gate="G$1" pin="2" pad="2"/><connect gate="G$1" pin="3" pad="3"/><connect gate="G$1" pin="4" pad="4"/><connect gate="G$1" pin="5" pad="5"/><connect gate="G$1" pin="6" pad="6"/><connect gate="G$1" pin="7" pad="7"/><connect gate="G$1" pin="8" pad="8"/><connect gate="G$1" pin="9" pad="9"/><connect gate="G$1" pin="10" pad="10"/><connect gate="G$1" pin="11" pad="11"/><connect gate="G$1" pin="12" pad="12"/><connect gate="G$1" pin="13" pad="13"/><connect gate="G$1" pin="14" pad="14"/></connects><technologies><technology name=""/></technologies></device></devices></deviceset><deviceset name="P43_DSOD123" prefix="X"><gates><gate name="G$1" symbol="P43_DSOD123" x="0" y="0"/></gates><devices><device name="" package="D_SOD-123"><connects><connect gate="G$1" pin="1" pad="1"/><connect gate="G$1" pin="2" pad="2"/></connects><technologies><technology name=""/></technologies></device></devices></deviceset></devicesets></library></libraries>
<attributes/><variantdefs/><classes><class number="0" name="default" width="0" drill="0"/></classes>
<parts><part name="ANT1" library="dive_revd" deviceset="P25_ANT7x2" device="" value="1575AT43A40"/><part name="BZ1" library="dive_revd" deviceset="P40_BUZZER9x9" device="" value="PKMCS0909E4000"/><part name="C1" library="dive_revd" deviceset="P1_C04021005Metric" device="" value="1uF"/><part name="C2" library="dive_revd" deviceset="P3_C06031608Metric" device="" value="22uF"/><part name="C3" library="dive_revd" deviceset="P1_C04021005Metric" device="" value="100nF"/><part name="C4" library="dive_revd" deviceset="P3_C06031608Metric" device="" value="4.7uF"/><part name="C5" library="dive_revd" deviceset="P3_C06031608Metric" device="" value="4.7uF"/><part name="C6" library="dive_revd" deviceset="P1_C04021005Metric" device="" value="1uF"/><part name="C7" library="dive_revd" deviceset="P3_C06031608Metric" device="" value="10uF"/><part name="C10" library="dive_revd" deviceset="P1_C04021005Metric" device="" value="2.2uF"/><part name="C11" library="dive_revd" deviceset="P1_C04021005Metric" device="" value="100nF"/><part name="C13" library="dive_revd" deviceset="P1_C04021005Metric" device="" value="100nF"/><part name="C20" library="dive_revd" deviceset="P3_C06031608Metric" device="" value="tune"/><part name="C21" library="dive_revd" deviceset="P3_C06031608Metric" device="" value="10uF"/><part name="C22" library="dive_revd" deviceset="P3_C06031608Metric" device="" value="1uF"/><part name="C23" library="dive_revd" deviceset="P3_C06031608Metric" device="" value="10uF"/><part name="C24" library="dive_revd" deviceset="P3_C06031608Metric" device="" value="22uF"/><part name="C25" library="dive_revd" deviceset="P3_C06031608Metric" device="" value="tune"/><part name="C26" library="dive_revd" deviceset="P1_C04021005Metric" device="" value="1nF"/><part name="C27" library="dive_revd" deviceset="P3_C06031608Metric" device="" value="1uF"/><part name="C28" library="dive_revd" deviceset="P3_C06031608Metric" device="" value="1uF"/><part name="C29" library="dive_revd" deviceset="P3_C06031608Metric" device="" value="1uF"/><part name="C30" library="dive_revd" deviceset="P3_C06031608Metric" device="" value="10uF"/><part name="C31" library="dive_revd" deviceset="P3_C06031608Metric" device="" value="22uF"/><part name="C32" library="dive_revd" deviceset="P3_C06031608Metric" device="" value="10uF"/><part name="C33" library="dive_revd" deviceset="P24_C04021005Metric24" device="" value="DNP"/><part name="C34" library="dive_revd" deviceset="P24_C04021005Metric24" device="" value="DNP"/><part name="C36" library="dive_revd" deviceset="P1_C04021005Metric" device="" value="100nF"/><part name="C37" library="dive_revd" deviceset="P1_C04021005Metric" device="" value="100nF"/><part name="C38" library="dive_revd" deviceset="P1_C04021005Metric" device="" value="100nF"/><part name="C39" library="dive_revd" deviceset="P1_C04021005Metric" device="" value="100nF"/><part name="C40" library="dive_revd" deviceset="P1_C04021005Metric" device="" value="100nF"/><part name="C41" library="dive_revd" deviceset="P1_C04021005Metric" device="" value="100nF"/><part name="C42" library="dive_revd" deviceset="P1_C04021005Metric" device="" value="100nF"/><part name="C43" library="dive_revd" deviceset="P1_C04021005Metric" device="" value="100nF"/><part name="C44" library="dive_revd" deviceset="P1_C04021005Metric" device="" value="100nF"/><part name="C45" library="dive_revd" deviceset="P1_C04021005Metric" device="" value="100nF"/><part name="C46" library="dive_revd" deviceset="P1_C04021005Metric" device="" value="100nF"/><part name="C47" library="dive_revd" deviceset="P1_C04021005Metric" device="" value="100nF"/><part name="C48" library="dive_revd" deviceset="P1_C04021005Metric" device="" value="100nF"/><part name="D1" library="dive_revd" deviceset="P16_DSOD323" device="" value="BAT54WS"/><part name="D2" library="dive_revd" deviceset="P26_DSOD32326" device="" value="BAT54WS"/><part name="D3" library="dive_revd" deviceset="P26_DSOD32326" device="" value="BAT54WS"/><part name="D4" library="dive_revd" deviceset="P43_DSOD123" device="" value="1N4148W"/><part name="E1" library="dive_revd" deviceset="P36_PAD15" device="" value="Wet contact 1"/><part name="E2" library="dive_revd" deviceset="P36_PAD15" device="" value="Wet contact 2"/><part name="FB1" library="dive_revd" deviceset="P14_L06031608Metric" device="" value="600R@100MHz"/><part name="J1" library="dive_revd" deviceset="P6_SERVICE2x4" device="" value="Service pads"/><part name="J2" library="dive_revd" deviceset="P10_FPC50P05" device="" value="Display FPC 50p"/><part name="J3" library="dive_revd" deviceset="P29_microSDHCHiroseDM3DSF" device="" value="microSD"/><part name="J4" library="dive_revd" deviceset="P38_JSTSHBM02BSRSSTB1x021MPP" device="" value="Battery"/><part name="J5" library="dive_revd" deviceset="P37_PADS215" device="" value="Qi receiver module out"/><part name="J6" library="dive_revd" deviceset="P15_PADS408" device="" value="Light sensor flex"/><part name="J7" library="dive_revd" deviceset="P35_POGO6" device="" value="Sensor board contacts"/><part name="J8" library="dive_revd" deviceset="P41_PADS21541" device="" value="Ferrite rod 38/5.3 kHz"/><part name="J9" library="dive_revd" deviceset="P41_PADS21541" device="" value="Ferrite rod 123 kHz"/><part name="J10" library="dive_revd" deviceset="P28_PADS212" device="" value="Vibration motor"/><part name="L4" library="dive_revd" deviceset="P17_L10082520Metric" device="" value="1uH"/><part name="L5" library="dive_revd" deviceset="P31_R04021005Metric31" device="" value="0R"/><part name="Q1" library="dive_revd" deviceset="P12_SOT23" device="" value="AO3400A"/><part name="Q2" library="dive_revd" deviceset="P32_SOT2332" device="" value="AO3400A"/><part name="Q3" library="dive_revd" deviceset="P32_SOT2332" device="" value="AO3400A"/><part name="R1" library="dive_revd" deviceset="P2_R04021005Metric" device="" value="10k"/><part name="R2" library="dive_revd" deviceset="P2_R04021005Metric" device="" value="2k"/><part name="R3" library="dive_revd" deviceset="P2_R04021005Metric" device="" value="10k"/><part name="R4" library="dive_revd" deviceset="P2_R04021005Metric" device="" value="18k"/><part name="R10" library="dive_revd" deviceset="P2_R04021005Metric" device="" value="2.2k"/><part name="R11" library="dive_revd" deviceset="P2_R04021005Metric" device="" value="2.2k"/><part name="R12" library="dive_revd" deviceset="P2_R04021005Metric" device="" value="4.7k"/><part name="R13" library="dive_revd" deviceset="P2_R04021005Metric" device="" value="4.7k"/><part name="R14" library="dive_revd" deviceset="P2_R04021005Metric" device="" value="4.7k"/><part name="R15" library="dive_revd" deviceset="P2_R04021005Metric" device="" value="4.7k"/><part name="R16" library="dive_revd" deviceset="P2_R04021005Metric" device="" value="DNP"/><part name="R17" library="dive_revd" deviceset="P2_R04021005Metric" device="" value="DNP"/><part name="R20" library="dive_revd" deviceset="P2_R04021005Metric" device="" value="10k"/><part name="R21" library="dive_revd" deviceset="P2_R04021005Metric" device="" value="1k"/><part name="R22" library="dive_revd" deviceset="P2_R04021005Metric" device="" value="10k"/><part name="R23" library="dive_revd" deviceset="P2_R04021005Metric" device="" value="1k"/><part name="R24" library="dive_revd" deviceset="P2_R04021005Metric" device="" value="10k"/><part name="R25" library="dive_revd" deviceset="P2_R04021005Metric" device="" value="10k"/><part name="R26" library="dive_revd" deviceset="P2_R04021005Metric" device="" value="10k"/><part name="R27" library="dive_revd" deviceset="P2_R04021005Metric" device="" value="732k"/><part name="R28" library="dive_revd" deviceset="P2_R04021005Metric" device="" value="100k"/><part name="R29" library="dive_revd" deviceset="P2_R04021005Metric" device="" value="100k"/><part name="R30" library="dive_revd" deviceset="P2_R04021005Metric" device="" value="1M"/><part name="R31" library="dive_revd" deviceset="P2_R04021005Metric" device="" value="33k"/><part name="R32" library="dive_revd" deviceset="P2_R04021005Metric" device="" value="10k"/><part name="R33" library="dive_revd" deviceset="P2_R04021005Metric" device="" value="100k"/><part name="R34" library="dive_revd" deviceset="P2_R04021005Metric" device="" value="100k"/><part name="R40" library="dive_revd" deviceset="P4_R06031608Metric" device="" value="15R"/><part name="R41" library="dive_revd" deviceset="P2_R04021005Metric" device="" value="100R"/><part name="R42" library="dive_revd" deviceset="P2_R04021005Metric" device="" value="10k"/><part name="R43" library="dive_revd" deviceset="P2_R04021005Metric" device="" value="10k"/><part name="R44" library="dive_revd" deviceset="P2_R04021005Metric" device="" value="10k"/><part name="R45" library="dive_revd" deviceset="P2_R04021005Metric" device="" value="4.7k"/><part name="R46" library="dive_revd" deviceset="P2_R04021005Metric" device="" value="1k"/><part name="R47" library="dive_revd" deviceset="P2_R04021005Metric" device="" value="100R"/><part name="R48" library="dive_revd" deviceset="P2_R04021005Metric" device="" value="100k"/><part name="R49" library="dive_revd" deviceset="P2_R04021005Metric" device="" value="1k"/><part name="R50" library="dive_revd" deviceset="P2_R04021005Metric" device="" value="100k"/><part name="TP1" library="dive_revd" deviceset="P23_TestPointPadD10mm" device="" value="SWIO"/><part name="U1" library="dive_revd" deviceset="P21_ESP32S3WROOM1" device="" value="ESP32-S3-WROOM-1-N16R8"/><part name="U2" library="dive_revd" deviceset="P27_TSSOP2444x78mmP065mm" device="" value="TCA9548APWR"/><part name="U5" library="dive_revd" deviceset="P20_LGA143x25mmP05mmLayoutBo" device="" value="QMI8658C"/><part name="U6" library="dive_revd" deviceset="P18_WLP4083x083mmP04mm" device="" value="MMC5603NJ"/><part name="U8" library="dive_revd" deviceset="P9_SOIC839x49mmP127mm" device="" value="MB85RC256VPF"/><part name="U9" library="dive_revd" deviceset="P8_TDFN81EP2x2mmP05mmEP08x1" device="" value="MAX17048G+T10"/><part name="U10" library="dive_revd" deviceset="P11_TSSOP844x3mmP065mm" device="" value="PCF85063ATT"/><part name="U11" library="dive_revd" deviceset="P30_SOIC839x49mmP127mm30" device="" value="MCP6022"/><part name="U12" library="dive_revd" deviceset="P42_TSSOP1444x5mmP065mm" device="" value="PCM1808PWR"/><part name="U13" library="dive_revd" deviceset="P39_MSOP83x3mmP065mm" device="" value="LM393DGKR"/><part name="U14" library="dive_revd" deviceset="P34_ubloxMAX" device="" value="MAX-M10S"/><part name="U15" library="dive_revd" deviceset="P22_TSSOP2044x65mmP065mm" device="" value="CH32V003F4P6"/><part name="U16" library="dive_revd" deviceset="P5_SOT236" device="" value="TMAG5273A1QDBVR"/><part name="U17" library="dive_revd" deviceset="P5_SOT236" device="" value="TMAG5273B1QDBVR"/><part name="U18" library="dive_revd" deviceset="P5_SOT236" device="" value="TMAG5273D1QDBVR"/><part name="U21" library="dive_revd" deviceset="P19_SOT235" device="" value="MCP73831T-2ACI/OT"/><part name="U23" library="dive_revd" deviceset="P19_SOT235" device="" value="TLV75733PDBVR"/><part name="U24" library="dive_revd" deviceset="P13_SOT563" device="" value="TPS61023DRLR"/><part name="U25" library="dive_revd" deviceset="P33_SOT23633" device="" value="TPS22917DBVR"/><part name="Y1" library="dive_revd" deviceset="P7_CrystalSMD32152Pin32x15m" device="" value="32.768kHz"/></parts>
<sheets><sheet><plain><text x="20.32" y="264.16" size="3.81" layer="97">Dykkecomputer rev D, hovedkort</text></plain>
<instances><instance part="ANT1" gate="G$1" x="20.32" y="246.38"/><instance part="BZ1" gate="G$1" x="20.32" y="228.6"/><instance part="C1" gate="G$1" x="20.32" y="210.82"/><instance part="C2" gate="G$1" x="20.32" y="193.04"/><instance part="C3" gate="G$1" x="20.32" y="175.26"/><instance part="C4" gate="G$1" x="20.32" y="157.48"/><instance part="C5" gate="G$1" x="20.32" y="139.7"/><instance part="C6" gate="G$1" x="20.32" y="121.92"/><instance part="C7" gate="G$1" x="20.32" y="104.14"/><instance part="C10" gate="G$1" x="20.32" y="86.36"/><instance part="C11" gate="G$1" x="20.32" y="68.58"/><instance part="C13" gate="G$1" x="20.32" y="50.8"/><instance part="C20" gate="G$1" x="20.32" y="33.02"/><instance part="C21" gate="G$1" x="20.32" y="15.24"/><instance part="C22" gate="G$1" x="96.52000000000001" y="246.38"/><instance part="C23" gate="G$1" x="96.52000000000001" y="228.6"/><instance part="C24" gate="G$1" x="96.52000000000001" y="210.82"/><instance part="C25" gate="G$1" x="96.52000000000001" y="193.04"/><instance part="C26" gate="G$1" x="96.52000000000001" y="175.26"/><instance part="C27" gate="G$1" x="96.52000000000001" y="157.48"/><instance part="C28" gate="G$1" x="96.52000000000001" y="139.7"/><instance part="C29" gate="G$1" x="96.52000000000001" y="121.92"/><instance part="C30" gate="G$1" x="96.52000000000001" y="104.14"/><instance part="C31" gate="G$1" x="96.52000000000001" y="86.36"/><instance part="C32" gate="G$1" x="96.52000000000001" y="68.58"/><instance part="C33" gate="G$1" x="96.52000000000001" y="50.8"/><instance part="C34" gate="G$1" x="96.52000000000001" y="33.02"/><instance part="C36" gate="G$1" x="96.52000000000001" y="15.24"/><instance part="C37" gate="G$1" x="172.72000000000003" y="246.38"/><instance part="C38" gate="G$1" x="172.72000000000003" y="228.6"/><instance part="C39" gate="G$1" x="172.72000000000003" y="210.82"/><instance part="C40" gate="G$1" x="172.72000000000003" y="193.04"/><instance part="C41" gate="G$1" x="172.72000000000003" y="175.26"/><instance part="C42" gate="G$1" x="172.72000000000003" y="157.48"/><instance part="C43" gate="G$1" x="172.72000000000003" y="139.7"/><instance part="C44" gate="G$1" x="172.72000000000003" y="121.92"/><instance part="C45" gate="G$1" x="172.72000000000003" y="104.14"/><instance part="C46" gate="G$1" x="172.72000000000003" y="86.36"/><instance part="C47" gate="G$1" x="172.72000000000003" y="68.58"/><instance part="C48" gate="G$1" x="172.72000000000003" y="50.8"/><instance part="D1" gate="G$1" x="172.72000000000003" y="33.02"/><instance part="D2" gate="G$1" x="172.72000000000003" y="15.24"/><instance part="D3" gate="G$1" x="248.92000000000002" y="246.38"/><instance part="D4" gate="G$1" x="248.92000000000002" y="228.6"/><instance part="E1" gate="G$1" x="248.92000000000002" y="210.82"/><instance part="E2" gate="G$1" x="248.92000000000002" y="193.04"/><instance part="FB1" gate="G$1" x="248.92000000000002" y="175.26"/><instance part="J1" gate="G$1" x="248.92000000000002" y="153.67"/><instance part="J2" gate="G$1" x="248.92000000000002" y="100.33"/><instance part="J3" gate="G$1" x="248.92000000000002" y="43.18"/><instance part="J4" gate="G$1" x="248.92000000000002" y="16.51"/><instance part="J5" gate="G$1" x="325.12" y="246.38"/><instance part="J6" gate="G$1" x="325.12" y="227.33"/><instance part="J7" gate="G$1" x="325.12" y="205.74"/><instance part="J8" gate="G$1" x="325.12" y="185.42"/><instance part="J9" gate="G$1" x="325.12" y="167.64"/><instance part="J10" gate="G$1" x="325.12" y="149.86"/><instance part="L4" gate="G$1" x="325.12" y="132.08"/><instance part="L5" gate="G$1" x="325.12" y="114.3"/><instance part="Q1" gate="G$1" x="325.12" y="95.25"/><instance part="Q2" gate="G$1" x="325.12" y="74.93"/><instance part="Q3" gate="G$1" x="325.12" y="54.61"/><instance part="R1" gate="G$1" x="325.12" y="35.56"/><instance part="R2" gate="G$1" x="325.12" y="17.78"/><instance part="R3" gate="G$1" x="401.32" y="246.38"/><instance part="R4" gate="G$1" x="401.32" y="228.6"/><instance part="R10" gate="G$1" x="401.32" y="210.82"/><instance part="R11" gate="G$1" x="401.32" y="193.04"/><instance part="R12" gate="G$1" x="401.32" y="175.26"/><instance part="R13" gate="G$1" x="401.32" y="157.48"/><instance part="R14" gate="G$1" x="401.32" y="139.7"/><instance part="R15" gate="G$1" x="401.32" y="121.92"/><instance part="R16" gate="G$1" x="401.32" y="104.14"/><instance part="R17" gate="G$1" x="401.32" y="86.36"/><instance part="R20" gate="G$1" x="401.32" y="68.58"/><instance part="R21" gate="G$1" x="401.32" y="50.8"/><instance part="R22" gate="G$1" x="401.32" y="33.02"/><instance part="R23" gate="G$1" x="401.32" y="15.24"/><instance part="R24" gate="G$1" x="477.52" y="246.38"/><instance part="R25" gate="G$1" x="477.52" y="228.6"/><instance part="R26" gate="G$1" x="477.52" y="210.82"/><instance part="R27" gate="G$1" x="477.52" y="193.04"/><instance part="R28" gate="G$1" x="477.52" y="175.26"/><instance part="R29" gate="G$1" x="477.52" y="157.48"/><instance part="R30" gate="G$1" x="477.52" y="139.7"/><instance part="R31" gate="G$1" x="477.52" y="121.92"/><instance part="R32" gate="G$1" x="477.52" y="104.14"/><instance part="R33" gate="G$1" x="477.52" y="86.36"/><instance part="R34" gate="G$1" x="477.52" y="68.58"/><instance part="R40" gate="G$1" x="477.52" y="50.8"/><instance part="R41" gate="G$1" x="477.52" y="33.02"/><instance part="R42" gate="G$1" x="477.52" y="15.24"/><instance part="R43" gate="G$1" x="553.72" y="246.38"/><instance part="R44" gate="G$1" x="553.72" y="228.6"/><instance part="R45" gate="G$1" x="553.72" y="210.82"/><instance part="R46" gate="G$1" x="553.72" y="193.04"/><instance part="R47" gate="G$1" x="553.72" y="175.26"/><instance part="R48" gate="G$1" x="553.72" y="157.48"/><instance part="R49" gate="G$1" x="553.72" y="139.7"/><instance part="R50" gate="G$1" x="553.72" y="121.92"/><instance part="TP1" gate="G$1" x="553.72" y="104.14"/><instance part="U1" gate="G$1" x="553.72" y="53.34"/><instance part="U2" gate="G$1" x="629.9200000000001" y="232.41"/><instance part="U5" gate="G$1" x="629.9200000000001" y="193.04"/><instance part="U6" gate="G$1" x="629.9200000000001" y="166.37"/><instance part="U8" gate="G$1" x="629.9200000000001" y="143.51"/><instance part="U9" gate="G$1" x="629.9200000000001" y="116.84"/><instance part="U10" gate="G$1" x="629.9200000000001" y="90.17"/><instance part="U11" gate="G$1" x="629.9200000000001" y="64.77"/><instance part="U12" gate="G$1" x="629.9200000000001" y="35.56"/><instance part="U13" gate="G$1" x="706.1200000000001" y="242.57"/><instance part="U14" gate="G$1" x="706.1200000000001" y="210.82"/><instance part="U15" gate="G$1" x="706.1200000000001" y="171.45"/><instance part="U16" gate="G$1" x="706.1200000000001" y="139.7"/><instance part="U17" gate="G$1" x="706.1200000000001" y="116.84"/><instance part="U18" gate="G$1" x="706.1200000000001" y="93.98"/><instance part="U21" gate="G$1" x="706.1200000000001" y="71.12"/><instance part="U23" gate="G$1" x="706.1200000000001" y="48.26"/><instance part="U24" gate="G$1" x="706.1200000000001" y="25.4"/><instance part="U25" gate="G$1" x="782.3200000000002" y="243.84"/><instance part="Y1" gate="G$1" x="782.3200000000002" y="223.52"/></instances><busses/>
<nets><net name="3V3" class="0"><segment><pinref part="C2" gate="G$1" pin="1"/><wire x1="7.62" y1="193.04" x2="0.0" y2="193.04" width="0.1524" layer="91"/><label x="0.0" y="193.04" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="C3" gate="G$1" pin="1"/><wire x1="7.62" y1="175.26" x2="0.0" y2="175.26" width="0.1524" layer="91"/><label x="0.0" y="175.26" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="C7" gate="G$1" pin="1"/><wire x1="7.62" y1="104.14" x2="0.0" y2="104.14" width="0.1524" layer="91"/><label x="0.0" y="104.14" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="C10" gate="G$1" pin="1"/><wire x1="7.62" y1="86.36" x2="0.0" y2="86.36" width="0.1524" layer="91"/><label x="0.0" y="86.36" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="C11" gate="G$1" pin="1"/><wire x1="7.62" y1="68.58" x2="0.0" y2="68.58" width="0.1524" layer="91"/><label x="0.0" y="68.58" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="C13" gate="G$1" pin="1"/><wire x1="7.62" y1="50.8" x2="0.0" y2="50.8" width="0.1524" layer="91"/><label x="0.0" y="50.8" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="C37" gate="G$1" pin="1"/><wire x1="160.02" y1="246.38" x2="152.4" y2="246.38" width="0.1524" layer="91"/><label x="152.4" y="246.38" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="C38" gate="G$1" pin="1"/><wire x1="160.02" y1="228.6" x2="152.4" y2="228.6" width="0.1524" layer="91"/><label x="152.4" y="228.6" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="C39" gate="G$1" pin="1"/><wire x1="160.02" y1="210.82" x2="152.4" y2="210.82" width="0.1524" layer="91"/><label x="152.4" y="210.82" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="C40" gate="G$1" pin="1"/><wire x1="160.02" y1="193.04" x2="152.4" y2="193.04" width="0.1524" layer="91"/><label x="152.4" y="193.04" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="C41" gate="G$1" pin="1"/><wire x1="160.02" y1="175.26" x2="152.4" y2="175.26" width="0.1524" layer="91"/><label x="152.4" y="175.26" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="C43" gate="G$1" pin="1"/><wire x1="160.02" y1="139.7" x2="152.4" y2="139.7" width="0.1524" layer="91"/><label x="152.4" y="139.7" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="C44" gate="G$1" pin="1"/><wire x1="160.02" y1="121.92" x2="152.4" y2="121.92" width="0.1524" layer="91"/><label x="152.4" y="121.92" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="C46" gate="G$1" pin="1"/><wire x1="160.02" y1="86.36" x2="152.4" y2="86.36" width="0.1524" layer="91"/><label x="152.4" y="86.36" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="C48" gate="G$1" pin="1"/><wire x1="160.02" y1="50.8" x2="152.4" y2="50.8" width="0.1524" layer="91"/><label x="152.4" y="50.8" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="J2" gate="G$1" pin="11"/><wire x1="236.22" y1="106.68" x2="228.6" y2="106.68" width="0.1524" layer="91"/><label x="228.6" y="106.68" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="J2" gate="G$1" pin="12"/><wire x1="236.22" y1="104.14" x2="228.6" y2="104.14" width="0.1524" layer="91"/><label x="228.6" y="104.14" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="J2" gate="G$1" pin="17"/><wire x1="236.22" y1="91.44" x2="228.6" y2="91.44" width="0.1524" layer="91"/><label x="228.6" y="91.44" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="J2" gate="G$1" pin="42"/><wire x1="261.62" y1="93.98" x2="269.24" y2="93.98" width="0.1524" layer="91"/><label x="269.24" y="93.98" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="J2" gate="G$1" pin="43"/><wire x1="261.62" y1="91.44" x2="269.24" y2="91.44" width="0.1524" layer="91"/><label x="269.24" y="91.44" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="J2" gate="G$1" pin="44"/><wire x1="261.62" y1="88.9" x2="269.24" y2="88.9" width="0.1524" layer="91"/><label x="269.24" y="88.9" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="J3" gate="G$1" pin="4"/><wire x1="236.22" y1="43.18" x2="228.6" y2="43.18" width="0.1524" layer="91"/><label x="228.6" y="43.18" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="J6" gate="G$1" pin="1"/><wire x1="312.42" y1="228.6" x2="304.8" y2="228.6" width="0.1524" layer="91"/><label x="304.8" y="228.6" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="J7" gate="G$1" pin="1"/><wire x1="312.42" y1="208.28" x2="304.8" y2="208.28" width="0.1524" layer="91"/><label x="304.8" y="208.28" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="R1" gate="G$1" pin="1"/><wire x1="312.42" y1="35.56" x2="304.8" y2="35.56" width="0.1524" layer="91"/><label x="304.8" y="35.56" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="R10" gate="G$1" pin="1"/><wire x1="388.62" y1="210.82" x2="381.0" y2="210.82" width="0.1524" layer="91"/><label x="381.0" y="210.82" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="R11" gate="G$1" pin="1"/><wire x1="388.62" y1="193.04" x2="381.0" y2="193.04" width="0.1524" layer="91"/><label x="381.0" y="193.04" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="R12" gate="G$1" pin="1"/><wire x1="388.62" y1="175.26" x2="381.0" y2="175.26" width="0.1524" layer="91"/><label x="381.0" y="175.26" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="R13" gate="G$1" pin="1"/><wire x1="388.62" y1="157.48" x2="381.0" y2="157.48" width="0.1524" layer="91"/><label x="381.0" y="157.48" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="R14" gate="G$1" pin="1"/><wire x1="388.62" y1="139.7" x2="381.0" y2="139.7" width="0.1524" layer="91"/><label x="381.0" y="139.7" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="R15" gate="G$1" pin="1"/><wire x1="388.62" y1="121.92" x2="381.0" y2="121.92" width="0.1524" layer="91"/><label x="381.0" y="121.92" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="R17" gate="G$1" pin="1"/><wire x1="388.62" y1="86.36" x2="381.0" y2="86.36" width="0.1524" layer="91"/><label x="381.0" y="86.36" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="R30" gate="G$1" pin="1"/><wire x1="464.82" y1="139.7" x2="457.2" y2="139.7" width="0.1524" layer="91"/><label x="457.2" y="139.7" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="R32" gate="G$1" pin="1"/><wire x1="464.82" y1="104.14" x2="457.2" y2="104.14" width="0.1524" layer="91"/><label x="457.2" y="104.14" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="R42" gate="G$1" pin="1"/><wire x1="464.82" y1="15.24" x2="457.2" y2="15.24" width="0.1524" layer="91"/><label x="457.2" y="15.24" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="R43" gate="G$1" pin="1"/><wire x1="541.02" y1="246.38" x2="533.4" y2="246.38" width="0.1524" layer="91"/><label x="533.4" y="246.38" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="R44" gate="G$1" pin="1"/><wire x1="541.02" y1="228.6" x2="533.4" y2="228.6" width="0.1524" layer="91"/><label x="533.4" y="228.6" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U1" gate="G$1" pin="2"/><wire x1="541.02" y1="83.82" x2="533.4" y2="83.82" width="0.1524" layer="91"/><label x="533.4" y="83.82" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U2" gate="G$1" pin="3"/><wire x1="617.22" y1="241.3" x2="609.6" y2="241.3" width="0.1524" layer="91"/><label x="609.6" y="241.3" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U2" gate="G$1" pin="24"/><wire x1="642.62" y1="218.44" x2="650.24" y2="218.44" width="0.1524" layer="91"/><label x="650.24" y="218.44" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="U5" gate="G$1" pin="5"/><wire x1="617.22" y1="190.5" x2="609.6" y2="190.5" width="0.1524" layer="91"/><label x="609.6" y="190.5" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U5" gate="G$1" pin="8"/><wire x1="642.62" y1="200.66" x2="650.24" y2="200.66" width="0.1524" layer="91"/><label x="650.24" y="200.66" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="U5" gate="G$1" pin="12"/><wire x1="642.62" y1="190.5" x2="650.24" y2="190.5" width="0.1524" layer="91"/><label x="650.24" y="190.5" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="U6" gate="G$1" pin="B1"/><wire x1="642.62" y1="167.64" x2="650.24" y2="167.64" width="0.1524" layer="91"/><label x="650.24" y="167.64" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="U8" gate="G$1" pin="8"/><wire x1="642.62" y1="139.7" x2="650.24" y2="139.7" width="0.1524" layer="91"/><label x="650.24" y="139.7" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="U10" gate="G$1" pin="8"/><wire x1="642.62" y1="86.36" x2="650.24" y2="86.36" width="0.1524" layer="91"/><label x="650.24" y="86.36" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="U12" gate="G$1" pin="4"/><wire x1="617.22" y1="35.56" x2="609.6" y2="35.56" width="0.1524" layer="91"/><label x="609.6" y="35.56" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U13" gate="G$1" pin="8"/><wire x1="718.82" y1="238.76" x2="726.44" y2="238.76" width="0.1524" layer="91"/><label x="726.44" y="238.76" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="U14" gate="G$1" pin="6"/><wire x1="693.42" y1="208.28" x2="685.8" y2="208.28" width="0.1524" layer="91"/><label x="685.8" y="208.28" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U15" gate="G$1" pin="9"/><wire x1="693.42" y1="162.56" x2="685.8" y2="162.56" width="0.1524" layer="91"/><label x="685.8" y="162.56" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U16" gate="G$1" pin="4"/><wire x1="718.82" y1="142.24" x2="726.44" y2="142.24" width="0.1524" layer="91"/><label x="726.44" y="142.24" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="U17" gate="G$1" pin="4"/><wire x1="718.82" y1="119.38" x2="726.44" y2="119.38" width="0.1524" layer="91"/><label x="726.44" y="119.38" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="U18" gate="G$1" pin="4"/><wire x1="718.82" y1="96.52" x2="726.44" y2="96.52" width="0.1524" layer="91"/><label x="726.44" y="96.52" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="U23" gate="G$1" pin="5"/><wire x1="718.82" y1="48.26" x2="726.44" y2="48.26" width="0.1524" layer="91"/><label x="726.44" y="48.26" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="U25" gate="G$1" pin="1"/><wire x1="769.62" y1="246.38" x2="762.0" y2="246.38" width="0.1524" layer="91"/><label x="762.0" y="246.38" size="1.27" layer="95" rot="MR0" xref="no"/></segment></net>
<net name="3V3_GNSS" class="0"><segment><pinref part="C30" gate="G$1" pin="1"/><wire x1="83.82" y1="104.14" x2="76.2" y2="104.14" width="0.1524" layer="91"/><label x="76.2" y="104.14" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="C47" gate="G$1" pin="1"/><wire x1="160.02" y1="68.58" x2="152.4" y2="68.58" width="0.1524" layer="91"/><label x="152.4" y="68.58" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U14" gate="G$1" pin="7"/><wire x1="693.42" y1="205.74" x2="685.8" y2="205.74" width="0.1524" layer="91"/><label x="685.8" y="205.74" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U14" gate="G$1" pin="8"/><wire x1="693.42" y1="203.2" x2="685.8" y2="203.2" width="0.1524" layer="91"/><label x="685.8" y="203.2" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U25" gate="G$1" pin="5"/><wire x1="795.02" y1="243.84" x2="802.64" y2="243.84" width="0.1524" layer="91"/><label x="802.64" y="243.84" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="U25" gate="G$1" pin="6"/><wire x1="795.02" y1="241.3" x2="802.64" y2="241.3" width="0.1524" layer="91"/><label x="802.64" y="241.3" size="1.27" layer="95" xref="no"/></segment></net>
<net name="5V_A" class="0"><segment><pinref part="C24" gate="G$1" pin="1"/><wire x1="83.82" y1="210.82" x2="76.2" y2="210.82" width="0.1524" layer="91"/><label x="76.2" y="210.82" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="C36" gate="G$1" pin="1"/><wire x1="83.82" y1="15.24" x2="76.2" y2="15.24" width="0.1524" layer="91"/><label x="76.2" y="15.24" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="C45" gate="G$1" pin="1"/><wire x1="160.02" y1="104.14" x2="152.4" y2="104.14" width="0.1524" layer="91"/><label x="152.4" y="104.14" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="FB1" gate="G$1" pin="2"/><wire x1="261.62" y1="175.26" x2="269.24" y2="175.26" width="0.1524" layer="91"/><label x="269.24" y="175.26" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="R25" gate="G$1" pin="1"/><wire x1="464.82" y1="228.6" x2="457.2" y2="228.6" width="0.1524" layer="91"/><label x="457.2" y="228.6" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U11" gate="G$1" pin="8"/><wire x1="642.62" y1="60.96" x2="650.24" y2="60.96" width="0.1524" layer="91"/><label x="650.24" y="60.96" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="U12" gate="G$1" pin="3"/><wire x1="617.22" y1="38.1" x2="609.6" y2="38.1" width="0.1524" layer="91"/><label x="609.6" y="38.1" size="1.27" layer="95" rot="MR0" xref="no"/></segment></net>
<net name="5V_RAW" class="0"><segment><pinref part="C31" gate="G$1" pin="1"/><wire x1="83.82" y1="86.36" x2="76.2" y2="86.36" width="0.1524" layer="91"/><label x="76.2" y="86.36" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="FB1" gate="G$1" pin="1"/><wire x1="236.22" y1="175.26" x2="228.6" y2="175.26" width="0.1524" layer="91"/><label x="228.6" y="175.26" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="R27" gate="G$1" pin="1"/><wire x1="464.82" y1="193.04" x2="457.2" y2="193.04" width="0.1524" layer="91"/><label x="457.2" y="193.04" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U24" gate="G$1" pin="6"/><wire x1="718.82" y1="22.86" x2="726.44" y2="22.86" width="0.1524" layer="91"/><label x="726.44" y="22.86" size="1.27" layer="95" xref="no"/></segment></net>
<net name="ADC_INL" class="0"><segment><pinref part="C22" gate="G$1" pin="2"/><wire x1="109.22" y1="246.38" x2="116.84" y2="246.38" width="0.1524" layer="91"/><label x="116.84" y="246.38" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="U12" gate="G$1" pin="13"/><wire x1="642.62" y1="30.48" x2="650.24" y2="30.48" width="0.1524" layer="91"/><label x="650.24" y="30.48" size="1.27" layer="95" xref="no"/></segment></net>
<net name="ADC_INR" class="0"><segment><pinref part="C29" gate="G$1" pin="1"/><wire x1="83.82" y1="121.92" x2="76.2" y2="121.92" width="0.1524" layer="91"/><label x="76.2" y="121.92" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U12" gate="G$1" pin="14"/><wire x1="642.62" y1="27.94" x2="650.24" y2="27.94" width="0.1524" layer="91"/><label x="650.24" y="27.94" size="1.27" layer="95" xref="no"/></segment></net>
<net name="ADC_VREF" class="0"><segment><pinref part="C23" gate="G$1" pin="1"/><wire x1="83.82" y1="228.6" x2="76.2" y2="228.6" width="0.1524" layer="91"/><label x="76.2" y="228.6" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U12" gate="G$1" pin="1"/><wire x1="617.22" y1="43.18" x2="609.6" y2="43.18" width="0.1524" layer="91"/><label x="609.6" y="43.18" size="1.27" layer="95" rot="MR0" xref="no"/></segment></net>
<net name="ANT_FEED" class="0"><segment><pinref part="ANT1" gate="G$1" pin="1"/><wire x1="7.62" y1="246.38" x2="0.0" y2="246.38" width="0.1524" layer="91"/><label x="0.0" y="246.38" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="C34" gate="G$1" pin="1"/><wire x1="83.82" y1="33.02" x2="76.2" y2="33.02" width="0.1524" layer="91"/><label x="76.2" y="33.02" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="L5" gate="G$1" pin="2"/><wire x1="337.82" y1="114.3" x2="345.44" y2="114.3" width="0.1524" layer="91"/><label x="345.44" y="114.3" size="1.27" layer="95" xref="no"/></segment></net>
<net name="BL_A" class="0"><segment><pinref part="J2" gate="G$1" pin="2"/><wire x1="236.22" y1="129.54" x2="228.6" y2="129.54" width="0.1524" layer="91"/><label x="228.6" y="129.54" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="R40" gate="G$1" pin="2"/><wire x1="490.22" y1="50.8" x2="497.84" y2="50.8" width="0.1524" layer="91"/><label x="497.84" y="50.8" size="1.27" layer="95" xref="no"/></segment></net>
<net name="BL_G" class="0"><segment><pinref part="Q1" gate="G$1" pin="1"/><wire x1="312.42" y1="96.52" x2="304.8" y2="96.52" width="0.1524" layer="91"/><label x="304.8" y="96.52" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="R41" gate="G$1" pin="2"/><wire x1="490.22" y1="33.02" x2="497.84" y2="33.02" width="0.1524" layer="91"/><label x="497.84" y="33.02" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="R50" gate="G$1" pin="1"/><wire x1="541.02" y1="121.92" x2="533.4" y2="121.92" width="0.1524" layer="91"/><label x="533.4" y="121.92" size="1.27" layer="95" rot="MR0" xref="no"/></segment></net>
<net name="BL_K" class="0"><segment><pinref part="J2" gate="G$1" pin="3"/><wire x1="236.22" y1="127.0" x2="228.6" y2="127.0" width="0.1524" layer="91"/><label x="228.6" y="127.0" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="J2" gate="G$1" pin="4"/><wire x1="236.22" y1="124.46" x2="228.6" y2="124.46" width="0.1524" layer="91"/><label x="228.6" y="124.46" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="J2" gate="G$1" pin="5"/><wire x1="236.22" y1="121.92" x2="228.6" y2="121.92" width="0.1524" layer="91"/><label x="228.6" y="121.92" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="J2" gate="G$1" pin="6"/><wire x1="236.22" y1="119.38" x2="228.6" y2="119.38" width="0.1524" layer="91"/><label x="228.6" y="119.38" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="J2" gate="G$1" pin="7"/><wire x1="236.22" y1="116.84" x2="228.6" y2="116.84" width="0.1524" layer="91"/><label x="228.6" y="116.84" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="J2" gate="G$1" pin="8"/><wire x1="236.22" y1="114.3" x2="228.6" y2="114.3" width="0.1524" layer="91"/><label x="228.6" y="114.3" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="Q1" gate="G$1" pin="3"/><wire x1="337.82" y1="96.52" x2="345.44" y2="96.52" width="0.1524" layer="91"/><label x="345.44" y="96.52" size="1.27" layer="95" xref="no"/></segment></net>
<net name="BOOST_EN" class="0"><segment><pinref part="R33" gate="G$1" pin="1"/><wire x1="464.82" y1="86.36" x2="457.2" y2="86.36" width="0.1524" layer="91"/><label x="457.2" y="86.36" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U15" gate="G$1" pin="10"/><wire x1="693.42" y1="160.02" x2="685.8" y2="160.02" width="0.1524" layer="91"/><label x="685.8" y="160.02" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U24" gate="G$1" pin="2"/><wire x1="693.42" y1="25.4" x2="685.8" y2="25.4" width="0.1524" layer="91"/><label x="685.8" y="25.4" size="1.27" layer="95" rot="MR0" xref="no"/></segment></net>
<net name="BOOT" class="0"><segment><pinref part="J1" gate="G$1" pin="8"/><wire x1="261.62" y1="149.86" x2="269.24" y2="149.86" width="0.1524" layer="91"/><label x="269.24" y="149.86" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="U1" gate="G$1" pin="27"/><wire x1="541.02" y1="20.32" x2="533.4" y2="20.32" width="0.1524" layer="91"/><label x="533.4" y="20.32" size="1.27" layer="95" rot="MR0" xref="no"/></segment></net>
<net name="BST_FB" class="0"><segment><pinref part="R27" gate="G$1" pin="2"/><wire x1="490.22" y1="193.04" x2="497.84" y2="193.04" width="0.1524" layer="91"/><label x="497.84" y="193.04" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="R28" gate="G$1" pin="1"/><wire x1="464.82" y1="175.26" x2="457.2" y2="175.26" width="0.1524" layer="91"/><label x="457.2" y="175.26" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U24" gate="G$1" pin="1"/><wire x1="693.42" y1="27.94" x2="685.8" y2="27.94" width="0.1524" layer="91"/><label x="685.8" y="27.94" size="1.27" layer="95" rot="MR0" xref="no"/></segment></net>
<net name="BST_SW" class="0"><segment><pinref part="L4" gate="G$1" pin="2"/><wire x1="337.82" y1="132.08" x2="345.44" y2="132.08" width="0.1524" layer="91"/><label x="345.44" y="132.08" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="U24" gate="G$1" pin="5"/><wire x1="718.82" y1="25.4" x2="726.44" y2="25.4" width="0.1524" layer="91"/><label x="726.44" y="25.4" size="1.27" layer="95" xref="no"/></segment></net>
<net name="BTN_DN" class="0"><segment><pinref part="U1" gate="G$1" pin="35"/><wire x1="566.42" y1="68.58" x2="574.04" y2="68.58" width="0.1524" layer="91"/><label x="574.04" y="68.58" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="U18" gate="G$1" pin="5"/><wire x1="718.82" y1="93.98" x2="726.44" y2="93.98" width="0.1524" layer="91"/><label x="726.44" y="93.98" size="1.27" layer="95" xref="no"/></segment></net>
<net name="BTN_SEL" class="0"><segment><pinref part="U1" gate="G$1" pin="34"/><wire x1="566.42" y1="71.12" x2="574.04" y2="71.12" width="0.1524" layer="91"/><label x="574.04" y="71.12" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="U17" gate="G$1" pin="5"/><wire x1="718.82" y1="116.84" x2="726.44" y2="116.84" width="0.1524" layer="91"/><label x="726.44" y="116.84" size="1.27" layer="95" xref="no"/></segment></net>
<net name="BTN_UP" class="0"><segment><pinref part="U1" gate="G$1" pin="32"/><wire x1="566.42" y1="76.2" x2="574.04" y2="76.2" width="0.1524" layer="91"/><label x="574.04" y="76.2" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="U16" gate="G$1" pin="5"/><wire x1="718.82" y1="139.7" x2="726.44" y2="139.7" width="0.1524" layer="91"/><label x="726.44" y="139.7" size="1.27" layer="95" xref="no"/></segment></net>
<net name="BUZZER" class="0"><segment><pinref part="D2" gate="G$1" pin="2"/><wire x1="185.42" y1="15.24" x2="193.04" y2="15.24" width="0.1524" layer="91"/><label x="193.04" y="15.24" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="U1" gate="G$1" pin="33"/><wire x1="566.42" y1="73.66" x2="574.04" y2="73.66" width="0.1524" layer="91"/><label x="574.04" y="73.66" size="1.27" layer="95" xref="no"/></segment></net>
<net name="BUZ_G" class="0"><segment><pinref part="D2" gate="G$1" pin="1"/><wire x1="160.02" y1="15.24" x2="152.4" y2="15.24" width="0.1524" layer="91"/><label x="152.4" y="15.24" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="D3" gate="G$1" pin="1"/><wire x1="236.22" y1="246.38" x2="228.6" y2="246.38" width="0.1524" layer="91"/><label x="228.6" y="246.38" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="Q2" gate="G$1" pin="1"/><wire x1="312.42" y1="76.2" x2="304.8" y2="76.2" width="0.1524" layer="91"/><label x="304.8" y="76.2" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="R45" gate="G$1" pin="1"/><wire x1="541.02" y1="210.82" x2="533.4" y2="210.82" width="0.1524" layer="91"/><label x="533.4" y="210.82" size="1.27" layer="95" rot="MR0" xref="no"/></segment></net>
<net name="BUZ_K" class="0"><segment><pinref part="BZ1" gate="G$1" pin="2"/><wire x1="33.02" y1="228.6" x2="40.64" y2="228.6" width="0.1524" layer="91"/><label x="40.64" y="228.6" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="Q2" gate="G$1" pin="3"/><wire x1="337.82" y1="76.2" x2="345.44" y2="76.2" width="0.1524" layer="91"/><label x="345.44" y="76.2" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="R46" gate="G$1" pin="2"/><wire x1="566.42" y1="193.04" x2="574.04" y2="193.04" width="0.1524" layer="91"/><label x="574.04" y="193.04" size="1.27" layer="95" xref="no"/></segment></net>
<net name="BUZ_SAFE" class="0"><segment><pinref part="D3" gate="G$1" pin="2"/><wire x1="261.62" y1="246.38" x2="269.24" y2="246.38" width="0.1524" layer="91"/><label x="269.24" y="246.38" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="U15" gate="G$1" pin="14"/><wire x1="718.82" y1="175.26" x2="726.44" y2="175.26" width="0.1524" layer="91"/><label x="726.44" y="175.26" size="1.27" layer="95" xref="no"/></segment></net>
<net name="C123_P" class="0"><segment><pinref part="C25" gate="G$1" pin="1"/><wire x1="83.82" y1="193.04" x2="76.2" y2="193.04" width="0.1524" layer="91"/><label x="76.2" y="193.04" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="D1" gate="G$1" pin="2"/><wire x1="185.42" y1="33.02" x2="193.04" y2="33.02" width="0.1524" layer="91"/><label x="193.04" y="33.02" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="J9" gate="G$1" pin="1"/><wire x1="312.42" y1="167.64" x2="304.8" y2="167.64" width="0.1524" layer="91"/><label x="304.8" y="167.64" size="1.27" layer="95" rot="MR0" xref="no"/></segment></net>
<net name="CHG_STAT" class="0"><segment><pinref part="R3" gate="G$1" pin="2"/><wire x1="414.02" y1="246.38" x2="421.64" y2="246.38" width="0.1524" layer="91"/><label x="421.64" y="246.38" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="R4" gate="G$1" pin="1"/><wire x1="388.62" y1="228.6" x2="381.0" y2="228.6" width="0.1524" layer="91"/><label x="381.0" y="228.6" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U1" gate="G$1" pin="31"/><wire x1="566.42" y1="78.74" x2="574.04" y2="78.74" width="0.1524" layer="91"/><label x="574.04" y="78.74" size="1.27" layer="95" xref="no"/></segment></net>
<net name="CHG_STAT5" class="0"><segment><pinref part="R3" gate="G$1" pin="1"/><wire x1="388.62" y1="246.38" x2="381.0" y2="246.38" width="0.1524" layer="91"/><label x="381.0" y="246.38" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U21" gate="G$1" pin="1"/><wire x1="693.42" y1="73.66" x2="685.8" y2="73.66" width="0.1524" layer="91"/><label x="685.8" y="73.66" size="1.27" layer="95" rot="MR0" xref="no"/></segment></net>
<net name="CMP_REF" class="0"><segment><pinref part="R30" gate="G$1" pin="2"/><wire x1="490.22" y1="139.7" x2="497.84" y2="139.7" width="0.1524" layer="91"/><label x="497.84" y="139.7" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="R31" gate="G$1" pin="1"/><wire x1="464.82" y1="121.92" x2="457.2" y2="121.92" width="0.1524" layer="91"/><label x="457.2" y="121.92" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U13" gate="G$1" pin="2"/><wire x1="693.42" y1="243.84" x2="685.8" y2="243.84" width="0.1524" layer="91"/><label x="685.8" y="243.84" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U13" gate="G$1" pin="6"/><wire x1="718.82" y1="243.84" x2="726.44" y2="243.84" width="0.1524" layer="91"/><label x="726.44" y="243.84" size="1.27" layer="95" xref="no"/></segment></net>
<net name="COIL_P" class="0"><segment><pinref part="C20" gate="G$1" pin="1"/><wire x1="7.62" y1="33.02" x2="0.0" y2="33.02" width="0.1524" layer="91"/><label x="0.0" y="33.02" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="J8" gate="G$1" pin="1"/><wire x1="312.42" y1="185.42" x2="304.8" y2="185.42" width="0.1524" layer="91"/><label x="304.8" y="185.42" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="R20" gate="G$1" pin="1"/><wire x1="388.62" y1="68.58" x2="381.0" y2="68.58" width="0.1524" layer="91"/><label x="381.0" y="68.58" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U11" gate="G$1" pin="3"/><wire x1="617.22" y1="63.5" x2="609.6" y2="63.5" width="0.1524" layer="91"/><label x="609.6" y="63.5" size="1.27" layer="95" rot="MR0" xref="no"/></segment></net>
<net name="EN" class="0"><segment><pinref part="C1" gate="G$1" pin="1"/><wire x1="7.62" y1="210.82" x2="0.0" y2="210.82" width="0.1524" layer="91"/><label x="0.0" y="210.82" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="J1" gate="G$1" pin="7"/><wire x1="261.62" y1="152.4" x2="269.24" y2="152.4" width="0.1524" layer="91"/><label x="269.24" y="152.4" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="R1" gate="G$1" pin="2"/><wire x1="337.82" y1="35.56" x2="345.44" y2="35.56" width="0.1524" layer="91"/><label x="345.44" y="35.56" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="U1" gate="G$1" pin="3"/><wire x1="541.02" y1="81.28" x2="533.4" y2="81.28" width="0.1524" layer="91"/><label x="533.4" y="81.28" size="1.27" layer="95" rot="MR0" xref="no"/></segment></net>
<net name="ENV" class="0"><segment><pinref part="C26" gate="G$1" pin="1"/><wire x1="83.82" y1="175.26" x2="76.2" y2="175.26" width="0.1524" layer="91"/><label x="76.2" y="175.26" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="D1" gate="G$1" pin="1"/><wire x1="160.02" y1="33.02" x2="152.4" y2="33.02" width="0.1524" layer="91"/><label x="152.4" y="33.02" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="R29" gate="G$1" pin="1"/><wire x1="464.82" y1="157.48" x2="457.2" y2="157.48" width="0.1524" layer="91"/><label x="457.2" y="157.48" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U13" gate="G$1" pin="3"/><wire x1="693.42" y1="241.3" x2="685.8" y2="241.3" width="0.1524" layer="91"/><label x="685.8" y="241.3" size="1.27" layer="95" rot="MR0" xref="no"/></segment></net>
<net name="FG_ALRT" class="0"><segment><pinref part="U9" gate="G$1" pin="5"/><wire x1="617.22" y1="111.76" x2="609.6" y2="111.76" width="0.1524" layer="91"/><label x="609.6" y="111.76" size="1.27" layer="95" rot="MR0" xref="no"/></segment></net>
<net name="GND" class="0"><segment><pinref part="C1" gate="G$1" pin="2"/><wire x1="33.02" y1="210.82" x2="40.64" y2="210.82" width="0.1524" layer="91"/><label x="40.64" y="210.82" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="C2" gate="G$1" pin="2"/><wire x1="33.02" y1="193.04" x2="40.64" y2="193.04" width="0.1524" layer="91"/><label x="40.64" y="193.04" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="C3" gate="G$1" pin="2"/><wire x1="33.02" y1="175.26" x2="40.64" y2="175.26" width="0.1524" layer="91"/><label x="40.64" y="175.26" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="C4" gate="G$1" pin="2"/><wire x1="33.02" y1="157.48" x2="40.64" y2="157.48" width="0.1524" layer="91"/><label x="40.64" y="157.48" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="C5" gate="G$1" pin="2"/><wire x1="33.02" y1="139.7" x2="40.64" y2="139.7" width="0.1524" layer="91"/><label x="40.64" y="139.7" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="C6" gate="G$1" pin="2"/><wire x1="33.02" y1="121.92" x2="40.64" y2="121.92" width="0.1524" layer="91"/><label x="40.64" y="121.92" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="C7" gate="G$1" pin="2"/><wire x1="33.02" y1="104.14" x2="40.64" y2="104.14" width="0.1524" layer="91"/><label x="40.64" y="104.14" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="C10" gate="G$1" pin="2"/><wire x1="33.02" y1="86.36" x2="40.64" y2="86.36" width="0.1524" layer="91"/><label x="40.64" y="86.36" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="C11" gate="G$1" pin="2"/><wire x1="33.02" y1="68.58" x2="40.64" y2="68.58" width="0.1524" layer="91"/><label x="40.64" y="68.58" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="C13" gate="G$1" pin="2"/><wire x1="33.02" y1="50.8" x2="40.64" y2="50.8" width="0.1524" layer="91"/><label x="40.64" y="50.8" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="C21" gate="G$1" pin="2"/><wire x1="33.02" y1="15.24" x2="40.64" y2="15.24" width="0.1524" layer="91"/><label x="40.64" y="15.24" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="C23" gate="G$1" pin="2"/><wire x1="109.22" y1="228.6" x2="116.84" y2="228.6" width="0.1524" layer="91"/><label x="116.84" y="228.6" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="C24" gate="G$1" pin="2"/><wire x1="109.22" y1="210.82" x2="116.84" y2="210.82" width="0.1524" layer="91"/><label x="116.84" y="210.82" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="C25" gate="G$1" pin="2"/><wire x1="109.22" y1="193.04" x2="116.84" y2="193.04" width="0.1524" layer="91"/><label x="116.84" y="193.04" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="C26" gate="G$1" pin="2"/><wire x1="109.22" y1="175.26" x2="116.84" y2="175.26" width="0.1524" layer="91"/><label x="116.84" y="175.26" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="C29" gate="G$1" pin="2"/><wire x1="109.22" y1="121.92" x2="116.84" y2="121.92" width="0.1524" layer="91"/><label x="116.84" y="121.92" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="C30" gate="G$1" pin="2"/><wire x1="109.22" y1="104.14" x2="116.84" y2="104.14" width="0.1524" layer="91"/><label x="116.84" y="104.14" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="C31" gate="G$1" pin="2"/><wire x1="109.22" y1="86.36" x2="116.84" y2="86.36" width="0.1524" layer="91"/><label x="116.84" y="86.36" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="C32" gate="G$1" pin="2"/><wire x1="109.22" y1="68.58" x2="116.84" y2="68.58" width="0.1524" layer="91"/><label x="116.84" y="68.58" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="C33" gate="G$1" pin="2"/><wire x1="109.22" y1="50.8" x2="116.84" y2="50.8" width="0.1524" layer="91"/><label x="116.84" y="50.8" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="C34" gate="G$1" pin="2"/><wire x1="109.22" y1="33.02" x2="116.84" y2="33.02" width="0.1524" layer="91"/><label x="116.84" y="33.02" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="C36" gate="G$1" pin="2"/><wire x1="109.22" y1="15.24" x2="116.84" y2="15.24" width="0.1524" layer="91"/><label x="116.84" y="15.24" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="C37" gate="G$1" pin="2"/><wire x1="185.42" y1="246.38" x2="193.04" y2="246.38" width="0.1524" layer="91"/><label x="193.04" y="246.38" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="C38" gate="G$1" pin="2"/><wire x1="185.42" y1="228.6" x2="193.04" y2="228.6" width="0.1524" layer="91"/><label x="193.04" y="228.6" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="C39" gate="G$1" pin="2"/><wire x1="185.42" y1="210.82" x2="193.04" y2="210.82" width="0.1524" layer="91"/><label x="193.04" y="210.82" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="C40" gate="G$1" pin="2"/><wire x1="185.42" y1="193.04" x2="193.04" y2="193.04" width="0.1524" layer="91"/><label x="193.04" y="193.04" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="C41" gate="G$1" pin="2"/><wire x1="185.42" y1="175.26" x2="193.04" y2="175.26" width="0.1524" layer="91"/><label x="193.04" y="175.26" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="C42" gate="G$1" pin="2"/><wire x1="185.42" y1="157.48" x2="193.04" y2="157.48" width="0.1524" layer="91"/><label x="193.04" y="157.48" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="C43" gate="G$1" pin="2"/><wire x1="185.42" y1="139.7" x2="193.04" y2="139.7" width="0.1524" layer="91"/><label x="193.04" y="139.7" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="C44" gate="G$1" pin="2"/><wire x1="185.42" y1="121.92" x2="193.04" y2="121.92" width="0.1524" layer="91"/><label x="193.04" y="121.92" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="C45" gate="G$1" pin="2"/><wire x1="185.42" y1="104.14" x2="193.04" y2="104.14" width="0.1524" layer="91"/><label x="193.04" y="104.14" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="C46" gate="G$1" pin="2"/><wire x1="185.42" y1="86.36" x2="193.04" y2="86.36" width="0.1524" layer="91"/><label x="193.04" y="86.36" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="C47" gate="G$1" pin="2"/><wire x1="185.42" y1="68.58" x2="193.04" y2="68.58" width="0.1524" layer="91"/><label x="193.04" y="68.58" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="C48" gate="G$1" pin="2"/><wire x1="185.42" y1="50.8" x2="193.04" y2="50.8" width="0.1524" layer="91"/><label x="193.04" y="50.8" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="E2" gate="G$1" pin="1"/><wire x1="236.22" y1="193.04" x2="228.6" y2="193.04" width="0.1524" layer="91"/><label x="228.6" y="193.04" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="J1" gate="G$1" pin="2"/><wire x1="236.22" y1="154.94" x2="228.6" y2="154.94" width="0.1524" layer="91"/><label x="228.6" y="154.94" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="J2" gate="G$1" pin="1"/><wire x1="236.22" y1="132.08" x2="228.6" y2="132.08" width="0.1524" layer="91"/><label x="228.6" y="132.08" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="J2" gate="G$1" pin="9"/><wire x1="236.22" y1="111.76" x2="228.6" y2="111.76" width="0.1524" layer="91"/><label x="228.6" y="111.76" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="J2" gate="G$1" pin="10"/><wire x1="236.22" y1="109.22" x2="228.6" y2="109.22" width="0.1524" layer="91"/><label x="228.6" y="109.22" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="J2" gate="G$1" pin="20"/><wire x1="236.22" y1="83.82" x2="228.6" y2="83.82" width="0.1524" layer="91"/><label x="228.6" y="83.82" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="J2" gate="G$1" pin="21"/><wire x1="236.22" y1="81.28" x2="228.6" y2="81.28" width="0.1524" layer="91"/><label x="228.6" y="81.28" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="J2" gate="G$1" pin="22"/><wire x1="236.22" y1="78.74" x2="228.6" y2="78.74" width="0.1524" layer="91"/><label x="228.6" y="78.74" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="J2" gate="G$1" pin="23"/><wire x1="236.22" y1="76.2" x2="228.6" y2="76.2" width="0.1524" layer="91"/><label x="228.6" y="76.2" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="J2" gate="G$1" pin="24"/><wire x1="236.22" y1="73.66" x2="228.6" y2="73.66" width="0.1524" layer="91"/><label x="228.6" y="73.66" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="J2" gate="G$1" pin="25"/><wire x1="236.22" y1="71.12" x2="228.6" y2="71.12" width="0.1524" layer="91"/><label x="228.6" y="71.12" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="J2" gate="G$1" pin="26"/><wire x1="236.22" y1="68.58" x2="228.6" y2="68.58" width="0.1524" layer="91"/><label x="228.6" y="68.58" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="J2" gate="G$1" pin="27"/><wire x1="261.62" y1="132.08" x2="269.24" y2="132.08" width="0.1524" layer="91"/><label x="269.24" y="132.08" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="J2" gate="G$1" pin="28"/><wire x1="261.62" y1="129.54" x2="269.24" y2="129.54" width="0.1524" layer="91"/><label x="269.24" y="129.54" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="J2" gate="G$1" pin="29"/><wire x1="261.62" y1="127.0" x2="269.24" y2="127.0" width="0.1524" layer="91"/><label x="269.24" y="127.0" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="J2" gate="G$1" pin="30"/><wire x1="261.62" y1="124.46" x2="269.24" y2="124.46" width="0.1524" layer="91"/><label x="269.24" y="124.46" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="J2" gate="G$1" pin="31"/><wire x1="261.62" y1="121.92" x2="269.24" y2="121.92" width="0.1524" layer="91"/><label x="269.24" y="121.92" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="J2" gate="G$1" pin="32"/><wire x1="261.62" y1="119.38" x2="269.24" y2="119.38" width="0.1524" layer="91"/><label x="269.24" y="119.38" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="J2" gate="G$1" pin="33"/><wire x1="261.62" y1="116.84" x2="269.24" y2="116.84" width="0.1524" layer="91"/><label x="269.24" y="116.84" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="J2" gate="G$1" pin="34"/><wire x1="261.62" y1="114.3" x2="269.24" y2="114.3" width="0.1524" layer="91"/><label x="269.24" y="114.3" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="J2" gate="G$1" pin="35"/><wire x1="261.62" y1="111.76" x2="269.24" y2="111.76" width="0.1524" layer="91"/><label x="269.24" y="111.76" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="J2" gate="G$1" pin="36"/><wire x1="261.62" y1="109.22" x2="269.24" y2="109.22" width="0.1524" layer="91"/><label x="269.24" y="109.22" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="J2" gate="G$1" pin="37"/><wire x1="261.62" y1="106.68" x2="269.24" y2="106.68" width="0.1524" layer="91"/><label x="269.24" y="106.68" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="J2" gate="G$1" pin="38"/><wire x1="261.62" y1="104.14" x2="269.24" y2="104.14" width="0.1524" layer="91"/><label x="269.24" y="104.14" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="J2" gate="G$1" pin="39"/><wire x1="261.62" y1="101.6" x2="269.24" y2="101.6" width="0.1524" layer="91"/><label x="269.24" y="101.6" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="J2" gate="G$1" pin="40"/><wire x1="261.62" y1="99.06" x2="269.24" y2="99.06" width="0.1524" layer="91"/><label x="269.24" y="99.06" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="J2" gate="G$1" pin="41"/><wire x1="261.62" y1="96.52" x2="269.24" y2="96.52" width="0.1524" layer="91"/><label x="269.24" y="96.52" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="J2" gate="G$1" pin="45"/><wire x1="261.62" y1="86.36" x2="269.24" y2="86.36" width="0.1524" layer="91"/><label x="269.24" y="86.36" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="J2" gate="G$1" pin="50"/><wire x1="261.62" y1="73.66" x2="269.24" y2="73.66" width="0.1524" layer="91"/><label x="269.24" y="73.66" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="J2" gate="G$1" pin="MP"/><wire x1="261.62" y1="71.12" x2="269.24" y2="71.12" width="0.1524" layer="91"/><label x="269.24" y="71.12" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="J2" gate="G$1" pin="MP@2"/><wire x1="261.62" y1="68.58" x2="269.24" y2="68.58" width="0.1524" layer="91"/><label x="269.24" y="68.58" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="J3" gate="G$1" pin="6"/><wire x1="236.22" y1="38.1" x2="228.6" y2="38.1" width="0.1524" layer="91"/><label x="228.6" y="38.1" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="J3" gate="G$1" pin="11"/><wire x1="261.62" y1="43.18" x2="269.24" y2="43.18" width="0.1524" layer="91"/><label x="269.24" y="43.18" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="J3" gate="G$1" pin="11@2"/><wire x1="261.62" y1="40.64" x2="269.24" y2="40.64" width="0.1524" layer="91"/><label x="269.24" y="40.64" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="J3" gate="G$1" pin="11@3"/><wire x1="261.62" y1="38.1" x2="269.24" y2="38.1" width="0.1524" layer="91"/><label x="269.24" y="38.1" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="J3" gate="G$1" pin="11@4"/><wire x1="261.62" y1="35.56" x2="269.24" y2="35.56" width="0.1524" layer="91"/><label x="269.24" y="35.56" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="J4" gate="G$1" pin="2"/><wire x1="236.22" y1="15.24" x2="228.6" y2="15.24" width="0.1524" layer="91"/><label x="228.6" y="15.24" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="J4" gate="G$1" pin="MP"/><wire x1="261.62" y1="17.78" x2="269.24" y2="17.78" width="0.1524" layer="91"/><label x="269.24" y="17.78" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="J4" gate="G$1" pin="MP@2"/><wire x1="261.62" y1="15.24" x2="269.24" y2="15.24" width="0.1524" layer="91"/><label x="269.24" y="15.24" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="J5" gate="G$1" pin="2"/><wire x1="337.82" y1="246.38" x2="345.44" y2="246.38" width="0.1524" layer="91"/><label x="345.44" y="246.38" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="J6" gate="G$1" pin="2"/><wire x1="312.42" y1="226.06" x2="304.8" y2="226.06" width="0.1524" layer="91"/><label x="304.8" y="226.06" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="J7" gate="G$1" pin="2"/><wire x1="312.42" y1="205.74" x2="304.8" y2="205.74" width="0.1524" layer="91"/><label x="304.8" y="205.74" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="J9" gate="G$1" pin="2"/><wire x1="337.82" y1="167.64" x2="345.44" y2="167.64" width="0.1524" layer="91"/><label x="345.44" y="167.64" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="Q1" gate="G$1" pin="2"/><wire x1="312.42" y1="93.98" x2="304.8" y2="93.98" width="0.1524" layer="91"/><label x="304.8" y="93.98" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="Q2" gate="G$1" pin="2"/><wire x1="312.42" y1="73.66" x2="304.8" y2="73.66" width="0.1524" layer="91"/><label x="304.8" y="73.66" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="Q3" gate="G$1" pin="2"/><wire x1="312.42" y1="53.34" x2="304.8" y2="53.34" width="0.1524" layer="91"/><label x="304.8" y="53.34" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="R2" gate="G$1" pin="2"/><wire x1="337.82" y1="17.78" x2="345.44" y2="17.78" width="0.1524" layer="91"/><label x="345.44" y="17.78" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="R4" gate="G$1" pin="2"/><wire x1="414.02" y1="228.6" x2="421.64" y2="228.6" width="0.1524" layer="91"/><label x="421.64" y="228.6" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="R16" gate="G$1" pin="2"/><wire x1="414.02" y1="104.14" x2="421.64" y2="104.14" width="0.1524" layer="91"/><label x="421.64" y="104.14" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="R26" gate="G$1" pin="2"/><wire x1="490.22" y1="210.82" x2="497.84" y2="210.82" width="0.1524" layer="91"/><label x="497.84" y="210.82" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="R28" gate="G$1" pin="2"/><wire x1="490.22" y1="175.26" x2="497.84" y2="175.26" width="0.1524" layer="91"/><label x="497.84" y="175.26" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="R29" gate="G$1" pin="2"/><wire x1="490.22" y1="157.48" x2="497.84" y2="157.48" width="0.1524" layer="91"/><label x="497.84" y="157.48" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="R31" gate="G$1" pin="2"/><wire x1="490.22" y1="121.92" x2="497.84" y2="121.92" width="0.1524" layer="91"/><label x="497.84" y="121.92" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="R33" gate="G$1" pin="2"/><wire x1="490.22" y1="86.36" x2="497.84" y2="86.36" width="0.1524" layer="91"/><label x="497.84" y="86.36" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="R34" gate="G$1" pin="2"/><wire x1="490.22" y1="68.58" x2="497.84" y2="68.58" width="0.1524" layer="91"/><label x="497.84" y="68.58" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="R45" gate="G$1" pin="2"/><wire x1="566.42" y1="210.82" x2="574.04" y2="210.82" width="0.1524" layer="91"/><label x="574.04" y="210.82" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="R48" gate="G$1" pin="2"/><wire x1="566.42" y1="157.48" x2="574.04" y2="157.48" width="0.1524" layer="91"/><label x="574.04" y="157.48" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="R50" gate="G$1" pin="2"/><wire x1="566.42" y1="121.92" x2="574.04" y2="121.92" width="0.1524" layer="91"/><label x="574.04" y="121.92" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="U1" gate="G$1" pin="1"/><wire x1="541.02" y1="86.36" x2="533.4" y2="86.36" width="0.1524" layer="91"/><label x="533.4" y="86.36" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U1" gate="G$1" pin="40"/><wire x1="566.42" y1="55.88" x2="574.04" y2="55.88" width="0.1524" layer="91"/><label x="574.04" y="55.88" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="U1" gate="G$1" pin="41"/><wire x1="566.42" y1="53.34" x2="574.04" y2="53.34" width="0.1524" layer="91"/><label x="574.04" y="53.34" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="U1" gate="G$1" pin="41@2"/><wire x1="566.42" y1="50.8" x2="574.04" y2="50.8" width="0.1524" layer="91"/><label x="574.04" y="50.8" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="U1" gate="G$1" pin="41@3"/><wire x1="566.42" y1="48.26" x2="574.04" y2="48.26" width="0.1524" layer="91"/><label x="574.04" y="48.26" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="U1" gate="G$1" pin="41@4"/><wire x1="566.42" y1="45.72" x2="574.04" y2="45.72" width="0.1524" layer="91"/><label x="574.04" y="45.72" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="U1" gate="G$1" pin="41@5"/><wire x1="566.42" y1="43.18" x2="574.04" y2="43.18" width="0.1524" layer="91"/><label x="574.04" y="43.18" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="U1" gate="G$1" pin="41@6"/><wire x1="566.42" y1="40.64" x2="574.04" y2="40.64" width="0.1524" layer="91"/><label x="574.04" y="40.64" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="U1" gate="G$1" pin="41@7"/><wire x1="566.42" y1="38.1" x2="574.04" y2="38.1" width="0.1524" layer="91"/><label x="574.04" y="38.1" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="U1" gate="G$1" pin="41@8"/><wire x1="566.42" y1="35.56" x2="574.04" y2="35.56" width="0.1524" layer="91"/><label x="574.04" y="35.56" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="U1" gate="G$1" pin="41@9"/><wire x1="566.42" y1="33.02" x2="574.04" y2="33.02" width="0.1524" layer="91"/><label x="574.04" y="33.02" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="U1" gate="G$1" pin="41@10"/><wire x1="566.42" y1="30.48" x2="574.04" y2="30.48" width="0.1524" layer="91"/><label x="574.04" y="30.48" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="U1" gate="G$1" pin="41@11"/><wire x1="566.42" y1="27.94" x2="574.04" y2="27.94" width="0.1524" layer="91"/><label x="574.04" y="27.94" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="U1" gate="G$1" pin="41@12"/><wire x1="566.42" y1="25.4" x2="574.04" y2="25.4" width="0.1524" layer="91"/><label x="574.04" y="25.4" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="U1" gate="G$1" pin="41@13"/><wire x1="566.42" y1="22.86" x2="574.04" y2="22.86" width="0.1524" layer="91"/><label x="574.04" y="22.86" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="U2" gate="G$1" pin="1"/><wire x1="617.22" y1="246.38" x2="609.6" y2="246.38" width="0.1524" layer="91"/><label x="609.6" y="246.38" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U2" gate="G$1" pin="2"/><wire x1="617.22" y1="243.84" x2="609.6" y2="243.84" width="0.1524" layer="91"/><label x="609.6" y="243.84" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U2" gate="G$1" pin="12"/><wire x1="617.22" y1="218.44" x2="609.6" y2="218.44" width="0.1524" layer="91"/><label x="609.6" y="218.44" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U2" gate="G$1" pin="21"/><wire x1="642.62" y1="226.06" x2="650.24" y2="226.06" width="0.1524" layer="91"/><label x="650.24" y="226.06" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="U5" gate="G$1" pin="2"/><wire x1="617.22" y1="198.12" x2="609.6" y2="198.12" width="0.1524" layer="91"/><label x="609.6" y="198.12" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U5" gate="G$1" pin="3"/><wire x1="617.22" y1="195.58" x2="609.6" y2="195.58" width="0.1524" layer="91"/><label x="609.6" y="195.58" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U5" gate="G$1" pin="6"/><wire x1="617.22" y1="187.96" x2="609.6" y2="187.96" width="0.1524" layer="91"/><label x="609.6" y="187.96" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U5" gate="G$1" pin="7"/><wire x1="617.22" y1="185.42" x2="609.6" y2="185.42" width="0.1524" layer="91"/><label x="609.6" y="185.42" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U6" gate="G$1" pin="A1"/><wire x1="617.22" y1="167.64" x2="609.6" y2="167.64" width="0.1524" layer="91"/><label x="609.6" y="167.64" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U8" gate="G$1" pin="1"/><wire x1="617.22" y1="147.32" x2="609.6" y2="147.32" width="0.1524" layer="91"/><label x="609.6" y="147.32" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U8" gate="G$1" pin="2"/><wire x1="617.22" y1="144.78" x2="609.6" y2="144.78" width="0.1524" layer="91"/><label x="609.6" y="144.78" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U8" gate="G$1" pin="3"/><wire x1="617.22" y1="142.24" x2="609.6" y2="142.24" width="0.1524" layer="91"/><label x="609.6" y="142.24" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U8" gate="G$1" pin="4"/><wire x1="617.22" y1="139.7" x2="609.6" y2="139.7" width="0.1524" layer="91"/><label x="609.6" y="139.7" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U8" gate="G$1" pin="7"/><wire x1="642.62" y1="142.24" x2="650.24" y2="142.24" width="0.1524" layer="91"/><label x="650.24" y="142.24" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="U9" gate="G$1" pin="1"/><wire x1="617.22" y1="121.92" x2="609.6" y2="121.92" width="0.1524" layer="91"/><label x="609.6" y="121.92" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U9" gate="G$1" pin="4"/><wire x1="617.22" y1="114.3" x2="609.6" y2="114.3" width="0.1524" layer="91"/><label x="609.6" y="114.3" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U9" gate="G$1" pin="6"/><wire x1="642.62" y1="121.92" x2="650.24" y2="121.92" width="0.1524" layer="91"/><label x="650.24" y="121.92" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="U9" gate="G$1" pin="9"/><wire x1="642.62" y1="114.3" x2="650.24" y2="114.3" width="0.1524" layer="91"/><label x="650.24" y="114.3" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="U10" gate="G$1" pin="4"/><wire x1="617.22" y1="86.36" x2="609.6" y2="86.36" width="0.1524" layer="91"/><label x="609.6" y="86.36" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U11" gate="G$1" pin="4"/><wire x1="617.22" y1="60.96" x2="609.6" y2="60.96" width="0.1524" layer="91"/><label x="609.6" y="60.96" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U12" gate="G$1" pin="2"/><wire x1="617.22" y1="40.64" x2="609.6" y2="40.64" width="0.1524" layer="91"/><label x="609.6" y="40.64" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U12" gate="G$1" pin="5"/><wire x1="617.22" y1="33.02" x2="609.6" y2="33.02" width="0.1524" layer="91"/><label x="609.6" y="33.02" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U12" gate="G$1" pin="10"/><wire x1="642.62" y1="38.1" x2="650.24" y2="38.1" width="0.1524" layer="91"/><label x="650.24" y="38.1" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="U12" gate="G$1" pin="11"/><wire x1="642.62" y1="35.56" x2="650.24" y2="35.56" width="0.1524" layer="91"/><label x="650.24" y="35.56" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="U12" gate="G$1" pin="12"/><wire x1="642.62" y1="33.02" x2="650.24" y2="33.02" width="0.1524" layer="91"/><label x="650.24" y="33.02" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="U13" gate="G$1" pin="4"/><wire x1="693.42" y1="238.76" x2="685.8" y2="238.76" width="0.1524" layer="91"/><label x="685.8" y="238.76" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U13" gate="G$1" pin="5"/><wire x1="718.82" y1="246.38" x2="726.44" y2="246.38" width="0.1524" layer="91"/><label x="726.44" y="246.38" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="U14" gate="G$1" pin="1"/><wire x1="693.42" y1="220.98" x2="685.8" y2="220.98" width="0.1524" layer="91"/><label x="685.8" y="220.98" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U14" gate="G$1" pin="10"/><wire x1="718.82" y1="220.98" x2="726.44" y2="220.98" width="0.1524" layer="91"/><label x="726.44" y="220.98" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="U14" gate="G$1" pin="12"/><wire x1="718.82" y1="215.9" x2="726.44" y2="215.9" width="0.1524" layer="91"/><label x="726.44" y="215.9" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="U15" gate="G$1" pin="7"/><wire x1="693.42" y1="167.64" x2="685.8" y2="167.64" width="0.1524" layer="91"/><label x="685.8" y="167.64" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U16" gate="G$1" pin="2"/><wire x1="693.42" y1="139.7" x2="685.8" y2="139.7" width="0.1524" layer="91"/><label x="685.8" y="139.7" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U16" gate="G$1" pin="3"/><wire x1="693.42" y1="137.16" x2="685.8" y2="137.16" width="0.1524" layer="91"/><label x="685.8" y="137.16" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U17" gate="G$1" pin="2"/><wire x1="693.42" y1="116.84" x2="685.8" y2="116.84" width="0.1524" layer="91"/><label x="685.8" y="116.84" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U17" gate="G$1" pin="3"/><wire x1="693.42" y1="114.3" x2="685.8" y2="114.3" width="0.1524" layer="91"/><label x="685.8" y="114.3" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U18" gate="G$1" pin="2"/><wire x1="693.42" y1="93.98" x2="685.8" y2="93.98" width="0.1524" layer="91"/><label x="685.8" y="93.98" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U18" gate="G$1" pin="3"/><wire x1="693.42" y1="91.44" x2="685.8" y2="91.44" width="0.1524" layer="91"/><label x="685.8" y="91.44" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U21" gate="G$1" pin="2"/><wire x1="693.42" y1="71.12" x2="685.8" y2="71.12" width="0.1524" layer="91"/><label x="685.8" y="71.12" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U23" gate="G$1" pin="2"/><wire x1="693.42" y1="48.26" x2="685.8" y2="48.26" width="0.1524" layer="91"/><label x="685.8" y="48.26" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U24" gate="G$1" pin="4"/><wire x1="718.82" y1="27.94" x2="726.44" y2="27.94" width="0.1524" layer="91"/><label x="726.44" y="27.94" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="U25" gate="G$1" pin="2"/><wire x1="769.62" y1="243.84" x2="762.0" y2="243.84" width="0.1524" layer="91"/><label x="762.0" y="243.84" size="1.27" layer="95" rot="MR0" xref="no"/></segment></net>
<net name="GNSS_EN" class="0"><segment><pinref part="R34" gate="G$1" pin="1"/><wire x1="464.82" y1="68.58" x2="457.2" y2="68.58" width="0.1524" layer="91"/><label x="457.2" y="68.58" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U15" gate="G$1" pin="13"/><wire x1="718.82" y1="177.8" x2="726.44" y2="177.8" width="0.1524" layer="91"/><label x="726.44" y="177.8" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="U25" gate="G$1" pin="3"/><wire x1="769.62" y1="241.3" x2="762.0" y2="241.3" width="0.1524" layer="91"/><label x="762.0" y="241.3" size="1.27" layer="95" rot="MR0" xref="no"/></segment></net>
<net name="GNSS_PPS" class="0"><segment><pinref part="U14" gate="G$1" pin="4"/><wire x1="693.42" y1="213.36" x2="685.8" y2="213.36" width="0.1524" layer="91"/><label x="685.8" y="213.36" size="1.27" layer="95" rot="MR0" xref="no"/></segment></net>
<net name="GNSS_RF" class="0"><segment><pinref part="C33" gate="G$1" pin="1"/><wire x1="83.82" y1="50.8" x2="76.2" y2="50.8" width="0.1524" layer="91"/><label x="76.2" y="50.8" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="L5" gate="G$1" pin="1"/><wire x1="312.42" y1="114.3" x2="304.8" y2="114.3" width="0.1524" layer="91"/><label x="304.8" y="114.3" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U14" gate="G$1" pin="11"/><wire x1="718.82" y1="218.44" x2="726.44" y2="218.44" width="0.1524" layer="91"/><label x="726.44" y="218.44" size="1.27" layer="95" xref="no"/></segment></net>
<net name="GNSS_RX" class="0"><segment><pinref part="U1" gate="G$1" pin="11"/><wire x1="541.02" y1="60.96" x2="533.4" y2="60.96" width="0.1524" layer="91"/><label x="533.4" y="60.96" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U14" gate="G$1" pin="2"/><wire x1="693.42" y1="218.44" x2="685.8" y2="218.44" width="0.1524" layer="91"/><label x="685.8" y="218.44" size="1.27" layer="95" rot="MR0" xref="no"/></segment></net>
<net name="GNSS_TX" class="0"><segment><pinref part="U1" gate="G$1" pin="10"/><wire x1="541.02" y1="63.5" x2="533.4" y2="63.5" width="0.1524" layer="91"/><label x="533.4" y="63.5" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U14" gate="G$1" pin="3"/><wire x1="693.42" y1="215.9" x2="685.8" y2="215.9" width="0.1524" layer="91"/><label x="685.8" y="215.9" size="1.27" layer="95" rot="MR0" xref="no"/></segment></net>
<net name="I2S_BCK" class="0"><segment><pinref part="U1" gate="G$1" pin="4"/><wire x1="541.02" y1="78.74" x2="533.4" y2="78.74" width="0.1524" layer="91"/><label x="533.4" y="78.74" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U12" gate="G$1" pin="8"/><wire x1="642.62" y1="43.18" x2="650.24" y2="43.18" width="0.1524" layer="91"/><label x="650.24" y="43.18" size="1.27" layer="95" xref="no"/></segment></net>
<net name="I2S_DIN" class="0"><segment><pinref part="U1" gate="G$1" pin="6"/><wire x1="541.02" y1="73.66" x2="533.4" y2="73.66" width="0.1524" layer="91"/><label x="533.4" y="73.66" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U12" gate="G$1" pin="9"/><wire x1="642.62" y1="40.64" x2="650.24" y2="40.64" width="0.1524" layer="91"/><label x="650.24" y="40.64" size="1.27" layer="95" xref="no"/></segment></net>
<net name="I2S_LRCK" class="0"><segment><pinref part="U1" gate="G$1" pin="5"/><wire x1="541.02" y1="76.2" x2="533.4" y2="76.2" width="0.1524" layer="91"/><label x="533.4" y="76.2" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U12" gate="G$1" pin="7"/><wire x1="617.22" y1="27.94" x2="609.6" y2="27.94" width="0.1524" layer="91"/><label x="609.6" y="27.94" size="1.27" layer="95" rot="MR0" xref="no"/></segment></net>
<net name="I2S_MCLK" class="0"><segment><pinref part="U1" gate="G$1" pin="7"/><wire x1="541.02" y1="71.12" x2="533.4" y2="71.12" width="0.1524" layer="91"/><label x="533.4" y="71.12" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U12" gate="G$1" pin="6"/><wire x1="617.22" y1="30.48" x2="609.6" y2="30.48" width="0.1524" layer="91"/><label x="609.6" y="30.48" size="1.27" layer="95" rot="MR0" xref="no"/></segment></net>
<net name="IMU_INT" class="0"><segment><pinref part="U5" gate="G$1" pin="4"/><wire x1="617.22" y1="193.04" x2="609.6" y2="193.04" width="0.1524" layer="91"/><label x="609.6" y="193.04" size="1.27" layer="95" rot="MR0" xref="no"/></segment></net>
<net name="IMU_SA0" class="0"><segment><pinref part="R16" gate="G$1" pin="1"/><wire x1="388.62" y1="104.14" x2="381.0" y2="104.14" width="0.1524" layer="91"/><label x="381.0" y="104.14" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="R17" gate="G$1" pin="2"/><wire x1="414.02" y1="86.36" x2="421.64" y2="86.36" width="0.1524" layer="91"/><label x="421.64" y="86.36" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="U5" gate="G$1" pin="1"/><wire x1="617.22" y1="200.66" x2="609.6" y2="200.66" width="0.1524" layer="91"/><label x="609.6" y="200.66" size="1.27" layer="95" rot="MR0" xref="no"/></segment></net>
<net name="LCD_BL" class="0"><segment><pinref part="R41" gate="G$1" pin="1"/><wire x1="464.82" y1="33.02" x2="457.2" y2="33.02" width="0.1524" layer="91"/><label x="457.2" y="33.02" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U1" gate="G$1" pin="9"/><wire x1="541.02" y1="66.04" x2="533.4" y2="66.04" width="0.1524" layer="91"/><label x="533.4" y="66.04" size="1.27" layer="95" rot="MR0" xref="no"/></segment></net>
<net name="LCD_CS" class="0"><segment><pinref part="J2" gate="G$1" pin="14"/><wire x1="236.22" y1="99.06" x2="228.6" y2="99.06" width="0.1524" layer="91"/><label x="228.6" y="99.06" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U1" gate="G$1" pin="18"/><wire x1="541.02" y1="43.18" x2="533.4" y2="43.18" width="0.1524" layer="91"/><label x="533.4" y="43.18" size="1.27" layer="95" rot="MR0" xref="no"/></segment></net>
<net name="LCD_DC" class="0"><segment><pinref part="J2" gate="G$1" pin="15"/><wire x1="236.22" y1="96.52" x2="228.6" y2="96.52" width="0.1524" layer="91"/><label x="228.6" y="96.52" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U1" gate="G$1" pin="22"/><wire x1="541.02" y1="33.02" x2="533.4" y2="33.02" width="0.1524" layer="91"/><label x="533.4" y="33.02" size="1.27" layer="95" rot="MR0" xref="no"/></segment></net>
<net name="LCD_RST" class="0"><segment><pinref part="J2" gate="G$1" pin="13"/><wire x1="236.22" y1="101.6" x2="228.6" y2="101.6" width="0.1524" layer="91"/><label x="228.6" y="101.6" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U1" gate="G$1" pin="23"/><wire x1="541.02" y1="30.48" x2="533.4" y2="30.48" width="0.1524" layer="91"/><label x="533.4" y="30.48" size="1.27" layer="95" rot="MR0" xref="no"/></segment></net>
<net name="PA_AC1" class="0"><segment><pinref part="C27" gate="G$1" pin="1"/><wire x1="83.82" y1="157.48" x2="76.2" y2="157.48" width="0.1524" layer="91"/><label x="76.2" y="157.48" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="R21" gate="G$1" pin="2"/><wire x1="414.02" y1="50.8" x2="421.64" y2="50.8" width="0.1524" layer="91"/><label x="421.64" y="50.8" size="1.27" layer="95" xref="no"/></segment></net>
<net name="PA_AC2" class="0"><segment><pinref part="C28" gate="G$1" pin="1"/><wire x1="83.82" y1="139.7" x2="76.2" y2="139.7" width="0.1524" layer="91"/><label x="76.2" y="139.7" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="R23" gate="G$1" pin="2"/><wire x1="414.02" y1="15.24" x2="421.64" y2="15.24" width="0.1524" layer="91"/><label x="421.64" y="15.24" size="1.27" layer="95" xref="no"/></segment></net>
<net name="PA_FB1" class="0"><segment><pinref part="R21" gate="G$1" pin="1"/><wire x1="388.62" y1="50.8" x2="381.0" y2="50.8" width="0.1524" layer="91"/><label x="381.0" y="50.8" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="R22" gate="G$1" pin="1"/><wire x1="388.62" y1="33.02" x2="381.0" y2="33.02" width="0.1524" layer="91"/><label x="381.0" y="33.02" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U11" gate="G$1" pin="2"/><wire x1="617.22" y1="66.04" x2="609.6" y2="66.04" width="0.1524" layer="91"/><label x="609.6" y="66.04" size="1.27" layer="95" rot="MR0" xref="no"/></segment></net>
<net name="PA_FB2" class="0"><segment><pinref part="R23" gate="G$1" pin="1"/><wire x1="388.62" y1="15.24" x2="381.0" y2="15.24" width="0.1524" layer="91"/><label x="381.0" y="15.24" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="R24" gate="G$1" pin="1"/><wire x1="464.82" y1="246.38" x2="457.2" y2="246.38" width="0.1524" layer="91"/><label x="457.2" y="246.38" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U11" gate="G$1" pin="6"/><wire x1="642.62" y1="66.04" x2="650.24" y2="66.04" width="0.1524" layer="91"/><label x="650.24" y="66.04" size="1.27" layer="95" xref="no"/></segment></net>
<net name="PA_OUT1" class="0"><segment><pinref part="R22" gate="G$1" pin="2"/><wire x1="414.02" y1="33.02" x2="421.64" y2="33.02" width="0.1524" layer="91"/><label x="421.64" y="33.02" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="U11" gate="G$1" pin="1"/><wire x1="617.22" y1="68.58" x2="609.6" y2="68.58" width="0.1524" layer="91"/><label x="609.6" y="68.58" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U11" gate="G$1" pin="5"/><wire x1="642.62" y1="68.58" x2="650.24" y2="68.58" width="0.1524" layer="91"/><label x="650.24" y="68.58" size="1.27" layer="95" xref="no"/></segment></net>
<net name="PA_OUT2" class="0"><segment><pinref part="C22" gate="G$1" pin="1"/><wire x1="83.82" y1="246.38" x2="76.2" y2="246.38" width="0.1524" layer="91"/><label x="76.2" y="246.38" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="R24" gate="G$1" pin="2"/><wire x1="490.22" y1="246.38" x2="497.84" y2="246.38" width="0.1524" layer="91"/><label x="497.84" y="246.38" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="U11" gate="G$1" pin="7"/><wire x1="642.62" y1="63.5" x2="650.24" y2="63.5" width="0.1524" layer="91"/><label x="650.24" y="63.5" size="1.27" layer="95" xref="no"/></segment></net>
<net name="PROG" class="0"><segment><pinref part="R2" gate="G$1" pin="1"/><wire x1="312.42" y1="17.78" x2="304.8" y2="17.78" width="0.1524" layer="91"/><label x="304.8" y="17.78" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U21" gate="G$1" pin="5"/><wire x1="718.82" y1="71.12" x2="726.44" y2="71.12" width="0.1524" layer="91"/><label x="726.44" y="71.12" size="1.27" layer="95" xref="no"/></segment></net>
<net name="RTC_CLK" class="0"><segment><pinref part="U10" gate="G$1" pin="7"/><wire x1="642.62" y1="88.9" x2="650.24" y2="88.9" width="0.1524" layer="91"/><label x="650.24" y="88.9" size="1.27" layer="95" xref="no"/></segment></net>
<net name="RTC_INT" class="0"><segment><pinref part="U10" gate="G$1" pin="3"/><wire x1="617.22" y1="88.9" x2="609.6" y2="88.9" width="0.1524" layer="91"/><label x="609.6" y="88.9" size="1.27" layer="95" rot="MR0" xref="no"/></segment></net>
<net name="RXD0" class="0"><segment><pinref part="J1" gate="G$1" pin="6"/><wire x1="261.62" y1="154.94" x2="269.24" y2="154.94" width="0.1524" layer="91"/><label x="269.24" y="154.94" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="U1" gate="G$1" pin="36"/><wire x1="566.42" y1="66.04" x2="574.04" y2="66.04" width="0.1524" layer="91"/><label x="574.04" y="66.04" size="1.27" layer="95" xref="no"/></segment></net>
<net name="SAFE_RX" class="0"><segment><pinref part="U1" gate="G$1" pin="38"/><wire x1="566.42" y1="60.96" x2="574.04" y2="60.96" width="0.1524" layer="91"/><label x="574.04" y="60.96" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="U15" gate="G$1" pin="2"/><wire x1="693.42" y1="180.34" x2="685.8" y2="180.34" width="0.1524" layer="91"/><label x="685.8" y="180.34" size="1.27" layer="95" rot="MR0" xref="no"/></segment></net>
<net name="SAFE_TX" class="0"><segment><pinref part="U1" gate="G$1" pin="39"/><wire x1="566.42" y1="58.42" x2="574.04" y2="58.42" width="0.1524" layer="91"/><label x="574.04" y="58.42" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="U15" gate="G$1" pin="3"/><wire x1="693.42" y1="177.8" x2="685.8" y2="177.8" width="0.1524" layer="91"/><label x="685.8" y="177.8" size="1.27" layer="95" rot="MR0" xref="no"/></segment></net>
<net name="SCL" class="0"><segment><pinref part="J6" gate="G$1" pin="4"/><wire x1="337.82" y1="226.06" x2="345.44" y2="226.06" width="0.1524" layer="91"/><label x="345.44" y="226.06" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="R11" gate="G$1" pin="2"/><wire x1="414.02" y1="193.04" x2="421.64" y2="193.04" width="0.1524" layer="91"/><label x="421.64" y="193.04" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="U1" gate="G$1" pin="17"/><wire x1="541.02" y1="45.72" x2="533.4" y2="45.72" width="0.1524" layer="91"/><label x="533.4" y="45.72" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U2" gate="G$1" pin="22"/><wire x1="642.62" y1="223.52" x2="650.24" y2="223.52" width="0.1524" layer="91"/><label x="650.24" y="223.52" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="U5" gate="G$1" pin="13"/><wire x1="642.62" y1="187.96" x2="650.24" y2="187.96" width="0.1524" layer="91"/><label x="650.24" y="187.96" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="U6" gate="G$1" pin="A2"/><wire x1="617.22" y1="165.1" x2="609.6" y2="165.1" width="0.1524" layer="91"/><label x="609.6" y="165.1" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U8" gate="G$1" pin="6"/><wire x1="642.62" y1="144.78" x2="650.24" y2="144.78" width="0.1524" layer="91"/><label x="650.24" y="144.78" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="U9" gate="G$1" pin="7"/><wire x1="642.62" y1="119.38" x2="650.24" y2="119.38" width="0.1524" layer="91"/><label x="650.24" y="119.38" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="U10" gate="G$1" pin="6"/><wire x1="642.62" y1="91.44" x2="650.24" y2="91.44" width="0.1524" layer="91"/><label x="650.24" y="91.44" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="U16" gate="G$1" pin="1"/><wire x1="693.42" y1="142.24" x2="685.8" y2="142.24" width="0.1524" layer="91"/><label x="685.8" y="142.24" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U17" gate="G$1" pin="1"/><wire x1="693.42" y1="119.38" x2="685.8" y2="119.38" width="0.1524" layer="91"/><label x="685.8" y="119.38" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U18" gate="G$1" pin="1"/><wire x1="693.42" y1="96.52" x2="685.8" y2="96.52" width="0.1524" layer="91"/><label x="685.8" y="96.52" size="1.27" layer="95" rot="MR0" xref="no"/></segment></net>
<net name="SCL_A" class="0"><segment><pinref part="J7" gate="G$1" pin="4"/><wire x1="337.82" y1="208.28" x2="345.44" y2="208.28" width="0.1524" layer="91"/><label x="345.44" y="208.28" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="R13" gate="G$1" pin="2"/><wire x1="414.02" y1="157.48" x2="421.64" y2="157.48" width="0.1524" layer="91"/><label x="421.64" y="157.48" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="U2" gate="G$1" pin="5"/><wire x1="617.22" y1="236.22" x2="609.6" y2="236.22" width="0.1524" layer="91"/><label x="609.6" y="236.22" size="1.27" layer="95" rot="MR0" xref="no"/></segment></net>
<net name="SCL_B" class="0"><segment><pinref part="J7" gate="G$1" pin="6"/><wire x1="337.82" y1="203.2" x2="345.44" y2="203.2" width="0.1524" layer="91"/><label x="345.44" y="203.2" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="R15" gate="G$1" pin="2"/><wire x1="414.02" y1="121.92" x2="421.64" y2="121.92" width="0.1524" layer="91"/><label x="421.64" y="121.92" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="U2" gate="G$1" pin="7"/><wire x1="617.22" y1="231.14" x2="609.6" y2="231.14" width="0.1524" layer="91"/><label x="609.6" y="231.14" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U15" gate="G$1" pin="12"/><wire x1="718.82" y1="180.34" x2="726.44" y2="180.34" width="0.1524" layer="91"/><label x="726.44" y="180.34" size="1.27" layer="95" xref="no"/></segment></net>
<net name="SDA" class="0"><segment><pinref part="J6" gate="G$1" pin="3"/><wire x1="337.82" y1="228.6" x2="345.44" y2="228.6" width="0.1524" layer="91"/><label x="345.44" y="228.6" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="R10" gate="G$1" pin="2"/><wire x1="414.02" y1="210.82" x2="421.64" y2="210.82" width="0.1524" layer="91"/><label x="421.64" y="210.82" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="U1" gate="G$1" pin="12"/><wire x1="541.02" y1="58.42" x2="533.4" y2="58.42" width="0.1524" layer="91"/><label x="533.4" y="58.42" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U2" gate="G$1" pin="23"/><wire x1="642.62" y1="220.98" x2="650.24" y2="220.98" width="0.1524" layer="91"/><label x="650.24" y="220.98" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="U5" gate="G$1" pin="14"/><wire x1="642.62" y1="185.42" x2="650.24" y2="185.42" width="0.1524" layer="91"/><label x="650.24" y="185.42" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="U6" gate="G$1" pin="B2"/><wire x1="642.62" y1="165.1" x2="650.24" y2="165.1" width="0.1524" layer="91"/><label x="650.24" y="165.1" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="U8" gate="G$1" pin="5"/><wire x1="642.62" y1="147.32" x2="650.24" y2="147.32" width="0.1524" layer="91"/><label x="650.24" y="147.32" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="U9" gate="G$1" pin="8"/><wire x1="642.62" y1="116.84" x2="650.24" y2="116.84" width="0.1524" layer="91"/><label x="650.24" y="116.84" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="U10" gate="G$1" pin="5"/><wire x1="642.62" y1="93.98" x2="650.24" y2="93.98" width="0.1524" layer="91"/><label x="650.24" y="93.98" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="U16" gate="G$1" pin="6"/><wire x1="718.82" y1="137.16" x2="726.44" y2="137.16" width="0.1524" layer="91"/><label x="726.44" y="137.16" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="U17" gate="G$1" pin="6"/><wire x1="718.82" y1="114.3" x2="726.44" y2="114.3" width="0.1524" layer="91"/><label x="726.44" y="114.3" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="U18" gate="G$1" pin="6"/><wire x1="718.82" y1="91.44" x2="726.44" y2="91.44" width="0.1524" layer="91"/><label x="726.44" y="91.44" size="1.27" layer="95" xref="no"/></segment></net>
<net name="SDA_A" class="0"><segment><pinref part="J7" gate="G$1" pin="3"/><wire x1="312.42" y1="203.2" x2="304.8" y2="203.2" width="0.1524" layer="91"/><label x="304.8" y="203.2" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="R12" gate="G$1" pin="2"/><wire x1="414.02" y1="175.26" x2="421.64" y2="175.26" width="0.1524" layer="91"/><label x="421.64" y="175.26" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="U2" gate="G$1" pin="4"/><wire x1="617.22" y1="238.76" x2="609.6" y2="238.76" width="0.1524" layer="91"/><label x="609.6" y="238.76" size="1.27" layer="95" rot="MR0" xref="no"/></segment></net>
<net name="SDA_B" class="0"><segment><pinref part="J7" gate="G$1" pin="5"/><wire x1="337.82" y1="205.74" x2="345.44" y2="205.74" width="0.1524" layer="91"/><label x="345.44" y="205.74" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="R14" gate="G$1" pin="2"/><wire x1="414.02" y1="139.7" x2="421.64" y2="139.7" width="0.1524" layer="91"/><label x="421.64" y="139.7" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="U2" gate="G$1" pin="6"/><wire x1="617.22" y1="233.68" x2="609.6" y2="233.68" width="0.1524" layer="91"/><label x="609.6" y="233.68" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U15" gate="G$1" pin="11"/><wire x1="718.82" y1="182.88" x2="726.44" y2="182.88" width="0.1524" layer="91"/><label x="726.44" y="182.88" size="1.27" layer="95" xref="no"/></segment></net>
<net name="SD_CS" class="0"><segment><pinref part="J3" gate="G$1" pin="2"/><wire x1="236.22" y1="48.26" x2="228.6" y2="48.26" width="0.1524" layer="91"/><label x="228.6" y="48.26" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="R42" gate="G$1" pin="2"/><wire x1="490.22" y1="15.24" x2="497.84" y2="15.24" width="0.1524" layer="91"/><label x="497.84" y="15.24" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="U1" gate="G$1" pin="8"/><wire x1="541.02" y1="68.58" x2="533.4" y2="68.58" width="0.1524" layer="91"/><label x="533.4" y="68.58" size="1.27" layer="95" rot="MR0" xref="no"/></segment></net>
<net name="SD_D1" class="0"><segment><pinref part="J3" gate="G$1" pin="8"/><wire x1="261.62" y1="50.8" x2="269.24" y2="50.8" width="0.1524" layer="91"/><label x="269.24" y="50.8" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="R43" gate="G$1" pin="2"/><wire x1="566.42" y1="246.38" x2="574.04" y2="246.38" width="0.1524" layer="91"/><label x="574.04" y="246.38" size="1.27" layer="95" xref="no"/></segment></net>
<net name="SD_D2" class="0"><segment><pinref part="J3" gate="G$1" pin="1"/><wire x1="236.22" y1="50.8" x2="228.6" y2="50.8" width="0.1524" layer="91"/><label x="228.6" y="50.8" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="R44" gate="G$1" pin="2"/><wire x1="566.42" y1="228.6" x2="574.04" y2="228.6" width="0.1524" layer="91"/><label x="574.04" y="228.6" size="1.27" layer="95" xref="no"/></segment></net>
<net name="SPI_MISO" class="0"><segment><pinref part="J3" gate="G$1" pin="7"/><wire x1="236.22" y1="35.56" x2="228.6" y2="35.56" width="0.1524" layer="91"/><label x="228.6" y="35.56" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U1" gate="G$1" pin="21"/><wire x1="541.02" y1="35.56" x2="533.4" y2="35.56" width="0.1524" layer="91"/><label x="533.4" y="35.56" size="1.27" layer="95" rot="MR0" xref="no"/></segment></net>
<net name="SPI_MOSI" class="0"><segment><pinref part="J2" gate="G$1" pin="18"/><wire x1="236.22" y1="88.9" x2="228.6" y2="88.9" width="0.1524" layer="91"/><label x="228.6" y="88.9" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="J3" gate="G$1" pin="3"/><wire x1="236.22" y1="45.72" x2="228.6" y2="45.72" width="0.1524" layer="91"/><label x="228.6" y="45.72" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U1" gate="G$1" pin="19"/><wire x1="541.02" y1="40.64" x2="533.4" y2="40.64" width="0.1524" layer="91"/><label x="533.4" y="40.64" size="1.27" layer="95" rot="MR0" xref="no"/></segment></net>
<net name="SPI_SCK" class="0"><segment><pinref part="J2" gate="G$1" pin="16"/><wire x1="236.22" y1="93.98" x2="228.6" y2="93.98" width="0.1524" layer="91"/><label x="228.6" y="93.98" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="J3" gate="G$1" pin="5"/><wire x1="236.22" y1="40.64" x2="228.6" y2="40.64" width="0.1524" layer="91"/><label x="228.6" y="40.64" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U1" gate="G$1" pin="20"/><wire x1="541.02" y1="38.1" x2="533.4" y2="38.1" width="0.1524" layer="91"/><label x="533.4" y="38.1" size="1.27" layer="95" rot="MR0" xref="no"/></segment></net>
<net name="SWIO" class="0"><segment><pinref part="TP1" gate="G$1" pin="1"/><wire x1="541.02" y1="104.14" x2="533.4" y2="104.14" width="0.1524" layer="91"/><label x="533.4" y="104.14" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U15" gate="G$1" pin="18"/><wire x1="718.82" y1="165.1" x2="726.44" y2="165.1" width="0.1524" layer="91"/><label x="726.44" y="165.1" size="1.27" layer="95" xref="no"/></segment></net>
<net name="TX123_ENV" class="0"><segment><pinref part="R32" gate="G$1" pin="2"/><wire x1="490.22" y1="104.14" x2="497.84" y2="104.14" width="0.1524" layer="91"/><label x="497.84" y="104.14" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="U1" gate="G$1" pin="25"/><wire x1="541.02" y1="25.4" x2="533.4" y2="25.4" width="0.1524" layer="91"/><label x="533.4" y="25.4" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U13" gate="G$1" pin="1"/><wire x1="693.42" y1="246.38" x2="685.8" y2="246.38" width="0.1524" layer="91"/><label x="685.8" y="246.38" size="1.27" layer="95" rot="MR0" xref="no"/></segment></net>
<net name="TXD0" class="0"><segment><pinref part="J1" gate="G$1" pin="5"/><wire x1="261.62" y1="157.48" x2="269.24" y2="157.48" width="0.1524" layer="91"/><label x="269.24" y="157.48" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="U1" gate="G$1" pin="37"/><wire x1="566.42" y1="63.5" x2="574.04" y2="63.5" width="0.1524" layer="91"/><label x="574.04" y="63.5" size="1.27" layer="95" xref="no"/></segment></net>
<net name="USB_DM" class="0"><segment><pinref part="J1" gate="G$1" pin="3"/><wire x1="236.22" y1="152.4" x2="228.6" y2="152.4" width="0.1524" layer="91"/><label x="228.6" y="152.4" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U1" gate="G$1" pin="13"/><wire x1="541.02" y1="55.88" x2="533.4" y2="55.88" width="0.1524" layer="91"/><label x="533.4" y="55.88" size="1.27" layer="95" rot="MR0" xref="no"/></segment></net>
<net name="USB_DP" class="0"><segment><pinref part="J1" gate="G$1" pin="4"/><wire x1="236.22" y1="149.86" x2="228.6" y2="149.86" width="0.1524" layer="91"/><label x="228.6" y="149.86" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U1" gate="G$1" pin="14"/><wire x1="541.02" y1="53.34" x2="533.4" y2="53.34" width="0.1524" layer="91"/><label x="533.4" y="53.34" size="1.27" layer="95" rot="MR0" xref="no"/></segment></net>
<net name="VBAT" class="0"><segment><pinref part="BZ1" gate="G$1" pin="1"/><wire x1="7.62" y1="228.6" x2="0.0" y2="228.6" width="0.1524" layer="91"/><label x="0.0" y="228.6" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="C5" gate="G$1" pin="1"/><wire x1="7.62" y1="139.7" x2="0.0" y2="139.7" width="0.1524" layer="91"/><label x="0.0" y="139.7" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="C6" gate="G$1" pin="1"/><wire x1="7.62" y1="121.92" x2="0.0" y2="121.92" width="0.1524" layer="91"/><label x="0.0" y="121.92" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="C32" gate="G$1" pin="1"/><wire x1="83.82" y1="68.58" x2="76.2" y2="68.58" width="0.1524" layer="91"/><label x="76.2" y="68.58" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="C42" gate="G$1" pin="1"/><wire x1="160.02" y1="157.48" x2="152.4" y2="157.48" width="0.1524" layer="91"/><label x="152.4" y="157.48" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="D4" gate="G$1" pin="1"/><wire x1="236.22" y1="228.6" x2="228.6" y2="228.6" width="0.1524" layer="91"/><label x="228.6" y="228.6" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="J1" gate="G$1" pin="1"/><wire x1="236.22" y1="157.48" x2="228.6" y2="157.48" width="0.1524" layer="91"/><label x="228.6" y="157.48" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="J4" gate="G$1" pin="1"/><wire x1="236.22" y1="17.78" x2="228.6" y2="17.78" width="0.1524" layer="91"/><label x="228.6" y="17.78" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="J10" gate="G$1" pin="1"/><wire x1="312.42" y1="149.86" x2="304.8" y2="149.86" width="0.1524" layer="91"/><label x="304.8" y="149.86" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="L4" gate="G$1" pin="1"/><wire x1="312.42" y1="132.08" x2="304.8" y2="132.08" width="0.1524" layer="91"/><label x="304.8" y="132.08" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="R40" gate="G$1" pin="1"/><wire x1="464.82" y1="50.8" x2="457.2" y2="50.8" width="0.1524" layer="91"/><label x="457.2" y="50.8" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="R46" gate="G$1" pin="1"/><wire x1="541.02" y1="193.04" x2="533.4" y2="193.04" width="0.1524" layer="91"/><label x="533.4" y="193.04" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U9" gate="G$1" pin="2"/><wire x1="617.22" y1="119.38" x2="609.6" y2="119.38" width="0.1524" layer="91"/><label x="609.6" y="119.38" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U9" gate="G$1" pin="3"/><wire x1="617.22" y1="116.84" x2="609.6" y2="116.84" width="0.1524" layer="91"/><label x="609.6" y="116.84" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U21" gate="G$1" pin="3"/><wire x1="693.42" y1="68.58" x2="685.8" y2="68.58" width="0.1524" layer="91"/><label x="685.8" y="68.58" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U23" gate="G$1" pin="1"/><wire x1="693.42" y1="50.8" x2="685.8" y2="50.8" width="0.1524" layer="91"/><label x="685.8" y="50.8" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U23" gate="G$1" pin="3"/><wire x1="693.42" y1="45.72" x2="685.8" y2="45.72" width="0.1524" layer="91"/><label x="685.8" y="45.72" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U24" gate="G$1" pin="3"/><wire x1="693.42" y1="22.86" x2="685.8" y2="22.86" width="0.1524" layer="91"/><label x="685.8" y="22.86" size="1.27" layer="95" rot="MR0" xref="no"/></segment></net>
<net name="VIB" class="0"><segment><pinref part="R47" gate="G$1" pin="1"/><wire x1="541.02" y1="175.26" x2="533.4" y2="175.26" width="0.1524" layer="91"/><label x="533.4" y="175.26" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U1" gate="G$1" pin="24"/><wire x1="541.02" y1="27.94" x2="533.4" y2="27.94" width="0.1524" layer="91"/><label x="533.4" y="27.94" size="1.27" layer="95" rot="MR0" xref="no"/></segment></net>
<net name="VIB_G" class="0"><segment><pinref part="Q3" gate="G$1" pin="1"/><wire x1="312.42" y1="55.88" x2="304.8" y2="55.88" width="0.1524" layer="91"/><label x="304.8" y="55.88" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="R47" gate="G$1" pin="2"/><wire x1="566.42" y1="175.26" x2="574.04" y2="175.26" width="0.1524" layer="91"/><label x="574.04" y="175.26" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="R48" gate="G$1" pin="1"/><wire x1="541.02" y1="157.48" x2="533.4" y2="157.48" width="0.1524" layer="91"/><label x="533.4" y="157.48" size="1.27" layer="95" rot="MR0" xref="no"/></segment></net>
<net name="VIB_K" class="0"><segment><pinref part="D4" gate="G$1" pin="2"/><wire x1="261.62" y1="228.6" x2="269.24" y2="228.6" width="0.1524" layer="91"/><label x="269.24" y="228.6" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="J10" gate="G$1" pin="2"/><wire x1="337.82" y1="149.86" x2="345.44" y2="149.86" width="0.1524" layer="91"/><label x="345.44" y="149.86" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="Q3" gate="G$1" pin="3"/><wire x1="337.82" y1="55.88" x2="345.44" y2="55.88" width="0.1524" layer="91"/><label x="345.44" y="55.88" size="1.27" layer="95" xref="no"/></segment></net>
<net name="VMID" class="0"><segment><pinref part="C20" gate="G$1" pin="2"/><wire x1="33.02" y1="33.02" x2="40.64" y2="33.02" width="0.1524" layer="91"/><label x="40.64" y="33.02" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="C21" gate="G$1" pin="1"/><wire x1="7.62" y1="15.24" x2="0.0" y2="15.24" width="0.1524" layer="91"/><label x="0.0" y="15.24" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="C27" gate="G$1" pin="2"/><wire x1="109.22" y1="157.48" x2="116.84" y2="157.48" width="0.1524" layer="91"/><label x="116.84" y="157.48" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="C28" gate="G$1" pin="2"/><wire x1="109.22" y1="139.7" x2="116.84" y2="139.7" width="0.1524" layer="91"/><label x="116.84" y="139.7" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="J8" gate="G$1" pin="2"/><wire x1="337.82" y1="185.42" x2="345.44" y2="185.42" width="0.1524" layer="91"/><label x="345.44" y="185.42" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="R20" gate="G$1" pin="2"/><wire x1="414.02" y1="68.58" x2="421.64" y2="68.58" width="0.1524" layer="91"/><label x="421.64" y="68.58" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="R25" gate="G$1" pin="2"/><wire x1="490.22" y1="228.6" x2="497.84" y2="228.6" width="0.1524" layer="91"/><label x="497.84" y="228.6" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="R26" gate="G$1" pin="1"/><wire x1="464.82" y1="210.82" x2="457.2" y2="210.82" width="0.1524" layer="91"/><label x="457.2" y="210.82" size="1.27" layer="95" rot="MR0" xref="no"/></segment></net>
<net name="VQI" class="0"><segment><pinref part="C4" gate="G$1" pin="1"/><wire x1="7.62" y1="157.48" x2="0.0" y2="157.48" width="0.1524" layer="91"/><label x="0.0" y="157.48" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="J5" gate="G$1" pin="1"/><wire x1="312.42" y1="246.38" x2="304.8" y2="246.38" width="0.1524" layer="91"/><label x="304.8" y="246.38" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U21" gate="G$1" pin="4"/><wire x1="718.82" y1="73.66" x2="726.44" y2="73.66" width="0.1524" layer="91"/><label x="726.44" y="73.66" size="1.27" layer="95" xref="no"/></segment></net>
<net name="WET" class="0"><segment><pinref part="R49" gate="G$1" pin="2"/><wire x1="566.42" y1="139.7" x2="574.04" y2="139.7" width="0.1524" layer="91"/><label x="574.04" y="139.7" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="U1" gate="G$1" pin="15"/><wire x1="541.02" y1="50.8" x2="533.4" y2="50.8" width="0.1524" layer="91"/><label x="533.4" y="50.8" size="1.27" layer="95" rot="MR0" xref="no"/></segment></net>
<net name="WET_PIN" class="0"><segment><pinref part="E1" gate="G$1" pin="1"/><wire x1="236.22" y1="210.82" x2="228.6" y2="210.82" width="0.1524" layer="91"/><label x="228.6" y="210.82" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="R49" gate="G$1" pin="1"/><wire x1="541.02" y1="139.7" x2="533.4" y2="139.7" width="0.1524" layer="91"/><label x="533.4" y="139.7" size="1.27" layer="95" rot="MR0" xref="no"/></segment></net>
<net name="XI" class="0"><segment><pinref part="U10" gate="G$1" pin="1"/><wire x1="617.22" y1="93.98" x2="609.6" y2="93.98" width="0.1524" layer="91"/><label x="609.6" y="93.98" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="Y1" gate="G$1" pin="1"/><wire x1="769.62" y1="223.52" x2="762.0" y2="223.52" width="0.1524" layer="91"/><label x="762.0" y="223.52" size="1.27" layer="95" rot="MR0" xref="no"/></segment></net>
<net name="XO" class="0"><segment><pinref part="U10" gate="G$1" pin="2"/><wire x1="617.22" y1="91.44" x2="609.6" y2="91.44" width="0.1524" layer="91"/><label x="609.6" y="91.44" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="Y1" gate="G$1" pin="2"/><wire x1="795.02" y1="223.52" x2="802.64" y2="223.52" width="0.1524" layer="91"/><label x="802.64" y="223.52" size="1.27" layer="95" xref="no"/></segment></net></nets>
</sheet></sheets>
</schematic>
</drawing>
</eagle>
