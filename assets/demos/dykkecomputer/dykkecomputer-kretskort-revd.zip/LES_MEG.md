# Dykkecomputer – kretskort rev D

To kort, ferdig plassert og rutet, med produksjonsfiler for JLCPCB.

| Kort | Størrelse | Lag | Deler | Status |
|---|---|---|---|---|
| Hovedkort | 70 × 96 mm, 0,8 mm, hjørnehakk mot toppringboltene | 4 (topp, GND-plan, 3V3-plan, bunn) | 120 + 4 M2-hull | 0 DRC-feil, 0 åpne forbindelser |
| Sensorkort | 4,6 × 23 mm, 1,0 mm | 2 | 2 × MS5837-30BA, 2 kondensatorer | 0 DRC-feil, 0 åpne forbindelser |

Advarsler som står igjen i DRC er kosmetiske (silketrykk) og fem termiske avlastninger med én eike.

## Innhold

- `hovedkort/` og `sensorkort/`
  - `*.brd` og `*.sch`: åpnes i Fusion Electronics (EAGLE 9-format). Skjemaet er et netteiketts-skjema laget fra kortet, slik at Fusion holder kort og skjema i samsvar. Det tegnede skjemaet (rev C, fire ark) forklarer kretsen.
  - `*.kicad_pcb`: samme kort i KiCad 7.
  - `gerber.zip`: Gerber og borefiler for bestilling.
  - `bom_jlc.csv` og `cpl_jlc.csv`: deleliste og plasseringsfil for montering hos JLCPCB.
  - `board.step`: kortet som 3D (uten komponentmodeller).
  - `*_drc.txt`: rapport fra designregelsjekken.
- `kilde/`: skriptene som bygger alt fra netteliste til Gerber (`revd.py` er kretsen som pad-for-pad-liste).

## Regler og oppbygging (hovedkort)

- Spor 0,15 mm, avstand 0,15 mm, via 0,45/0,25 mm. Strøm (VBAT, 5 V, lader, bakgrunnslys) 0,3 mm. GNSS-RF 0,3 mm.
- Innerlag 1 er helt GND, innerlag 2 er 3V3. Ytterlagene er fylt med GND og sydd til planet med via hver 3. mm.
- Ingen kobber under antennen på ESP32-modulen (alle lag) eller under GNSS-chipantennen.
- Toppsiden under skjermen har bare deler under 1,0 mm høyde. Høyere deler står i stripene utenfor skjermen eller på undersiden.
- På undersiden er det ingen deler over batteriet, ferrittstaven eller vibrasjonsmotoren.
- Silketrykk: komponentnavn er 0,9 mm høye med 0,15 mm strek og står rett opp (speilvendt på undersiden, så de leses riktig når kortet snus). De står ved siden av delen, ikke over pads eller andre deler. Navn som ikke har plass i tette felt, står bare på monteringstegningen (Fab-laget) og i plasseringsfilen.

## Endringer fra rev C (sjekket mot databladene)

- GNSS: ATGM336H-5N er byttet til u-blox MAX-M10S, med samme 18-pads fotavtrykk. ATGM336H trenger aktiv antenne eller egen LNA. MAX-M10S har LNA og SAW innebygd og fungerer med passiv chipantenne.
- MMC5603NJ har ikke CAP-pinne. C10 er nå 2,2 µF på VDD, som databladet krever.
- Lastbryter: TPS22916C (0,4 mm WCSP) er byttet til TPS22917DBV (SOT-23-6).
- Skjerm: 50-polet 0,5 mm FPC, som er standard for 3,5″ 55,5 × 84,96 mm-paneler. 4-tråds SPI (IM2..0 = 111), og alle seks LED-katoder går til Q1.
- QMI8658C: CS er høy (I²C), SDx/SCx går til GND, og SA0 er åpen (0x6B).
- Ekstra avkobling: PCM1808 VCC/VDD, hver hallsensor, CH32V003, MAX17048 og GNSS.

## Sjekkes ved bestilling

1. FPC-pinnetabellen på det eksakte skjermpanelet som kjøpes. Kontakten skal være lav, maks 1,0 mm (f.eks. Hirose FH52-50S-0.5SH), og landmønsteret må kontrolleres mot databladet.
2. Landmønster og frisone for Johanson 1575AT43A0040 og Murata PKMCS0909E4000.
3. MAX-M10S-tilpasning: start med L5 = 0 Ω og C33/C34 ikke montert, og juster med VNA.
4. Rotasjoner i plasseringsfilen. JLC viser forhåndsvisning, og rotasjonen rettes der for deler som står feil.
5. Lagerstatus hos LCSC for alle delenumre.

## Bygging

Monteres hos JLCPCB: begge sider på hovedkortet, undersiden på sensorkortet. Følgende loddes for hånd med ledning:
- Qi-modul (J5), ferrittspoler (J8, J9), vibrasjonsmotor (J10), lysflex (J6) og våtkontakter (E1, E2).

Se `bom_jlc.csv` for hele listen.
