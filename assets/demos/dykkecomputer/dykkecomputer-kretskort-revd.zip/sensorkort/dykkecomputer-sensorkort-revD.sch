<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE eagle SYSTEM "eagle.dtd">
<eagle version="9.6.2">
<drawing>
<settings><setting alwaysvectorfont="no"/><setting verticaltext="up"/></settings>
<grid distance="0.1" unitdist="inch" unit="inch" style="lines" multiple="1" display="no" altdistance="0.01" altunitdist="inch" altunit="inch"/>
<layers>
<layer number="1" name="Top" color="4" fill="1" visible="yes" active="yes"/>
<layer number="2" name="Route2" color="1" fill="3" visible="yes" active="yes"/>
<layer number="15" name="Route15" color="23" fill="5" visible="yes" active="yes"/>
<layer number="16" name="Bottom" color="1" fill="1" visible="yes" active="yes"/>
<layer number="17" name="Pads" color="2" fill="1" visible="yes" active="yes"/>
<layer number="18" name="Vias" color="2" fill="1" visible="yes" active="yes"/>
<layer number="19" name="Unrouted" color="6" fill="1" visible="yes" active="yes"/>
<layer number="20" name="Dimension" color="15" fill="1" visible="yes" active="yes"/>
<layer number="21" name="tPlace" color="7" fill="1" visible="yes" active="yes"/>
<layer number="22" name="bPlace" color="7" fill="1" visible="yes" active="yes"/>
<layer number="25" name="tNames" color="7" fill="1" visible="yes" active="yes"/>
<layer number="26" name="bNames" color="7" fill="1" visible="yes" active="yes"/>
<layer number="27" name="tValues" color="7" fill="1" visible="yes" active="yes"/>
<layer number="28" name="bValues" color="7" fill="1" visible="yes" active="yes"/>
<layer number="29" name="tStop" color="7" fill="3" visible="no" active="yes"/>
<layer number="30" name="bStop" color="7" fill="6" visible="no" active="yes"/>
<layer number="31" name="tCream" color="7" fill="4" visible="no" active="yes"/>
<layer number="32" name="bCream" color="7" fill="5" visible="no" active="yes"/>
<layer number="39" name="tKeepout" color="4" fill="11" visible="yes" active="yes"/>
<layer number="40" name="bKeepout" color="1" fill="11" visible="yes" active="yes"/>
<layer number="41" name="tRestrict" color="4" fill="10" visible="yes" active="yes"/>
<layer number="42" name="bRestrict" color="1" fill="10" visible="yes" active="yes"/>
<layer number="43" name="vRestrict" color="2" fill="10" visible="yes" active="yes"/>
<layer number="44" name="Drills" color="7" fill="1" visible="no" active="yes"/>
<layer number="45" name="Holes" color="7" fill="1" visible="no" active="yes"/>
<layer number="47" name="Measures" color="7" fill="1" visible="no" active="yes"/>
<layer number="51" name="tDocu" color="7" fill="1" visible="yes" active="yes"/>
<layer number="52" name="bDocu" color="7" fill="1" visible="yes" active="yes"/>
<layer number="91" name="Nets" color="2" fill="1" visible="yes" active="yes"/>
<layer number="92" name="Busses" color="1" fill="1" visible="yes" active="yes"/>
<layer number="93" name="Pins" color="2" fill="1" visible="no" active="yes"/>
<layer number="94" name="Symbols" color="4" fill="1" visible="yes" active="yes"/>
<layer number="95" name="Names" color="7" fill="1" visible="yes" active="yes"/>
<layer number="96" name="Values" color="7" fill="1" visible="yes" active="yes"/>
<layer number="97" name="Info" color="7" fill="1" visible="yes" active="yes"/>
</layers>
<schematic xreflabel="%F%N/%S.%C%R" xrefpart="/%S.%C%R">
<description>Dykkecomputer rev D, sensorkort. Net-label schematic generated from the routed board; the drawn schematic (rev C sheets) explains the circuit.</description>
<libraries><library name="dive_revd"><description>Dykkecomputer rev D, sensorkort: packages generated from the routed board</description><packages><package name="POGO_LAND_6">
<smd name="1" x="0.0" y="-5.0" dx="1.4" dy="1.4" layer="1" roundness="100"/>
<smd name="2" x="0.0" y="-3.0" dx="1.4" dy="1.4" layer="1" roundness="100"/>
<smd name="3" x="0.0" y="-1.0" dx="1.4" dy="1.4" layer="1" roundness="100"/>
<smd name="4" x="0.0" y="1.0" dx="1.4" dy="1.4" layer="1" roundness="100"/>
<smd name="5" x="0.0" y="3.0" dx="1.4" dy="1.4" layer="1" roundness="100"/>
<smd name="6" x="0.0" y="5.0" dx="1.4" dy="1.4" layer="1" roundness="100"/>
<text x="0" y="1" size="0.6" layer="25">&gt;NAME</text>
</package>
<package name="C_0402_1005Metric">
<smd name="1" x="-0.48" y="-0.0" dx="0.56" dy="0.62" layer="1" roundness="50"/>
<smd name="2" x="0.48" y="0.0" dx="0.56" dy="0.62" layer="1" roundness="50"/>
<text x="0" y="1" size="0.6" layer="25">&gt;NAME</text>
</package>
<package name="TE_MS5837-xxBA">
<smd name="1" x="1.0" y="-1.0" dx="1.3" dy="1.3" layer="1" roundness="0" rot="R180.0"/>
<smd name="2" x="1.0" y="1.0" dx="1.3" dy="1.3" layer="1" roundness="0" rot="R180.0"/>
<smd name="3" x="-1.0" y="1.0" dx="1.3" dy="1.3" layer="1" roundness="0" rot="R180.0"/>
<smd name="4" x="-1.0" y="-1.0" dx="1.3" dy="1.3" layer="1" roundness="0" rot="R180.0"/>
<text x="0" y="1" size="0.6" layer="25">&gt;NAME</text>
</package></packages><symbols><symbol name="P1_POGOLAND6">
<wire x1="-7.62" y1="5.08" x2="7.62" y2="5.08" width="0.254" layer="94"/>
<wire x1="7.62" y1="5.08" x2="7.62" y2="-5.08" width="0.254" layer="94"/>
<wire x1="7.62" y1="-5.08" x2="-7.62" y2="-5.08" width="0.254" layer="94"/>
<wire x1="-7.62" y1="-5.08" x2="-7.62" y2="5.08" width="0.254" layer="94"/>
<text x="-7.62" y="6.35" size="1.778" layer="95">&gt;NAME</text>
<text x="-7.62" y="-7.62" size="1.778" layer="96">&gt;VALUE</text>
<pin name="1" x="-12.7" y="2.54" length="short" rot="R0"/>
<pin name="2" x="-12.7" y="0.0" length="short" rot="R0"/>
<pin name="3" x="-12.7" y="-2.54" length="short" rot="R0"/>
<pin name="4" x="12.7" y="2.54" length="short" rot="R180"/>
<pin name="5" x="12.7" y="0.0" length="short" rot="R180"/>
<pin name="6" x="12.7" y="-2.54" length="short" rot="R180"/>
</symbol><symbol name="P2_C04021005Metric">
<wire x1="-7.62" y1="2.54" x2="7.62" y2="2.54" width="0.254" layer="94"/>
<wire x1="7.62" y1="2.54" x2="7.62" y2="-2.54" width="0.254" layer="94"/>
<wire x1="7.62" y1="-2.54" x2="-7.62" y2="-2.54" width="0.254" layer="94"/>
<wire x1="-7.62" y1="-2.54" x2="-7.62" y2="2.54" width="0.254" layer="94"/>
<text x="-7.62" y="3.81" size="1.778" layer="95">&gt;NAME</text>
<text x="-7.62" y="-5.08" size="1.778" layer="96">&gt;VALUE</text>
<pin name="1" x="-12.7" y="0.0" length="short" rot="R0"/>
<pin name="2" x="12.7" y="0.0" length="short" rot="R180"/>
</symbol><symbol name="P3_TEMS5837xxBA">
<wire x1="-7.62" y1="3.81" x2="7.62" y2="3.81" width="0.254" layer="94"/>
<wire x1="7.62" y1="3.81" x2="7.62" y2="-3.81" width="0.254" layer="94"/>
<wire x1="7.62" y1="-3.81" x2="-7.62" y2="-3.81" width="0.254" layer="94"/>
<wire x1="-7.62" y1="-3.81" x2="-7.62" y2="3.81" width="0.254" layer="94"/>
<text x="-7.62" y="5.08" size="1.778" layer="95">&gt;NAME</text>
<text x="-7.62" y="-6.35" size="1.778" layer="96">&gt;VALUE</text>
<pin name="1" x="-12.7" y="1.27" length="short" rot="R0"/>
<pin name="2" x="-12.7" y="-1.27" length="short" rot="R0"/>
<pin name="3" x="12.7" y="1.27" length="short" rot="R180"/>
<pin name="4" x="12.7" y="-1.27" length="short" rot="R180"/>
</symbol></symbols><devicesets><deviceset name="P1_POGOLAND6" prefix="X"><gates><gate name="G$1" symbol="P1_POGOLAND6" x="0" y="0"/></gates><devices><device name="" package="POGO_LAND_6"><connects><connect gate="G$1" pin="1" pad="1"/><connect gate="G$1" pin="2" pad="2"/><connect gate="G$1" pin="3" pad="3"/><connect gate="G$1" pin="4" pad="4"/><connect gate="G$1" pin="5" pad="5"/><connect gate="G$1" pin="6" pad="6"/></connects><technologies><technology name=""/></technologies></device></devices></deviceset><deviceset name="P2_C04021005Metric" prefix="X"><gates><gate name="G$1" symbol="P2_C04021005Metric" x="0" y="0"/></gates><devices><device name="" package="C_0402_1005Metric"><connects><connect gate="G$1" pin="1" pad="1"/><connect gate="G$1" pin="2" pad="2"/></connects><technologies><technology name=""/></technologies></device></devices></deviceset><deviceset name="P3_TEMS5837xxBA" prefix="X"><gates><gate name="G$1" symbol="P3_TEMS5837xxBA" x="0" y="0"/></gates><devices><device name="" package="TE_MS5837-xxBA"><connects><connect gate="G$1" pin="1" pad="1"/><connect gate="G$1" pin="2" pad="2"/><connect gate="G$1" pin="3" pad="3"/><connect gate="G$1" pin="4" pad="4"/></connects><technologies><technology name=""/></technologies></device></devices></deviceset></devicesets></library></libraries>
<attributes/><variantdefs/><classes><class number="0" name="default" width="0" drill="0"/></classes>
<parts><part name="C1" library="dive_revd" deviceset="P2_C04021005Metric" device="" value="100nF"/><part name="C2" library="dive_revd" deviceset="P2_C04021005Metric" device="" value="100nF"/><part name="J1" library="dive_revd" deviceset="P1_POGOLAND6" device="" value="spring contact lands"/><part name="U3" library="dive_revd" deviceset="P3_TEMS5837xxBA" device="" value="MS5837-30BA"/><part name="U4" library="dive_revd" deviceset="P3_TEMS5837xxBA" device="" value="MS5837-30BA"/></parts>
<sheets><sheet><plain><text x="20.32" y="264.16" size="3.81" layer="97">Dykkecomputer rev D, sensorkort</text></plain>
<instances><instance part="C1" gate="G$1" x="20.32" y="246.38"/><instance part="C2" gate="G$1" x="20.32" y="228.6"/><instance part="J1" gate="G$1" x="20.32" y="208.28"/><instance part="U3" gate="G$1" x="20.32" y="186.69"/><instance part="U4" gate="G$1" x="20.32" y="166.37"/></instances><busses/>
<nets><net name="3V3" class="0"><segment><pinref part="C1" gate="G$1" pin="1"/><wire x1="7.62" y1="246.38" x2="0.0" y2="246.38" width="0.1524" layer="91"/><label x="0.0" y="246.38" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="C2" gate="G$1" pin="1"/><wire x1="7.62" y1="228.6" x2="0.0" y2="228.6" width="0.1524" layer="91"/><label x="0.0" y="228.6" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="J1" gate="G$1" pin="1"/><wire x1="7.62" y1="210.82" x2="0.0" y2="210.82" width="0.1524" layer="91"/><label x="0.0" y="210.82" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U3" gate="G$1" pin="2"/><wire x1="7.62" y1="185.42" x2="0.0" y2="185.42" width="0.1524" layer="91"/><label x="0.0" y="185.42" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U4" gate="G$1" pin="2"/><wire x1="7.62" y1="165.1" x2="0.0" y2="165.1" width="0.1524" layer="91"/><label x="0.0" y="165.1" size="1.27" layer="95" rot="MR0" xref="no"/></segment></net>
<net name="GND" class="0"><segment><pinref part="C1" gate="G$1" pin="2"/><wire x1="33.02" y1="246.38" x2="40.64" y2="246.38" width="0.1524" layer="91"/><label x="40.64" y="246.38" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="C2" gate="G$1" pin="2"/><wire x1="33.02" y1="228.6" x2="40.64" y2="228.6" width="0.1524" layer="91"/><label x="40.64" y="228.6" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="J1" gate="G$1" pin="2"/><wire x1="7.62" y1="208.28" x2="0.0" y2="208.28" width="0.1524" layer="91"/><label x="0.0" y="208.28" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U3" gate="G$1" pin="1"/><wire x1="7.62" y1="187.96" x2="0.0" y2="187.96" width="0.1524" layer="91"/><label x="0.0" y="187.96" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U4" gate="G$1" pin="1"/><wire x1="7.62" y1="167.64" x2="0.0" y2="167.64" width="0.1524" layer="91"/><label x="0.0" y="167.64" size="1.27" layer="95" rot="MR0" xref="no"/></segment></net>
<net name="SCL_A" class="0"><segment><pinref part="J1" gate="G$1" pin="4"/><wire x1="33.02" y1="210.82" x2="40.64" y2="210.82" width="0.1524" layer="91"/><label x="40.64" y="210.82" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="U3" gate="G$1" pin="3"/><wire x1="33.02" y1="187.96" x2="40.64" y2="187.96" width="0.1524" layer="91"/><label x="40.64" y="187.96" size="1.27" layer="95" xref="no"/></segment></net>
<net name="SCL_B" class="0"><segment><pinref part="J1" gate="G$1" pin="6"/><wire x1="33.02" y1="205.74" x2="40.64" y2="205.74" width="0.1524" layer="91"/><label x="40.64" y="205.74" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="U4" gate="G$1" pin="3"/><wire x1="33.02" y1="167.64" x2="40.64" y2="167.64" width="0.1524" layer="91"/><label x="40.64" y="167.64" size="1.27" layer="95" xref="no"/></segment></net>
<net name="SDA_A" class="0"><segment><pinref part="J1" gate="G$1" pin="3"/><wire x1="7.62" y1="205.74" x2="0.0" y2="205.74" width="0.1524" layer="91"/><label x="0.0" y="205.74" size="1.27" layer="95" rot="MR0" xref="no"/></segment><segment><pinref part="U3" gate="G$1" pin="4"/><wire x1="33.02" y1="185.42" x2="40.64" y2="185.42" width="0.1524" layer="91"/><label x="40.64" y="185.42" size="1.27" layer="95" xref="no"/></segment></net>
<net name="SDA_B" class="0"><segment><pinref part="J1" gate="G$1" pin="5"/><wire x1="33.02" y1="208.28" x2="40.64" y2="208.28" width="0.1524" layer="91"/><label x="40.64" y="208.28" size="1.27" layer="95" xref="no"/></segment><segment><pinref part="U4" gate="G$1" pin="4"/><wire x1="33.02" y1="165.1" x2="40.64" y2="165.1" width="0.1524" layer="91"/><label x="40.64" y="165.1" size="1.27" layer="95" xref="no"/></segment></net></nets>
</sheet></sheets>
</schematic>
</drawing>
</eagle>
