"""Depth sensor board (rev D): 4.6 x 23 mm, 2 layers, lies on the sealing flange at x = -32.75.
Top: 6 landing pads for the spring contacts from the main board (J7) and the two capacitors.
Bottom: MS5837-30BA A (port 1, y = -2) and B (port 2, y = -10) hanging into their sealed bores.
Coordinates are housing coordinates; board centre (-32.75, -6)."""
import sys, pcbnew
from shapely.geometry import Point, box as sbox
from board_common import K, H, mm, load, smd, new_fp, courtyard, add_outline, edge_keepouts, OX, OY

CX, CY = -32.75, -6.0
W, L = 4.6, 23.0
b = pcbnew.BOARD()
b.SetCopperLayerCount(2)
ds = b.GetDesignSettings(); ds.SetBoardThickness(mm(1.0))
ds.m_ViasMinSize = mm(0.45); ds.m_MinThroughDrill = mm(0.2); ds.m_CopperEdgeClearance = mm(0.28); ds.m_TrackMinWidth = mm(0.1)
dc = ds.m_NetSettings.m_DefaultNetClass
dc.SetTrackWidth(mm(0.2)); dc.SetClearance(mm(0.15)); dc.SetViaDiameter(mm(0.45)); dc.SetViaDrill(mm(0.25))
outline = sbox(CX - W / 2, CY - L / 2, CX + W / 2, CY + L / 2).buffer(-0.5, join_style=1).buffer(0.5, resolution=8)
for (hx, hy) in ((CX, -15.0), (CX, 3.0)):
    outline = outline.difference(Point(hx, hy).buffer(0.9, resolution=24))     # M1.6 clearance holes (cut as board edge)
add_outline(b, outline)
edge_keepouts(b, outline, 0.3)
nets = {}
def net(n):
    if n not in nets:
        x = pcbnew.NETINFO_ITEM(b, n); b.Add(x); nets[n] = x
    return nets[n]
def place(fp, ref, val, x, y, rot, side, pads):
    fp.SetReference(ref); fp.SetValue(val); b.Add(fp); fp.SetPosition(K(x, y))
    if side == "B": fp.Flip(K(x, y), False)
    fp.SetOrientationDegrees(rot)
    for p in fp.Pads():
        if p.GetNumber() in pads: p.SetNet(net(pads[p.GetNumber()]))
pogo = new_fp("POGO_LAND_6")
for i in range(6): smd(pogo, str(i + 1), 0, 5.0 - 2.0 * i, 1.4, 1.4, "circle")
courtyard(pogo, 1.6, 11.6)
place(pogo, "J1", "spring contact lands", CX, CY, 0, "F", {"1": "3V3", "2": "GND", "3": "SDA_A", "4": "SCL_A", "5": "SDA_B", "6": "SCL_B"})
ms = "Sensor_Pressure:TE_MS5837-xxBA"
place(load(ms), "U3", "MS5837-30BA", CX, -2.0, 0, "B", {"1": "GND", "2": "3V3", "3": "SCL_A", "4": "SDA_A"})
place(load(ms), "U4", "MS5837-30BA", CX, -10.0, 0, "B", {"1": "GND", "2": "3V3", "3": "SCL_B", "4": "SDA_B"})
c = "Capacitor_SMD:C_0402_1005Metric"
place(load(c), "C1", "100nF", CX + 1.4, -0.6, 90, "F", {"1": "3V3", "2": "GND"})
place(load(c), "C2", "100nF", CX - 1.4, -11.4, 90, "F", {"1": "3V3", "2": "GND"})
b.Save(sys.argv[1] if len(sys.argv) > 1 else "sensor.kicad_pcb")
print("sensor board saved")
