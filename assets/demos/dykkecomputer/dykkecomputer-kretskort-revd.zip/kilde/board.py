"""Builds the rev D main board as a KiCad 7 board: outline from housing rev B3, footprints, nets, placement, planes, keep-outs.
Usage: python3 board.py out.kicad_pcb"""
import sys, math, os
import pcbnew
from shapely.geometry import Polygon, Point, box as sbox
from shapely.ops import unary_union
from revd import P
from board_common import edge_keepouts

FPLIB = "/usr/share/kicad/footprints/"
OX, OY = 100.0, 100.0                       # housing (0,0) at KiCad (100,100); KiCad y points the other way
mm = pcbnew.FromMM
def K(x, y): return pcbnew.VECTOR2I(mm(OX + x), mm(OY - y))
def H(v): return (pcbnew.ToMM(v.x) - OX, OY - pcbnew.ToMM(v.y))      # KiCad -> housing

# ---------------------------------------------------------------- housing constraints (rev B3)
PW, PL, PR = 70.0, 96.0, 4.0
MOUNTS = [(sx * 32.8, sy * 40.0) for sx in (-1, 1) for sy in (-1, 1)]
CORNER = [(sx * 33.5, sy * 47.5) for sx in (-1, 1) for sy in (-1, 1)]          # top-ring bolt bosses, 8 mm notch
DISP = sbox(-27.75, -42.48, 27.75, 42.48)                                      # display panel above the top side
FOAM = [sbox(x - 3, y - 3, x + 3, y + 3) for (x, y) in [(-22, -36), (22, -36), (-22, 36), (22, 36)]]
BATTERY = sbox(-25.2, -44.2, 25.2, 18.2)                                       # battery + printed tray under the bottom side
FERRITE = sbox(25.3, -30.5, 30.3, -3.5)                                        # ferrite rod tray (bottom side)
ESP_ANT_KEEP = sbox(-28.5, 39.6, -9.5, 48.5)                                   # no copper under the module antenna, any layer
GNSS_ANT_KEEP = sbox(16.2, 44.9, 25.8, 48.5).difference(sbox(16.2, 43.5, 19.3, 46.4))   # feed channel to pad 1
MOTOR = Point(0.0, 23.6).buffer(5.3)                                         # coin motor glued to the bottom side                                    # chip antenna clearance (feed comes in from -y)

def outline():
    r = sbox(-PW / 2, -PL / 2, PW / 2, PL / 2)
    rr = r.buffer(-PR, join_style=1).buffer(PR, resolution=16)
    for (x, y) in CORNER:
        rr = rr.difference(Point(x, y).buffer(4.0, resolution=24))
    return rr
BOARD_POLY = outline()

# ---------------------------------------------------------------- custom footprints (KiCad local frame, y down)
def new_fp(name):
    fp = pcbnew.FOOTPRINT(None)
    fp.SetFPID(pcbnew.LIB_ID("dive", name))
    return fp

def smd(fp, num, x, y, w, h, shape="rect", layer="F"):
    p = pcbnew.PAD(fp)
    p.SetNumber(num)
    p.SetShape({"rect": pcbnew.PAD_SHAPE_ROUNDRECT, "circle": pcbnew.PAD_SHAPE_CIRCLE}[shape])
    if shape == "rect": p.SetRoundRectRadiusRatio(0.15)
    p.SetAttribute(pcbnew.PAD_ATTRIB_SMD)
    ls = pcbnew.LSET(); [ls.AddLayer(l) for l in (pcbnew.F_Cu, pcbnew.F_Mask, pcbnew.F_Paste)]
    p.SetLayerSet(ls)
    p.SetSize(pcbnew.VECTOR2I(mm(w), mm(h)))
    p.SetPosition(pcbnew.VECTOR2I(mm(x), mm(y)))
    p.SetPos0(pcbnew.VECTOR2I(mm(x), mm(y))) if hasattr(p, "SetPos0") else None
    fp.Add(p)
    return p

def courtyard(fp, w, h, cx=0, cy=0):
    for (x0, y0, x1, y1) in [(-w/2, -h/2, w/2, -h/2), (w/2, -h/2, w/2, h/2), (w/2, h/2, -w/2, h/2), (-w/2, h/2, -w/2, -h/2)]:
        s = pcbnew.FP_SHAPE(fp)
        s.SetShape(pcbnew.SHAPE_T_SEGMENT)
        s.SetStart(pcbnew.VECTOR2I(mm(cx + x0), mm(cy + y0))); s.SetEnd(pcbnew.VECTOR2I(mm(cx + x1), mm(cy + y1)))
        s.SetStart0(s.GetStart()); s.SetEnd0(s.GetEnd())
        s.SetLayer(pcbnew.F_CrtYd); s.SetWidth(mm(0.05))
        fp.Add(s)
    for (x0, y0, x1, y1) in [(-w/2, -h/2, w/2, -h/2), (w/2, -h/2, w/2, h/2), (w/2, h/2, -w/2, h/2), (-w/2, h/2, -w/2, -h/2)]:
        s = pcbnew.FP_SHAPE(fp)
        s.SetShape(pcbnew.SHAPE_T_SEGMENT)
        s.SetStart(pcbnew.VECTOR2I(mm(cx + x0 + 0.1 * (1 if x0 < 0 else -1)), mm(cy + y0))); s.SetEnd(pcbnew.VECTOR2I(mm(cx + x1), mm(cy + y1)))
        s.SetStart0(s.GetStart()); s.SetEnd0(s.GetEnd())
        s.SetLayer(pcbnew.F_Fab); s.SetWidth(mm(0.1))
        fp.Add(s)

def custom(name):
    fp = new_fp(name)
    if name == "SERVICE_2x4":
        for i in range(8):
            smd(fp, str(i + 1), -1.25 if i < 4 else 1.25, -3.0 + 2.0 * (i % 4), 1.3, 1.3, "circle")
        courtyard(fp, 4.4, 8.6)
    elif name.startswith("PADS_2_"):
        s = float(name.split("_")[2])
        for i in range(2): smd(fp, str(i + 1), (-1 + 2 * i) * (s / 2 + 0.6), 0, s, s * 1.4)
        courtyard(fp, 2 * s + 1.6, s * 1.4 + 0.6)
    elif name == "PADS_4_0.8":
        for i in range(4): smd(fp, str(i + 1), -1.5 + i, 0, 0.6, 1.4)
        courtyard(fp, 4.4, 2.0)
    elif name == "PAD_1.5":
        smd(fp, "1", 0, 0, 1.6, 1.6, "circle"); courtyard(fp, 2.0, 2.0)
    elif name == "POGO_6":
        for i in range(6): smd(fp, str(i + 1), 0, 5.0 - 2.0 * i, 1.6, 1.6, "circle")
        courtyard(fp, 2.2, 12.2)
    elif name == "FPC_50_P0.5":              # Hirose FH52-50S-0.5SH style land: 50 x (0.30 x 1.0) at 0.5 mm, two fixing pads
        for i in range(50): smd(fp, str(i + 1), (i - 24.5) * 0.5, 0, 0.30, 1.0)
        for s in (-1, 1): smd(fp, "MP", s * 14.15, 2.0, 1.6, 2.2)
        courtyard(fp, 30.6, 5.4, 0, 1.3)
    elif name == "ANT_7x2":                  # Johanson 1575AT43A0040: feed and mounting terminal at the ends
        smd(fp, "1", -3.05, 0, 0.9, 2.2); smd(fp, "2", 3.05, 0, 0.9, 2.2)
        courtyard(fp, 7.6, 2.6)
    elif name == "BUZZER_9x9":               # Murata PKMCS0909E4000 (9 x 9 x 1.9), two terminals
        smd(fp, "1", -3.6, 0, 1.6, 2.4); smd(fp, "2", 3.6, 0, 1.6, 2.4)
        courtyard(fp, 9.4, 9.4)
    else:
        raise ValueError(name)
    return fp

def load(spec):
    lib, name = spec.split(":")
    if lib == "custom": return custom(name)
    fp = pcbnew.FootprintLoad(FPLIB + lib + ".pretty", name)
    if fp is None: raise RuntimeError("footprint not found: " + spec)
    return fp

# ---------------------------------------------------------------- build
board = pcbnew.BOARD()
board.SetCopperLayerCount(4)
ds = board.GetDesignSettings()
ds.SetBoardThickness(mm(0.8))
ds.m_TrackMinWidth = mm(0.1); ds.m_ViasMinSize = mm(0.45); ds.m_MinThroughDrill = mm(0.2); ds.m_MinClearance = mm(0.1)
ds.m_CopperEdgeClearance = mm(0.3); ds.m_HoleClearance = mm(0.25)

# outline
poly = pcbnew.PCB_SHAPE(board); poly.SetShape(pcbnew.SHAPE_T_POLY); poly.SetLayer(pcbnew.Edge_Cuts); poly.SetWidth(mm(0.1))
board.Add(poly)
_ps = poly.GetPolyShape(); _ps.NewOutline()
for (x, y) in list(BOARD_POLY.exterior.coords)[:-1]:
    v = K(x, y); _ps.Append(v.x, v.y)

nets = {}
def net(name):
    if name not in nets:
        n = pcbnew.NETINFO_ITEM(board, name); board.Add(n); nets[name] = n
    return nets[name]
for spec in P.values():
    for n in spec[5].values(): net(n)

placed = {}            # ref -> footprint
rects = {"F": [], "B": []}
HEIGHT_TOP_LIMIT_PARTS = set()

def fp_rect(fp, grow=0.15):
    if fp.GetReference() == "U1":
        x, y = H(fp.GetPosition()); return sbox(x - 9.05 - grow, y - 12.8 - grow, x + 9.05 + grow, y + 12.8 + grow)
    fp.BuildCourtyardCaches() if hasattr(fp, "BuildCourtyardCaches") else None
    side = pcbnew.F_CrtYd if not fp.IsFlipped() else pcbnew.B_CrtYd
    try:
        cy = fp.GetCourtyard(side)
        if cy.OutlineCount():
            bb = cy.BBox()
            x0, y1 = H(pcbnew.VECTOR2I(bb.GetLeft(), bb.GetTop())); x1, y0 = H(pcbnew.VECTOR2I(bb.GetRight(), bb.GetBottom()))
            return sbox(x0 - grow, y0 - grow, x1 + grow, y1 + grow)
    except Exception:
        pass
    bb = fp.GetBoundingBox(False, False)
    x0, y1 = H(pcbnew.VECTOR2I(bb.GetLeft(), bb.GetTop())); x1, y0 = H(pcbnew.VECTOR2I(bb.GetRight(), bb.GetBottom()))
    return sbox(x0 - grow, y0 - grow, x1 + grow, y1 + grow)

def put(ref, spec, x, y, rot, side):
    fp = load(spec[0])
    fp.SetReference(ref); fp.SetValue(spec[1])
    for z in list(fp.Zones()): fp.Remove(z)          # library keep-outs (ESP32 antenna) are replaced by the board-level ones
    if ref == "U1":                                   # library courtyard includes the antenna clearance; use the module body
        for gi in list(fp.GraphicalItems()):
            if gi.GetLayer() in (pcbnew.F_CrtYd, pcbnew.B_CrtYd): fp.Remove(gi)
        courtyard(fp, 18.6, 26.1)
    board.Add(fp)
    fp.SetPosition(K(x, y))
    if side == "B": fp.Flip(K(x, y), False)
    fp.SetOrientationDegrees(rot)
    for p in fp.Pads():
        n = spec[5].get(p.GetNumber())
        if n: p.SetNet(net(n))
    return fp

def allowed(shape, side, ref):
    if not BOARD_POLY.buffer(-0.35).contains(shape): return False
    for (mx, my) in MOUNTS:
        if shape.intersects(Point(mx, my).buffer(3.4 if side == "B" else 2.3)): return False
    if shape.intersects(ESP_ANT_KEEP) or shape.intersects(GNSS_ANT_KEEP): return False
    if side == "B":
        if shape.intersects(BATTERY) or shape.intersects(FERRITE) or shape.intersects(MOTOR): return False
    else:
        if any(shape.intersects(f) for f in FOAM): return False
    return not any(shape.intersects(r) for r in rects[side])

# fixed parts first
order = [r for r, s in P.items() if s[4][0] != "near"] + [r for r, s in P.items() if s[4][0] == "near"]
log = []
for ref in order:
    spec = P[ref]
    fpname, val, mpn, side, place, pads = spec
    if place[0] != "near":
        x, y, rot = place
        fp = put(ref, spec, x, y, rot, side)
        sh = fp_rect(fp, 0.0)
        if not ref.startswith("H"):
            ok = BOARD_POLY.contains(sh)
            if not ok: log.append(f"WARN {ref} outside board")
            if side == "B" and (sh.intersects(BATTERY) or sh.intersects(FERRITE) or sh.intersects(MOTOR)): log.append(f"WARN {ref} over battery/ferrite/motor")
            for r2, (s2, sd2) in placed.items():
                if sd2 == side and sh.intersects(s2): log.append(f"WARN {ref} overlaps {r2}")
        placed[ref] = (sh, side if not ref.startswith("H") else "both")
        rects[side].append(sh) if not ref.startswith("H") else None
        continue
    _, aref, apad = place
    afp = board.FindFootprintByReference(aref)
    tx, ty = None, None
    for p in afp.Pads():
        if p.GetNumber() == apad: tx, ty = H(p.GetPosition()); break
    if tx is None: tx, ty = H(afp.GetPosition())
    fp = put(ref, spec, tx, ty, 0, side)
    best = None
    r0 = 1.3 if (afp.IsFlipped() != (side == "B")) else 0.6     # other side than the anchor: leave room for its via
    for ring in range(0, 120):
        rr = r0 + ring * 0.25
        n = max(8, int(2 * math.pi * rr / 0.5))
        for k in range(n):
            a = 2 * math.pi * k / n
            x, y = tx + rr * math.cos(a), ty + rr * math.sin(a)
            for rot in (0, 90):
                fp.SetPosition(K(x, y)); fp.SetOrientationDegrees(rot)
                sh = fp_rect(fp, 0.12)
                if allowed(sh, side, ref):
                    best = (x, y, rot, sh); break
            if best: break
        if best: break
    if not best:
        log.append(f"FAIL place {ref} near {aref}"); continue
    x, y, rot, sh = best
    fp.SetPosition(K(x, y)); fp.SetOrientationDegrees(rot)
    rects[side].append(sh); placed[ref] = (sh, side)

# ---------------------------------------------------------------- zones: GND plane (In1), 3V3 plane (In2), GND pours outside
def zone(layer, netname, shape, prio=0, clearance=0.2, keepout=False, layers=None):
    z = pcbnew.ZONE(board)
    z.SetLayer(layer)
    o = z.Outline(); o.NewOutline()
    for (x, y) in list(shape.exterior.coords)[:-1]:
        v = K(x, y); o.Append(v.x, v.y)
    if keepout:
        z.SetIsRuleArea(True); z.SetDoNotAllowCopperPour(True); z.SetDoNotAllowTracks(True); z.SetDoNotAllowVias(True)
        z.SetDoNotAllowPads(False); z.SetDoNotAllowFootprints(False)
        ls = pcbnew.LSET(); [ls.AddLayer(l) for l in (layers or (pcbnew.F_Cu, pcbnew.In1_Cu, pcbnew.In2_Cu, pcbnew.B_Cu))]
        z.SetLayerSet(ls)
    else:
        z.SetNet(net(netname)); z.SetAssignedPriority(prio) if hasattr(z, "SetAssignedPriority") else z.SetPriority(prio)
        z.SetLocalClearance(mm(clearance)); z.SetMinThickness(mm(0.2))
        z.SetPadConnection(pcbnew.ZONE_CONNECTION_THERMAL); z.SetThermalReliefGap(mm(0.25)); z.SetThermalReliefSpokeWidth(mm(0.3))
    board.Add(z)
    return z

print("zones",flush=True)
inner = BOARD_POLY.buffer(-0.4)
zone(pcbnew.In1_Cu, "GND", inner, clearance=0.2)
zone(pcbnew.In2_Cu, "3V3", inner, clearance=0.2)
edge_keepouts(board, BOARD_POLY, 0.3)
zone(pcbnew.F_Cu, None, ESP_ANT_KEEP.intersection(BOARD_POLY.buffer(1)), keepout=True)
zone(pcbnew.F_Cu, None, sbox(16.2, 43.5, 25.8, 48.5).intersection(BOARD_POLY.buffer(1)), keepout=True, layers=(pcbnew.F_Cu, pcbnew.In1_Cu, pcbnew.In2_Cu))
zone(pcbnew.B_Cu, None, sbox(19.6, 44.9, 25.8, 48.5).intersection(BOARD_POLY.buffer(1)), keepout=True, layers=(pcbnew.B_Cu,))

out = sys.argv[1] if len(sys.argv) > 1 else "revd.kicad_pcb"
print("saving",flush=True)
board.Save(out)
print("saved",flush=True)
print("\n".join(log))
print("parts", len(P), "nets", len(nets), "placed", len(placed))
