"""BOM for JLCPCB assembly (Comment, Designator, Footprint, MPN) from revd.py, plus the sensor board."""
import csv, sys
from revd import P
rows = {}
skip_pref = ("H", "J5", "J8", "J9", "J10", "J6", "J1", "J7", "E1", "E2", "TP1")
for ref, (fp, val, mpn, side, place, pads) in P.items():
    if ref.startswith("H") or ref in skip_pref: continue
    if val.startswith("DNP") or val == "tune": dnp = True
    else: dnp = False
    key = (val, fp.split(":")[1], mpn, dnp)
    rows.setdefault(key, []).append(ref)
sensor = [("MS5837-30BA", "TE_MS5837-xxBA", "MS583730BA01-50", False, ["S:U3", "S:U4"]),
          ("100nF", "C_0402_1005Metric", "", False, ["S:C1", "S:C2"])]
def k(r): return (r.rstrip("0123456789"), int("".join(c for c in r if c.isdigit()) or 0))
with open(sys.argv[1], "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["Comment", "Designator", "Footprint", "Manufacturer part / note", "Qty", "Fit"])
    for (val, fp, mpn, dnp), refs in sorted(rows.items(), key=lambda kv: k(sorted(kv[1], key=k)[0])):
        refs = sorted(refs, key=k)
        w.writerow([val, ",".join(refs), fp, mpn, len(refs), "DNP / tune on the bench" if dnp else "yes"])
    for val, fp, mpn, dnp, refs in sensor:
        w.writerow([val, ",".join(refs), fp, mpn + " (sensor board)", len(refs), "yes"])
    w.writerow([])
    w.writerow(["Hand-soldered / wired (not assembled by JLC)"])
    for ref in ("J5", "J8", "J9", "J10", "J6", "E1", "E2"):
        fp, val, mpn, *_ = P[ref]
        w.writerow([val, ref, fp.split(":")[1], mpn, 1, "wires"])
print("bom rows", len(rows))
