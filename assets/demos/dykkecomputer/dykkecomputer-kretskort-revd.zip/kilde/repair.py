"""Route the few connections the autorouter left open: grid A* on F.Cu/B.Cu with through vias, keeping 0.15 mm from other nets.
Reads the pairs from the KiCad DRC report, adds tracks/vias, refills zones, writes a new DRC report.
Usage: python3 repair.py in.kicad_pcb drc.txt out.kicad_pcb"""
import sys, re, heapq, math
import numpy as np
import pcbnew
from shapely.geometry import Point, LineString, box
from shapely.ops import unary_union
from shapely import prepared

src, rep, out = sys.argv[1:4]
b = pcbnew.LoadBoard(src)
W, CL, VD = 0.15, 0.15, 0.45            # track width, clearance, via diameter
STEP = 0.05
mm = pcbnew.ToMM
LAY = {"F.Cu": pcbnew.F_Cu, "B.Cu": pcbnew.B_Cu}

pairs = []
txt = open(rep).read()
for blk in txt.split("[unconnected_items]")[1:]:
    items = re.findall(r"@\(([\d.]+) mm, ([\d.]+) mm\): (.*)", blk)[:2]
    pts = []
    for x, y, desc in items:
        net = re.search(r"\[([^\]]+)\]", desc).group(1)
        lay = "B.Cu" if "on B.Cu" in desc and "F.Cu - B.Cu" not in desc else "F.Cu"
        anylayer = "Via" in desc or "F.Cu - B.Cu" in desc
        pts.append((float(x), float(y), lay, anylayer, net))
    pairs.append(pts)

def copper_shapes(layer, skip_net):
    shp = []
    for fp in b.GetFootprints():
        for p in fp.Pads():
            if p.GetNetname() == skip_net or not p.IsOnLayer(layer): continue
            poly = p.GetEffectivePolygon()
            o = poly.Outline(0)
            pts = [(mm(o.CPoint(i).x), mm(o.CPoint(i).y)) for i in range(o.PointCount())]
            from shapely.geometry import Polygon
            shp.append(Polygon(pts) if len(pts) > 2 else Point(mm(p.GetPosition().x), mm(p.GetPosition().y)).buffer(0.2))
    for t in b.GetTracks():
        if t.GetNetname() == skip_net: continue
        if t.GetClass() == "PCB_VIA":
            shp.append(Point(mm(t.GetPosition().x), mm(t.GetPosition().y)).buffer(mm(t.GetWidth()) / 2))
        elif t.GetLayer() == layer:
            shp.append(LineString([(mm(t.GetStart().x), mm(t.GetStart().y)), (mm(t.GetEnd().x), mm(t.GetEnd().y))]).buffer(mm(t.GetWidth()) / 2))
    for z in b.Zones():
        if z.GetIsRuleArea() and z.IsOnLayer(layer):
            o = z.Outline().Outline(0)
            from shapely.geometry import Polygon
            shp.append(Polygon([(mm(o.CPoint(i).x), mm(o.CPoint(i).y)) for i in range(o.PointCount())]))
    return unary_union(shp)

edge = b.GetBoardEdgesBoundingBox()
def route(a, c, net):
    x0, x1 = min(a[0], c[0]) - 4, max(a[0], c[0]) + 4
    y0, y1 = min(a[1], c[1]) - 4, max(a[1], c[1]) + 4
    nx, ny = int((x1 - x0) / STEP) + 1, int((y1 - y0) / STEP) + 1
    free = {}
    for name, L in LAY.items():
        obst = prepared.prep(copper_shapes(L, net).buffer(CL + W / 2))
        g = np.zeros((nx, ny), bool)
        for i in range(nx):
            for j in range(ny):
                g[i, j] = not obst.contains(Point(x0 + i * STEP, y0 + j * STEP))
        free[name] = g
    via_ok = {}
    vob = {n: prepared.prep(copper_shapes(L, net).buffer(CL + VD / 2)) for n, L in LAY.items()}
    def can_via(i, j):
        k = (i, j)
        if k not in via_ok:
            p = Point(x0 + i * STEP, y0 + j * STEP)
            via_ok[k] = not vob["F.Cu"].contains(p) and not vob["B.Cu"].contains(p)
        return via_ok[k]
    def cell(p): return (int(round((p[0] - x0) / STEP)), int(round((p[1] - y0) / STEP)))
    starts = [(cell(a), l) for l in (LAY if a[3] else [a[2]])]
    goals = {(cell(c), l) for l in (LAY if c[3] else [c[2]])}
    gi, gj = cell(c)
    for (s, l) in starts: free[l][s] = True
    for (s, l) in goals: free[l][s] = True
    h = lambda i, j: math.hypot(i - gi, j - gj)
    openq, came, cost = [], {}, {}
    for (s, l) in starts:
        cost[(s, l)] = 0; heapq.heappush(openq, (h(*s), 0, s, l))
    moves = [(1, 0), (-1, 0), (0, 1), (0, -1), (1, 1), (1, -1), (-1, 1), (-1, -1)]
    while openq:
        f, cst, s, l = heapq.heappop(openq)
        if (s, l) in goals:
            path = [(s, l)]
            while (s, l) in came:
                s, l = came[(s, l)]; path.append((s, l))
            return path[::-1], (x0, y0)
        if cst > cost.get((s, l), 1e9): continue
        i, j = s
        for di, dj in moves:
            ni, nj = i + di, j + dj
            if not (0 <= ni < nx and 0 <= nj < ny) or not free[l][ni, nj]: continue
            nc = cst + math.hypot(di, dj)
            k = ((ni, nj), l)
            if nc < cost.get(k, 1e9):
                cost[k] = nc; came[k] = (s, l); heapq.heappush(openq, (nc + h(ni, nj), nc, (ni, nj), l))
        ol = "B.Cu" if l == "F.Cu" else "F.Cu"
        if free[ol][i, j] and can_via(i, j):
            k = (s, ol); nc = cst + 30
            if nc < cost.get(k, 1e9):
                cost[k] = nc; came[k] = (s, l); heapq.heappush(openq, (nc + h(i, j), nc, s, ol))
    return None, None

def simplify(cells):
    out = [cells[0]]
    for k in range(1, len(cells) - 1):
        a, c, d = out[-1], cells[k], cells[k + 1]
        if c[1] != a[1] or c[1] != d[1]: out.append(c); continue
        if (c[0][0] - a[0][0]) * (d[0][1] - c[0][1]) != (c[0][1] - a[0][1]) * (d[0][0] - c[0][0]): out.append(c)
    out.append(cells[-1]); return out

done = 0
for pts in pairs:
    a, c = pts
    path, org = route(a, c, a[4])
    if not path:
        print("no path for", a[4]); continue
    ni = b.FindNet(a[4])
    P = lambda s: pcbnew.VECTOR2I(pcbnew.FromMM(org[0] + s[0] * STEP), pcbnew.FromMM(org[1] + s[1] * STEP))
    pts2 = simplify(path)
    for (s1, l1), (s2, l2) in zip(pts2, pts2[1:]):
        if l1 != l2:
            v = pcbnew.PCB_VIA(b); v.SetPosition(P(s1)); v.SetWidth(pcbnew.FromMM(VD)); v.SetDrill(pcbnew.FromMM(0.25))
            v.SetViaType(pcbnew.VIATYPE_THROUGH); v.SetLayerPair(pcbnew.F_Cu, pcbnew.B_Cu); v.SetNet(ni); b.Add(v)
        if s1 != s2:
            t = pcbnew.PCB_TRACK(b); t.SetStart(P(s1)); t.SetEnd(P(s2)); t.SetWidth(pcbnew.FromMM(W)); t.SetLayer(LAY[l2]); t.SetNet(ni); b.Add(t)
    done += 1
    print("routed", a[4], "segments", len(pts2) - 1)
pcbnew.ZONE_FILLER(b).Fill(b.Zones())
b.BuildConnectivity()
b.Save(out)
pcbnew.WriteDRCReport(b, out.replace(".kicad_pcb", "_drc.txt"), pcbnew.EDA_UNITS_MILLIMETRES, True)
print("repaired", done, "of", len(pairs), "unconnected now", b.GetConnectivity().GetUnconnectedCount(True))
