"""Post-process the KiCad DSN for Freerouting: inner layers as planes, wider net classes for power and RF."""
import re, sys
s = open(sys.argv[1]).read()
for L in ("In1.Cu", "In2.Cu"):
    s = s.replace(f"(layer {L}\n      (type signal)", f"(layer {L}\n      (type power)")
classes = {"power": (300, ["VBAT", "VQI", "5V_RAW", "BST_SW", "BL_A", "BL_K", "5V_A"]),
           "rf": (300, ["GNSS_RF", "ANT_FEED"]),
           "mid": (250, ["3V3_GNSS", "VIB_K", "BUZ_K"])}
m = re.search(r'\(class kicad_default "" (.*?)\n      \(circuit', s, re.S)
names = m.group(1).split()
special = {n for _, (w, l) in classes.items() for n in l}
keep = [n for n in names if n not in special]
s = s[:m.start()] + '(class kicad_default "" ' + " ".join(keep) + "\n      (circuit" + s[m.end():]
extra = ""
for c, (w, l) in classes.items():
    extra += (f"    (class {c} {' '.join(l)}\n      (circuit\n        (use_via Via[0-3]_450:250_um)\n      )\n"
              f"      (rule\n        (width {w})\n        (clearance 150.1)\n      )\n    )\n")
i = s.index("  )\n  (wiring")
s = s[:i] + extra + s[i:]
open(sys.argv[2], "w").write(s)
print("ok")
