"""Dive computer main board, rev D: the circuit as physical pads.

Each part: ref -> (footprint, value, mpn, side, place, pads)
  footprint: "Lib:Name" from the KiCad library, or "custom:<name>" built in board.py
  side: "F" (top, under the display) or "B" (bottom, beside the battery)
  place: (x, y, rot) in housing coordinates (mm, +y towards the ESP32 antenna end), or ("near", ref) for auto placement
  pads: {pad number: net}; pads not listed are left unconnected

Changes from the rev C schematic (checked against the datasheets, see NOTES at the end):
  * GNSS ATGM336H-5N -> u-blox MAX-M10S: same 18-pad LCC, but with built-in LNA and SAW so a passive chip antenna works
  * MMC5603NJ has no CAP pin: C10 is now the 2.2 uF VDD capacitor the datasheet asks for
  * TPS22916C (0.4 mm WCSP) -> TPS22917DBV (SOT-23-6), easier to assemble
  * Display: 50-pin 0.5 mm FPC of the 55.5 x 84.96 mm 3.5" panels, 4-wire SPI (IM2..0 = 111)
  * QMI8658C: CS high (I2C), SDx/SCx to GND, SA0 open (internal pull-up -> 0x6B)
  * Added decoupling: PCM1808 VCC/VDD, each hall sensor, CH32V003, MAX17048, GNSS
  * LM393 second comparator parked (IN+ to GND, IN- to the 100 mV reference)
  * Depth sensors U3/U4 and their capacitor sit on the separate sensor board (sensor.py); the light sensor U7 on its flex
"""

R0402, C0402, C0603 = "Resistor_SMD:R_0402_1005Metric", "Capacitor_SMD:C_0402_1005Metric", "Capacitor_SMD:C_0603_1608Metric"
L0603 = "Inductor_SMD:L_0603_1608Metric"

def two(fp, val, mpn, side, place, a, b):
    return (fp, val, mpn, side, place, {"1": a, "2": b})

P = {}
# ---------------------------------------------------------------- MCU
esp = {"1": "GND", "2": "3V3", "3": "EN", "4": "I2S_BCK", "5": "I2S_LRCK", "6": "I2S_DIN", "7": "I2S_MCLK", "8": "SD_CS",
       "9": "LCD_BL", "10": "GNSS_TX", "11": "GNSS_RX", "12": "SDA", "13": "USB_DM", "14": "USB_DP", "15": "WET", "17": "SCL",
       "18": "LCD_CS", "19": "SPI_MOSI", "20": "SPI_SCK", "21": "SPI_MISO", "22": "LCD_DC", "23": "LCD_RST", "24": "VIB",
       "25": "TX123_ENV", "27": "BOOT", "31": "CHG_STAT", "32": "BTN_UP", "33": "BUZZER", "34": "BTN_SEL", "35": "BTN_DN",
       "36": "RXD0", "37": "TXD0", "38": "SAFE_RX", "39": "SAFE_TX", "40": "GND", "41": "GND"}
P["U1"] = ("RF_Module:ESP32-S3-WROOM-1", "ESP32-S3-WROOM-1-N16R8", "ESP32-S3-WROOM-1-N16R8", "B", (-19.0, 33.4, 180), esp)
P["R1"] = two(R0402, "10k", "", "F", ("near", "U1", "3"), "3V3", "EN")
P["C1"] = two(C0402, "1uF", "", "F", ("near", "U1", "3"), "EN", "GND")
P["C2"] = two(C0603, "22uF", "6.3V X5R", "F", ("near", "U1", "2"), "3V3", "GND")
P["C3"] = two(C0402, "100nF", "", "F", ("near", "U1", "2"), "3V3", "GND")
J1 = {"1": "VBAT", "2": "GND", "3": "USB_DM", "4": "USB_DP", "5": "TXD0", "6": "RXD0", "7": "EN", "8": "BOOT"}
P["J1"] = ("custom:SERVICE_2x4", "Service pads", "", "F", (-31.25, 5.0, 0), J1)

# ---------------------------------------------------------------- power
P["J5"] = ("custom:PADS_2_1.5", "Qi receiver module out", "wired module (5 V, 5 W Qi receiver)", "B", (-30.0, -19.5, 90), {"1": "VQI", "2": "GND"})
P["U21"] = ("Package_TO_SOT_SMD:SOT-23-5", "MCP73831T-2ACI/OT", "MCP73831T-2ACI/OT", "F", (-31.0, -26.0, 90),
            {"1": "CHG_STAT5", "2": "GND", "3": "VBAT", "4": "VQI", "5": "PROG"})
P["R2"] = two(R0402, "2k", "", "F", ("near", "U21", "5"), "PROG", "GND")
P["R3"] = two(R0402, "10k", "", "F", ("near", "U21", "1"), "CHG_STAT5", "CHG_STAT")
P["R4"] = two(R0402, "18k", "", "F", ("near", "U21", "1"), "CHG_STAT", "GND")
P["C4"] = two(C0603, "4.7uF", "10V X5R", "F", ("near", "U21", "4"), "VQI", "GND")
P["C5"] = two(C0603, "4.7uF", "10V X5R", "F", ("near", "U21", "3"), "VBAT", "GND")
P["J4"] = ("Connector_JST:JST_SH_BM02B-SRSS-TB_1x02-1MP_P1.00mm_Vertical", "Battery", "JST BM02B-SRSS-TB", "B", (-28.3, -28.0, 90),
           {"1": "VBAT", "2": "GND", "MP": "GND"})
P["U23"] = ("Package_TO_SOT_SMD:SOT-23-5", "TLV75733PDBVR", "TLV75733PDBVR", "F", (-31.0, -13.0, 90),
            {"1": "VBAT", "2": "GND", "3": "VBAT", "5": "3V3"})
P["C6"] = two(C0402, "1uF", "", "F", ("near", "U23", "1"), "VBAT", "GND")
P["C7"] = two(C0603, "10uF", "6.3V X5R", "F", ("near", "U23", "5"), "3V3", "GND")
P["U9"] = ("Package_DFN_QFN:TDFN-8-1EP_2x2mm_P0.5mm_EP0.8x1.2mm", "MAX17048G+T10", "MAX17048G+T10", "F", (-20.0, -24.0, 0),
           {"1": "GND", "2": "VBAT", "3": "VBAT", "4": "GND", "5": "FG_ALRT", "6": "GND", "7": "SCL", "8": "SDA", "9": "GND"})
P["C42"] = two(C0402, "100nF", "", "F", ("near", "U9", "3"), "VBAT", "GND")
# 5 V analog boost, off unless diving
P["U24"] = ("Package_TO_SOT_SMD:SOT-563", "TPS61023DRLR", "TPS61023DRLR", "F", (-31.0, -34.0, 0),
            {"1": "BST_FB", "2": "BOOST_EN", "3": "VBAT", "4": "GND", "5": "BST_SW", "6": "5V_RAW"})
P["L4"] = two("Inductor_SMD:L_1008_2520Metric", "1uH", "1 uH >= 1.5 A, 2520 (e.g. Murata DFE252012F-1R0M)", "F", ("near", "U24", "5"), "VBAT", "BST_SW")
P["R27"] = two(R0402, "732k", "1%", "F", ("near", "U24", "1"), "5V_RAW", "BST_FB")
P["R28"] = two(R0402, "100k", "1%", "F", ("near", "U24", "1"), "BST_FB", "GND")
P["R33"] = two(R0402, "100k", "", "F", ("near", "U24", "2"), "BOOST_EN", "GND")
P["C31"] = two(C0603, "22uF", "10V X5R", "F", ("near", "U24", "6"), "5V_RAW", "GND")
P["C32"] = two(C0603, "10uF", "10V X5R", "F", ("near", "U24", "3"), "VBAT", "GND")

# ---------------------------------------------------------------- sensors (I2C)
tca = {"1": "GND", "2": "GND", "3": "3V3", "4": "SDA_A", "5": "SCL_A", "6": "SDA_B", "7": "SCL_B", "12": "GND",
       "21": "GND", "22": "SCL", "23": "SDA", "24": "3V3"}
P["U2"] = ("Package_SO:TSSOP-24_4.4x7.8mm_P0.65mm", "TCA9548APWR", "TCA9548APWR", "B", (-30.4, 9.0, 90), tca)
P["C11"] = two(C0402, "100nF", "", "F", ("near", "U2", "24"), "3V3", "GND")
P["J7"] = ("custom:POGO_6", "Sensor board contacts", "pads for 6 spring contacts", "B", (-32.75, -6.0, 0),
           {"1": "3V3", "2": "GND", "3": "SDA_A", "4": "SCL_A", "5": "SDA_B", "6": "SCL_B"})
for r, n in (("R10", "SDA"), ("R11", "SCL")):
    P[r] = two(R0402, "2.2k", "", "F", ("near", "U2", "23"), "3V3", n)
for r, n in (("R12", "SDA_A"), ("R13", "SCL_A"), ("R14", "SDA_B"), ("R15", "SCL_B")):
    P[r] = two(R0402, "4.7k", "", "F", ("near", "U2", "5"), "3V3", n)
P["U5"] = ("Package_LGA:LGA-14_3x2.5mm_P0.5mm_LayoutBorder3x4y", "QMI8658C", "QMI8658C", "F", (-12.0, -16.0, 0),
           {"1": "IMU_SA0", "2": "GND", "3": "GND", "4": "IMU_INT", "5": "3V3", "6": "GND", "7": "GND", "8": "3V3",
            "12": "3V3", "13": "SCL", "14": "SDA"})
P["C13"] = two(C0402, "100nF", "", "F", ("near", "U5", "8"), "3V3", "GND")
P["R16"] = two(R0402, "DNP", "0R, fit for address 0x6A", "F", ("near", "U5", "1"), "IMU_SA0", "GND")
P["R17"] = two(R0402, "DNP", "0R, optional", "F", ("near", "U5", "1"), "3V3", "IMU_SA0")
P["U6"] = ("Package_BGA:WLP-4_0.83x0.83mm_P0.4mm", "MMC5603NJ", "MMC5603NJ", "F", (-5.0, -16.0, 0),
           {"A1": "GND", "A2": "SCL", "B1": "3V3", "B2": "SDA"})
P["C10"] = two(C0402, "2.2uF", "6.3V X5R", "F", ("near", "U6", "B1"), "3V3", "GND")
P["J6"] = ("custom:PADS_4_0.8", "Light sensor flex", "solder flex, VEML6030 on the flex", "F", (18.0, -44.6, 0),
           {"1": "3V3", "2": "GND", "3": "SDA", "4": "SCL"})
P["U8"] = ("Package_SO:SOIC-8_3.9x4.9mm_P1.27mm", "MB85RC256VPF", "MB85RC256VPF-G-JNERE2", "F", (-31.3, 27.0, 90),
           {"1": "GND", "2": "GND", "3": "GND", "4": "GND", "5": "SDA", "6": "SCL", "7": "GND", "8": "3V3"})
P["C43"] = two(C0402, "100nF", "", "F", ("near", "U8", "8"), "3V3", "GND")
P["U10"] = ("Package_SO:TSSOP-8_4.4x3mm_P0.65mm", "PCF85063ATT", "PCF85063ATT/AJ", "F", (-31.3, 16.0, 90),
            {"1": "XI", "2": "XO", "3": "RTC_INT", "4": "GND", "5": "SDA", "6": "SCL", "7": "RTC_CLK", "8": "3V3"})
P["Y1"] = two("Crystal:Crystal_SMD_3215-2Pin_3.2x1.5mm", "32.768kHz", "7 pF load", "F", ("near", "U10", "1"), "XI", "XO")
P["C44"] = two(C0402, "100nF", "", "F", ("near", "U10", "8"), "3V3", "GND")

# ---------------------------------------------------------------- tank receiver (bottom strip, +x side above the ferrite rod)
P["J8"] = ("custom:PADS_2_1.5", "Ferrite rod 38/5.3 kHz", "wired coil L2", "B", (27.7, -1.3, 0), {"1": "COIL_P", "2": "VMID"})
P["C20"] = two(C0603, "tune", "tuning/damping, measure", "F", ("near", "J8", "1"), "COIL_P", "VMID")
P["R20"] = two(R0402, "10k", "", "F", ("near", "J8", "1"), "COIL_P", "VMID")
P["U11"] = ("Package_SO:SOIC-8_3.9x4.9mm_P1.27mm", "MCP6022", "MCP6022T-I/SN", "B", (31.3, 11.6, 90),
            {"1": "PA_OUT1", "2": "PA_FB1", "3": "COIL_P", "4": "GND", "5": "PA_OUT1", "6": "PA_FB2", "7": "PA_OUT2", "8": "5V_A"})
P["C45"] = two(C0402, "100nF", "", "F", ("near", "U11", "8"), "5V_A", "GND")
P["R21"] = two(R0402, "1k", "", "F", ("near", "U11", "2"), "PA_FB1", "PA_AC1")

P["R22"] = two(R0402, "10k", "", "F", ("near", "U11", "2"), "PA_FB1", "PA_OUT1")
P["C27"] = two(C0603, "1uF", "", "F", ("near", "R21", "2"), "PA_AC1", "VMID")
P["R23"] = two(R0402, "1k", "", "F", ("near", "U11", "6"), "PA_FB2", "PA_AC2")

P["R24"] = two(R0402, "10k", "", "F", ("near", "U11", "6"), "PA_FB2", "PA_OUT2")
P["C28"] = two(C0603, "1uF", "", "F", ("near", "R23", "2"), "PA_AC2", "VMID")
P["R25"] = two(R0402, "10k", "", "F", ("near", "U11", "8"), "5V_A", "VMID")
P["R26"] = two(R0402, "10k", "", "F", ("near", "U11", "8"), "VMID", "GND")
P["C21"] = two(C0603, "10uF", "", "F", ("near", "U11", "8"), "VMID", "GND")
P["C22"] = two(C0603, "1uF", "", "F", ("near", "U11", "7"), "PA_OUT2", "ADC_INL")
P["U12"] = ("Package_SO:TSSOP-14_4.4x5mm_P0.65mm", "PCM1808PWR", "PCM1808PWR", "B", (31.5, 19.6, 90),
            {"1": "ADC_VREF", "2": "GND", "3": "5V_A", "4": "3V3", "5": "GND", "6": "I2S_MCLK", "7": "I2S_LRCK", "8": "I2S_BCK",
             "9": "I2S_DIN", "10": "GND", "11": "GND", "12": "GND", "13": "ADC_INL", "14": "ADC_INR"})
P["C29"] = two(C0603, "1uF", "", "F", ("near", "U12", "14"), "ADC_INR", "GND")
P["C23"] = two(C0603, "10uF", "", "F", ("near", "U12", "1"), "ADC_VREF", "GND")
P["C36"] = two(C0402, "100nF", "", "F", ("near", "U12", "3"), "5V_A", "GND")
P["C37"] = two(C0402, "100nF", "", "F", ("near", "U12", "4"), "3V3", "GND")
P["FB1"] = two(L0603, "600R@100MHz", "ferrite bead", "F", ("near", "U12", "3"), "5V_RAW", "5V_A")
P["C24"] = two(C0603, "22uF", "10V X5R", "F", ("near", "U12", "3"), "5V_A", "GND")
# 123 kHz channel
P["J9"] = ("custom:PADS_2_1.5", "Ferrite rod 123 kHz", "wired coil L3", "B", (32.4, -1.3, 0), {"1": "C123_P", "2": "GND"})
P["C25"] = two(C0603, "tune", "tuning 123 kHz", "F", ("near", "J9", "1"), "C123_P", "GND")
P["D1"] = ("Diode_SMD:D_SOD-323", "BAT54WS", "BAT54WS", "F", ("near", "J9", "1"), {"1": "ENV", "2": "C123_P"})
P["C26"] = two(C0402, "1nF", "", "F", ("near", "D1", "1"), "ENV", "GND")
P["R29"] = two(R0402, "100k", "", "F", ("near", "D1", "1"), "ENV", "GND")
P["U13"] = ("Package_SO:MSOP-8_3x3mm_P0.65mm", "LM393DGKR", "LM393DGKR", "B", (31.3, 4.2, 90),
            {"1": "TX123_ENV", "2": "CMP_REF", "3": "ENV", "4": "GND", "5": "GND", "6": "CMP_REF", "8": "3V3"})
P["C46"] = two(C0402, "100nF", "", "F", ("near", "U13", "8"), "3V3", "GND")
P["R30"] = two(R0402, "1M", "", "F", ("near", "U13", "2"), "3V3", "CMP_REF")
P["R31"] = two(R0402, "33k", "", "F", ("near", "U13", "2"), "CMP_REF", "GND")
P["R32"] = two(R0402, "10k", "", "F", ("near", "U13", "1"), "3V3", "TX123_ENV")

# ---------------------------------------------------------------- GNSS (bottom, +y end, antenna at the POM wall)
gnss = {"1": "GND", "2": "GNSS_RX", "3": "GNSS_TX", "4": "GNSS_PPS", "6": "3V3", "7": "3V3_GNSS", "8": "3V3_GNSS",
        "10": "GND", "11": "GNSS_RF", "12": "GND"}
P["U14"] = ("RF_GPS:ublox_MAX", "MAX-M10S", "MAX-M10S-00B", "B", (16.0, 38.6, 0), gnss)
P["U25"] = ("Package_TO_SOT_SMD:SOT-23-6", "TPS22917DBVR", "TPS22917DBVR", "B", (5.9, 29.5, 0),
            {"1": "3V3", "2": "GND", "3": "GNSS_EN", "5": "3V3_GNSS", "6": "3V3_GNSS"})
P["R34"] = two(R0402, "100k", "", "F", ("near", "U25", "3"), "GNSS_EN", "GND")
P["C30"] = two(C0603, "10uF", "", "F", ("near", "U14", "8"), "3V3_GNSS", "GND")
P["C47"] = two(C0402, "100nF", "", "F", ("near", "U14", "8"), "3V3_GNSS", "GND")
P["L5"] = two(R0402, "0R", "match: start 0R, tune with VNA", "B", ("near", "U14", "11"), "GNSS_RF", "ANT_FEED")
P["C33"] = two(C0402, "DNP", "match shunt", "B", ("near", "U14", "11"), "GNSS_RF", "GND")
P["C34"] = two(C0402, "DNP", "match shunt", "B", ("near", "U14", "11"), "ANT_FEED", "GND")
P["ANT1"] = ("custom:ANT_7x2", "1575AT43A40", "Johanson 1575AT43A0040E", "B", (21.0, 46.2, 0), {"1": "ANT_FEED"})

# ---------------------------------------------------------------- display, SD, safety MCU, outputs
fpc = {"1": "GND", "2": "BL_A", "9": "GND", "10": "GND", "11": "3V3", "12": "3V3", "13": "LCD_RST", "14": "LCD_CS",
       "15": "LCD_DC", "16": "SPI_SCK", "17": "3V3", "18": "SPI_MOSI", "42": "3V3", "43": "3V3", "44": "3V3", "45": "GND", "50": "GND", "MP": "GND"}
for k in range(3, 9): fpc[str(k)] = "BL_K"
for k in range(20, 42): fpc[str(k)] = "GND"
P["J2"] = ("custom:FPC_50_P0.5", "Display FPC 50p", "Hirose FH52-50S-0.5SH (1.0 mm high)", "F", (0.0, -40.6, 0), fpc)
P["R40"] = two("Resistor_SMD:R_0603_1608Metric", "15R", "0.1 W", "F", (30.0, -31.0, 90), "VBAT", "BL_A")
P["Q1"] = ("Package_TO_SOT_SMD:SOT-23", "AO3400A", "AO3400A", "F", (30.8, -34.8, 0), {"1": "BL_G", "2": "GND", "3": "BL_K"})
P["R41"] = two(R0402, "100R", "", "F", ("near", "Q1", "1"), "LCD_BL", "BL_G")
P["R50"] = two(R0402, "100k", "gate pull-down", "F", ("near", "Q1", "1"), "BL_G", "GND")
P["J3"] = ("Connector_Card:microSD_HC_Hirose_DM3D-SF", "microSD", "Hirose DM3D-SF", "B", (0.0, 38.0, 0),
           {"1": "SD_D2", "2": "SD_CS", "3": "SPI_MOSI", "4": "3V3", "5": "SPI_SCK", "6": "GND", "7": "SPI_MISO", "8": "SD_D1", "11": "GND"})
P["C48"] = two(C0402, "100nF", "", "F", ("near", "J3", "4"), "3V3", "GND")
for r, n in (("R42", "SD_CS"), ("R43", "SD_D1"), ("R44", "SD_D2")):
    P[r] = two(R0402, "10k", "", "F", ("near", "J3", "2"), "3V3", n)
ch = {"2": "SAFE_RX", "3": "SAFE_TX", "7": "GND", "9": "3V3", "10": "BOOST_EN", "11": "SDA_B", "12": "SCL_B", "13": "GNSS_EN",
      "14": "BUZ_SAFE", "18": "SWIO"}
P["U15"] = ("Package_SO:TSSOP-20_4.4x6.5mm_P0.65mm", "CH32V003F4P6", "CH32V003F4P6", "B", (24.4, 27.6, 0), ch)
P["C41"] = two(C0402, "100nF", "", "F", ("near", "U15", "9"), "3V3", "GND")
P["TP1"] = ("TestPoint:TestPoint_Pad_D1.0mm", "SWIO", "", "B", ("near", "U15", "18"), {"1": "SWIO"})
P["D2"] = ("Diode_SMD:D_SOD-323", "BAT54WS", "BAT54WS", "B", ("near", "Q2", "1"), {"1": "BUZ_G", "2": "BUZZER"})
P["D3"] = ("Diode_SMD:D_SOD-323", "BAT54WS", "BAT54WS", "B", ("near", "Q2", "1"), {"1": "BUZ_G", "2": "BUZ_SAFE"})
P["R45"] = two(R0402, "4.7k", "", "F", ("near", "Q2", "1"), "BUZ_G", "GND")
P["Q2"] = ("Package_TO_SOT_SMD:SOT-23", "AO3400A", "AO3400A", "B", (20.6, 21.0, 0), {"1": "BUZ_G", "2": "GND", "3": "BUZ_K"})
P["BZ1"] = ("custom:BUZZER_9x9", "PKMCS0909E4000", "Murata PKMCS0909E4000-R1", "B", (13.5, 23.1, 0), {"1": "VBAT", "2": "BUZ_K"})
P["R46"] = two(R0402, "1k", "", "F", ("near", "BZ1", "2"), "VBAT", "BUZ_K")
P["J10"] = ("custom:PADS_2_1.2", "Vibration motor", "1027 coin motor, wired", "B", (-7.5, 21.4, 90), {"1": "VBAT", "2": "VIB_K"})
P["Q3"] = ("Package_TO_SOT_SMD:SOT-23", "AO3400A", "AO3400A", "B", (-7.4, 26.4, 0), {"1": "VIB_G", "2": "GND", "3": "VIB_K"})
P["R47"] = two(R0402, "100R", "", "F", ("near", "Q3", "1"), "VIB", "VIB_G")
P["R48"] = two(R0402, "100k", "", "F", ("near", "Q3", "1"), "VIB_G", "GND")
P["D4"] = ("Diode_SMD:D_SOD-123", "1N4148W", "1N4148W", "B", ("near", "Q3", "3"), {"1": "VBAT", "2": "VIB_K"})
# buttons: hall sensors on the top-side board edge, opposite each lever magnet
for ref, val, y, x, net, c in (("U16", "TMAG5273A1QDBVR", -10.8, 32.9, "BTN_UP", "C38"),
                               ("U17", "TMAG5273B1QDBVR", 6.8, 32.9, "BTN_SEL", "C39"),
                               ("U18", "TMAG5273D1QDBVR", -2.0, -32.9, "BTN_DN", "C40")):
    P[ref] = ("Package_TO_SOT_SMD:SOT-23-6", val, val, "F", (x, y, 90),
              {"1": "SCL", "2": "GND", "3": "GND", "4": "3V3", "5": net, "6": "SDA"})
    P[c] = two(C0402, "100nF", "", "F", ("near", ref, "4"), "3V3", "GND")
P["E1"] = ("custom:PAD_1.5", "Wet contact 1", "wire to the 316L screw tab", "B", (8.8, 46.4, 0), {"1": "WET_PIN"})
P["E2"] = ("custom:PAD_1.5", "Wet contact 2", "wire to the 316L screw tab", "B", (-8.3, 46.6, 0), {"1": "GND"})
P["R49"] = two(R0402, "1k", "", "F", ("near", "E1", "1"), "WET_PIN", "WET")

for i, (x, y) in enumerate([(sx * 32.8, sy * 40.0) for sx in (-1, 1) for sy in (-1, 1)]):
    P[f"H{i+1}"] = ("MountingHole:MountingHole_2.2mm_M2", "M2", "", "F", (x, y, 0), {})

NOTES = """Checked against datasheets (pad numbers): ESP32-S3-WROOM-1 (KiCad library symbol), TCA9548APWR, MCP73831-2-OT, TLV757P DBV,
TPS61023 DRL (FB 595 mV: 732k/100k -> 4.95 V), TPS22917 DBV, MAX17048 TDFN (CELL not connected inside, EP to GND),
PCF85063ATT TSSOP8, MB85RC256V SOP8, QMI8658C LGA-14 (same pinout as LSM6DS3), MMC5603NJ (A1 GND, A2 SCL, B1 VDD, B2 SDA),
PCM1808 TSSOP14 (MD1=MD0=0 slave, FMT=0 I2S), TMAG5273 DBV (1 SCL, 2 GND, 3 TEST->GND, 4 VCC, 5 INT, 6 SDA), CH32V003F4P6 TSSOP20,
MCP6022 and LM393 SO-8 standard dual pinout, AO3400A (1 G, 2 S, 3 D).
To confirm when ordering: display FPC pin table of the exact panel bought, FH52 land pattern, Johanson 1575AT43A40 land
pattern and keep-out, PKMCS0909E land pattern."""
