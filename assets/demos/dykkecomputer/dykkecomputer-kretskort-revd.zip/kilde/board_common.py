import pcbnew
FPLIB = "/usr/share/kicad/footprints/"
OX, OY = 100.0, 100.0                       # housing (0,0) at KiCad (100,100); KiCad y points the other way
mm = pcbnew.FromMM
def K(x, y): return pcbnew.VECTOR2I(mm(OX + x), mm(OY - y))
def H(v): return (pcbnew.ToMM(v.x) - OX, OY - pcbnew.ToMM(v.y))      # KiCad -> housing

# ---------------------------------------------------------------- custom footprints (KiCad local frame, y down)
def new_fp(name):
    fp = pcbnew.FOOTPRINT(None)
    fp.SetFPID(pcbnew.LIB_ID("dive", name))
    return fp

def smd(fp, num, x, y, w, h, shape="rect", layer="F"):
    p = pcbnew.PAD(fp)
    p.SetNumber(num)
    p.SetShape({"rect": pcbnew.PAD_SHAPE_ROUNDRECT, "circle": pcbnew.PAD_SHAPE_CIRCLE}[shape])
    if shape == "rect": p.SetRoundRectRadiusRatio(0.15)
    p.SetAttribute(pcbnew.PAD_ATTRIB_SMD)
    ls = pcbnew.LSET(); [ls.AddLayer(l) for l in (pcbnew.F_Cu, pcbnew.F_Mask, pcbnew.F_Paste)]
    p.SetLayerSet(ls)
    p.SetSize(pcbnew.VECTOR2I(mm(w), mm(h)))
    p.SetPosition(pcbnew.VECTOR2I(mm(x), mm(y)))
    p.SetPos0(pcbnew.VECTOR2I(mm(x), mm(y))) if hasattr(p, "SetPos0") else None
    fp.Add(p)
    return p

def courtyard(fp, w, h, cx=0, cy=0):
    for (x0, y0, x1, y1) in [(-w/2, -h/2, w/2, -h/2), (w/2, -h/2, w/2, h/2), (w/2, h/2, -w/2, h/2), (-w/2, h/2, -w/2, -h/2)]:
        s = pcbnew.FP_SHAPE(fp)
        s.SetShape(pcbnew.SHAPE_T_SEGMENT)
        s.SetStart(pcbnew.VECTOR2I(mm(cx + x0), mm(cy + y0))); s.SetEnd(pcbnew.VECTOR2I(mm(cx + x1), mm(cy + y1)))
        s.SetStart0(s.GetStart()); s.SetEnd0(s.GetEnd())
        s.SetLayer(pcbnew.F_CrtYd); s.SetWidth(mm(0.05))
        fp.Add(s)
    for (x0, y0, x1, y1) in [(-w/2, -h/2, w/2, -h/2), (w/2, -h/2, w/2, h/2), (w/2, h/2, -w/2, h/2), (-w/2, h/2, -w/2, -h/2)]:
        s = pcbnew.FP_SHAPE(fp)
        s.SetShape(pcbnew.SHAPE_T_SEGMENT)
        s.SetStart(pcbnew.VECTOR2I(mm(cx + x0 + 0.1 * (1 if x0 < 0 else -1)), mm(cy + y0))); s.SetEnd(pcbnew.VECTOR2I(mm(cx + x1), mm(cy + y1)))
        s.SetStart0(s.GetStart()); s.SetEnd0(s.GetEnd())
        s.SetLayer(pcbnew.F_Fab); s.SetWidth(mm(0.1))
        fp.Add(s)

def load(spec):
    lib, name = spec.split(":")
    fp = pcbnew.FootprintLoad(FPLIB + lib + ".pretty", name)
    if fp is None: raise RuntimeError("footprint not found: " + spec)
    return fp


def add_outline(board, shp):
    poly = pcbnew.PCB_SHAPE(board); poly.SetShape(pcbnew.SHAPE_T_POLY); poly.SetLayer(pcbnew.Edge_Cuts); poly.SetWidth(mm(0.1))
    board.Add(poly)
    ps = poly.GetPolyShape(); ps.NewOutline()
    for (x, y) in list(shp.exterior.coords)[:-1]:
        v = K(x, y); ps.Append(v.x, v.y)
    for ring in shp.interiors:
        h = pcbnew.PCB_SHAPE(board); h.SetShape(pcbnew.SHAPE_T_POLY); h.SetLayer(pcbnew.Edge_Cuts); h.SetWidth(mm(0.1)); board.Add(h)
        hp = h.GetPolyShape(); hp.NewOutline()
        for (x, y) in list(ring.coords)[:-1]:
            v = K(x, y); hp.Append(v.x, v.y)

def edge_keepouts(board, shp, d=0.3):
    """Thin keep-out strips (tracks and vias) along every outline edge, so the autorouter keeps copper off the board edge."""
    from shapely.geometry import LineString
    rings = [shp.exterior] + list(shp.interiors)
    for ring in rings:
        pts = list(ring.coords)
        for a, c in zip(pts, pts[1:]):
            strip = LineString([a, c]).buffer(d, cap_style=2).intersection(shp)
            if strip.is_empty or strip.geom_type != "Polygon": continue
            z = pcbnew.ZONE(board)
            ls = pcbnew.LSET()
            for l in range(board.GetCopperLayerCount() - 1):
                ls.AddLayer([pcbnew.F_Cu, pcbnew.In1_Cu, pcbnew.In2_Cu][l])
            ls.AddLayer(pcbnew.B_Cu)
            z.SetLayerSet(ls)
            z.SetIsRuleArea(True); z.SetDoNotAllowTracks(True); z.SetDoNotAllowVias(True); z.SetDoNotAllowCopperPour(False)
            z.SetDoNotAllowPads(False); z.SetDoNotAllowFootprints(False)
            o = z.Outline(); o.NewOutline()
            for (x, y) in list(strip.exterior.coords)[:-1]:
                v = K(x, y); o.Append(v.x, v.y)
            board.Add(z)
