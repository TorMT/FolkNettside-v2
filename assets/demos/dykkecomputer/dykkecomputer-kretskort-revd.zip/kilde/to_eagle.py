"""Write a routed KiCad board as an EAGLE 9 .brd (opens in Fusion Electronics) plus a matching .sch.
The schematic has one box symbol per part with a pin per used pad ("pad name" = "pad number" + net) and net labels, so Fusion keeps
board and schematic consistent (forward/back annotation).
Usage: python3 to_eagle.py routed.kicad_pcb out_basename "Title" """
import sys, math, html, itertools
import pcbnew

src, base, title = sys.argv[1], sys.argv[2], sys.argv[3]
b = pcbnew.LoadBoard(src)
OX, OY = 100.0, 100.0
X = lambda v: html.escape(str(v), quote=True)
def g(v):                      # KiCad global -> housing mm
    return (round(pcbnew.ToMM(v.x) - OX, 4), round(OY - pcbnew.ToMM(v.y), 4))
EL = {pcbnew.F_Cu: 1, pcbnew.In1_Cu: 2, pcbnew.In2_Cu: 15, pcbnew.B_Cu: 16}
LAYERS = """<layers>
<layer number="1" name="Top" color="4" fill="1" visible="yes" active="yes"/>
<layer number="2" name="Route2" color="1" fill="3" visible="yes" active="yes"/>
<layer number="15" name="Route15" color="23" fill="5" visible="yes" active="yes"/>
<layer number="16" name="Bottom" color="1" fill="1" visible="yes" active="yes"/>
<layer number="17" name="Pads" color="2" fill="1" visible="yes" active="yes"/>
<layer number="18" name="Vias" color="2" fill="1" visible="yes" active="yes"/>
<layer number="19" name="Unrouted" color="6" fill="1" visible="yes" active="yes"/>
<layer number="20" name="Dimension" color="15" fill="1" visible="yes" active="yes"/>
<layer number="21" name="tPlace" color="7" fill="1" visible="yes" active="yes"/>
<layer number="22" name="bPlace" color="7" fill="1" visible="yes" active="yes"/>
<layer number="25" name="tNames" color="7" fill="1" visible="yes" active="yes"/>
<layer number="26" name="bNames" color="7" fill="1" visible="yes" active="yes"/>
<layer number="27" name="tValues" color="7" fill="1" visible="yes" active="yes"/>
<layer number="28" name="bValues" color="7" fill="1" visible="yes" active="yes"/>
<layer number="29" name="tStop" color="7" fill="3" visible="no" active="yes"/>
<layer number="30" name="bStop" color="7" fill="6" visible="no" active="yes"/>
<layer number="31" name="tCream" color="7" fill="4" visible="no" active="yes"/>
<layer number="32" name="bCream" color="7" fill="5" visible="no" active="yes"/>
<layer number="39" name="tKeepout" color="4" fill="11" visible="yes" active="yes"/>
<layer number="40" name="bKeepout" color="1" fill="11" visible="yes" active="yes"/>
<layer number="41" name="tRestrict" color="4" fill="10" visible="yes" active="yes"/>
<layer number="42" name="bRestrict" color="1" fill="10" visible="yes" active="yes"/>
<layer number="43" name="vRestrict" color="2" fill="10" visible="yes" active="yes"/>
<layer number="44" name="Drills" color="7" fill="1" visible="no" active="yes"/>
<layer number="45" name="Holes" color="7" fill="1" visible="no" active="yes"/>
<layer number="47" name="Measures" color="7" fill="1" visible="no" active="yes"/>
<layer number="51" name="tDocu" color="7" fill="1" visible="yes" active="yes"/>
<layer number="52" name="bDocu" color="7" fill="1" visible="yes" active="yes"/>
<layer number="91" name="Nets" color="2" fill="1" visible="yes" active="yes"/>
<layer number="92" name="Busses" color="1" fill="1" visible="yes" active="yes"/>
<layer number="93" name="Pins" color="2" fill="1" visible="no" active="yes"/>
<layer number="94" name="Symbols" color="4" fill="1" visible="yes" active="yes"/>
<layer number="95" name="Names" color="7" fill="1" visible="yes" active="yes"/>
<layer number="96" name="Values" color="7" fill="1" visible="yes" active="yes"/>
<layer number="97" name="Info" color="7" fill="1" visible="yes" active="yes"/>
</layers>"""

# ---------------------------------------------------------------- packages from the placed footprints (orientation removed)
packages, elements, pkgname_of, padnames = {}, [], {}, {}
for fp in b.GetFootprints():
    ref = fp.GetReference()
    pos = fp.GetPosition(); ang = fp.GetOrientationDegrees(); flipped = fp.IsFlipped()
    # local pad geometry: undo placement. For a flipped KiCad footprint the board view is mirrored (KiCad flips top/bottom),
    # EAGLE mirrors left/right: MR<a> == KiCad flipped at (180 - a); local coords taken in the element's own frame
    a_el = ang % 360
    ca, sa = math.cos(math.radians(-a_el)), math.sin(math.radians(-a_el))
    px, py = g(pos)
    seen, pads = {}, []
    for p in fp.Pads():
        num = p.GetNumber() or "X"
        k = seen.get(num, 0); seen[num] = k + 1
        name = num if k == 0 else f"{num}@{k+1}"
        gx, gy = g(p.GetPosition())
        dx, dy = gx - px, gy - py
        if flipped: dx = -dx                      # EAGLE: global = pos + Mirror_x(Rot(a) * local)  ->  local = Rot(-a) * Mirror_x(d)
        lx, ly = round(dx * ca - dy * sa, 4), round(dx * sa + dy * ca, 4)
        theta = p.GetOrientationDegrees()
        prot = round(((-theta - a_el) if flipped else (theta - a_el)) % 360, 3)
        sx, sy = pcbnew.ToMM(p.GetSize().x), pcbnew.ToMM(p.GetSize().y)
        drill = pcbnew.ToMM(p.GetDrillSize().x) if p.GetAttribute() in (pcbnew.PAD_ATTRIB_PTH, pcbnew.PAD_ATTRIB_NPTH) else 0
        shape = p.GetShape()
        rnd = 100 if shape in (pcbnew.PAD_SHAPE_CIRCLE, pcbnew.PAD_SHAPE_OVAL) else (int(p.GetRoundRectRadiusRatio() * 200) if shape == pcbnew.PAD_SHAPE_ROUNDRECT else 0)
        net = p.GetNetname()
        pads.append(dict(name=name, x=lx, y=ly, dx=sx, dy=sy, rot=prot, drill=drill, rnd=rnd, npth=p.GetAttribute() == pcbnew.PAD_ATTRIB_NPTH,
                         net=net, paste=p.IsOnLayer(pcbnew.F_Paste) or p.IsOnLayer(pcbnew.B_Paste), copper=p.IsOnCopperLayer()))
    key = (fp.GetFPID().GetLibItemName().wx_str(), tuple((d["name"], d["x"], d["y"], round(d["dx"], 3), round(d["dy"], 3), d["rot"], d["drill"]) for d in pads))
    if key not in pkgname_of:
        nm = key[0]
        if nm in packages: nm = f"{nm}_{len(packages)}"
        pkgname_of[key] = nm
        cy = fp.GetCourtyard(pcbnew.B_CrtYd if flipped else pcbnew.F_CrtYd)
        packages[nm] = (pads, None)
    pk = pkgname_of[key]
    x, y = g(pos)
    rot = ("MR" if flipped else "R") + str(round(a_el, 3))
    rt = fp.Reference()
    tx, ty = g(rt.GetPosition())
    on_silk = rt.GetLayer() in (pcbnew.F_SilkS, pcbnew.B_SilkS) and rt.IsVisible()
    tang = round(rt.GetDrawRotation().AsDegrees() % 360, 1)
    name_attr = dict(x=tx, y=ty, size=round(pcbnew.ToMM(rt.GetTextHeight()), 2), layer=(26 if flipped else 25) if on_silk else (52 if flipped else 51),
                     rot=("MR" if flipped else "R") + str(tang), show=on_silk)
    elements.append(dict(ref=ref, pkg=pk, value=fp.GetValue(), x=x, y=y, rot=rot, pads=pads, name=name_attr))

def pkg_xml(nm, pads):
    out = [f'<package name="{X(nm)}">']
    for d in pads:
        if not d["copper"]: continue
        if d["npth"]:
            out.append(f'<hole x="{d["x"]}" y="{d["y"]}" drill="{d["drill"]}"/>')
        elif d["drill"]:
            out.append(f'<pad name="{X(d["name"])}" x="{d["x"]}" y="{d["y"]}" drill="{d["drill"]}" diameter="{max(d["dx"], d["dy"])}" shape="round"/>')
        else:
            r = f' rot="R{d["rot"]}"' if d["rot"] else ""
            cream = "" if d["paste"] else ' cream="no"'
            out.append(f'<smd name="{X(d["name"])}" x="{d["x"]}" y="{d["y"]}" dx="{round(d["dx"], 4)}" dy="{round(d["dy"], 4)}" layer="1" roundness="{d["rnd"]}"{r}{cream}/>')
    out.append(f'<text x="0" y="1" size="0.6" layer="25">&gt;NAME</text>')
    out.append("</package>")
    return "\n".join(out)

def copper_pads(el): return [d for d in el["pads"] if d["copper"] and not d["npth"]]

# ---------------------------------------------------------------- symbols / devices: one per package+value combination
dev_of = {}
symbols, devicesets = [], []
for el in elements:
    cp = copper_pads(el)
    if not cp:
        el["dev"] = None; continue
    key = el["pkg"]
    if key in dev_of:
        el["dev"] = dev_of[key]; continue
    nm = f"P{len(dev_of)+1}_{''.join(ch for ch in key if ch.isalnum())[:24]}"
    dev_of[key] = nm; el["dev"] = nm
    n = len(cp); half = (n + 1) // 2
    h = max(half, 1) * 2.54 + 2.54; w = 15.24
    sy = [f'<symbol name="{nm}">',
          f'<wire x1="{-w/2}" y1="{h/2}" x2="{w/2}" y2="{h/2}" width="0.254" layer="94"/>',
          f'<wire x1="{w/2}" y1="{h/2}" x2="{w/2}" y2="{-h/2}" width="0.254" layer="94"/>',
          f'<wire x1="{w/2}" y1="{-h/2}" x2="{-w/2}" y2="{-h/2}" width="0.254" layer="94"/>',
          f'<wire x1="{-w/2}" y1="{-h/2}" x2="{-w/2}" y2="{h/2}" width="0.254" layer="94"/>',
          f'<text x="{-w/2}" y="{h/2+1.27}" size="1.778" layer="95">&gt;NAME</text>',
          f'<text x="{-w/2}" y="{-h/2-2.54}" size="1.778" layer="96">&gt;VALUE</text>']
    for i, d in enumerate(cp):
        left = i < half
        yy = round(h / 2 - 2.54 - (i if left else i - half) * 2.54, 3)
        xx = -w / 2 - 5.08 if left else w / 2 + 5.08
        sy.append(f'<pin name="{X(d["name"])}" x="{xx}" y="{yy}" length="short" rot="{"R0" if left else "R180"}"/>')
    sy.append("</symbol>")
    symbols.append("\n".join(sy))
    conns = "".join(f'<connect gate="G$1" pin="{X(d["name"])}" pad="{X(d["name"])}"/>' for d in cp)
    devicesets.append(f'<deviceset name="{nm}" prefix="X"><gates><gate name="G$1" symbol="{nm}" x="0" y="0"/></gates>'
                      f'<devices><device name="" package="{X(key)}"><connects>{conns}</connects><technologies><technology name=""/></technologies></device></devices></deviceset>')

lib_pk = "\n".join(pkg_xml(nm, pads) for nm, (pads, _) in packages.items())
library = (f'<library name="dive_revd"><description>{X(title)}: packages generated from the routed board</description>'
           f'<packages>{lib_pk}</packages><symbols>{"".join(symbols)}</symbols><devicesets>{"".join(devicesets)}</devicesets></library>')

# ---------------------------------------------------------------- board
plain = []
for d in b.GetDrawings():
    if d.GetLayer() == pcbnew.Edge_Cuts and d.GetShape() == pcbnew.SHAPE_T_POLY:
        ps = d.GetPolyShape()
        for oi in range(ps.OutlineCount()):
            ch = ps.Outline(oi); pts = [g(ch.CPoint(i)) for i in range(ch.PointCount())]
            for a, c2 in zip(pts, pts[1:] + pts[:1]):
                plain.append(f'<wire x1="{a[0]}" y1="{a[1]}" x2="{c2[0]}" y2="{c2[1]}" width="0" layer="20"/>')
sig = {}
for el in elements:
    for d in copper_pads(el):
        if d["net"]: sig.setdefault(d["net"], []).append(f'<contactref element="{X(el["ref"])}" pad="{X(d["name"])}"/>')
for t in b.GetTracks():
    n = t.GetNetname()
    if not n: continue
    if t.GetClass() == "PCB_VIA":
        x, y = g(t.GetPosition())
        sig.setdefault(n, []).append(f'<via x="{x}" y="{y}" extent="1-16" drill="{pcbnew.ToMM(t.GetDrillValue())}" diameter="{pcbnew.ToMM(t.GetWidth())}"/>')
    else:
        a, c2 = g(t.GetStart()), g(t.GetEnd())
        sig.setdefault(n, []).append(f'<wire x1="{a[0]}" y1="{a[1]}" x2="{c2[0]}" y2="{c2[1]}" width="{pcbnew.ToMM(t.GetWidth())}" layer="{EL[t.GetLayer()]}"/>')
for z in b.Zones():
    if z.GetIsRuleArea():
        o = z.Outline().Outline(0); pts = [g(o.CPoint(i)) for i in range(o.PointCount())]
        for lay in (41, 42, 43):
            plain.append(f'<polygon width="0.1" layer="{lay}">' + "".join(f'<vertex x="{p[0]}" y="{p[1]}"/>' for p in pts) + "</polygon>")
        continue
    n = z.GetNetname()
    o = z.Outline().Outline(0); pts = [g(o.CPoint(i)) for i in range(o.PointCount())]
    rank = 6 if z.GetLayer() in (pcbnew.F_Cu, pcbnew.B_Cu) else 1
    sig.setdefault(n, []).append(f'<polygon width="0.2" layer="{EL[z.GetLayer()]}" isolate="{pcbnew.ToMM(z.GetLocalClearance())}" thermals="yes" rank="{rank}">'
                                 + "".join(f'<vertex x="{p[0]}" y="{p[1]}"/>' for p in pts) + "</polygon>")
def el_xml(e):
    n = e["name"]
    attrs = (f'<attribute name="NAME" value="{X(e["ref"])}" x="{n["x"]}" y="{n["y"]}" size="{n["size"]}" layer="{n["layer"]}" font="vector" ratio="16" rot="{n["rot"]}" align="center"'
             + ('' if n["show"] else ' display="off"') + '/>'
             f'<attribute name="VALUE" value="{X(e["value"])}" x="{e["x"]}" y="{e["y"]}" size="0.6" layer="{52 if e["rot"].startswith("M") else 51}" display="off"/>')
    return (f'<element name="{X(e["ref"])}" library="dive_revd" package="{X(e["pkg"])}" value="{X(e["value"])}" x="{e["x"]}" y="{e["y"]}" smashed="yes"'
            + (f' rot="{e["rot"]}"' if e["rot"] not in ("R0", "R0.0") else "") + ">" + attrs + "</element>")
els = "\n".join(el_xml(e) for e in elements)
signals = "\n".join(f'<signal name="{X(n)}">' + "".join(v) + "</signal>" for n, v in sorted(sig.items()))
lay_count = b.GetCopperLayerCount()
setup = '<designrules name="dive"><param name="layerSetup" value="(1*16)"/></designrules>' if lay_count == 2 else \
        '<designrules name="dive"><param name="layerSetup" value="(1*2*15*16)"/><param name="mdWireWire" value="0.15mm"/><param name="mdWirePad" value="0.15mm"/><param name="mdWireVia" value="0.15mm"/><param name="msWidth" value="0.1mm"/><param name="msDrill" value="0.25mm"/></designrules>'
brd = f'''<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE eagle SYSTEM "eagle.dtd">
<eagle version="9.6.2">
<drawing>
<settings><setting alwaysvectorfont="no"/><setting verticaltext="up"/></settings>
<grid distance="0.1" unitdist="mm" unit="mm" style="lines" multiple="1" display="no" altdistance="0.01" altunitdist="mm" altunit="mm"/>
{LAYERS}
<board>
<plain>{"".join(plain)}</plain>
<libraries>{library}</libraries>
<attributes/><variantdefs/><classes><class number="0" name="default" width="0" drill="0"/></classes>
{setup}
<elements>
{els}
</elements>
<signals>
{signals}
</signals>
</board>
</drawing>
</eagle>
'''
open(base + ".brd", "w").write(brd)

# ---------------------------------------------------------------- schematic: parts in a grid, every pin with a net label
parts, insts, nets_sch = [], [], {}
col, row, colw = 0, 0, 0
x0, y0 = 20.32, 254.0
cx, cy = x0, y0
for el in sorted([e for e in elements if e["dev"]], key=lambda e: (e["ref"].rstrip("0123456789"), int("".join(ch for ch in e["ref"] if ch.isdigit()) or 0))):
    cp = copper_pads(el); half = (len(cp) + 1) // 2; h = max(half, 1) * 2.54 + 2.54
    if cy - h < 15: cy = y0; cx += 76.2
    py = round(cy - h / 2 - 5.08, 2)
    parts.append(f'<part name="{X(el["ref"])}" library="dive_revd" deviceset="{el["dev"]}" device="" value="{X(el["value"])}"/>')
    insts.append(f'<instance part="{X(el["ref"])}" gate="G$1" x="{cx}" y="{py}"/>')
    for i, d in enumerate(cp):
        if not d["net"]: continue
        left = i < half
        yy = round(py + h / 2 - 2.54 - (i if left else i - half) * 2.54, 3)
        xp = round(cx + (-15.24 / 2 - 5.08 if left else 15.24 / 2 + 5.08), 3)
        xe = round(xp + (-7.62 if left else 7.62), 3)
        nets_sch.setdefault(d["net"], []).append(
            f'<segment><pinref part="{X(el["ref"])}" gate="G$1" pin="{X(d["name"])}"/>'
            f'<wire x1="{xp}" y1="{yy}" x2="{xe}" y2="{yy}" width="0.1524" layer="91"/>'
            f'<label x="{xe}" y="{yy}" size="1.27" layer="95"{" rot=\"MR0\"" if left else ""} xref="no"/></segment>')
    cy -= h + 12.7
sheet_nets = "\n".join(f'<net name="{X(n)}" class="0">{"".join(v)}</net>' for n, v in sorted(nets_sch.items()))
sch = f'''<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE eagle SYSTEM "eagle.dtd">
<eagle version="9.6.2">
<drawing>
<settings><setting alwaysvectorfont="no"/><setting verticaltext="up"/></settings>
<grid distance="0.1" unitdist="inch" unit="inch" style="lines" multiple="1" display="no" altdistance="0.01" altunitdist="inch" altunit="inch"/>
{LAYERS}
<schematic xreflabel="%F%N/%S.%C%R" xrefpart="/%S.%C%R">
<description>{X(title)}. Net-label schematic generated from the routed board; the drawn schematic (rev C sheets) explains the circuit.</description>
<libraries>{library}</libraries>
<attributes/><variantdefs/><classes><class number="0" name="default" width="0" drill="0"/></classes>
<parts>{"".join(parts)}</parts>
<sheets><sheet><plain><text x="20.32" y="264.16" size="3.81" layer="97">{X(title)}</text></plain>
<instances>{"".join(insts)}</instances><busses/>
<nets>{sheet_nets}</nets>
</sheet></sheets>
</schematic>
</drawing>
</eagle>
'''
open(base + ".sch", "w").write(sch)
print("elements", len(elements), "packages", len(packages), "signals", len(sig))
