"""Import the Freerouting session, add GND pours on the outer layers, fill zones, write DRC report and a connectivity summary.
Usage: python3 finish.py board.kicad_pcb session.ses out.kicad_pcb [pour]"""
import sys, pcbnew
from shapely.geometry import Polygon
src, ses, out = sys.argv[1:4]
pour = len(sys.argv) > 4 and sys.argv[4] == "pour"
b = pcbnew.LoadBoard(src)
import re
def sexp(txt):
    tok = re.findall(r'\(|\)|"[^"]*"|[^\s()]+', txt)
    st = [[]]
    for t in tok:
        if t == "(": st.append([])
        elif t == ")": x = st.pop(); st[-1].append(x)
        else: st[-1].append(t.strip('"'))
    return st[0][0]
def find(node, key):
    for c in node:
        if isinstance(c, list) and c and c[0] == key: yield c
tree = sexp(open(ses).read())
routes = next(find(tree, "routes"))
res = float(next(find(routes, "resolution"))[2])            # units per um
U = lambda v: int(round(float(v) / res * 1000))              # -> KiCad nm
layers = {"F.Cu": pcbnew.F_Cu, "In1.Cu": pcbnew.In1_Cu, "In2.Cu": pcbnew.In2_Cu, "B.Cu": pcbnew.B_Cu}
vsz = {}
lib = next(find(routes, "library_out"), [])
for ps in find(lib, "padstack"):
    sh = next(find(ps, "shape")); circ = sh[1]
    vsz[ps[1]] = U(circ[2])
nt = nv = 0
for net in find(next(find(routes, "network_out")), "net"):
    ni = b.FindNet(net[1])
    for w in find(net, "wire"):
        p = next(find(w, "path"))
        lay, width, pts = layers[p[1]], U(p[2]), p[3:]
        xy = [(U(pts[i]), -U(pts[i + 1])) for i in range(0, len(pts) - 1, 2)]
        for (a, c) in zip(xy, xy[1:]):
            t = pcbnew.PCB_TRACK(b); t.SetStart(pcbnew.VECTOR2I(*a)); t.SetEnd(pcbnew.VECTOR2I(*c))
            t.SetWidth(width); t.SetLayer(lay); t.SetNet(ni); b.Add(t); nt += 1
    for v in find(net, "via"):
        x, y = U(v[2]), -U(v[3])
        via = pcbnew.PCB_VIA(b); via.SetPosition(pcbnew.VECTOR2I(x, y)); via.SetWidth(vsz.get(v[1], pcbnew.FromMM(0.45)))
        via.SetDrill(pcbnew.FromMM(0.25)); via.SetViaType(pcbnew.VIATYPE_THROUGH); via.SetLayerPair(pcbnew.F_Cu, pcbnew.B_Cu)
        via.SetNet(ni); b.Add(via); nv += 1
print("SES import: segments", nt, "vias", nv)
if pour:
    # copy the In1 GND plane outline to both outer layers as lower-priority GND pours
    bb = b.GetBoardEdgesBoundingBox()
    gnd = b.FindNet("GND")
    for layer in (pcbnew.F_Cu, pcbnew.B_Cu):
        z = pcbnew.ZONE(b)
        z.SetLayer(layer)
        o = z.Outline(); o.NewOutline()
        for (x, y) in ((bb.GetLeft(), bb.GetTop()), (bb.GetRight(), bb.GetTop()), (bb.GetRight(), bb.GetBottom()), (bb.GetLeft(), bb.GetBottom())):
            o.Append(x, y)
        z.SetNet(gnd)
        z.SetLocalClearance(pcbnew.FromMM(0.25)); z.SetMinThickness(pcbnew.FromMM(0.25))
        z.SetPadConnection(pcbnew.ZONE_CONNECTION_THERMAL); z.SetThermalReliefGap(pcbnew.FromMM(0.25)); z.SetThermalReliefSpokeWidth(pcbnew.FromMM(0.3))
        z.SetIslandRemovalMode(pcbnew.ISLAND_REMOVAL_MODE_ALWAYS)
        b.Add(z)
for z in list(b.Zones()):                       # drop the thin edge strips used only to steer the autorouter
    if z.GetIsRuleArea():
        bb = z.GetBoundingBox()
        if min(pcbnew.ToMM(bb.GetWidth()), pcbnew.ToMM(bb.GetHeight())) < 0.7: b.Delete(z)
filler = pcbnew.ZONE_FILLER(b)
filler.Fill(b.Zones())
b.BuildConnectivity()
b.Save(out)
ntr = sum(1 for t in b.GetTracks() if t.GetClass() == "PCB_TRACK")
nv = sum(1 for t in b.GetTracks() if t.GetClass() == "PCB_VIA")
print("tracks", ntr, "vias", nv)
pcbnew.WriteDRCReport(b, out.replace(".kicad_pcb", "_drc.txt"), pcbnew.EDA_UNITS_MILLIMETRES, True)
print("unconnected:", b.GetConnectivity().GetUnconnectedCount(True))
