"""Readable silkscreen: values to the fab layer, reference designators 0.9 mm / 0.15 mm stroke, upright, placed next to
their part where they cover no pad and no other text; references that do not fit are moved to the fab layer
(still on the assembly drawing and in the placement file). Usage: python3 silkfix.py in.kicad_pcb out.kicad_pcb"""
import sys, pcbnew
from shapely.geometry import box as sbox, Polygon
from shapely.strtree import STRtree
src, out = sys.argv[1:3]
b = pcbnew.LoadBoard(src)
mm, FM = pcbnew.ToMM, pcbnew.FromMM
H, STROKE = 0.9, 0.15

edge = None
for d in b.GetDrawings():
    if d.GetLayer() == pcbnew.Edge_Cuts and d.GetShape() == pcbnew.SHAPE_T_POLY:
        o = d.GetPolyShape().Outline(0)
        edge = Polygon([(mm(o.CPoint(i).x), mm(o.CPoint(i).y)) for i in range(o.PointCount())])
inside = edge.buffer(-0.4)

def bb_poly(bb, grow=0.0):
    return sbox(mm(bb.GetLeft()) - grow, mm(bb.GetTop()) - grow, mm(bb.GetRight()) + grow, mm(bb.GetBottom()) + grow)

# obstacles per side: pads (mask openings) and NPTH holes
obst = {"F": [], "B": []}
for fp in b.GetFootprints():
    for p in fp.Pads():
        sh = bb_poly(p.GetBoundingBox(), 0.12)
        if p.IsOnLayer(pcbnew.F_Mask) or p.HasHole(): obst["F"].append(sh)
        if p.IsOnLayer(pcbnew.B_Mask) or p.HasHole(): obst["B"].append(sh)
for t in b.GetTracks():
    if t.GetClass() == "PCB_VIA":
        sh = bb_poly(t.GetBoundingBox(), 0.08)
        obst["F"].append(sh); obst["B"].append(sh)
bodies = {"F": [], "B": []}                      # other parts' outlines: text under a part is hidden after assembly
for fp in b.GetFootprints():
    if fp.GetReference().startswith("H"): continue
    cy = fp.GetCourtyard(pcbnew.B_CrtYd if fp.IsFlipped() else pcbnew.F_CrtYd)
    shp = bb_poly(cy.BBox()) if cy.OutlineCount() else bb_poly(fp.GetBoundingBox(False, False))
    bodies["B" if fp.IsFlipped() else "F"].append((fp.GetReference(), shp.buffer(-0.05)))
trees = {s: STRtree(v) for s, v in obst.items()}
placed = {"F": [], "B": []}

def free(shape, side, me=""):
    if not inside.contains(shape): return False
    if any(r != me and shape.intersects(g) for r, g in bodies[side]): return False
    for i in trees[side].query(shape):
        if shape.intersects(obst[side][int(i)]): return False
    return not any(shape.intersects(p) for p in placed[side])

fps = sorted(b.GetFootprints(), key=lambda f: -bb_poly(f.GetBoundingBox(False, False)).area)
shown = hidden = 0
for fp in fps:
    side = "B" if fp.IsFlipped() else "F"
    silk, fab = (pcbnew.B_SilkS, pcbnew.B_Fab) if side == "B" else (pcbnew.F_SilkS, pcbnew.F_Fab)
    val = fp.Value(); val.SetLayer(fab); val.SetVisible(False)
    ref = fp.Reference()
    if fp.GetReference().startswith("H"):
        ref.SetLayer(fab); ref.SetVisible(False); continue
    ref.SetLayer(silk); ref.SetVisible(True)
    ref.SetTextSize(pcbnew.VECTOR2I(FM(H), FM(H))); ref.SetTextThickness(FM(STROKE))
    ref.SetMirrored(side == "B")
    ref.SetKeepUpright(True)
    body = bb_poly(fp.GetBoundingBox(False, False))
    for s in fp.Pads(): body = body.union(bb_poly(s.GetBoundingBox()))
    x0, y0, x1, y1 = body.bounds
    cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
    best = None
    for (hh, gap) in [(H, g) for g in (0.2, 0.5, 0.9, 1.4, 2.0)] + [(0.8, g) for g in (0.15, 0.4, 0.8)]:
        ref.SetTextSize(pcbnew.VECTOR2I(FM(hh), FM(hh)))
        cands = [(cx, y0 - gap - hh / 2, 0), (cx, y1 + gap + hh / 2, 0), (x0 - gap - hh / 2, cy, 90), (x1 + gap + hh / 2, cy, 90),
                 (x0, y0 - gap - hh / 2, 0), (x1, y1 + gap + hh / 2, 0), (x0 - gap - hh / 2, y0, 90), (x1 + gap + hh / 2, y1, 90)]
        for (tx, ty, ang) in cands:
            ref.SetTextAngle(pcbnew.EDA_ANGLE(ang - fp.GetOrientationDegrees(), pcbnew.DEGREES_T))
            ref.SetPosition(pcbnew.VECTOR2I(FM(tx), FM(ty)))
            shp = bb_poly(ref.GetBoundingBox(), 0.05)
            if free(shp, side, fp.GetReference()):
                best = shp; break
        if best: break
    if best:
        placed[side].append(best); shown += 1
    else:
        ref.SetLayer(fab); hidden += 1
b.Save(out)
print(f"references on silkscreen {shown}, moved to fab (no room) {hidden}")
