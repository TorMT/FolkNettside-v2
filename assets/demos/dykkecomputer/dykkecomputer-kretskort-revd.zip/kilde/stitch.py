"""Add GND stitching vias on a grid wherever both outer layers are free, so the outer GND pours join the In1 plane
(no isolated islands under the display). Usage: python3 stitch.py in.kicad_pcb out.kicad_pcb"""
import sys, pcbnew
from shapely.geometry import Point, LineString, Polygon
from shapely.ops import unary_union
from shapely import prepared
src, out = sys.argv[1:3]
b = pcbnew.LoadBoard(src)
mm = pcbnew.ToMM
gnd = b.FindNet("GND")
def shapes(layer):
    s = []
    for fp in b.GetFootprints():
        for p in fp.Pads():
            if not p.IsOnLayer(layer) and not p.HasHole(): continue
            o = p.GetEffectivePolygon().Outline(0)
            pts = [(mm(o.CPoint(i).x), mm(o.CPoint(i).y)) for i in range(o.PointCount())]
            s.append(Polygon(pts) if len(pts) > 2 else Point(mm(p.GetPosition().x), mm(p.GetPosition().y)).buffer(0.3))
            if p.HasHole(): s.append(Point(mm(p.GetPosition().x), mm(p.GetPosition().y)).buffer(mm(p.GetDrillSize().x) / 2 + 0.3))
    for t in b.GetTracks():
        if t.GetClass() == "PCB_VIA":
            s.append(Point(mm(t.GetPosition().x), mm(t.GetPosition().y)).buffer(mm(t.GetWidth()) / 2 + 0.3))
        elif t.GetLayer() == layer:
            s.append(LineString([(mm(t.GetStart().x), mm(t.GetStart().y)), (mm(t.GetEnd().x), mm(t.GetEnd().y))]).buffer(mm(t.GetWidth()) / 2))
    for z in b.Zones():
        if z.GetIsRuleArea():
            o = z.Outline().Outline(0)
            s.append(Polygon([(mm(o.CPoint(i).x), mm(o.CPoint(i).y)) for i in range(o.PointCount())]))
    return unary_union(s)
blocked = prepared.prep(unary_union([shapes(pcbnew.F_Cu), shapes(pcbnew.B_Cu)]).buffer(0.15 + 0.225))
edge = None
for d in b.GetDrawings():
    if d.GetLayer() == pcbnew.Edge_Cuts and d.GetShape() == pcbnew.SHAPE_T_POLY:
        o = d.GetPolyShape().Outline(0)
        edge = Polygon([(mm(o.CPoint(i).x), mm(o.CPoint(i).y)) for i in range(o.PointCount())])
inside = prepared.prep(edge.buffer(-1.0))
bb = edge.bounds
n = 0
y = bb[1] + 1.5
while y < bb[3]:
    x = bb[0] + 1.5
    while x < bb[2]:
        p = Point(x, y)
        if inside.contains(p) and not blocked.contains(p):
            v = pcbnew.PCB_VIA(b); v.SetPosition(pcbnew.VECTOR2I(pcbnew.FromMM(x), pcbnew.FromMM(y)))
            v.SetWidth(pcbnew.FromMM(0.45)); v.SetDrill(pcbnew.FromMM(0.25)); v.SetViaType(pcbnew.VIATYPE_THROUGH)
            v.SetLayerPair(pcbnew.F_Cu, pcbnew.B_Cu); v.SetNet(gnd); b.Add(v); n += 1
        x += 3.0
    y += 3.0
pcbnew.ZONE_FILLER(b).Fill(b.Zones())
b.BuildConnectivity()
b.Save(out)
pcbnew.WriteDRCReport(b, out.replace(".kicad_pcb", "_drc.txt"), pcbnew.EDA_UNITS_MILLIMETRES, True)
print("stitching vias", n, "unconnected", b.GetConnectivity().GetUnconnectedCount(True))
