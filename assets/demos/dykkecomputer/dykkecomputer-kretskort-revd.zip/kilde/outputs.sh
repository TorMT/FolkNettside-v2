#!/bin/bash
# Manufacturing outputs for one routed board: Gerbers + drill (JLCPCB), pick-and-place, STEP, SVG renders.
# Usage: outputs.sh board.kicad_pcb outdir layers(2|4)
set -e
B=$1; O=$2; N=$3
mkdir -p "$O/gerber"
if [ "$N" = 4 ]; then L="F.Cu,In1.Cu,In2.Cu,B.Cu"; else L="F.Cu,B.Cu"; fi
kicad-cli pcb export gerbers -o "$O/gerber/" -l "$L,F.Paste,B.Paste,F.SilkS,B.SilkS,F.Mask,B.Mask,Edge.Cuts" --subtract-soldermask --no-x2 --use-drill-file-origin "$B" >/dev/null
kicad-cli pcb export drill -o "$O/gerber/" --format excellon --drill-origin absolute --excellon-units mm --excellon-separate-th --generate-map --map-format gerberx2 "$B" >/dev/null
kicad-cli pcb export pos -o "$O/pos.csv" --format csv --units mm --side both --use-drill-file-origin "$B" >/dev/null
kicad-cli pcb export step -o "$O/board.step" --subst-models --force "$B" >/dev/null 2>&1 || echo "step export failed"
kicad-cli pcb export svg -o "$O/top.svg" -l "F.Cu,F.SilkS,F.Mask,Edge.Cuts" --exclude-drawing-sheet --page-size-mode 2 "$B" >/dev/null
kicad-cli pcb export svg -o "$O/bottom.svg" -m -l "B.Cu,B.SilkS,B.Mask,Edge.Cuts" --exclude-drawing-sheet --page-size-mode 2 "$B" >/dev/null
(cd "$O/gerber" && zip -q -r ../gerber.zip .)
ls -la "$O"
