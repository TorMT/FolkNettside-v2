"""Check an exported EAGLE .brd against the KiCad board: every pad of every element must land on the same spot and net
(EAGLE transform as implemented by KiCad's own EAGLE importer: rotate, then mirror in x for MR)."""
import sys, math, xml.etree.ElementTree as ET, pcbnew
brd, kpcb = sys.argv[1], sys.argv[2]
t = ET.parse(brd).getroot()
pk = {p.get("name"): p for p in t.iter("package")}
b = pcbnew.LoadBoard(kpcb)
kp = {}
for fp in b.GetFootprints():
    for p in fp.Pads():
        kp.setdefault(fp.GetReference(), []).append((round(pcbnew.ToMM(p.GetPosition().x) - 100, 3), round(100 - pcbnew.ToMM(p.GetPosition().y), 3), p.GetNetname()))
netof = {}
for s in t.iter("signal"):
    for c in s.iter("contactref"): netof[(c.get("element"), c.get("pad"))] = s.get("name")
bad = n = 0
for e in t.iter("element"):
    rot = e.get("rot", "R0"); mir = rot.startswith("M"); a = math.radians(float(rot.lstrip("MR")))
    ex, ey = float(e.get("x")), float(e.get("y"))
    for s in list(pk[e.get("package")].iter("smd")) + list(pk[e.get("package")].iter("pad")):
        lx, ly = float(s.get("x")), float(s.get("y"))
        gx, gy = lx * math.cos(a) - ly * math.sin(a), lx * math.sin(a) + ly * math.cos(a)
        if mir: gx = -gx
        gx, gy = round(ex + gx, 3), round(ey + gy, 3)
        n += 1
        net = netof.get((e.get("name"), s.get("name")), "")
        if not any(abs(gx - x) < 0.01 and abs(gy - y) < 0.01 and (net == nn) for (x, y, nn) in kp[e.get("name")]):
            bad += 1
            if bad < 10: print("MISMATCH", e.get("name"), s.get("name"), gx, gy, net)
print(f"pads checked {n}, mismatches {bad}")
