/*
 * app_api.c — helpers for the phone app, in the same WebAssembly module as the simulator:
 * settings blob <-> fields, and UDDF export of downloaded logs. Same C code as the firmware.
 */
#include <string.h>

#include "divecore/divelog.h"
#include "divecore/gear.h"
#include "divecore/plan.h"
#include "divecore/settings.h"

#define EXPORT __attribute__((visibility("default")))

static dc_settings_t A;
static uint8_t blob[DC_SETTINGS_BLOB_SIZE];
#define APP_LOGS (1024 * 1024)
static uint8_t app_logs[APP_LOGS];
static int app_lens[64];
static char xml[4 * 1024 * 1024];

int sim_field_get(const dc_settings_t *s, int code, int i);
void sim_field_set(dc_settings_t *s, int code, int i, int v);

EXPORT uint8_t *app_blob(void) { return blob; }
EXPORT int app_st_load(int len) { return settings_deserialize(blob, len, &A) ? 1 : 0; }
EXPORT int app_st_save(void) { settings_validate(&A); return settings_serialize(&A, blob, sizeof(blob)); }
EXPORT int app_st_get(int code, int i) { return sim_field_get(&A, code, i); }
EXPORT void app_st_set(int code, int i, int v) { sim_field_set(&A, code, i, v); }

/* ---- gear list <-> fields. Fields: 0 type, 1 flags, 2 size x10, 3 working pressure, 4 transmitter ---- */
static dc_gear_t AG;
static uint8_t gblob[GEAR_BLOB_MAX];
static char gname[GEAR_NAME + 1];
EXPORT uint8_t *app_gear_blob(void) { return gblob; }
EXPORT char *app_gear_namebuf(void) { return gname; }
EXPORT int app_gear_load(int len) { return gear_deserialize(gblob, len, &AG) ? AG.n : -1; }
EXPORT void app_gear_clear(void) { gear_init(&AG); }
EXPORT int app_gear_max(void) { return GEAR_MAX; }
EXPORT int app_gear_n(void) { return AG.n; }
EXPORT double app_gear_get(int i, int f)
{
    if (i < 0 || i >= GEAR_MAX) return 0;
    const gear_item_t *it = &AG.item[i];
    switch (f) {
    case 0: return it->type;
    case 1: return it->flags;
    case 2: return it->size_x10;
    case 3: return it->work_bar;
    default: return it->tx_serial;
    }
}
EXPORT const char *app_gear_name(int i) { return (i >= 0 && i < GEAR_MAX) ? AG.item[i].name : ""; }
/* Appends an item; the name is taken from app_gear_namebuf(). Returns its index or -1. */
EXPORT int app_gear_add(int type, int flags, int size_x10, int work_bar, double tx)
{
    if (AG.n >= GEAR_MAX) return -1;
    gear_item_t *it = &AG.item[AG.n];
    memset(it, 0, sizeof(*it));
    it->type = (uint8_t)type;
    it->flags = (uint8_t)flags;
    it->size_x10 = (uint16_t)size_x10;
    it->work_bar = (uint16_t)work_bar;
    it->tx_serial = (uint32_t)tx;
    gname[GEAR_NAME] = 0;
    strncpy(it->name, gname, GEAR_NAME);
    return AG.n++;
}
EXPORT int app_gear_cyl(int gas) { return (gas >= 0 && gas < DC_MAX_GASES) ? AG.gas_cyl[gas] : 0; }
EXPORT void app_gear_set_cyl(int gas, int item_plus_1) { if (gas >= 0 && gas < DC_MAX_GASES) AG.gas_cyl[gas] = (uint8_t)item_plus_1; }
EXPORT int app_gear_save(double synced_unix)
{
    AG.synced_unix = (uint32_t)synced_unix;
    gear_validate(&AG);
    return gear_serialize(&AG, gblob, sizeof(gblob));
}
EXPORT double app_gear_synced(void) { return AG.synced_unix; }
/* Gear stored with downloaded log i: number of items, or 0. */
EXPORT int app_log_gear(int i)
{
    int off = 0;
    for (int k = 0; k < i; k++) off += app_lens[k];
    return divelog_gear(app_logs + off, app_lens[i], &AG) ? AG.n : 0;
}

EXPORT uint8_t *app_log_buf(void) { return app_logs; }
EXPORT int app_log_buf_size(void) { return APP_LOGS; }
EXPORT int *app_log_lens(void) { return app_lens; }
EXPORT char *app_xml(void) { return xml; }
/* n logs packed back to back in app_log_buf with their lengths in app_log_lens. */
EXPORT int app_uddf(int n)
{
    const uint8_t *ptrs[64];
    int off = 0;
    if (n > 64) n = 64;
    for (int i = 0; i < n; i++) {
        ptrs[i] = app_logs + off;
        off += app_lens[i];
    }
    int r = divelog_uddf(ptrs, app_lens, n, xml, (int)sizeof(xml) - 1);
    if (r >= 0) xml[r] = 0;
    return r;
}
/* Summary of one downloaded log for the app's list: 0 dive no, 1 start unix, 2 duration s,
 * 3 max depth cm, 4 samples, 5 had deco, 6 valid. */
EXPORT double app_log_info(int i, int field)
{
    int off = 0;
    for (int k = 0; k < i; k++) off += app_lens[k];
    divelog_header_t h;
    int ok = divelog_parse(app_logs + off, app_lens[i], &h);
    if (field == 6) return ok;
    if (!ok) return 0;
    switch (field) {
    case 0: return h.dive_no;
    case 1: return h.start_unix;
    case 2: return h.duration_s;
    case 3: return h.max_depth_cm;
    case 4: return h.n_samples;
    default: return h.had_deco;
    }
}

/* ---- dive planner: the plan is worked out with the settings loaded by app_st_load()/app_st_set() ---- */
static dc_divplan_t AP;
static uint8_t pblob[DIVPLAN_BLOB];
EXPORT uint8_t *app_plan_blob(void) { return pblob; }
EXPORT int app_plan_compute(int depth_m, int bottom_min, int sac)
{
    settings_validate(&A);
    return divplan_compute(&AP, depth_m, bottom_min, sac, &A, NULL) ? 1 : 0;
}
EXPORT int app_plan_load(int len) { return divplan_deserialize(pblob, len, &AP) ? 1 : 0; }
EXPORT int app_plan_save(double created_unix)
{
    AP.created_unix = (uint32_t)created_unix;
    return divplan_serialize(&AP, pblob, sizeof(pblob));
}
/* 0 valid, 1 depth, 2 bottom, 3 run time, 4 TTS, 5 stops, 6 gas ok mask, 7 SAC, 8 GF low, 9 GF high */
EXPORT int app_plan_get(int f)
{
    switch (f) {
    case 0: return AP.valid;
    case 1: return AP.depth_m;
    case 2: return AP.bottom_min;
    case 3: return AP.runtime_min;
    case 4: return AP.tts_min;
    case 5: return AP.n_stops;
    case 6: return AP.gas_ok;
    case 7: return AP.sac_l_min;
    case 8: return AP.gf_low;
    default: return AP.gf_high;
    }
}
EXPORT int app_plan_stop(int i, int minutes) { return (i < 0 || i >= AP.n_stops) ? 0 : (minutes ? AP.stop[i].minutes : AP.stop[i].depth_m); }
EXPORT int app_plan_gas(int i) { return (i < 0 || i >= DC_MAX_GASES) ? 0 : AP.gas_bar[i]; }
