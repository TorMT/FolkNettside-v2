import fs from 'fs';
const { instance } = await WebAssembly.instantiate(fs.readFileSync(new URL('./build/divecore.wasm', import.meta.url)));
const x = instance.exports; x._initialize();
x.sim_reset(0.5, 0.8, 0); x.sim_set_gas(0, 0.21, 0, 1); x.sim_set_gas(1, 0.50, 0, 1);
let depth = 0, t = 0, tank = 220;
const out = k => x.sim_out(k);
for (; t < 40 * 60; t++) {               // 2 min descent to 40 m, then 38 min at depth? use 25 min bottom
  if (t < 120) depth = t / 3; else if (t < 25 * 60) depth = 40;
  else depth = Math.max(out(24) || 0, depth - 9 / 60);  // ascend to first stop
  x.sim_step(1, depth, 10, 45, 15);
  if (t % 5 === 0) { tank -= 5 * 1.4 * (1 + depth / 10) * 15 / 60 / 12; x.sim_tank_packet(0, tank, 0.3); }
}
console.log({state: out(0), depth: out(1).toFixed(1), indeco: out(7), ndl: out(6), tts: out(9), stops: out(10),
  firstStop: out(24), ceiling: out(8).toFixed(1), cns: out(14).toFixed(1), tank: out(17).toFixed(0), sac: out(18).toFixed(1),
  txok: out(30), txbad: out(31), alarms: out(20)});
let s=[]; for (let i=0;i<out(10);i++) s.push(`${x.sim_stop(i,0)}m ${x.sim_stop(i,1)}min gas${x.sim_stop(i,2)}`); console.log(s.join(', '));
