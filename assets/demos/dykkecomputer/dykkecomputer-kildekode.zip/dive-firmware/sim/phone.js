/*
 * phone.js — the phone app: protocol client, Bluetooth and simulator transports, and the UI.
 * Used by app/index.html (real Bluetooth) and by the simulator page (simulated link).
 * Settings parsing and UDDF export run in the WebAssembly build of the firmware core (`X`).
 */
const DCP = { INFO: 1, GET_SETTINGS: 2, SET_SETTINGS: 3, LIST_LOGS: 4, READ_LOG: 5, LOG_SIZE: 6, LIVE: 7, GET_GEAR: 8, SET_GEAR: 9, TANKS: 0x0A, PREDIVE: 0x0B, SET_PLAN: 0x0C, GET_PLAN: 0x0D, OTA_BEGIN: 0x10, OTA_DATA: 0x11, OTA_END: 0x12, SET_TIME: 0x0E };
const DCP_STATUS = ['OK', 'Bad request', 'Not while diving', 'Not found', 'Checksum error', 'Failed'];
const DC_SVC = '6e400001-d1c0-4c2a-9b1e-7d1f0dc00001';
const DC_RX = '6e400002-d1c0-4c2a-9b1e-7d1f0dc00001';
const DC_TX = '6e400003-d1c0-4c2a-9b1e-7d1f0dc00001';
const DC_STATES = ['Sleeping', 'On the surface', 'Diving', 'Surface interval', 'Charging'];

class DcpError extends Error {}
class DcpOffline extends DcpError {}

class DcpClient {
  constructor(transport) { this.t = transport; this.seq = 0; this.busy = Promise.resolve(); }
  req(cmd, payload = new Uint8Array(0)) {
    const run = async () => {
      this.seq = (this.seq + 1) & 255;
      const r = new Uint8Array(4 + payload.length);
      r[0] = cmd; r[1] = this.seq; r[2] = payload.length & 255; r[3] = payload.length >> 8; r.set(payload, 4);
      const resp = await this.t.send(r);
      if (resp.length < 5 || resp[0] !== (cmd | 0x80) || resp[1] !== this.seq) throw new DcpError('The dive computer sent an unexpected reply.');
      const len = resp[3] | (resp[4] << 8);
      return { status: resp[2], data: resp.slice(5, 5 + len) };
    };
    const p = this.busy.then(run, run);       // one request at a time
    this.busy = p.catch(() => {});
    return p;
  }
  async ok(cmd, payload) {
    const r = await this.req(cmd, payload);
    if (r.status !== 0) throw new DcpError(DCP_STATUS[r.status] || `Error ${r.status}`);
    return r.data;
  }
  async tanks() {
    const d = await this.ok(DCP.TANKS), v = new DataView(d.buffer, d.byteOffset), out = [];
    for (let i = 0; i + 12 <= d.length; i += 12) {
      const dbar = v.getUint16(i + 6, true);
      out.push({ present: d[i] === 1, battery: d[i + 1], serial: v.getUint32(i + 2, true), bar: dbar === 0xFFFF ? null : dbar / 10,
        age: v.getUint16(i + 8, true), gasOn: d[i + 10] === 1 });
    }
    return out;
  }
  async info() {
    const d = await this.ok(DCP.INFO);
    return { proto: d[0], state: d[1], battery: d[2], logs: d[3] | (d[4] << 8), fw: new TextDecoder().decode(d.slice(5)) };
  }
  async live() {
    const d = await this.ok(DCP.LIVE), v = new DataView(d.buffer, d.byteOffset);
    const tank = v.getUint16(7, true);
    return { state: d[0], depth: v.getUint16(1, true) / 100, ndl: d[3], tts: v.getUint16(4, true), gas: d[6],
      tank: tank === 0xFFFF ? null : tank / 10, cns: d[9], alarms: v.getUint16(10, true), deco: d[12] === 1 };
  }
  getSettings() { return this.ok(DCP.GET_SETTINGS); }
  async predive() {
    const d = await this.ok(DCP.PREDIVE), dec = new TextDecoder(), str = (o, n) => { let e = o; while (e < o + n && d[e]) e++; return dec.decode(d.slice(o, e)); };
    const items = [];
    for (let i = 0; i < d[0]; i++) { const o = 2 + i * 49; items.push({ level: d[o], label: str(o + 1, 20), detail: str(o + 21, 28) }); }
    return { worst: d[1], items };
  }
  getPlan() { return this.ok(DCP.GET_PLAN); }
  setPlan(blob) { return this.ok(DCP.SET_PLAN, blob); }
  getGear() { return this.ok(DCP.GET_GEAR); }
  setGear(blob) { return this.ok(DCP.SET_GEAR, blob); }
  setSettings(blob) { return this.ok(DCP.SET_SETTINGS, blob); }
  async listLogs() {
    const d = await this.ok(DCP.LIST_LOGS), v = new DataView(d.buffer, d.byteOffset), out = [];
    for (let o = 0; o + 16 <= d.length; o += 16)
      out.push({ idx: v.getUint16(o, true), no: v.getUint16(o + 2, true), start: v.getUint32(o + 4, true),
        duration: v.getUint32(o + 8, true), maxDepth: v.getUint16(o + 12, true) / 100, deco: d[o + 14] === 1 });
    return out;
  }
  async readLog(idx, onProgress) {
    const sz = await this.ok(DCP.LOG_SIZE, new Uint8Array([idx & 255, idx >> 8]));
    const size = new DataView(sz.buffer, sz.byteOffset).getUint32(0, true);
    const out = new Uint8Array(size);
    let off = 0;
    while (off < size) {
      const want = Math.min(512, size - off);
      const p = new Uint8Array(8), v = new DataView(p.buffer);
      v.setUint16(0, idx, true); v.setUint32(2, off, true); v.setUint16(6, want, true);
      const d = await this.ok(DCP.READ_LOG, p);
      if (!d.length) break;
      out.set(d, off); off += d.length;
      if (onProgress) onProgress(off / size);
    }
    return out.slice(0, off);
  }
  async updateFirmware(bytes, onProgress) {
    const u32 = n => { const b = new Uint8Array(4); new DataView(b.buffer).setUint32(0, n >>> 0, true); return b; };
    await this.ok(DCP.OTA_BEGIN, u32(bytes.length));
    const chunk = 480;
    for (let off = 0; off < bytes.length; off += chunk) {
      const part = bytes.slice(off, off + chunk), p = new Uint8Array(4 + part.length);
      p.set(u32(off), 0); p.set(part, 4);
      await this.ok(DCP.OTA_DATA, p);
      if (onProgress) onProgress(Math.min(1, (off + part.length) / bytes.length));
    }
    await this.ok(DCP.OTA_END, u32(crc32(bytes)));
  }
}

function crc32(b) {
  let c = 0xFFFFFFFF;
  for (let i = 0; i < b.length; i++) { c ^= b[i]; for (let k = 0; k < 8; k++) c = (c >>> 1) ^ (0xEDB88320 & -(c & 1)); }
  return (~c) >>> 0;
}

/* Simulated Bluetooth: requests go straight into the firmware's proto_handle() in WebAssembly. */
class SimTransport {
  constructor(X) { this.X = X; this.connected = true; }
  async send(bytes) {
    const X = this.X, mem = () => new Uint8Array(X.memory.buffer);
    if (!X.sim_ble_allowed()) throw new DcpOffline('Lost the dive computer: its Bluetooth is off, or a dive has started (Bluetooth only works on the surface).');
    mem().set(bytes, X.sim_io_req());
    const n = X.sim_proto(bytes.length);
    await new Promise(r => setTimeout(r, 4));   // a little link latency
    return mem().slice(X.sim_io_resp(), X.sim_io_resp() + n);
  }
}

/* Real Bluetooth LE through Web Bluetooth (Chrome on Android, Windows, macOS; not iOS Safari). */
class BleTransport {
  static available() { return typeof navigator !== 'undefined' && !!navigator.bluetooth; }
  async connect(onDisconnect) {
    this.device = await navigator.bluetooth.requestDevice({ filters: [{ services: [DC_SVC] }] });
    this.device.addEventListener('gattserverdisconnected', () => { this.connected = false; if (onDisconnect) onDisconnect(); });
    const server = await this.device.gatt.connect();
    const svc = await server.getPrimaryService(DC_SVC);
    this.rx = await svc.getCharacteristic(DC_RX);
    this.tx = await svc.getCharacteristic(DC_TX);
    this.buf = new Uint8Array(0);
    this.tx.addEventListener('characteristicvaluechanged', e => {
      const v = new Uint8Array(e.target.value.buffer), n = new Uint8Array(this.buf.length + v.length);
      n.set(this.buf); n.set(v, this.buf.length); this.buf = n;
      if (this.buf.length >= 5 && this.buf.length >= 5 + (this.buf[3] | (this.buf[4] << 8)) && this.done) this.done();
    });
    await this.tx.startNotifications();
    this.connected = true;
    return this.device.name || 'Dive computer';
  }
  disconnect() { if (this.device && this.device.gatt.connected) this.device.gatt.disconnect(); }
  async send(bytes) {
    this.buf = new Uint8Array(0);
    const reply = new Promise((resolve, reject) => {
      const timer = setTimeout(() => reject(new DcpOffline('No answer from the dive computer.')), 5000);
      this.done = () => { clearTimeout(timer); this.done = null; resolve(this.buf); };
    });
    for (let off = 0; off < bytes.length; off += 180) await this.rx.writeValueWithResponse(bytes.slice(off, off + 180));
    return reply;
  }
}

/* Settings blob <-> plain object, using the firmware's own settings code in WebAssembly. */
const SETTING_FIELDS = { gfLow: 10, gfHigh: 11, water: 12, lastStop: 13, ppo2Bottom: 14, ppo2Deco: 15, reserve: 16,
  ascentAlarm: 17, brightness: 18, pairing: 19, declination: 20, safetyStop: 21, bluetooth: 22, depthAlarm: 23,
  timeAlarm: 24, ndlWarn: 25, turnMargin: 26, flip: 27, logInterval: 28 };
function settingsFromBlob(X, blob) {
  new Uint8Array(X.memory.buffer).set(blob, X.app_blob());
  if (!X.app_st_load(blob.length)) throw new DcpError('Settings from the dive computer failed their checksum.');
  const s = { gases: [] };
  for (let i = 0; i < 5; i++)
    s.gases.push({ o2: X.app_st_get(0, i), he: X.app_st_get(1, i), on: X.app_st_get(2, i), cyl: X.app_st_get(3, i), fill: X.app_st_get(4, i), serial: X.app_st_get(5, i) >>> 0 });
  for (const [k, code] of Object.entries(SETTING_FIELDS)) s[k] = X.app_st_get(code, 0);
  return s;
}
function settingsToBlob(X, s) {
  s.gases.forEach((g, i) => { X.app_st_set(0, i, g.o2); X.app_st_set(1, i, g.he); X.app_st_set(2, i, g.on); X.app_st_set(3, i, g.cyl); X.app_st_set(4, i, g.fill); X.app_st_set(5, i, g.serial); });
  for (const [k, code] of Object.entries(SETTING_FIELDS)) X.app_st_set(code, 0, s[k]);
  const n = X.app_st_save();
  return new Uint8Array(X.memory.buffer).slice(X.app_blob(), X.app_blob() + n);
}
/* Gear list blob <-> plain object, using the firmware's gear code in WebAssembly.
 * { items: [{ type, onDive, size, work, serial, name }], gasCyl: [item index or -1 per gas], synced } */
const GEAR_TYPES = ['', 'Cylinder', 'Regulator', 'BCD', 'Suit', 'Weights', 'Light', 'Camera', 'Other'];
const GEAR_SIZE = { 1: ['L', 0.5, 30], 4: ['mm', 0.5, 10], 5: ['kg', 0.5, 30] };   /* types with a size: unit, step, max */
function gearFromBlob(X, blob) {
  new Uint8Array(X.memory.buffer).set(blob, X.app_gear_blob());
  const n = X.app_gear_load(blob.length);
  if (n < 0) throw new DcpError('The gear list from the dive computer failed its checksum.');
  return gearRead(X);
}
function gearRead(X) {
  const g = { items: [], gasCyl: [], synced: X.app_gear_synced() };
  for (let i = 0; i < X.app_gear_n(); i++) {
    const p = X.app_gear_name(i), m = new Uint8Array(X.memory.buffer); let e = p; while (m[e]) e++;
    g.items.push({ type: X.app_gear_get(i, 0), onDive: (X.app_gear_get(i, 1) & 1) === 1, size: X.app_gear_get(i, 2) / 10,
      work: X.app_gear_get(i, 3), serial: X.app_gear_get(i, 4), name: new TextDecoder().decode(m.subarray(p, e)) });
  }
  for (let k = 0; k < 5; k++) g.gasCyl.push(X.app_gear_cyl(k) - 1);
  return g;
}
function gearToBlob(X, g) {
  X.app_gear_clear();
  const enc = new TextEncoder();
  g.items.slice(0, X.app_gear_max()).forEach(it => {
    const buf = new Uint8Array(X.memory.buffer, X.app_gear_namebuf(), 17); buf.fill(0);
    buf.set(enc.encode(it.name.replace(/[^\x20-\x7e]/g, '?')).slice(0, 16));
    X.app_gear_add(it.type, it.onDive ? 1 : 0, Math.round((it.size || 0) * 10), it.type === 1 ? it.work : 0, it.type === 1 ? it.serial >>> 0 : 0);
  });
  g.gasCyl.forEach((c, k) => X.app_gear_set_cyl(k, c >= 0 ? c + 1 : 0));
  const n = X.app_gear_save(Math.floor(Date.now() / 1000));
  return new Uint8Array(X.memory.buffer).slice(X.app_gear_blob(), X.app_gear_blob() + n);
}
const GEAR_KEY = 'dc-gear-library';
function gearLibraryLoad() { try { const s = localStorage.getItem(GEAR_KEY); return s ? JSON.parse(s) : null; } catch (e) { return null; } }
function gearLibrarySave(g) { try { localStorage.setItem(GEAR_KEY, JSON.stringify(g)); } catch (e) { /* storage unavailable: the computer still has it */ } }

function logsToUddf(X, logs) {
  const mem = new Uint8Array(X.memory.buffer), lens = new Int32Array(X.memory.buffer, X.app_log_lens(), 64);
  let off = 0;
  logs.forEach((l, i) => { mem.set(l, X.app_log_buf() + off); lens[i] = l.length; off += l.length; });
  const n = X.app_uddf(logs.length);
  if (n === -1) throw new DcpError('A downloaded log failed its checksum.');
  if (n < 0) throw new DcpError('Too much data for one export; export fewer dives.');
  return new TextDecoder().decode(new Uint8Array(X.memory.buffer, X.app_xml(), n));
}

/* Dive log bytes -> plain object (layout in divelog.h). Used for the share card. */
function parseDiveLog(X, b) {
  const v = new DataView(b.buffer, b.byteOffset, b.byteLength);
  if (b.length < 68 || b[0] !== 68 || b[1] !== 76 || b[2] !== 71) throw new DcpError('Not a dive log.');
  if (b[3] !== 2) throw new DcpError('This dive log is from a different firmware version. Update the app.');
  const SZ = 24, i24 = o => { const x = b[o] | b[o + 1] << 8 | b[o + 2] << 16; return x & 0x800000 ? x - 0x1000000 : x; };
  const h = { no: v.getUint16(4, true), start: v.getUint32(6, true), duration: v.getUint32(10, true), maxDepth: v.getUint16(14, true) / 100,
    minTemp: v.getInt16(16, true) / 10, interval: b[20] || 2, gfLow: b[21], gfHigh: b[22], n: v.getUint32(44, true), deco: b[48] === 1,
    cns: b[49], battStart: b[50], battEnd: b[51], gases: [],
    pos: b[59] ? { lat: i24(53) / 1e4, lon: i24(56) / 1e4 } : null };
  for (let i = 0; i < 5; i++) h.gases.push({ o2: b[24 + i], he: b[29 + i], on: b[34 + i] === 1, cyl: b[39 + i] });
  h.samples = [];
  for (let j = 0; j < h.n && 64 + (j + 1) * SZ <= b.length; j++) {
    const o = 64 + j * SZ, tanks = [];
    for (let k = 0; k < 5; k++) { const t = v.getUint16(o + 10 + 2 * k, true); tanks.push(t === 0xFFFF ? null : t / 10); }
    h.samples.push({ t: j * h.interval, depth: v.getUint16(o, true) / 100, temp: v.getInt16(o + 2, true) / 10, ceil: v.getUint16(o + 4, true) / 100, gas: b[o + 8], tanks,
      x: v.getInt16(o + 20, true) / 10, y: v.getInt16(o + 22, true) / 10 });
  }
  const base = 64 + h.n * SZ + 4;
  h.gear = [];
  if (b.length > base) { try { h.gear = gearFromBlob(X, b.slice(base)).items; } catch (e) { /* no gear block */ } }
  // derived numbers
  const s = h.samples, dt = h.interval;
  let sumD = 0, decoS = 0;
  s.forEach(x => { sumD += x.depth; if (x.ceil > 0) decoS += dt; });
  h.avgDepth = s.length ? sumD / s.length : 0;
  // time spent stopped on the way up (deco and safety stops): after leaving the bottom, samples that hardly move
  let leave = 0; s.forEach((x, j) => { if (x.depth >= 0.9 * h.maxDepth) leave = j; });
  let stopS = 0;
  for (let j = leave + 1; j < s.length; j++) if (s[j].depth > 1 && Math.abs(s[j].depth - s[j - 1].depth) < 0.15) stopS += dt;
  h.decoMin = Math.round(decoS / 60);
  h.stopMin = Math.round(stopS / 60);
  h.used = h.gases.map((g, k) => {
    const p = s.map(x => x.tanks[k]).filter(x => x !== null);
    return p.length ? { start: p[0], end: p[p.length - 1], bar: p[0] - p[p.length - 1] } : null;
  });
  // SAC on gas 1 while it was breathed: litres used / (ambient bar x minutes)
  let barMin = 0;
  s.forEach(x => { if (x.gas === 0) barMin += (1.013 + x.depth / 10) * dt / 60; });
  h.sac = h.used[0] && barMin > 0 ? h.gases[0].cyl * h.used[0].bar / barMin : null;
  h.switches = [];
  s.forEach((x, j) => { if (j && x.gas !== s[j - 1].gas) h.switches.push({ t: x.t, depth: x.depth, gas: x.gas }); });
  return h;
}

/* ---------- dive archive on the phone: one summary per dive, kept after the computer's card is wiped ---------- */
const ARCHIVE_KEY = 'dc-dive-archive', LASTPOS_KEY = 'dc-last-position';
function archiveLoad() { try { return JSON.parse(localStorage.getItem(ARCHIVE_KEY) || '[]'); } catch (e) { return []; } }
function archiveSave(a) { try { localStorage.setItem(ARCHIVE_KEY, JSON.stringify(a)); } catch (e) { /* storage unavailable: the archive lasts for this visit */ } }
function lastPosLoad() { try { return JSON.parse(localStorage.getItem(LASTPOS_KEY) || 'null'); } catch (e) { return null; } }
function lastPosSave(p) { try { localStorage.setItem(LASTPOS_KEY, JSON.stringify(p)); } catch (e) { /* ignore */ } }
/* Summary of a parsed log. pos: the computer's own fix, else the phone's (right after the dive, or from the pre-dive sync). */
function summarizeDive(h, phonePos) {
  const step = Math.max(1, Math.ceil(h.samples.length / 150)), track = [];
  h.samples.forEach((s, j) => { if (j % step === 0) track.push([Math.round(s.x), Math.round(s.y)]); });
  const used = h.used.reduce((a, u) => a + (u ? u.bar : 0), 0);
  return { key: h.start, no: h.no, start: h.start, duration: h.duration, maxDepth: h.maxDepth, avgDepth: +h.avgDepth.toFixed(1), minTemp: h.minTemp,
    sac: h.sac ? +h.sac.toFixed(1) : null, deco: h.deco, used: Math.round(used), battUsed: h.battStart !== 255 && h.battEnd !== 255 ? h.battStart - h.battEnd : null,
    pos: h.pos || phonePos || null, posFrom: h.pos ? 'computer' : phonePos ? 'phone' : null, track, site: '' };
}
function diveStats(a) {
  if (!a.length) return null;
  const by = (f, pick = Math.max) => a.reduce((b, d) => (b === null || pick(f(d), f(b)) === f(d) ? d : b), null);
  const months = [], now = new Date();
  for (let k = 11; k >= 0; k--) { const m = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() - k, 1)); months.push({ y: m.getUTCFullYear(), m: m.getUTCMonth(), n: 0, min: 0 }); }
  a.forEach(d => { const t = new Date(d.start * 1000), e = months.find(x => x.y === t.getUTCFullYear() && x.m === t.getUTCMonth()); if (e) { e.n++; e.min += d.duration / 60; } });
  const withSac = a.filter(d => d.sac), sites = new Set(a.filter(d => d.site).map(d => d.site));
  return { count: a.length, totalS: a.reduce((s, d) => s + d.duration, 0), deepest: by(d => d.maxDepth), longest: by(d => d.duration),
    coldest: by(d => d.minTemp, Math.min), bestSac: withSac.length ? withSac.reduce((b, d) => (d.sac < b.sac ? d : b)) : null,
    decoDives: a.filter(d => d.deco).length, sites: sites.size, months, busiest: months.reduce((b, m) => (m.n > b.n ? m : b), months[0]) };
}

/* ---------- maps: OpenStreetMap tiles when the page may load them, a plain chart otherwise ---------- */
const MAP_TILE = (z, x, y) => `https://tile.openstreetmap.org/${z}/${x}/${y}.png`;
const mercX = (lon, z) => (lon + 180) / 360 * 256 * 2 ** z;
const mercY = (lat, z) => { const r = lat * Math.PI / 180; return (1 - Math.log(Math.tan(r) + 1 / Math.cos(r)) / Math.PI) / 2 * 256 * 2 ** z; };
function trackLatLon(pos, track) { const k = 111320; return track.map(([x, y]) => ({ lat: pos.lat + y / k, lon: pos.lon + x / (k * Math.cos(pos.lat * Math.PI / 180)) })); }
function loadTile(url) {
  return new Promise((res, rej) => { const im = new Image(); im.crossOrigin = 'anonymous'; const t = setTimeout(() => rej(new Error('timeout')), 4000);
    im.onload = () => { clearTimeout(t); res(im); }; im.onerror = () => { clearTimeout(t); rej(new Error('tile')); }; im.src = url; });
}
/*
 * Draws into (x, y, w, h). lines: [[{lat,lon}...]], pins: [{lat, lon, label, n}]. Returns true when map tiles were drawn.
 * scale: a multiplier for line widths and text (the share card is drawn at 1080 px).
 */
async function drawMap(c, x, y, w, h, lines, pins, opts = {}) {
  const pts = [].concat(...lines, pins), k = opts.scale || 1;
  if (!pts.length) return false;
  let z = 18;
  const span = zz => { const xs = pts.map(p => mercX(p.lon, zz)), ys = pts.map(p => mercY(p.lat, zz)); return { x0: Math.min(...xs), x1: Math.max(...xs), y0: Math.min(...ys), y1: Math.max(...ys) }; };
  while (z > 2) { const s = span(z); if (s.x1 - s.x0 <= (w - 90 * k) / k && s.y1 - s.y0 <= (h - 70 * k) / k) break; z--; }
  if (pts.length === 1 || (opts.maxZoom && z > opts.maxZoom)) z = Math.min(z, opts.maxZoom || 15);
  const s = span(z), cx = (s.x0 + s.x1) / 2, cy = (s.y0 + s.y1) / 2;
  const PX = lon => x + w / 2 + (mercX(lon, z) - cx) * k, PY = lat => y + h / 2 + (mercY(lat, z) - cy) * k;
  c.save(); c.beginPath(); c.rect(x, y, w, h); c.clip();
  let tiled = false;
  if (opts.tiles) {
    try {
      const tx0 = Math.floor((cx - w / 2 / k) / 256), tx1 = Math.floor((cx + w / 2 / k) / 256), ty0 = Math.floor((cy - h / 2 / k) / 256), ty1 = Math.floor((cy + h / 2 / k) / 256), jobs = [];
      for (let tx = tx0; tx <= tx1; tx++) for (let ty = ty0; ty <= ty1; ty++) jobs.push(loadTile(MAP_TILE(z, tx, ty)).then(im => ({ im, tx, ty })));
      const tiles = await Promise.all(jobs);
      tiles.forEach(t => c.drawImage(t.im, x + w / 2 + (t.tx * 256 - cx) * k, y + h / 2 + (t.ty * 256 - cy) * k, 256 * k, 256 * k));
      c.fillStyle = 'rgba(6,25,42,.25)'; c.fillRect(x, y, w, h);
      tiled = true;
    } catch (e) { tiled = false; }
  }
  const lat0 = pts[0].lat, mPerPx = 156543.03 * Math.cos(lat0 * Math.PI / 180) / 2 ** z / k;
  if (!tiled) {
    c.fillStyle = '#0A2233'; c.fillRect(x, y, w, h);
    const nice = [5, 10, 20, 50, 100, 200, 500, 1000, 2000, 5000, 10000, 50000, 100000, 500000], grid = nice.find(n => n / mPerPx >= 60 * k) || 1000000, g = grid / mPerPx;
    c.strokeStyle = 'rgba(143,166,182,.16)'; c.lineWidth = k;
    for (let gx = x + (w / 2) % g; gx < x + w; gx += g) { c.beginPath(); c.moveTo(gx, y); c.lineTo(gx, y + h); c.stroke(); }
    for (let gy = y + (h / 2) % g; gy < y + h; gy += g) { c.beginPath(); c.moveTo(x, gy); c.lineTo(x + w, gy); c.stroke(); }
  }
  lines.forEach(l => {
    if (l.length < 2) return;
    c.beginPath(); l.forEach((p, j) => (j ? c.lineTo(PX(p.lon), PY(p.lat)) : c.moveTo(PX(p.lon), PY(p.lat))));
    c.strokeStyle = tiled ? '#06192A' : 'rgba(6,25,42,.9)'; c.lineWidth = 9 * k; c.lineJoin = 'round'; c.lineCap = 'round'; c.stroke();
    c.strokeStyle = '#FF7A45'; c.lineWidth = 5 * k; c.stroke();
    const e = l[l.length - 1]; c.fillStyle = '#F2F6F8'; c.beginPath(); c.arc(PX(e.lon), PY(e.lat), 6 * k, 0, 7); c.fill();
  });
  c.font = `600 ${13 * k}px "Inter", system-ui, sans-serif`; c.textAlign = 'left';
  pins.forEach(p => {
    const px = PX(p.lon), py = PY(p.lat);
    c.fillStyle = '#5FD0C4'; c.strokeStyle = '#06192A'; c.lineWidth = 2 * k; c.beginPath(); c.arc(px, py, (p.n > 1 ? 10 : 8) * k, 0, 7); c.fill(); c.stroke();
    if (p.n > 1) { c.fillStyle = '#06192A'; c.textAlign = 'center'; c.fillText(String(p.n), px, py + 4.5 * k); c.textAlign = 'left'; }
    if (p.label) { c.fillStyle = '#F2F6F8'; c.strokeStyle = 'rgba(6,25,42,.85)'; c.lineWidth = 4 * k; c.strokeText(p.label, px + 14 * k, py + 5 * k); c.fillText(p.label, px + 14 * k, py + 5 * k); }
  });
  // scale bar
  const want = 110 * k * mPerPx, bar = [5, 10, 20, 50, 100, 200, 500, 1000, 2000, 5000, 10000, 20000, 50000, 100000, 500000].reduce((b, n) => (n <= want ? n : b), 5), bw = bar / mPerPx;
  c.fillStyle = '#F2F6F8'; c.fillRect(x + 16 * k, y + h - 18 * k, bw, 3 * k);
  c.fillText(bar >= 1000 ? `${bar / 1000} km` : `${bar} m`, x + 16 * k, y + h - 24 * k);
  if (tiled) { c.textAlign = 'right'; c.font = `500 ${11 * k}px system-ui, sans-serif`; c.fillStyle = 'rgba(242,246,248,.85)'; c.fillText('© OpenStreetMap contributors', x + w - 10 * k, y + h - 10 * k); }
  c.restore();
  return tiled;
}

/* A Strava-style picture of one dive: 1080 x 1350 (4:5, fits Instagram and most feeds). */
async function drawShareCard(canvas, h, site, opts = {}) {
  const W = 1080, H = 1350; canvas.width = W; canvas.height = H;
  const c = canvas.getContext('2d');
  const F = (w, s) => `${w} ${s}px "Space Grotesk", "Inter", system-ui, sans-serif`;
  const T = (t, x, y, s, col, w = 600, al = 'left') => { c.font = F(w, s); c.fillStyle = col; c.textAlign = al; c.fillText(t, x, y); };
  const sea = c.createLinearGradient(0, 0, 0, H);
  sea.addColorStop(0, '#0B2A3C'); sea.addColorStop(0.55, '#06192A'); sea.addColorStop(1, '#030B14');
  c.fillStyle = sea; c.fillRect(0, 0, W, H);
  // header
  const d = new Date(h.start * 1000);
  const date = d.toLocaleDateString('en-GB', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
  const time = d.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' });
  T(`DIVE #${h.no}`, 72, 110, 30, '#5FD0C4', 700);
  T(site || 'Unnamed site', 72, 182, 64, '#F2F6F8', 700);
  T(`${date} · ${time}`, 72, 232, 30, '#8FA6B6', 500);
  // stats grid
  const gasName = g => g.he ? `Tx${g.o2}/${g.he}` : g.o2 === 21 ? 'Air' : g.o2 === 100 ? 'O2' : `EAN${g.o2}`;
  const used = h.used.reduce((a, u) => a + (u ? u.bar : 0), 0);
  const stats = [
    ['Max depth', `${h.maxDepth.toFixed(1)} m`], ['Dive time', `${Math.round(h.duration / 60)} min`], ['Avg depth', `${h.avgDepth.toFixed(1)} m`],
    ['Water', `${h.minTemp.toFixed(0)} °C`], ['Gas used', used ? `${used.toFixed(0)} bar` : '—'], ['SAC', h.sac ? `${h.sac.toFixed(1)} L/min` : '—']];
  // with a position or a track there is a map strip under the profile, so everything above is a little tighter
  const moved = h.samples.some(q => Math.abs(q.x) > 3 || Math.abs(q.y) > 3), pos = opts.pos || h.pos, hasMap = !!pos || moved;
  stats.forEach(([k, val], i) => {
    const x = 72 + (i % 3) * 320, y = (hasMap ? 310 : 330) + Math.floor(i / 3) * (hasMap ? 130 : 150);
    T(k.toUpperCase(), x, y, 24, '#8FA6B6', 600);
    T(val, x, y + 64, 58, '#F2F6F8', 700);
  });
  // profile
  const px = 72, py = hasMap ? 580 : 640, pw = W - 144, ph = hasMap ? 290 : 400, s = h.samples, tMax = Math.max(60, h.duration), dMax = Math.max(10, Math.ceil(h.maxDepth / 5) * 5);
  const X_ = t => px + pw * t / tMax, Y_ = dd => py + ph * dd / dMax;
  c.strokeStyle = 'rgba(143,166,182,.25)'; c.lineWidth = 2;
  for (let dd = 0; dd <= dMax; dd += dMax > 40 ? 20 : 10) { c.beginPath(); c.moveTo(px, Y_(dd)); c.lineTo(px + pw, Y_(dd)); c.stroke(); T(`${dd} m`, px + pw, Y_(dd) - 8, 20, '#5E7687', 500, 'right'); }
  const fill = c.createLinearGradient(0, py, 0, py + ph);
  fill.addColorStop(0, 'rgba(95,208,196,.55)'); fill.addColorStop(1, 'rgba(30,110,170,.25)');
  c.beginPath(); c.moveTo(X_(0), Y_(0));
  s.forEach(x => c.lineTo(X_(x.t), Y_(x.depth)));
  c.lineTo(X_(s.length ? s[s.length - 1].t : 0), Y_(0)); c.closePath(); c.fillStyle = fill; c.fill();
  c.beginPath(); c.moveTo(X_(0), Y_(0)); s.forEach(x => c.lineTo(X_(x.t), Y_(x.depth))); c.strokeStyle = '#5FD0C4'; c.lineWidth = 5; c.stroke();
  if (s.some(x => x.ceil > 0)) {
    c.beginPath(); let pen = false;
    s.forEach(x => { if (x.ceil > 0) { if (pen) c.lineTo(X_(x.t), Y_(x.ceil)); else c.moveTo(X_(x.t), Y_(x.ceil)); pen = true; } else pen = false; });
    c.strokeStyle = '#FF6B5E'; c.lineWidth = 3; c.setLineDash([10, 8]); c.stroke(); c.setLineDash([]);
  }
  h.switches.forEach(sw => { c.fillStyle = '#FFB547'; c.beginPath(); c.arc(X_(sw.t), Y_(sw.depth), 10, 0, Math.PI * 2); c.fill(); T(gasName(h.gases[sw.gas]), X_(sw.t) + 16, Y_(sw.depth) + 8, 22, '#FFB547', 700); });
  // max depth marker
  let mi = 0; s.forEach((x, j) => { if (x.depth > s[mi].depth) mi = j; });
  if (s.length) { T(`${h.maxDepth.toFixed(1)} m`, X_(s[mi].t) + 14, Y_(s[mi].depth) - 16, 24, '#F2F6F8', 700, 'left'); }
  // tags: gases, deco, GF
  const tags = h.gases.filter(g => g.on).map(gasName);
  tags.push(h.deco ? `Deco · ${h.stopMin} min stops` : h.stopMin ? `No deco · ${h.stopMin} min safety stop` : 'No deco'); tags.push(`GF ${h.gfLow}/${h.gfHigh}`);
  const tagY = hasMap ? 900 : 1090;
  let tx = 72; c.font = F(600, 26);
  tags.forEach(t => { const w = c.measureText(t).width + 36; c.fillStyle = 'rgba(95,208,196,.14)'; c.beginPath(); c.roundRect ? c.roundRect(tx, tagY, w, 50, 25) : c.rect(tx, tagY, w, 50); c.fill(); T(t, tx + 18, tagY + 34, 26, '#BFE9E4', 600); tx += w + 14; });
  // gear
  const gear = h.gear.map(g => g.name || GEAR_TYPES[g.type]).slice(0, 5).join(' · ');
  if (gear) T(gear, 72, hasMap ? 1222 : 1200, hasMap ? 22 : 26, '#8FA6B6', 500);
  if (hasMap) {
    const at = pos || { lat: 0, lon: 0 }, line = moved ? trackLatLon(at, h.samples.filter((q, j) => j % Math.max(1, Math.ceil(h.samples.length / 300)) === 0).map(q => [q.x, q.y])) : [];
    c.save(); c.beginPath(); c.roundRect ? c.roundRect(72, 970, W - 144, 220, 18) : c.rect(72, 970, W - 144, 220); c.clip();
    await drawMap(c, 72, 970, W - 144, 220, line.length ? [line] : [], [{ lat: at.lat, lon: at.lon, label: pos ? 'Entry' : '' }], { tiles: !!pos && opts.tiles, scale: 2, maxZoom: 17 });
    c.restore();
    if (pos) T(`${Math.abs(pos.lat).toFixed(4)}° ${pos.lat >= 0 ? 'N' : 'S'}  ${Math.abs(pos.lon).toFixed(4)}° ${pos.lon >= 0 ? 'E' : 'W'}`, W - 90, 1004, 22, '#F2F6F8', 600, 'right');
    else T('Underwater track (no GPS fix)', W - 90, 1004, 22, '#F2F6F8', 600, 'right');
  }
  c.fillStyle = 'rgba(143,166,182,.25)'; c.fillRect(72, 1240, W - 144, 2);
  T('NTNU DIVE COMPUTER', 72, 1290, 24, '#5E7687', 700);
  T('Logged on my own dive computer', W - 72, 1290, 24, '#5E7687', 500, 'right');
}

const SITE_KEY = 'dc-dive-sites';
function siteLoad(no) { try { return (JSON.parse(localStorage.getItem(SITE_KEY) || '{}'))[no] || ''; } catch (e) { return ''; } }
function siteSave(no, name) { try { const m = JSON.parse(localStorage.getItem(SITE_KEY) || '{}'); m[no] = name; localStorage.setItem(SITE_KEY, JSON.stringify(m)); } catch (e) { /* storage unavailable */ } }

function gasLabel(g) { return g.he ? `Tx${g.o2}/${g.he}` : g.o2 === 21 ? 'Air' : g.o2 === 100 ? 'O2' : `EAN${g.o2}`; }
function fmtTime(s) { const m = Math.round(s / 60); return m >= 60 ? `${Math.floor(m / 60)} h ${m % 60} min` : `${m} min`; }
function fmtDate(u) { return new Date(u * 1000).toISOString().slice(0, 16).replace('T', ' ') + ' UTC'; }

/*
 * PhoneUI: renders the app into `root`.
 * opts: { X, transport (if already connected), connect: async () => transport, canDownload, title }
 */
class PhoneUI {
  constructor(root, opts) {
    this.root = root; this.o = opts; this.client = null; this.logs = []; this.downloaded = new Map();
    root.classList.add('ph');
    root.innerHTML = `
      <div class="ph-bar"><span class="ph-dot" data-r="dot"></span><span data-r="status">Not connected</span>
        <button type="button" class="ph-btn ph-primary" data-r="connect">Connect</button></div>
      <p class="ph-err" data-r="err" hidden></p>
      <div data-r="body" hidden>
        <section><h3>Dive computer</h3><dl class="ph-kv" data-r="info"></dl></section>
        <section><h3>Ready to dive?</h3><div data-r="check"></div></section>
        <section><h3>Live</h3><div class="ph-live" data-r="live"></div></section>
        <section><h3>Transmitters</h3><div data-r="tanks"></div></section>
        <section><h3>Gear</h3><p class="ph-note">Add your gear once, tick what you bring, pick the cylinder for each gas and sync before the dive. The computer shows the list under Settings → Gear check and stores it with the dive log.</p>
          <div data-r="gear"></div></section>
        <section><h3>Dive plan</h3><p class="ph-note">Worked out with the same decompression code and settings as the computer. Send it, and the computer shows planned against actual and warns when you go deeper or stay longer.</p>
          <div data-r="plan"></div></section>
        <section><h3>Settings</h3><form data-r="form" class="ph-form"></form></section>
        <section><h3>Dive logs</h3><div data-r="logs"></div>
          <div class="ph-row"><button type="button" class="ph-btn" data-r="refresh">Refresh list</button>
          <button type="button" class="ph-btn ph-primary" data-r="export">Download all and export UDDF</button></div>
          <p class="ph-note" data-r="logmsg"></p><div data-r="uddf"></div><div data-r="share" class="ph-share" hidden></div></section>
        <section><h3>Statistics</h3><div data-r="stats"></div></section>
        <section><h3>Dive sites</h3><div data-r="sites"></div></section>
        <section><h3>Firmware update</h3>
          <div class="ph-row"><input type="file" id="ph-fw" data-r="fw" aria-label="Firmware file"><button type="button" class="ph-btn" data-r="flash">Install</button></div>
          <progress data-r="prog" max="1" value="0" hidden></progress><p class="ph-note" data-r="fwmsg">Only on the surface. The computer checks the image and reboots into it; if it fails to start it rolls back.</p></section>
      </div>`;
    this.r = {};
    root.querySelectorAll('[data-r]').forEach(el => { this.r[el.dataset.r] = el; });
    this.r.connect.addEventListener('click', () => this.client ? this.disconnect() : this.connect());
    this.r.refresh.addEventListener('click', () => this.loadLogs());
    this.r.export.addEventListener('click', () => this.exportAll());
    this.r.flash.addEventListener('click', () => this.flash());
    this.polls = 0;
    this.r.logs.addEventListener('click', e => { const b = e.target.closest('[data-share]'); if (b) this.share(Number(b.dataset.share)); });
    this.r.form.addEventListener('submit', e => { e.preventDefault(); this.saveSettings(); });
  }
  error(msg) { this.r.err.textContent = msg || ''; this.r.err.hidden = !msg; }
  async connect() {
    this.error('');
    try {
      const t = this.o.connect ? await this.o.connect(() => this.disconnect()) : this.o.transport;
      this.client = new DcpClient(t);
      this.r.status.textContent = this.o.title || 'Connected';
      this.r.dot.classList.add('on'); this.r.connect.textContent = 'Disconnect'; this.r.connect.classList.remove('ph-primary');
      this.r.body.hidden = false;
      if (this.o.onConnect) this.o.onConnect(true);
      /* The computer has no network clock: give it the phone's (UTC) on every connect, for log dates and off-gassing while it was off. */
      { const t = new Uint8Array(4); new DataView(t.buffer).setUint32(0, Math.floor(Date.now() / 1000), true); await this.client.ok(DCP.SET_TIME, t).catch(() => {}); }
      await this.loadInfo(); await this.loadSettings(); await this.loadGear(); await this.loadPlan(); await this.loadCheck(); await this.loadLogs(); await this.syncArchive();
      clearInterval(this.timer); this.timer = setInterval(() => this.loadLive(), 1000); this.loadLive();
    } catch (e) { this.error(e.message || String(e)); this.disconnect(true); }
  }
  disconnect(keepError) {
    clearInterval(this.timer);
    if (this.client && this.o.onConnect) this.o.onConnect(false);
    if (this.client && this.client.t.disconnect) this.client.t.disconnect();
    this.client = null;
    this.r.status.textContent = 'Not connected'; this.r.dot.classList.remove('on');
    this.r.connect.textContent = 'Connect'; this.r.connect.classList.add('ph-primary');
    this.r.body.hidden = true;
    if (!keepError) this.error('');
  }
  async loadInfo() {
    const i = await this.client.info();
    const bt = i.battery === 255 ? 'unknown' : `<span class="ph-batt${i.battery < 15 ? ' low' : i.battery < 30 ? ' warn' : ''}"><i style="width:${i.battery}%"></i></span> ${i.battery} %${i.battery < 30 && i.state !== 4 ? ' · charge before diving' : ''}`;
    this.r.info.innerHTML = `<dt>Firmware</dt><dd>${i.fw}</dd><dt>Battery</dt><dd>${bt}</dd><dt>State</dt><dd>${DC_STATES[i.state] || i.state}</dd><dt>Dives stored</dt><dd>${i.logs}</dd>`;
  }
  async loadLive() {
    if (!this.client) return;
    try {
      const l = await this.client.live(), s = this.settings;
      const gas = s ? gasLabel(s.gases[l.gas]) : `Gas ${l.gas + 1}`;
      this.r.live.innerHTML = `<div><b>${l.depth.toFixed(1)} m</b><span>depth</span></div>
        <div><b>${l.deco ? 'TTS ' + l.tts + "'" : (l.ndl >= 99 ? '99+' : l.ndl + "'")}</b><span>${l.deco ? 'in deco' : 'no-deco limit'}</span></div>
        <div><b>${l.tank === null ? '—' : l.tank.toFixed(0) + ' bar'}</b><span>${gas}</span></div>
        <div><b>${l.cns} %</b><span>CNS</span></div>
        <div><b>${DC_STATES[l.state] || l.state}</b><span>${l.alarms ? 'alarm active' : 'no alarms'}</span></div>`;
      this.r.body.classList.toggle('ph-diving', l.state === 2);
      if (++this.polls % 5 === 1) { await this.loadTanks(); await this.loadInfo(); await this.loadCheck(); }
    } catch (e) {
      if (e instanceof DcpOffline) { this.disconnect(true); this.error(e.message); }
      /* otherwise keep the last values; a dropped poll is fine */
    }
  }
  /* Phone position, or null. opts.getPosition comes from the page (GPS in the app, a fixed point in the simulator). */
  async position() { try { return this.o.getPosition ? await this.o.getPosition() : null; } catch (e) { return null; } }
  async notePosition() { const p = await this.position(); if (p) lastPosSave({ lat: p.lat, lon: p.lon, t: Math.floor(Date.now() / 1000) }); }
  async loadCheck() {
    if (!this.client) return;
    let c;
    try { c = await this.client.predive(); } catch (e) { if (e instanceof DcpOffline) return; throw e; }   /* the link dropped: the poll reports it */
    const warn = c.items.filter(i => i.level === 1).length, stop = c.items.filter(i => i.level === 2).length;
    const head = stop ? `<b class="ph-lv2">Do not dive: ${stop} thing${stop > 1 ? 's' : ''} to fix</b>` : warn ? `<b class="ph-lv1">${warn} thing${warn > 1 ? 's' : ''} to check</b>` : '<b class="ph-lv0">Ready to dive</b>';
    this.r.check.innerHTML = `<p class="ph-checkhead">${head}</p><ul class="ph-check">${c.items.map(i => `<li class="ph-lv${i.level}"><span>${['✓', '!', '✕'][i.level]}</span><b>${i.label}</b><em>${i.detail}</em></li>`).join('')}</ul>`;
  }
  async loadPlan() {
    const b = await this.client.getPlan(), X = this.o.X;
    this.planOnDevice = null;
    if (b.length) { new Uint8Array(X.memory.buffer).set(b, X.app_plan_blob()); if (X.app_plan_load(b.length)) this.planOnDevice = this.readPlan(); }
    this.renderPlan(this.planOnDevice, this.planOnDevice ? 'This plan is on the dive computer.' : '');
  }
  readPlan() {
    const X = this.o.X, p = { depth: X.app_plan_get(1), bottom: X.app_plan_get(2), runtime: X.app_plan_get(3), tts: X.app_plan_get(4), sac: X.app_plan_get(7),
      gfLow: X.app_plan_get(8), gfHigh: X.app_plan_get(9), ok: X.app_plan_get(6), stops: [], gas: [] };
    for (let i = 0; i < X.app_plan_get(5); i++) p.stops.push({ depth: X.app_plan_stop(i, 0), min: X.app_plan_stop(i, 1) });
    for (let i = 0; i < 5; i++) p.gas.push(X.app_plan_gas(i));
    return p;
  }
  renderPlan(p, msg) {
    const el = this.r.plan, s = this.settings, v = p || { depth: 30, bottom: 30, sac: 18 };
    let h = `<div class="ph-row"><label for="ph-pd">Depth</label><span><input id="ph-pd" type="number" min="3" max="150" value="${v.depth}"> m</span>
      <label for="ph-pb">Bottom time</label><span><input id="ph-pb" type="number" min="1" max="240" value="${v.bottom}"> min</span>
      <label for="ph-ps">SAC</label><span><input id="ph-ps" type="number" min="5" max="40" value="${v.sac}"> L/min</span>
      <button type="button" class="ph-btn" data-calc>Calculate</button></div>`;
    if (p) {
      const short = p.gas.some((g, i) => g && !(p.ok & (1 << i)));
      h += `<dl class="ph-kv ph-planout"><dt>Run time</dt><dd>${p.runtime} min (ascent and stops ${p.tts} min) · GF ${p.gfLow}/${p.gfHigh}</dd>
        <dt>Stops</dt><dd>${p.stops.length ? p.stops.map(x => `${x.depth} m ${x.min}'`).join(' · ') : 'none: no-decompression dive'}</dd>
        ${p.gas.map((g, i) => g ? `<dt>Gas ${i + 1} ${s ? gasLabel(s.gases[i]) : ''}</dt><dd class="${p.ok & (1 << i) ? '' : 'ph-warn'}">${g} bar needed of ${s ? s.gases[i].fill : '?'} bar${p.ok & (1 << i) ? '' : ': not enough'}</dd>` : '').join('')}</dl>
        <div class="ph-row"><button type="button" class="ph-btn ph-primary" data-send ${short ? 'disabled' : ''}>Send plan to dive computer</button>
        <button type="button" class="ph-btn" data-clear>Clear plan on computer</button></div>`;
    }
    h += `<p class="ph-note" data-r="planmsg">${msg || ''}</p>`;
    el.innerHTML = h;
    const say = t => { el.querySelector('[data-r="planmsg"]').textContent = t; };
    const X = this.o.X;
    el.querySelector('[data-calc]').addEventListener('click', () => {
      settingsToBlob(X, this.settings);     /* the planner uses the settings shown above (gases, GF, reserve) */
      const n = id => Number(el.querySelector('#ph-' + id).value);
      if (!X.app_plan_compute(n('pd'), n('pb'), n('ps'))) { say('Depth 3–150 m, bottom time 1–240 min, SAC 5–40 L/min.'); return; }
      this.plan = this.readPlan();
      this.renderPlan(this.plan, this.plan.gas.some((g, i) => g && !(this.plan.ok & (1 << i))) ? 'Not enough gas for this plan: shorten it, or use a bigger cylinder or another gas.' : 'Not sent yet.');
    });
    const send = el.querySelector('[data-send]');
    if (send) send.addEventListener('click', async () => {
      try {
        settingsToBlob(X, this.settings);
        X.app_plan_compute(p.depth, p.bottom, p.sac);
        const n = X.app_plan_save(Math.floor(Date.now() / 1000));
        await this.client.setPlan(new Uint8Array(X.memory.buffer).slice(X.app_plan_blob(), X.app_plan_blob() + n));
        this.planOnDevice = p; this.notePosition();
        this.renderPlan(p, 'Sent. The computer shows it on the surface screen and on the Deco page during the dive.');
        if (this.o.onSettings) this.o.onSettings('plan');
        await this.loadCheck();
      } catch (e) { say(`Not sent: ${e.message}`); }
    });
    const clear = el.querySelector('[data-clear]');
    if (clear) clear.addEventListener('click', async () => {
      try { await this.client.setPlan(new Uint8Array(0)); this.planOnDevice = null; this.renderPlan(null, 'No plan on the computer.'); if (this.o.onSettings) this.o.onSettings('plan'); await this.loadCheck(); }
      catch (e) { say(`Not cleared: ${e.message}`); }
    });
  }
  /* Download dives the phone has not seen, keep a summary of each, then show statistics and the site map. */
  async syncArchive() {
    const arch = archiveLoad(), have = new Set(arch.map(d => d.key)), now = Math.floor(Date.now() / 1000);
    let added = 0;
    for (const l of this.logs) {
      if (have.has(l.start)) continue;
      try {
        const h = parseDiveLog(this.o.X, await this.download(l));
        let phone = null;
        const last = lastPosLoad();
        if (!h.pos) {
          if (Math.abs(now - (h.start + h.duration)) < 3 * 3600) phone = await this.position();          /* just surfaced: we are at the site */
          if (!phone && last && h.start - last.t < 6 * 3600 && h.start >= last.t - 600) phone = { lat: last.lat, lon: last.lon };   /* where we synced before the dive */
        }
        arch.push(summarizeDive(h, phone)); added++;
      } catch (e) { /* a corrupt log stays on the computer; skip it here */ }
    }
    if (added) { arch.sort((a, b) => a.start - b.start); archiveSave(arch); this.r.logmsg.textContent = `${added} new dive${added > 1 ? 's' : ''} saved on this phone.`; }
    this.archive = arch;
    this.renderStats(); this.renderSites();
  }
  renderStats() {
    const st = diveStats(this.archive || []);
    if (!st) { this.r.stats.innerHTML = '<p class="ph-note">Your totals and records appear here after the first dive.</p>'; return; }
    const hrs = st.totalS / 3600, MON = ['J', 'F', 'M', 'A', 'M', 'J', 'J', 'A', 'S', 'O', 'N', 'D'], top = Math.max(1, ...st.months.map(m => m.n));
    const rec = (label, d, val) => d ? `<li><span>${label}</span><b>${val}</b><em>#${d.no} · ${new Date(d.start * 1000).toISOString().slice(0, 10)}${d.site ? ' · ' + d.site : ''}</em></li>` : '';
    this.r.stats.innerHTML = `<div class="ph-live">
        <div><b>${st.count}</b><span>dives</span></div><div><b>${hrs >= 10 ? hrs.toFixed(0) : hrs.toFixed(1)} h</b><span>under water</span></div>
        <div><b>${st.deepest.maxDepth.toFixed(1)} m</b><span>deepest</span></div><div><b>${st.decoDives}</b><span>deco dives</span></div><div><b>${st.sites}</b><span>named sites</span></div></div>
      <div class="ph-months" role="img" aria-label="Dives per month, last 12 months">${st.months.map(m => `<div title="${m.n} dives, ${Math.round(m.min)} min"><i style="height:${Math.round(m.n / top * 100)}%"></i><b>${m.n || ''}</b><span>${MON[m.m]}</span></div>`).join('')}</div>
      <ul class="ph-records">${rec('Deepest', st.deepest, st.deepest.maxDepth.toFixed(1) + ' m')}${rec('Longest', st.longest, fmtTime(st.longest.duration))}
        ${rec('Coldest water', st.coldest, st.coldest.minTemp.toFixed(0) + ' °C')}${st.bestSac ? rec('Lowest SAC', st.bestSac, st.bestSac.sac.toFixed(1) + ' L/min') : ''}</ul>`;
  }
  async renderSites() {
    const a = (this.archive || []).filter(d => d.pos);
    if (!a.length) { this.r.sites.innerHTML = '<p class="ph-note">Dives get a position from the computer\'s GPS fix before the dive, or from this phone when you sync before or right after a dive.</p>'; return; }
    const groups = [];                                         /* dives within about 150 m share a pin */
    a.forEach(d => { const g = groups.find(q => Math.abs(q.lat - d.pos.lat) < 0.0014 && Math.abs(q.lon - d.pos.lon) < 0.003); if (g) { g.n++; if (d.site) g.label = d.site; } else groups.push({ lat: d.pos.lat, lon: d.pos.lon, n: 1, label: d.site || '' }); });
    this.r.sites.innerHTML = `<canvas class="ph-map" width="720" height="400" aria-label="Map of dive sites"></canvas>
      <ul class="ph-records">${groups.map(g => `<li><span>${g.label || 'Unnamed site'}</span><b>${g.n} dive${g.n > 1 ? 's' : ''}</b><em>${g.lat.toFixed(4)}, ${g.lon.toFixed(4)}</em></li>`).join('')}</ul>`;
    const cv = this.r.sites.querySelector('canvas'), last = a[a.length - 1];
    const line = groups.length === 1 && last.track && last.track.length > 1 ? [trackLatLon(last.pos, last.track)] : [];
    await drawMap(cv.getContext('2d'), 0, 0, 720, 400, line, groups, { tiles: this.o.tiles, maxZoom: 16 });
  }
  async loadTanks() {
    if (!this.client) return;
    const t = await this.client.tanks(), s = this.settings;
    const rows = t.map((x, i) => ({ ...x, i })).filter(x => x.gasOn || x.present);
    const batt = b => b === 2 ? '<span class="ph-warn">weak, replace</span>' : b === 1 ? 'OK' : '—';
    this.r.tanks.innerHTML = rows.length ? `<table class="ph-logs"><thead><tr><th>Tank</th><th>Serial</th><th>Pressure</th><th>Battery</th><th>Heard</th></tr></thead><tbody>${
      rows.map(x => `<tr><td>T${x.i + 1}${s ? ' ' + gasLabel(s.gases[x.i]) : ''}</td><td class="ph-mono">${x.serial ? String(x.serial).padStart(6, '0') : 'not paired'}</td>
        <td>${x.bar === null ? '—' : x.bar.toFixed(0) + ' bar'}</td><td>${x.present ? batt(x.battery) : '—'}</td><td>${x.present ? (x.age < 60 ? x.age + ' s ago' : Math.round(x.age / 60) + ' min ago') : 'never'}</td></tr>`).join('')}</tbody></table>`
      : '<p class="ph-note">No gases with transmitters yet.</p>';
  }
  async loadGear() {
    const dev = gearFromBlob(this.o.X, await this.client.getGear());
    const lib = gearLibraryLoad();
    /* The computer's list wins when it has one (it may have learned transmitter serials); otherwise the phone's library. */
    this.gear = dev.items.length || !lib ? dev : lib;
    this.gearFromDevice = dev.items.length > 0;
    if (dev.items.length) gearLibrarySave(dev);
    this.renderGear(this.gearFromDevice ? `On the dive computer: synced ${dev.synced ? fmtDate(dev.synced) : 'earlier'}.` : (lib ? 'Loaded from this phone. Not on the dive computer yet: sync it.' : 'No gear yet. Add what you dive with.'));
  }
  renderGear(msg) {
    const g = this.gear, s = this.settings, el = this.r.gear;
    const esc = t => String(t).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c]);
    let h = '<div class="ph-gear-wrap"><table class="ph-gear"><thead><tr><th>Bring</th><th>Item</th><th>Type</th><th>Size</th><th>Transmitter</th><th></th></tr></thead><tbody>';
    g.items.forEach((it, i) => {
      const sz = GEAR_SIZE[it.type];
      h += `<tr><td><input type="checkbox" data-g="onDive" data-i="${i}" ${it.onDive ? 'checked' : ''} aria-label="Bring ${esc(it.name)}"></td>
        <td><input type="text" maxlength="16" data-g="name" data-i="${i}" value="${esc(it.name)}" aria-label="Name"></td>
        <td><select data-g="type" data-i="${i}" aria-label="Type">${GEAR_TYPES.map((t, k) => k ? `<option value="${k}" ${k === it.type ? 'selected' : ''}>${t}</option>` : '').join('')}</select></td>
        <td>${sz ? `<input type="number" step="${sz[1]}" min="0" max="${sz[2]}" data-g="size" data-i="${i}" value="${it.size}" aria-label="Size"> ${sz[0]}` : ''}
          ${it.type === 1 ? `<br><input type="number" step="1" min="50" max="300" data-g="work" data-i="${i}" value="${it.work || 232}" aria-label="Working pressure"> bar` : ''}</td>
        <td>${it.type === 1 ? `<input type="number" min="0" max="16777215" data-g="serial" data-i="${i}" value="${it.serial || ''}" placeholder="pair" class="ph-serial" aria-label="Transmitter serial">` : ''}</td>
        <td><button type="button" class="ph-btn ph-x" data-del="${i}" aria-label="Remove ${esc(it.name)}">✕</button></td></tr>`;
    });
    h += '</tbody></table></div>';
    h += `<div class="ph-row"><select data-r="newtype" aria-label="New item type">${GEAR_TYPES.map((t, k) => k ? `<option value="${k}">${t}</option>` : '').join('')}</select>
      <button type="button" class="ph-btn" data-add ${g.items.length >= 12 ? 'disabled' : ''}>Add item</button><span class="ph-note">${g.items.length} of 12</span></div>`;
    const cyls = g.items.map((it, i) => [it, i]).filter(([it]) => it.type === 1);
    h += '<h4>Cylinders for this dive</h4><div class="ph-grid">';
    s.gases.forEach((x, k) => {
      if (k > 0 && !x.on && g.gasCyl[k] < 0) return;
      h += `<label for="ph-gc-${k}">Gas ${k + 1} · ${gasLabel(x)}</label><span><select id="ph-gc-${k}" data-gc="${k}"><option value="-1">${k === 0 ? 'Cylinder size from settings' : 'Not carried'}</option>
        ${cyls.map(([it, i]) => `<option value="${i}" ${g.gasCyl[k] === i ? 'selected' : ''}>${esc(it.name || 'Cylinder')} · ${it.size} L</option>`).join('')}</select></span>`;
    });
    h += '</div><p class="ph-note">Turn on more gases under Settings first. A cylinder\'s transmitter pairs it to its gas; the computer fills in serials it learns underwater.</p>';
    const lead = g.items.filter(it => it.type === 5 && it.onDive).reduce((a, it) => a + (it.size || 0), 0);
    h += `<div class="ph-row"><button type="button" class="ph-btn ph-primary" data-sync>Sync gear to dive computer</button>
      <span class="ph-note" data-r="gearmsg">${esc(msg || '')}${lead ? ` · lead ${lead} kg` : ''}</span></div>`;
    el.innerHTML = h;
    this.r.gearmsg = el.querySelector('[data-r="gearmsg"]');
    el.querySelectorAll('[data-g]').forEach(inp => inp.addEventListener('change', () => {
      const it = g.items[Number(inp.dataset.i)], f = inp.dataset.g;
      if (f === 'onDive') it.onDive = inp.checked;
      else if (f === 'name') it.name = inp.value.slice(0, 16);
      else if (f === 'type') { it.type = Number(inp.value); if (!GEAR_SIZE[it.type]) it.size = 0; this.renderGear('Not synced yet.'); return; }
      else it[f] = Number(inp.value) || 0;
      this.r.gearmsg.textContent = 'Changed. Not synced yet.';
    }));
    el.querySelectorAll('[data-gc]').forEach(sel => sel.addEventListener('change', () => {
      const k = Number(sel.dataset.gc), v = Number(sel.value);
      g.gasCyl = g.gasCyl.map((c, j) => (j !== k && c === v && v >= 0) ? -1 : c);   /* one cylinder, one gas */
      g.gasCyl[k] = v;
      if (v >= 0) g.items[v].onDive = true;
      this.renderGear('Not synced yet.');
    }));
    el.querySelectorAll('[data-del]').forEach(b => b.addEventListener('click', () => {
      const i = Number(b.dataset.del);
      g.items.splice(i, 1);
      g.gasCyl = g.gasCyl.map(c => c === i ? -1 : (c > i ? c - 1 : c));
      this.renderGear('Removed. Not synced yet.');
    }));
    el.querySelector('[data-add]').addEventListener('click', () => {
      const type = Number(el.querySelector('[data-r="newtype"]').value);
      const dflt = { 1: ['Cylinder', 12], 4: ['Wetsuit', 7], 5: ['Weights', 4] }[type] || [GEAR_TYPES[type], 0];
      g.items.push({ type, onDive: true, size: dflt[1], work: type === 1 ? 232 : 0, serial: 0, name: dflt[0] });
      this.renderGear('Added. Not synced yet.');
    });
    el.querySelector('[data-sync]').addEventListener('click', () => this.syncGear());
  }
  async syncGear() {
    try {
      await this.client.setGear(gearToBlob(this.o.X, this.gear));
      gearLibrarySave(this.gear);
      await this.loadSettings();       /* cylinder sizes and transmitters went into the gas settings */
      await this.loadGear();
      this.r.gearmsg.textContent = `Synced: ${this.gear.items.filter(i => i.onDive).length} items on this dive. Check them on the computer under Settings → Gear check.`;
      if (this.o.onSettings) this.o.onSettings('gear');
      this.notePosition();             /* where you kit up is usually the dive site */
      await this.loadCheck();
    } catch (e) { this.r.gearmsg.textContent = `Not synced: ${e.message}`; }
  }
  async loadSettings() {
    this.settings = settingsFromBlob(this.o.X, await this.client.getSettings());
    this.renderSettings();
  }
  renderSettings() {
    const s = this.settings, f = this.r.form;
    const num = (id, v, min, max, step, label, unit) => `<label for="ph-${id}">${label}</label><span><input id="ph-${id}" type="number" min="${min}" max="${max}" step="${step}" value="${v}">${unit ? ' ' + unit : ''}</span>`;
    let g = '<div class="ph-gear-wrap"><table class="ph-gas"><thead><tr><th>Gas</th><th>O₂ %</th><th>He %</th><th>On</th><th>Cyl L</th><th>Fill</th><th>Paired</th></tr></thead><tbody>';
    s.gases.forEach((x, i) => {
      g += `<tr><td>${i + 1}</td><td><input id="ph-o2-${i}" type="number" min="5" max="100" value="${x.o2}" aria-label="Gas ${i + 1} oxygen"></td>
        <td><input id="ph-he-${i}" type="number" min="0" max="95" value="${x.he}" aria-label="Gas ${i + 1} helium"></td>
        <td><input id="ph-on-${i}" type="checkbox" ${x.on ? 'checked' : ''} ${i === 0 ? 'disabled' : ''} aria-label="Gas ${i + 1} in use"></td>
        <td><input id="ph-cyl-${i}" type="number" min="1" max="30" value="${x.cyl}" aria-label="Gas ${i + 1} cylinder"></td>
        <td><input id="ph-fill-${i}" type="number" min="50" max="300" step="10" value="${x.fill}" aria-label="Gas ${i + 1} fill"></td>
        <td class="ph-mono">${x.serial ? String(x.serial).padStart(6, '0') : '—'}</td></tr>`;
    });
    g += '</tbody></table></div>';
    f.innerHTML = g + `<div class="ph-grid">
      ${num('gfl', s.gfLow, 10, 100, 5, 'GF low', '%')}${num('gfh', s.gfHigh, 40, 100, 5, 'GF high', '%')}
      <label for="ph-water">Water</label><span><select id="ph-water"><option value="0">Salt</option><option value="1">Fresh</option><option value="2">EN 13319</option></select></span>
      <label for="ph-last">Last stop</label><span><select id="ph-last"><option value="3">3 m</option><option value="6">6 m</option></select></span>
      ${num('ppb', (s.ppo2Bottom / 100).toFixed(2), 1.0, 1.6, 0.05, 'ppO₂ bottom', 'bar')}${num('ppd', (s.ppo2Deco / 100).toFixed(2), 1.2, 1.6, 0.05, 'ppO₂ deco', 'bar')}
      ${num('res', s.reserve, 20, 100, 5, 'Reserve at surface', 'bar')}${num('asc', s.ascentAlarm, 6, 18, 1, 'Ascent alarm', 'm/min')}
      ${num('bri', s.brightness, 1, 5, 1, 'Brightness', '/ 5')}${num('dec', s.declination, -30, 30, 1, 'Declination', '°')}
      <label for="ph-ss">Safety stop</label><span><input id="ph-ss" type="checkbox" ${s.safetyStop ? 'checked' : ''}></span>
      <label for="ph-pair">Pair new transmitters</label><span><input id="ph-pair" type="checkbox" ${s.pairing ? 'checked' : ''}></span>
      </div><h4>Alarms</h4><div class="ph-grid">
      ${num('tm', s.turnMargin, 10, 50, 5, 'Turn-soon margin', 'bar')}
      ${num('da', s.depthAlarm, 0, 150, 10, 'Depth alarm (0 = off)', 'm')}${num('ta', s.timeAlarm, 0, 300, 10, 'Dive time alarm (0 = off)', 'min')}
      ${num('nw', s.ndlWarn, 0, 10, 1, 'NDL warning (0 = off)', 'min')}
      </div><h4>Device</h4><div class="ph-grid">
      <label for="ph-flip">Flip screen (other arm)</label><span><input id="ph-flip" type="checkbox" ${s.flip ? 'checked' : ''}></span>
      ${num('li', s.logInterval, 1, 10, 1, 'Log interval', 's')}
      <label for="ph-bt">Bluetooth</label><span><input id="ph-bt" type="checkbox" ${s.bluetooth ? 'checked' : ''}> <span class="ph-note">on the surface only; turning it off disconnects this phone</span></span>
      </div><div class="ph-row"><button type="submit" class="ph-btn ph-primary">Save to dive computer</button>
      <button type="button" class="ph-btn" data-forget>Forget transmitters</button><span class="ph-note" data-r="setmsg"></span></div>`;
    f.querySelector('#ph-water').value = s.water; f.querySelector('#ph-last').value = s.lastStop;
    this.r.setmsg = f.querySelector('[data-r="setmsg"]');
    f.querySelector('[data-forget]').addEventListener('click', () => { this.settings.gases.forEach(x => { x.serial = 0; }); this.saveSettings(true); });
  }
  readForm() {
    const f = this.r.form, v = id => Number(f.querySelector('#ph-' + id).value), c = id => f.querySelector('#ph-' + id).checked ? 1 : 0;
    const s = this.settings;
    s.gases.forEach((g, i) => { g.o2 = v('o2-' + i); g.he = v('he-' + i); g.on = i === 0 ? 1 : c('on-' + i); g.cyl = v('cyl-' + i); g.fill = v('fill-' + i); });
    Object.assign(s, { gfLow: v('gfl'), gfHigh: v('gfh'), water: v('water'), lastStop: v('last'), ppo2Bottom: Math.round(v('ppb') * 100),
      ppo2Deco: Math.round(v('ppd') * 100), reserve: v('res'), ascentAlarm: v('asc'), brightness: v('bri'), declination: v('dec'),
      safetyStop: c('ss'), pairing: c('pair'), turnMargin: v('tm'), depthAlarm: v('da'), timeAlarm: v('ta'), ndlWarn: v('nw'),
      flip: c('flip'), logInterval: v('li'), bluetooth: c('bt') });
  }
  async saveSettings(skipForm) {
    try {
      if (!skipForm) this.readForm();
      await this.client.setSettings(settingsToBlob(this.o.X, this.settings));
      if (!this.settings.bluetooth) {
        if (this.o.onSettings) this.o.onSettings();
        this.disconnect(true);
        this.error('Saved. Bluetooth is now off on the dive computer, so the phone was disconnected. Turn it back on under Settings → Bluetooth on the computer.');
        return;
      }
      await this.loadSettings();
      if (this.gear) this.renderGear(this.r.gearmsg ? this.r.gearmsg.textContent : '');
      this.r.setmsg.textContent = 'Saved. The dive computer checked and applied the settings.';
      if (this.o.onSettings) this.o.onSettings();
    } catch (e) { this.r.setmsg.textContent = `Not saved: ${e.message}`; }
  }
  async loadLogs() {
    try {
      this.logs = await this.client.listLogs();
      this.r.logs.innerHTML = this.logs.length ? `<table class="ph-logs"><thead><tr><th>#</th><th>Date</th><th>Max</th><th>Time</th><th></th><th></th></tr></thead><tbody>${
        this.logs.map(l => `<tr><td>${l.no}</td><td>${fmtDate(l.start)}</td><td>${l.maxDepth.toFixed(1)} m</td><td>${fmtTime(l.duration)}</td><td>${l.deco ? 'deco' : ''}</td><td><button type="button" class="ph-btn ph-small" data-share="${l.idx}">Share</button></td></tr>`).join('')}</tbody></table>`
        : '<p class="ph-note">No dives stored yet. Finish a dive (5 min above 1 m) and refresh.</p>';
    } catch (e) { this.r.logmsg.textContent = e.message; }
  }
  async exportAll() {
    if (!this.logs.length) { this.r.logmsg.textContent = 'No dives to export.'; return; }
    try {
      const all = [];
      for (const [k, l] of this.logs.entries()) {
        all.push(await this.download(l));
        this.r.logmsg.textContent = `Downloaded ${k + 1} of ${this.logs.length}`;
      }
      const xml = logsToUddf(this.o.X, all);
      const kb = Math.round(xml.length / 1024);
      if (this.o.canDownload) {
        const a = document.createElement('a');
        a.href = URL.createObjectURL(new Blob([xml], { type: 'application/xml' }));
        a.download = `dives-${new Date().toISOString().slice(0, 10)}.uddf`;
        a.click();
        this.r.logmsg.textContent = `Exported ${all.length} dive(s), ${kb} KB. Import the .uddf file in Subsurface (File → Import log files).`;
      } else {
        this.r.logmsg.textContent = `Exported ${all.length} dive(s), ${kb} KB of UDDF. The real app saves this as a .uddf file; here you can copy it.`;
        this.r.uddf.innerHTML = '<textarea class="ph-xml" readonly aria-label="UDDF export"></textarea><button type="button" class="ph-btn" data-copy>Copy UDDF</button>';
        const ta = this.r.uddf.querySelector('textarea'); ta.value = xml;
        this.r.uddf.querySelector('[data-copy]').addEventListener('click', async () => {
          try { await navigator.clipboard.writeText(xml); this.r.logmsg.textContent = 'Copied.'; } catch (e) { ta.select(); this.r.logmsg.textContent = 'Press Ctrl+C / Cmd+C to copy the selected text.'; }
        });
      }
    } catch (e) { this.r.logmsg.textContent = `Export failed: ${e.message}`; }
  }
  async download(l) {
    if (!this.downloaded.has(l.no)) this.downloaded.set(l.no, await this.client.readLog(l.idx, p => { this.r.logmsg.textContent = `Downloading dive ${l.no}: ${Math.round(p * 100)} %`; }));
    return this.downloaded.get(l.no);
  }
  async share(idx) {
    const l = this.logs.find(x => x.idx === idx);
    if (!l) return;
    try {
      const dive = parseDiveLog(this.o.X, await this.download(l));
      this.r.logmsg.textContent = '';
      const el = this.r.share;
      el.hidden = false;
      el.innerHTML = `<div class="ph-row"><label for="ph-site">Dive site</label><input id="ph-site" type="text" maxlength="40" placeholder="e.g. Gulosen, Trondheimsfjorden"></div>
        <canvas class="ph-card" aria-label="Share picture of dive ${dive.no}"></canvas>
        <div class="ph-row"><button type="button" class="ph-btn ph-primary" data-go>Share…</button>${this.o.canDownload ? '<button type="button" class="ph-btn" data-save>Save image</button>' : ''}
        <button type="button" class="ph-btn" data-close>Close</button></div><p class="ph-note" data-msg></p>`;
      const cv = el.querySelector('canvas'), site = el.querySelector('#ph-site'), msg = el.querySelector('[data-msg]');
      const entry = (this.archive || []).find(d => d.key === dive.start);
      site.value = (entry && entry.site) || siteLoad(dive.start);
      const redraw = () => drawShareCard(cv, dive, site.value.trim(), { tiles: this.o.tiles, pos: entry && entry.pos });
      redraw();
      site.addEventListener('input', () => { siteSave(dive.start, site.value.trim()); if (entry) { entry.site = site.value.trim(); archiveSave(this.archive); } redraw(); });
      site.addEventListener('change', () => { this.renderStats(); this.renderSites(); });
      const file = () => new Promise((res, rej) => cv.toBlob ? cv.toBlob(b => b ? res(new File([b], `dive-${dive.no}.png`, { type: 'image/png' })) : rej(new Error('no image')), 'image/png') : rej(new Error('no image')));
      el.querySelector('[data-close]').addEventListener('click', () => { el.hidden = true; el.innerHTML = ''; });
      el.querySelector('[data-go]').addEventListener('click', async () => {
        const noSheet = this.o.canDownload ? 'This browser cannot open the share sheet. Use Save image and post it from your gallery.' : 'In the app on a phone this opens the share sheet (Instagram, Strava, Messenger …). Here you can only preview it.';
        if (!navigator.canShare) { msg.textContent = noSheet; return; }
        try {
          const f = await file();
          if (navigator.canShare && navigator.canShare({ files: [f] })) {
            await navigator.share({ files: [f], title: `Dive #${dive.no}`, text: `${site.value.trim() || 'Dive'} · ${dive.maxDepth.toFixed(1)} m · ${Math.round(dive.duration / 60)} min` });
            msg.textContent = 'Shared.';
          } else msg.textContent = this.o.canDownload ? 'This browser cannot open the share sheet. Use Save image and post it from your gallery.' : 'In the app on a phone this opens the share sheet (Instagram, Strava, Messenger …). Here you can only preview it.';
        } catch (e) { if (e.name !== 'AbortError') msg.textContent = this.o.canDownload ? 'Could not share. Use Save image instead.' : 'In the app on a phone this opens the share sheet (Instagram, Strava, Messenger …). Here you can only preview it.'; }
      });
      const save = el.querySelector('[data-save]');
      if (save) save.addEventListener('click', async () => { const f = await file(); const a = document.createElement('a'); a.href = URL.createObjectURL(f); a.download = f.name; a.click(); });
      el.scrollIntoView && el.scrollIntoView({ block: 'nearest' });
    } catch (e) { this.r.logmsg.textContent = `Could not make the picture: ${e.message}`; }
  }
  async flash() {
    const file = this.r.fw.files && this.r.fw.files[0];
    if (!file) { this.r.fwmsg.textContent = 'Choose a firmware file (.bin) first.'; return; }
    try {
      const bytes = new Uint8Array(await file.arrayBuffer());
      this.r.prog.hidden = false;
      await this.client.updateFirmware(bytes, p => { this.r.prog.value = p; this.r.fwmsg.textContent = `Sending ${Math.round(p * 100)} %`; });
      this.r.fwmsg.textContent = 'Installed. The dive computer restarts into the new firmware.';
      await this.loadInfo().catch(() => {});
    } catch (e) { this.r.fwmsg.textContent = `Update failed: ${e.message}`; }
  }
}

const PHONE_CSS = `
.ph{font:14px/1.5 var(--f-body, system-ui, sans-serif);color:var(--ink,#13202B)}
.ph h3{font:600 15px var(--f-display, system-ui);margin:14px 0 6px}
.ph-bar{display:flex;align-items:center;gap:10px;flex-wrap:wrap}
.ph-dot{width:10px;height:10px;border-radius:50%;background:var(--muted,#888)}
.ph-dot.on{background:#2E9E6E}
.ph-btn{font:500 13px var(--f-body, system-ui);background:transparent;color:var(--ink,#13202B);border:1px solid var(--line,#ccc);border-radius:7px;padding:6px 11px;cursor:pointer}
.ph-btn.ph-primary{background:var(--accent,#CC3A2E);border-color:var(--accent,#CC3A2E);color:#fff}
.ph-bar .ph-btn{margin-left:auto}
.ph-row{display:flex;flex-wrap:wrap;gap:8px;align-items:center;margin-top:8px}
.ph-err{color:var(--accent,#CC3A2E);margin:8px 0 0}
.ph-note{font-size:12.5px;color:var(--muted,#667);margin:6px 0 0}
.ph-kv{display:grid;grid-template-columns:max-content 1fr;gap:2px 14px;margin:0}
.ph-kv dt{color:var(--muted,#667)}.ph-kv dd{margin:0;font-family:var(--f-mono, monospace)}
.ph-live{display:grid;grid-template-columns:repeat(auto-fit,minmax(96px,1fr));gap:8px}
.ph-live div{border-left:2px solid var(--line,#ccc);padding-left:8px}
.ph-live b{display:block;font:600 16px var(--f-mono, monospace)}.ph-live span{font-size:12px;color:var(--muted,#667)}
.ph-gas,.ph-logs{width:100%;border-collapse:collapse;font-size:13px}
.ph-btn.ph-small{padding:2px 9px;font-size:12px}
.ph-warn{color:var(--accent,#CC3A2E);font-weight:600}
.ph-batt{display:inline-block;vertical-align:-1px;width:30px;height:12px;border:1.5px solid currentColor;border-radius:3px;position:relative;margin-right:4px}
.ph-batt i{position:absolute;left:1px;top:1px;bottom:1px;max-width:calc(100% - 2px);background:#2E9E6E;border-radius:1px}
.ph-batt.warn i{background:#D9921E}.ph-batt.low i{background:var(--accent,#CC3A2E)}
.ph-check{list-style:none;margin:6px 0 0;padding:0;display:grid;gap:3px}
.ph-check li{display:grid;grid-template-columns:18px minmax(90px,max-content) 1fr;gap:8px;align-items:baseline;font-size:13px}
.ph-check em{font-style:normal;color:var(--muted,#667)}
.ph-checkhead{margin:0}
.ph-lv0>span,b.ph-lv0{color:#2E9E6E}.ph-lv1>span,b.ph-lv1,.ph-lv1 em{color:#B87A12}.ph-lv2>span,b.ph-lv2,.ph-lv2 em{color:var(--accent,#CC3A2E)}
.ph-planout{margin-top:10px}
.ph-months{display:grid;grid-template-columns:repeat(12,1fr);gap:4px;height:92px;margin:12px 0 4px;align-items:end}
.ph-months div{display:grid;grid-template-rows:1fr auto;height:100%;position:relative;text-align:center}
.ph-months i{align-self:end;background:#2E9E6E;border-radius:3px 3px 0 0;min-height:2px;opacity:.85}
.ph-months b{position:absolute;left:0;right:0;top:0;font:500 10px var(--f-mono, monospace);color:var(--muted,#667)}
.ph-months span{font:500 10px var(--f-mono, monospace);color:var(--muted,#667);padding-top:2px}
.ph-records{list-style:none;margin:8px 0 0;padding:0;font-size:13px}
.ph-records li{display:grid;grid-template-columns:minmax(96px,max-content) max-content 1fr;gap:10px;border-top:1px solid var(--line,#ddd);padding:4px 0;align-items:baseline}
.ph-records span,.ph-records em{color:var(--muted,#667);font-style:normal}.ph-records em{font-size:12px;text-align:right}
.ph-map{display:block;width:100%;height:auto;aspect-ratio:9/5;border-radius:8px;background:#0A2233}
.ph-share{margin-top:12px;border-top:1px solid var(--line,#ddd);padding-top:10px}
.ph-share input[type=text]{flex:1;min-width:0;font:14px var(--f-body, system-ui);color:var(--ink,#13202B);background:var(--bg,#fff);border:1px solid var(--line,#ccc);border-radius:6px;padding:5px 8px}
.ph-card{display:block;width:100%;max-width:360px;aspect-ratio:4/5;height:auto;margin-top:10px;border-radius:10px}
.ph-gas th,.ph-logs th{text-align:left;font:500 11px var(--f-mono, monospace);text-transform:uppercase;letter-spacing:.05em;color:var(--muted,#667);padding:3px}
.ph-gas td,.ph-logs td{border-top:1px solid var(--line,#ddd);padding:3px}
.ph input[type=number],.ph select{font:13px var(--f-mono, monospace);color:var(--ink,#13202B);background:var(--bg,#fff);border:1px solid var(--line,#ccc);border-radius:6px;padding:3px 5px;width:62px}
.ph select{width:auto}
.ph-grid{display:grid;grid-template-columns:max-content 1fr;gap:6px 12px;align-items:center;margin-top:10px}
.ph-grid label{color:var(--muted,#667);font-size:13px}
.ph-mono{font-family:var(--f-mono, monospace)}
.ph h4{font:600 13px var(--f-display, system-ui);margin:14px 0 4px;color:var(--muted,#667)}
.ph-gear{width:100%;border-collapse:collapse;font-size:13px}
.ph-gear th{text-align:left;font:500 11px var(--f-mono, monospace);text-transform:uppercase;letter-spacing:.05em;color:var(--muted,#667);padding:3px}
.ph-gear td{border-top:1px solid var(--line,#ddd);padding:4px 3px;vertical-align:top}
.ph input[type=text]{font:13px var(--f-body, system-ui);color:var(--ink,#13202B);background:var(--bg,#fff);border:1px solid var(--line,#ccc);border-radius:6px;padding:3px 5px;width:130px;max-width:100%}
.ph input.ph-serial{width:84px}
.ph-gear td:nth-child(4){white-space:nowrap}
.ph-gear input[type=number]{width:56px}
.ph-x{padding:3px 8px}
.ph-gear-wrap{overflow-x:auto}
.ph-xml{width:100%;height:140px;font:11.5px var(--f-mono, monospace);margin-top:8px;color:var(--ink,#13202B);background:var(--bg,#fff);border:1px solid var(--line,#ccc);border-radius:6px}
.ph progress{width:100%;margin-top:8px}
.ph-diving .ph-form,.ph-diving [data-r="flash"],.ph-diving [data-r="gear"]{opacity:.5;pointer-events:none}
.ph button:focus-visible,.ph input:focus-visible,.ph select:focus-visible{outline:2px solid var(--accent,#CC3A2E);outline-offset:2px}
`;
