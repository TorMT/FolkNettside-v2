#!/bin/sh
# Builds sim/build/divecore.wasm from the same sources as the firmware. Needs: pip install ziglang
set -e
cd "$(dirname "$0")/.."
python3 -m ziglang cc -target wasm32-wasi -O2 -mexec-model=reactor -fvisibility=hidden -Icomponents/divecore/include \
  components/divecore/src/*.c sim/sim_api.c sim/app_api.c -Wl,--export-dynamic -Wl,--strip-all -o sim/build/divecore.wasm
echo "built sim/build/divecore.wasm ($(wc -c < sim/build/divecore.wasm) bytes)"
