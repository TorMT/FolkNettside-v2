import { JSDOM } from 'jsdom';
import { createCanvas } from '@napi-rs/canvas';
import fs from 'fs';
const html = fs.readFileSync(new URL('../build/simulator.html', import.meta.url), 'utf8');
const sleep = ms => new Promise(r => setTimeout(r, ms));
async function open(preset) {
  let now = 0; const rafs = []; const canv = new Map();
  const dom = new JSDOM(html, { runScripts: 'dangerously', beforeParse(w) {
    w.HTMLCanvasElement.prototype.getContext = function () {
      if (!canv.has(this)) canv.set(this, createCanvas(this.width || 800, this.height || 480));
      const c = canv.get(this); if (c.width !== (this.width || 800)) { c.width = this.width; c.height = this.height; }
      return c.getContext('2d');
    };
    w.requestAnimationFrame = cb => rafs.push(cb); w.performance.now = () => now; w.WebAssembly = WebAssembly; w.TextDecoder = TextDecoder; w.TextEncoder = TextEncoder;
  }});
  const w = dom.window, d = w.document;
  await sleep(300);
  const P = { w, d, canv,
    frame(n = 1) { for (let i = 0; i < n && rafs.length; i++) { now += 250; rafs.shift()(now); } },
    click(id, n = 1) { for (let i = 0; i < n; i++) d.getElementById(id).click(); this.frame(); },
    shot(name) { this.frame(); fs.writeFileSync(name, canv.get(d.getElementById('screen')).toBuffer('image/png')); },
    log() { return [...d.querySelectorAll('#log li')].map(li => li.textContent.replace(/\s+/g, ' ').trim()).reverse(); } };
  if (preset) { d.getElementById('preset').value = preset; d.getElementById('preset').dispatchEvent(new w.Event('change')); }
  return P;
}
const fail = []; const ok = (c, m) => { console.log((c ? 'PASS ' : 'FAIL ') + m); if (!c) fail.push(m); };

// 1. presets
for (const preset of (process.env.P||'rec,nitrox,deco,trimix,bad').split(',')) {
  const P = await open(preset);
  P.d.querySelector('[data-speed="60"]').click();
  P.frame(1000);
  const L = P.log(), alarms = L.filter(l => /Alarm/.test(l)).map(l => l.replace(/^\s*\d+:\d+/, ''));
  console.log(`\n${preset}: ${alarms.join(' | ')}`);
  ok(L.some(l => /Surfaced/.test(l)), `${preset}: dive completed`);
  if (preset === 'bad') {
    ok(alarms.some(a => /Too deep for gas/.test(a)), 'bad: too deep for gas alarm');
    ok(alarms.some(a => /Ascent too fast/.test(a)), 'bad: ascent too fast alarm');
  } else {
    ok(!alarms.some(a => /Too deep|Ascent too fast|Low gas|Ceiling/.test(a)), `${preset}: no critical mistakes flagged`);
  }
  P.w.close();
}

// 2. surface menu, Bluetooth, gear sync, dive menu, logs with gear
const P = await open('deco');
const w = P.w, d = P.d;
const until = async (fn, n = 200) => { for (let i = 0; i < n && !fn(); i++) { await sleep(25); P.frame(); } return fn(); };
P.d.querySelector('#run').click();                      // pause the dive clock on the surface
P.click('b-up'); P.click('b-sel');                      // Settings page, open
ok(P.log().some(l => /Settings menu opened/.test(l)), 'surface: settings menu opens');
P.shot('menu_root.png');
P.click('b-down', 5); P.click('b-sel');                 // Deco
P.click('b-sel'); P.click('b-up'); P.click('b-sel');    // GF low +5
ok(d.getElementById('gfl').value === '55', `menu changed GF low and the bench followed (${d.getElementById('gfl').value})`);
P.click('b-down', 6); P.click('b-sel');                 // Back
P.click('b-down', 1); P.click('b-sel');                 // Alarms
P.click('b-down', 3); P.click('b-sel'); P.click('b-up', 3); P.click('b-sel');   // depth alarm 30 m
ok(w.eval('1') && P.log().some(l => /Setting changed/.test(l)), 'depth alarm set from the menu');
P.shot('menu_alarms.png');
P.click('b-down', 5); P.click('b-sel');                 // Back -> Alarms row (3)
P.click('b-down', 4); P.click('b-sel');                 // Bluetooth page
P.click('b-sel');                                       // Bluetooth off
P.shot('menu_bt_off.png');
// phone cannot connect now
d.querySelector('#phone [data-r="connect"]').click();
await until(() => !d.querySelector('#phone [data-r="err"]').hidden);
ok(/Bluetooth is off/.test(d.querySelector('#phone [data-r="err"]').textContent), `phone refused with Bluetooth off: "${d.querySelector('#phone [data-r="err"]').textContent.slice(0, 60)}"`);
P.click('b-sel');                                       // Bluetooth on
d.querySelector('#phone [data-r="connect"]').click();
await until(() => d.querySelector('#phone [data-r="gear"] [data-add]'));
ok(!!d.querySelector('#phone [data-r="gear"] [data-add]'), 'phone connects with Bluetooth on and shows Gear');
P.shot('menu_bt_on.png');
P.click('b-down', 3); P.click('b-sel');                 // Back to root (cursor on Bluetooth)

// add gear on the phone
const G = () => d.querySelector('#phone [data-r="gear"]');
const add = (type) => { G().querySelector('[data-r="newtype"]').value = String(type); G().querySelector('[data-add]').click(); };
const setLast = (field, v) => { const els = G().querySelectorAll(`[data-g="${field}"]`); const el = els[els.length - 1]; if (el.type === 'checkbox') el.checked = v; else el.value = v; el.dispatchEvent(new w.Event('change')); };
add(1); setLast('name', 'Faber 24L twin'); setLast('size', 24); setLast('serial', 104300);
add(1); setLast('name', 'Alu 11L stage'); setLast('size', 11.1); setLast('serial', 105411);
add(5); setLast('name', 'Belt'); setLast('size', 4);
add(4); setLast('name', 'Drysuit'); setLast('size', 0);
add(2); setLast('name', 'Apeks XTX50');
add(6); setLast('name', 'Spare light'); setLast('onDive', false);
let sel = G().querySelector('[data-gc="0"]'); sel.value = '0'; sel.dispatchEvent(new w.Event('change'));
sel = G().querySelector('[data-gc="1"]'); sel.value = '1'; sel.dispatchEvent(new w.Event('change'));
G().querySelector('[data-sync]').click();
await until(() => /Synced:/.test(G().querySelector('[data-r="gearmsg"]').textContent));
ok(/Synced: 5 items/.test(G().querySelector('[data-r="gearmsg"]').textContent), `gear synced: ${G().querySelector('[data-r="gearmsg"]').textContent.slice(0, 50)}`);
ok(d.getElementById('g0c').value === '24' && d.getElementById('g1c').value === '11', `cylinders reached the gas settings (${d.getElementById('g0c').value} L, ${d.getElementById('g1c').value} L)`);
ok(w.eval('0') === 0 && P.log().some(l => /Gear synced/.test(l)), 'device logged the sync');
console.log('BENCH', [0,1,2].map(i=>[d.getElementById(`g${i}o`).value,d.getElementById(`g${i}h`).value,d.getElementById(`g${i}e`).checked,d.getElementById(`g${i}c`).value,d.getElementById(`g${i}f`).value].join('/')).join('  '), d.getElementById('gfl').value, d.getElementById('gfh').value);
// device gear check page
P.click('b-up', 8); P.click('b-sel');                  // root cursor 7 -> up 6 = Gear (1)
P.shot('menu_gear.png');
const gearTxt = []; // read rows through the canvas-independent API
const X = w.eval('null');
P.click('b-down', 20); 
// back out & exit
P.click('b-up', 20);
// find Back: last row; press up once from first row wraps to last (Back)
P.click('b-up'); P.click('b-sel'); P.click('b-up', 3); P.click('b-sel');
ok(P.log().some(l => /menu closed/.test(l)), 'settings menu exits');

// compass lock from the dive menu during the dive
d.getElementById('hdg').value = 45; d.getElementById('hdg').dispatchEvent(new w.Event('input'));
P.d.querySelector('#run').click(); P.frame(300); P.d.querySelector('#run').click();   // to the bottom, paused

await until(() => !d.querySelector('#phone [data-r="err"]').hidden, 100);
ok(/Lost the dive computer|dive has started/.test(d.querySelector('#phone [data-r="err"]').textContent), 'phone dropped when the dive started');
P.click('b-sel');                                        // still on Settings page: dive menu
ok(P.log().some(l => /Dive menu opened/.test(l)), 'underwater the dive menu opens');
P.shot('menu_dive.png');
P.click('b-sel');                                        // Switch to EAN50: too deep
ok(P.log().some(l => /too rich for 40 m: switch refused/.test(l)), 'EAN50 refused at 40 m from the dive menu');
P.click('b-down'); P.click('b-sel');                     // Lock bearing
ok(P.log().some(l => /Bearing locked at 45/.test(l)), 'bearing locked from the dive menu');
d.getElementById('hdg').value = 10; d.getElementById('hdg').dispatchEvent(new w.Event('input'));
P.shot('compass_dive.png');
P.click('b-up', 4); P.shot('main_dive.png');

// finish the dive, reconnect, export
P.d.querySelector('#run').click(); P.d.querySelector('[data-speed="60"]').click();
P.frame(1000);
P.d.querySelector('#run').click();
ok(P.log().some(l => /Depth alarm/.test(l)), 'depth alarm (30 m) fired');
d.querySelector('#phone [data-r="connect"]').click();
await until(() => d.querySelectorAll('#phone [data-r="logs"] tbody tr').length === 1);
ok(d.querySelectorAll('#phone [data-r="logs"] tbody tr').length === 1, 'phone reconnects after the dive and lists it');
d.querySelector('#phone [data-r="export"]').click();
await until(() => d.querySelector('#phone textarea'), 400);
const xml = d.querySelector('#phone textarea') ? d.querySelector('#phone textarea').value : '';
fs.writeFileSync('phone_export.uddf', xml);
ok(/<equipmentused>/.test(xml) && /Faber 24L twin/.test(xml) && /<leadquantity>4\.0<\/leadquantity>/.test(xml) && !/Spare light/.test(xml) && /<greatestdepth>40\.\d\d/.test(xml),
   `UDDF has the gear used on the dive (${xml.length} chars)`);
// turn Bluetooth off from the phone
d.querySelector('#ph-bt').checked = false;
d.querySelector('#phone [data-r="form"]').dispatchEvent(new w.Event('submit', { cancelable: true }));
await until(() => /Bluetooth is now off/.test(d.querySelector('#phone [data-r="err"]').textContent));
ok(/Bluetooth is now off/.test(d.querySelector('#phone [data-r="err"]').textContent), 'turning Bluetooth off from the phone disconnects it');
fs.writeFileSync('phone_panel.html', d.getElementById('phone').outerHTML);
P.w.close();

console.log(fail.length ? `\n${fail.length} FAILED` : '\nALL PASSED');
