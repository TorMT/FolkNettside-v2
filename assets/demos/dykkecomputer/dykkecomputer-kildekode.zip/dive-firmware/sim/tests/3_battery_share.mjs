import { JSDOM } from 'jsdom';
import { createCanvas } from '@napi-rs/canvas';
import fs from 'fs';
const html = fs.readFileSync(new URL('../build/simulator.html', import.meta.url), 'utf8');
const sleep = ms => new Promise(r => setTimeout(r, ms));
async function open(preset) {
  let now = 0; const rafs = []; const canv = new Map();
  const dom = new JSDOM(html, { runScripts: 'dangerously', beforeParse(w) {
    w.HTMLCanvasElement.prototype.getContext = function () {
      if (!canv.has(this)) canv.set(this, createCanvas(this.width || 800, this.height || 480));
      const c = canv.get(this); if (c.width !== (this.width || 800)) { c.width = this.width; c.height = this.height; }
      return c.getContext('2d');
    };
    w.requestAnimationFrame = cb => rafs.push(cb); w.performance.now = () => now; w.WebAssembly = { ...WebAssembly, instantiate: async (...a) => { const r = await WebAssembly.instantiate(...a); w.__X = r.instance.exports; return r; } }; w.TextDecoder = TextDecoder; w.TextEncoder = TextEncoder;
  }});
  const w = dom.window, d = w.document;
  await sleep(300);
  const P = { w, d, canv,
    frame(n = 1) { for (let i = 0; i < n && rafs.length; i++) { now += 250; rafs.shift()(now); } },
    click(id, n = 1) { for (let i = 0; i < n; i++) d.getElementById(id).click(); this.frame(); },
    shot(name) { this.frame(); fs.writeFileSync(name, canv.get(d.getElementById('screen')).toBuffer('image/png')); },
    log() { return [...d.querySelectorAll('#log li')].map(li => li.textContent.replace(/\s+/g, ' ').trim()).reverse(); } };
  if (preset) { d.getElementById('preset').value = preset; d.getElementById('preset').dispatchEvent(new w.Event('change')); }
  return P;
}
const fail = []; const ok = (c, m) => { console.log((c ? 'PASS ' : 'FAIL ') + m); if (!c) fail.push(m); };
const menu = P => { const X = P.w.__X, m = new Uint8Array(X.memory.buffer), cs = p => { let e = p; while (m[e]) e++; return Buffer.from(m.subarray(p, e)).toString(); };
  const n = X.sim_menu_rows(); const r = []; for (let i = 0; i < n; i++) r.push(`${cs(X.sim_menu_label(i))}=${cs(X.sim_menu_value(i))}`); return r; };
const settle = async P => { for (let i = 0; i < 40; i++) { await sleep(30); P.frame(); } };

const P = await open('deco');
const { d, w } = P;
d.querySelector('#run').click();
const batt = d.getElementById('batt'); batt.value = 25; batt.dispatchEvent(new w.Event('input'));
d.getElementById('tx-weak').checked = true;
P.shot('surface_battery.png');
ok(P.w.__X.sim_battery() === 25 && !P.w.__X.sim_battery_ok(), 'battery 25 %: charge before diving');
batt.value = 90; batt.dispatchEvent(new w.Event('input'));
d.querySelector('[data-speed="60"]').click(); d.querySelector('#run').click();
P.frame(150); d.querySelector('#run').click();
P.click('b-up', 7); P.shot('tanks_weak.png'); P.click('b-down', 7);
const L = P.log();
ok(L.some(l => /Transmitter battery weak/.test(l)), 'weak transmitter battery warns underwater');
ok(P.w.__X.sim_battery() < 90 && P.w.__X.sim_battery() > 80, `battery drains while diving (${P.w.__X.sim_battery()} %)`);
d.querySelector('#run').click(); P.frame(1000); d.querySelector('#run').click();
d.querySelector('#phone [data-r="connect"]').click(); await settle(P);
const info = d.querySelector('#phone [data-r="info"]').textContent.replace(/\s+/g, ' ');
ok(/Battery.*\d+ %/.test(info), `phone shows computer battery (${info.slice(0, 80)})`);
const tk = d.querySelector('#phone [data-r="tanks"]').textContent.replace(/\s+/g, ' ');
ok(/T1.*weak, replace/.test(tk) && /T2.*OK/.test(tk), `phone shows transmitter batteries (${tk.slice(0, 160)})`);
d.querySelector('#phone [data-share]').click(); await settle(P);
const cv = d.querySelector('#phone canvas.ph-card');
ok(!!cv && cv.width === 1080, 'share card drawn');
const site = d.querySelector('#ph-site'); site.value = 'Gulosen, Trondheimsfjorden'; site.dispatchEvent(new w.Event('input')); await settle(P);
if (cv) fs.writeFileSync('share_card.png', P.canv.get(cv).toBuffer('image/png'));
d.querySelector('#phone [data-go]').click(); await settle(P);
ok(/preview|share sheet/.test(d.querySelector('#phone [data-msg]').textContent), 'share button explains preview in the simulator');
P.w.close();
console.log(fail.length ? `\n${fail.length} FAILED` : '\nALL PASSED');
