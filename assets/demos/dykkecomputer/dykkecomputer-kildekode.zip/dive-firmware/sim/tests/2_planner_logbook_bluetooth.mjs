import { JSDOM } from 'jsdom';
import { createCanvas } from '@napi-rs/canvas';
import fs from 'fs';
const html = fs.readFileSync(new URL('../build/simulator.html', import.meta.url), 'utf8');
const sleep = ms => new Promise(r => setTimeout(r, ms));
async function open(preset) {
  let now = 0; const rafs = []; const canv = new Map();
  const dom = new JSDOM(html, { runScripts: 'dangerously', beforeParse(w) {
    w.HTMLCanvasElement.prototype.getContext = function () {
      if (!canv.has(this)) canv.set(this, createCanvas(this.width || 800, this.height || 480));
      const c = canv.get(this); if (c.width !== (this.width || 800)) { c.width = this.width; c.height = this.height; }
      return c.getContext('2d');
    };
    w.requestAnimationFrame = cb => rafs.push(cb); w.performance.now = () => now; w.WebAssembly = { ...WebAssembly, instantiate: async (...a) => { const r = await WebAssembly.instantiate(...a); w.__X = r.instance.exports; return r; } }; w.TextDecoder = TextDecoder; w.TextEncoder = TextEncoder;
  }});
  const w = dom.window, d = w.document;
  await sleep(300);
  const P = { w, d, canv,
    frame(n = 1) { for (let i = 0; i < n && rafs.length; i++) { now += 250; rafs.shift()(now); } },
    click(id, n = 1) { for (let i = 0; i < n; i++) d.getElementById(id).click(); this.frame(); },
    shot(name) { this.frame(); fs.writeFileSync(name, canv.get(d.getElementById('screen')).toBuffer('image/png')); },
    log() { return [...d.querySelectorAll('#log li')].map(li => li.textContent.replace(/\s+/g, ' ').trim()).reverse(); } };
  if (preset) { d.getElementById('preset').value = preset; d.getElementById('preset').dispatchEvent(new w.Event('change')); }
  return P;
}
const fail = []; const ok = (c, m) => { console.log((c ? 'PASS ' : 'FAIL ') + m); if (!c) fail.push(m); };
const menu = P => { const X = P.w.__X, m = new Uint8Array(X.memory.buffer), cs = p => { let e = p; while (m[e]) e++; return Buffer.from(m.subarray(p, e)).toString(); };
  const n = X.sim_menu_rows(); const r = []; for (let i = 0; i < n; i++) r.push(`${cs(X.sim_menu_label(i))}=${cs(X.sim_menu_value(i))}`); return r; };
const settle = async P => { for (let i = 0; i < 40; i++) { await sleep(30); P.frame(); } };

const P = await open('rec');
const { d, w } = P;
d.querySelector('#run').click();                    // pause on the surface
P.click('b-up'); P.click('b-sel');                  // Settings page, open the surface menu
let rows = menu(P);
console.log(rows.join(' | '));
ok(rows[0].startsWith('Pre-dive check') && rows.some(r => r.startsWith('Dive planner')) && rows.some(r => r.startsWith('Logbook')) && rows.some(r => r.startsWith('Bluetooth')), 'surface menu has planner, logbook and Bluetooth');
P.click('b-down', 3); P.click('b-sel');             // Dive planner
rows = menu(P); console.log(rows.join(' | '));
ok(rows[0] === 'No-fly=clear' && rows.some(r => /^18 m=\d+ min|^18 m=99\+ min/.test(r)), 'planner shows NDLs and no-fly');
P.shot('menu_planner.png');
P.click('b-up'); P.click('b-sel');                  // Back (last row)
P.click('b-down'); P.click('b-sel');                // Logbook
rows = menu(P); ok(rows[0] === 'Dives stored=0', `empty logbook (${rows[0]})`);
P.click('b-up'); P.click('b-sel');
// Bluetooth off
P.click('b-down', 6); P.click('b-sel'); rows = menu(P); console.log(rows.join(' | '));
P.click('b-sel');                                   // toggle Bluetooth
rows = menu(P); ok(rows[0] === 'Bluetooth=Off', 'Bluetooth switched off from the menu');
P.shot('menu_bt_off2.png');
d.querySelector('#phone [data-r="connect"]').click(); await settle(P);
const err = d.querySelector('#phone [data-r="err"]').textContent;
ok(!d.querySelector('#phone [data-r="body"]').hidden === false && /Bluetooth/.test(err), `phone cannot connect with Bluetooth off (${err})`);
P.click('b-sel'); rows = menu(P); ok(rows[0] === 'Bluetooth=On', 'Bluetooth back on');
P.click('b-up'); P.click('b-sel'); P.click('b-down', 2); P.click('b-sel');   // Back, Exit
ok(!P.w.__X.sim_menu_is_open(), 'menu closed');

// phone: add gear and sync
d.querySelector('#phone [data-r="connect"]').click(); await settle(P);
ok(!d.querySelector('#phone [data-r="body"]').hidden, 'phone connects with Bluetooth on');
const gearBtn = [...d.querySelectorAll('#phone button')].find(b => /Add item/.test(b.textContent));
const syncBtn = [...d.querySelectorAll('#phone button')].find(b => /Sync gear/.test(b.textContent));
ok(!!gearBtn && !!syncBtn, 'phone has gear editor with sync');
if (gearBtn) {
  gearBtn.click(); await settle(P);
  const names = d.querySelectorAll('#phone input[aria-label*="name" i]');
  if (names.length) { names[names.length - 1].value = 'Faber 15L'; names[names.length - 1].dispatchEvent(new w.Event('input', { bubbles: true })); names[names.length - 1].dispatchEvent(new w.Event('change', { bubbles: true })); }
  const sel = d.querySelector('#phone select[aria-label*="Gas 1" i]');
  if (sel) { sel.value = sel.options[sel.options.length - 1].value; sel.dispatchEvent(new w.Event('change', { bubbles: true })); }
  [...d.querySelectorAll('#phone button')].find(b => /Sync gear/.test(b.textContent)).click(); await settle(P);
  ok(P.w.__X.sim_gear_count() >= 1, `gear synced to the computer (${P.w.__X.sim_gear_count()} items)`);
}

// dive: phone drops, dive menu is the short one
d.querySelector('[data-speed="60"]').click(); d.querySelector('#run').click();
P.frame(60); await settle(P);
ok(d.querySelector('#phone [data-r="body"]').hidden, 'phone dropped when the dive started');
d.querySelector('#run').click();
P.click('b-sel'); rows = menu(P); console.log('dive menu: ' + rows.join(' | '));
ok(rows.some(r => /Lock bearing/.test(r)) && !rows.some(r => /Gases|Deco|Bluetooth|planner/i.test(r)), 'dive menu is short: no settings underwater');
P.shot('menu_dive2.png');
P.click('b-up'); P.click('b-sel');                  // Back to dive
d.querySelector('#run').click(); P.frame(1000); d.querySelector('#run').click();
// after the dive: logbook and planner with repeat-dive tissues
P.click('b-sel'); P.click('b-down', 4); P.click('b-sel'); rows = menu(P); console.log(rows.join(' | '));
ok(rows[0] === 'Dives stored=1' && /^#1 /.test(rows[1]), 'logbook lists the dive');
P.shot('menu_logbook.png');
P.click('b-up'); P.click('b-sel'); P.click('b-up'); P.click('b-sel'); rows = menu(P); console.log(rows.join(' | '));
ok(rows[0] !== 'No-fly=clear', `no-fly time after the dive (${rows[0]})`);
P.shot('menu_planner_after.png');
P.w.close();
console.log(fail.length ? `\n${fail.length} FAILED` : '\nALL PASSED');
