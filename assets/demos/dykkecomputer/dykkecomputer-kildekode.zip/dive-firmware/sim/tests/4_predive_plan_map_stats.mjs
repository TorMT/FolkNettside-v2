import { JSDOM } from 'jsdom';
import { createCanvas } from '@napi-rs/canvas';
import fs from 'fs';
const html = fs.readFileSync(new URL('../build/simulator.html', import.meta.url), 'utf8');
const sleep = ms => new Promise(r => setTimeout(r, ms));
async function open(preset) {
  let now = 0; const rafs = []; const canv = new Map();
  const dom = new JSDOM(html, { runScripts: 'dangerously', beforeParse(w) {
    w.HTMLCanvasElement.prototype.getContext = function () {
      if (!canv.has(this)) canv.set(this, createCanvas(this.width || 800, this.height || 480));
      const c = canv.get(this); if (c.width !== (this.width || 800)) { c.width = this.width; c.height = this.height; }
      return c.getContext('2d');
    };
    w.requestAnimationFrame = cb => rafs.push(cb); w.performance.now = () => now; w.WebAssembly = { ...WebAssembly, instantiate: async (...a) => { const r = await WebAssembly.instantiate(...a); w.__X = r.instance.exports; return r; } }; w.TextDecoder = TextDecoder; w.TextEncoder = TextEncoder;
  }});
  const w = dom.window, d = w.document;
  await sleep(300);
  const P = { w, d, canv,
    frame(n = 1) { for (let i = 0; i < n && rafs.length; i++) { now += 250; rafs.shift()(now); } },
    click(id, n = 1) { for (let i = 0; i < n; i++) d.getElementById(id).click(); this.frame(); },
    shot(name) { this.frame(); fs.writeFileSync(name, canv.get(d.getElementById('screen')).toBuffer('image/png')); },
    log() { return [...d.querySelectorAll('#log li')].map(li => li.textContent.replace(/\s+/g, ' ').trim()).reverse(); } };
  if (preset) { d.getElementById('preset').value = preset; d.getElementById('preset').dispatchEvent(new w.Event('change')); }
  return P;
}
const fail = []; const ok = (c, m) => { console.log((c ? 'PASS ' : 'FAIL ') + m); if (!c) fail.push(m); };
const menu = P => { const X = P.w.__X, m = new Uint8Array(X.memory.buffer), cs = p => { let e = p; while (m[e]) e++; return Buffer.from(m.subarray(p, e)).toString(); };
  const n = X.sim_menu_rows(); const r = []; for (let i = 0; i < n; i++) r.push(`${cs(X.sim_menu_label(i))}=${cs(X.sim_menu_value(i))}`); return r; };
const settle = async P => { for (let i = 0; i < 40; i++) { await sleep(30); P.frame(); } };

const P = await open('deco');
const { d, w } = P, X = () => P.w.__X;
const until = async (fn, n = 300) => { for (let i = 0; i < n && !fn(); i++) { await sleep(25); P.frame(); } return fn(); };
d.querySelector('#run').click();                                  // pause on the surface
P.shot('surface_check.png');
ok(X().sim_predive(0) === 1, `surface: things to check before any sync (${X().sim_predive(1)} warnings)`);

// phone: check list, plan, send
d.querySelector('#phone [data-r="connect"]').click();
await until(() => d.querySelector('#phone [data-r="check"] li'));
const chk = () => d.querySelector('#phone [data-r="check"]').textContent.replace(/\s+/g, ' ');
ok(/to check/.test(chk()) && /Phone sync/.test(chk()) && /never synced/.test(chk()), `phone shows the check (${chk().slice(0, 90)})`);
const plan = () => d.querySelector('#phone [data-r="plan"]');
plan().querySelector('#ph-pd').value = 40; plan().querySelector('#ph-pb').value = 25; plan().querySelector('#ph-ps').value = 14;
plan().querySelector('[data-calc]').click(); await settle(P);
const ptxt = plan().textContent.replace(/\s+/g, ' ');
console.log('PLAN', ptxt.slice(ptxt.indexOf('Run time'), ptxt.indexOf('Send plan')));
ok(/Run time\s*\d+ min/.test(ptxt) && /Stops.*3 m \d+'/.test(ptxt) && /Gas 1 Air\s*\d+ bar needed of 220 bar/.test(ptxt), 'planner shows run time, stops and gas');
plan().querySelector('[data-send]').click();
await until(() => X().sim_plan(0) === 1);
ok(X().sim_plan(1) === 40 && X().sim_plan(2) === 25 && X().sim_plan(5) >= 3, `plan on the computer: ${X().sim_plan(1)} m ${X().sim_plan(2)} min, ${X().sim_plan(5)} stops, run ${X().sim_plan(3)} min`);
// a plan that needs more gas than the cylinder holds
plan().querySelector('#ph-pb').value = 60; plan().querySelector('[data-calc]').click(); await settle(P);
ok(/not enough/.test(plan().textContent) && plan().querySelector('[data-send]').disabled, 'a plan without enough gas cannot be sent');
P.shot('surface_plan.png');
fs.writeFileSync('phone_plan.html', d.querySelector('#phone').outerHTML);

// menu: pre-dive page and plan page
P.click('b-up'); P.click('b-sel'); let rows = menu(P); console.log(rows.join(' | '));
ok(rows[0].startsWith('Pre-dive check=') && rows[1].startsWith('Dive plan=40 m 25 min'), 'menu starts with the check and the plan');
P.click('b-sel'); rows = menu(P); console.log(rows.join(' | ')); P.shot('menu_check.png');
ok(rows.some(r => /^Battery=\d+ %$/.test(r)) && rows.some(r => /^Plan=40 m 25 min, gas fits/.test(r)), 'check page lists battery and plan');
P.click('b-up'); P.click('b-sel'); P.click('b-down'); P.click('b-sel'); rows = menu(P); console.log(rows.join(' | ')); P.shot('menu_plan.png');
ok(rows[0] === 'Plan=40 m  25 min' && rows.some(r => /^Stop 3 m=\d+ min/.test(r)), 'plan page shows the stops');
P.click('b-up'); P.click('b-sel'); P.click('b-up', 2); P.click('b-sel');   // Back, Exit
ok(!X().sim_menu_is_open(), 'menu closed');
P.click('b-down');                                                // back to Main

// dive it on autopilot (deco preset is the same 40 m / 25 min): on plan, no plan warnings; track logged
d.querySelector('[data-speed="60"]').click(); d.querySelector('#run').click();
P.frame(120); d.querySelector('#run').click();
P.click('b-down', 2); P.shot('deco_plan.png'); P.click('b-up', 2);
d.querySelector('#run').click(); P.frame(900); d.querySelector('#run').click();
const L = P.log();
ok(!L.some(l => /Deeper than the plan|Past the planned|More deco/.test(l)), `on plan: no plan warnings (${L.filter(l => /Alarm/.test(l)).join('; ')})`);
ok(L.some(l => /Surfaced/.test(l)), 'dive finished');

// phone again: archive, stats, sites map, share card with map
await sleep(1300); P.frame(); await settle(P);                    // the app's poll notices the dive and drops
if (/Disconnect/.test(d.querySelector('#phone [data-r="connect"]').textContent)) d.querySelector('#phone [data-r="connect"]').click();
d.querySelector('#phone [data-r="connect"]').click();
await until(() => /dives/.test(d.querySelector('#phone [data-r="stats"]').textContent));
const st = d.querySelector('#phone [data-r="stats"]').textContent.replace(/\s+/g, ' ');
ok(/1\s*dives/.test(st) && /40\.0 m\s*deepest/.test(st) && /Deepest\s*40\.0 m\s*#1/.test(st), `statistics (${st.slice(0, 110)})`);
await until(() => d.querySelector('#phone [data-r="sites"] canvas'));
const sites = d.querySelector('#phone [data-r="sites"]').textContent.replace(/\s+/g, ' ');
ok(/1 dive\s*63\.4305, 10\.3951/.test(sites), `dive site from the computer's fix (${sites})`);
await settle(P);
fs.writeFileSync('sites_map.png', P.canv.get(d.querySelector('#phone [data-r="sites"] canvas')).toBuffer('image/png'));
d.querySelector('#phone [data-share]').click();
await until(() => d.querySelector('#phone canvas.ph-card'));
const site = d.querySelector('#ph-site'); site.value = 'Munkholmen'; site.dispatchEvent(new w.Event('input')); await settle(P); await settle(P);
fs.writeFileSync('share_card_map.png', P.canv.get(d.querySelector('#phone canvas.ph-card')).toBuffer('image/png'));
ok(true, 'share card with map drawn');
fs.writeFileSync('phone_stats.html', d.querySelector('#phone').outerHTML);

// plan warnings: a shorter plan, then dive the 40 m preset again
plan().querySelector('#ph-pd').value = 30; plan().querySelector('#ph-pb').value = 15; plan().querySelector('[data-calc]').click(); await settle(P);
plan().querySelector('[data-send]').click(); await until(() => X().sim_plan(1) === 30);
d.querySelector('#reset').click(); P.frame(2);
d.querySelector('#run').click(); P.frame(160); d.querySelector('#run').click();
P.shot('main_offplan.png');
const L2 = P.log();
ok(L2.some(l => /Deeper than the plan/.test(l)) && L2.some(l => /Past the planned bottom time/.test(l)), 'off plan: deeper and over-time warnings');

// sleep and wake
if (/Disconnect/.test(d.querySelector('#phone [data-r="connect"]').textContent)) d.querySelector('#phone [data-r="connect"]').click();   // a connected phone keeps it awake
d.querySelector('#reset').click(); P.frame(2);
d.querySelector('[data-mode="manual"]').click(); d.getElementById('target').value = 0; d.getElementById('target').dispatchEvent(new w.Event('input'));
if (d.querySelector('#run').textContent === 'Run') d.querySelector('#run').click();
P.frame(60);                                                       // 15 min of sim time, dry, idle
ok(X().sim_out(0) === 0, `asleep after 10 dry minutes (state ${X().sim_out(0)})`);
P.click('b-up'); ok(X().sim_out(0) === 1, 'a button wakes it');
P.frame(60); ok(X().sim_out(0) === 0, 'sleeps again');
d.getElementById('target').value = 2; d.getElementById('target').dispatchEvent(new w.Event('input')); P.frame(2);
ok(X().sim_out(0) !== 0, 'getting wet wakes it');
// backlight follows the light
d.getElementById('lux').value = 4.5; d.getElementById('lux').dispatchEvent(new w.Event('input'));
const b1 = X().sim_backlight(30000), b2 = X().sim_backlight(2);
ok(b1 === 100 && b2 < 50, `auto backlight ${b1} % in daylight, ${b2} % at depth`);
P.w.close();
console.log(fail.length ? `\n${fail.length} FAILED` : '\nALL PASSED');
