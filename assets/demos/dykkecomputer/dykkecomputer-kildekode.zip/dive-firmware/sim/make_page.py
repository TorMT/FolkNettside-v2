"""Build the simulator page and the phone app page: python3 sim/make_page.py

sim/build/simulator.html, app.html   for sandboxed previews (the simulator is a page body without a document wrapper)
sim/build/web/simulator.html, app.html   complete documents for an ordinary web host such as GitHub Pages:
                                         saving files and OpenStreetMap tiles are switched on
"""
import base64, pathlib
root = pathlib.Path(__file__).parent
wasm = base64.b64encode((root / "build" / "divecore.wasm").read_bytes()).decode()
phone = (root / "phone.js").read_text()
web = root / "build" / "web"
web.mkdir(parents=True, exist_ok=True)
HEAD = """<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<script>window.DC_WEB = true;</script>
"""
for src, dst in [("simulator.template.html", "simulator.html"), ("app.template.html", "app.html")]:
    html = (root / src).read_text().replace("__PHONE_JS__", phone).replace("__WASM_B64__", wasm)
    (root / "build" / dst).write_text(html)
    print(f"wrote sim/build/{dst} ({len(html)} bytes)")
    if html.lstrip().lower().startswith("<!doctype"):
        page = html.replace("<head>", "<head>\n<script>window.DC_WEB = true;</script>", 1)
    else:
        page = HEAD + html + "\n</html>\n"     # the browser closes <head> at the first page element
    (web / dst).write_text(page)
    print(f"wrote sim/build/web/{dst} ({len(page)} bytes)")
