/*
 * sim_api.c — thin WebAssembly interface to divecore for the browser simulator.
 * The simulator runs exactly the same deco, oxygen, state machine and transmitter
 * code as the ESP32 firmware.
 */
#include <math.h>
#include <stdio.h>
#include <string.h>

#include "divecore/dive.h"
#include "divecore/divelog.h"
#include "divecore/gear.h"
#include "divecore/hw.h"
#include "divecore/plan.h"
#include "divecore/predive.h"
#include "divecore/menu.h"
#include "divecore/proto.h"
#include "divecore/settings.h"
#include "divecore/nav.h"
#include "divecore/txdsp.h"

#define EXPORT __attribute__((visibility("default")))

static dive_t D;
static nav_t N;
static float load_pct[DC_NUM_TISSUES];
static float sig[24000];
static uint32_t seed = 12345;
static int tx_ok, tx_bad;

/* ---- settings fields, shared by the bench, the menu test and the phone app ---- */
int sim_field_get(const dc_settings_t *s, int code, int i);
void sim_field_set(dc_settings_t *s, int code, int i, int v);
#define st_get sim_field_get
#define st_set sim_field_set
int sim_field_get(const dc_settings_t *s, int code, int i)
{
    if (i < 0 || i >= DC_MAX_GASES) i = 0;
    switch (code) {
    case 0: return s->gas[i].o2_pct;
    case 1: return s->gas[i].he_pct;
    case 2: return s->gas[i].enabled;
    case 3: return s->gas[i].cylinder_l;
    case 4: return s->gas[i].fill_bar;
    case 5: return (int)s->gas[i].tx_serial;
    case 10: return s->gf_low;
    case 11: return s->gf_high;
    case 12: return s->water;
    case 13: return s->last_stop_m;
    case 14: return s->ppo2_bottom_x100;
    case 15: return s->ppo2_deco_x100;
    case 16: return s->reserve_bar;
    case 17: return s->ascent_alarm_mpm;
    case 18: return s->brightness;
    case 19: return s->pairing;
    case 20: return s->declination_deg;
    case 21: return s->safety_stop;
    case 22: return s->bluetooth;
    case 23: return s->depth_alarm_m;
    case 24: return s->time_alarm_min;
    case 25: return s->ndl_warn_min;
    case 26: return s->turn_margin_bar;
    case 27: return s->flip;
    case 28: return s->log_interval_s;
    case 29: return s->vibrate;
    case 30: return s->sound;
    case 31: return s->auto_bright;
    case 32: return s->sleep_min;
    default: return 0;
    }
}

void sim_field_set(dc_settings_t *s, int code, int i, int v)
{
    if (i < 0 || i >= DC_MAX_GASES) i = 0;
    switch (code) {
    case 0: s->gas[i].o2_pct = (uint8_t)v; break;
    case 1: s->gas[i].he_pct = (uint8_t)v; break;
    case 2: s->gas[i].enabled = (uint8_t)v; break;
    case 3: s->gas[i].cylinder_l = (uint8_t)v; break;
    case 4: s->gas[i].fill_bar = (uint16_t)v; break;
    case 5: s->gas[i].tx_serial = (uint32_t)v; break;
    case 10: s->gf_low = (uint8_t)v; break;
    case 11: s->gf_high = (uint8_t)v; break;
    case 12: s->water = (uint8_t)v; break;
    case 13: s->last_stop_m = (uint8_t)v; break;
    case 14: s->ppo2_bottom_x100 = (uint8_t)v; break;
    case 15: s->ppo2_deco_x100 = (uint8_t)v; break;
    case 16: s->reserve_bar = (uint8_t)v; break;
    case 17: s->ascent_alarm_mpm = (uint8_t)v; break;
    case 18: s->brightness = (uint8_t)v; break;
    case 19: s->pairing = (uint8_t)v; break;
    case 20: s->declination_deg = (int8_t)v; break;
    case 21: s->safety_stop = (uint8_t)v; break;
    case 22: s->bluetooth = (uint8_t)v; break;
    case 23: s->depth_alarm_m = (uint8_t)v; break;
    case 24: s->time_alarm_min = (uint16_t)v; break;
    case 25: s->ndl_warn_min = (uint8_t)v; break;
    case 26: s->turn_margin_bar = (uint8_t)v; break;
    case 27: s->flip = (uint8_t)v; break;
    case 28: s->log_interval_s = (uint8_t)v; break;
    case 29: s->vibrate = (uint8_t)v; break;
    case 30: s->sound = (uint8_t)v; break;
    case 31: s->auto_bright = (uint8_t)v; break;
    case 32: s->sleep_min = (uint8_t)v; break;
    }
}

/* ---- the simulated device: settings, menu, log store, phone protocol ---- */
static dc_settings_t S;
static dc_gear_t G;
static dc_divplan_t PL;
static predive_t PD;
static alarm_notifier_t AN;
static int depth_sensors = 2;
static double gnss_lat = 63.4305, gnss_lon = 10.3951;
static int phone_connected;
static menu_t M;
static menu_row_t rows[MENU_MAX_ROWS];
static char menu_title[24];
static int n_rows;

#define LOG_STORE (768 * 1024)
#define MAX_LOGS 64
static uint8_t logmem[LOG_STORE];
static int log_off[MAX_LOGS], log_len[MAX_LOGS], n_logs, log_used;
static divelog_writer_t LW;
static int logging = -1;           /* index being written, -1 when not diving */
static uint32_t clock_unix;        /* simulated wall clock */
static dive_state_t last_state;

static uint8_t io_req[1024], io_resp[4096];
static uint32_t ota_size, ota_next, ota_crc;
static char fw_version[32] = "0.1.0-sim";
static proto_dev_t P;

static int lc(void *c) { (void)c; return n_logs; }
static int ls(void *c, int i) { (void)c; return (i >= 0 && i < n_logs) ? log_len[i] : 0; }
static int lr(void *c, int i, uint32_t off, uint8_t *buf, int len)
{
    (void)c;
    if (i < 0 || i >= n_logs) return -1;
    if ((int)off >= log_len[i]) return 0;
    if ((int)off + len > log_len[i]) len = log_len[i] - (int)off;
    memcpy(buf, logmem + log_off[i] + off, (size_t)len);
    return len;
}
static bool store(void *c, const dc_settings_t *s)
{
    (void)c;
    S = *s;
    settings_apply(&S, &D);
    return true;
}
static bool store_plan(void *c, const dc_divplan_t *p)
{
    (void)c;
    (void)p;        /* proto already copied it into PL */
    return true;
}
static void refresh_predive(void)
{
    predive_env_t env = {.depth_sensors = depth_sensors, .now_unix = clock_unix};
    predive_run(&D, &S, &G, &PL, &env, &PD);
}
static bool store_gear(void *c, const dc_gear_t *g)
{
    (void)c;
    G = *g;
    return true;
}
static int ota(void *c, int step, uint32_t value, const uint8_t *data, int len)
{
    (void)c;
    if (step == OTA_BEGIN) {
        if (value == 0 || value > 4u * 1024u * 1024u) return ST_FAILED;
        ota_size = value; ota_next = 0; ota_crc = 0xFFFFFFFFu;
        return ST_OK;
    }
    if (step == OTA_DATA) {
        if (value != ota_next || ota_next + (uint32_t)len > ota_size) return ST_BAD_REQUEST;
        dc_crc32_feed(&ota_crc, data, len);
        ota_next += (uint32_t)len;
        return ST_OK;
    }
    if (ota_next != ota_size || ~ota_crc != value) return ST_CRC;
    snprintf(fw_version, sizeof(fw_version), "0.1.1-sim (%lu bytes)", (unsigned long)ota_size);
    return ST_OK;
}

/* Reset the dive state (logs and settings are kept). Call sim_st_apply() after setting fields. */
EXPORT void sim_reset(float gf_low, float gf_high, int water)
{
    (void)gf_low; (void)gf_high; (void)water;
    if (S.gf_high == 0) settings_default(&S);
    dive_init(&D);
    settings_apply(&S, &D);
    menu_init(&M, &S);
    M.gear = &G;
    M.dive = &D;
    M.predive = &PD;
    M.plan = &PL;
    alarm_notifier_init(&AN);
    logging = -1;
    last_state = D.state;
    P = (proto_dev_t){.log_count = lc, .log_size = ls, .log_read = lr, .settings_store = store, .ota = ota,
                      .gear_store = store_gear, .settings = &S, .gear = &G, .dive = &D, .fw_version = fw_version,
                      .battery_pct = 87, .plan = &PL, .plan_store = store_plan, .depth_sensors = depth_sensors};
    refresh_predive();
    M.logbook = menu_logbook_proto;
    M.log_ctx = &P;
    nav_init(&N, 0.15f);
    nav_set_origin(&N, gnss_lat, gnss_lon);
    tx_ok = tx_bad = 0;
}


EXPORT void sim_set_battery(int pct) { dive_set_battery(&D, pct); P.battery_pct = (uint8_t)(pct < 0 ? 255 : pct); }
EXPORT int sim_battery(void) { return D.battery_pct; }
EXPORT int sim_battery_ok(void) { return dive_battery_ok_for_dive(&D) ? 1 : 0; }

EXPORT int sim_switch_gas(int i) { return dive_switch_gas(&D, i) ? 1 : 0; }

EXPORT void sim_set_charging(int on) { dive_set_charging(&D, on != 0); }

/* Advance one step: depth from the profile, heading and swim speed for navigation. */
EXPORT void sim_set_clock(double unix_s) { clock_unix = (uint32_t)unix_s; P.now_unix = clock_unix; }

static void log_begin(void)
{
    if (n_logs >= MAX_LOGS || log_used + DIVELOG_HEADER + DIVELOG_FOOTER + 4096 > LOG_STORE) return;
    logging = n_logs;
    log_off[logging] = log_used;
    log_len[logging] = DIVELOG_HEADER;
    divelog_begin(&LW, &D, (uint16_t)(n_logs + 1), clock_unix, S.log_interval_s, logmem + log_used);
    nav_init(&N, 0.15f);                    /* the entry point is the last surface fix */
    nav_set_origin(&N, gnss_lat, gnss_lon);
    divelog_set_entry(&LW, gnss_lat, gnss_lon);
}

EXPORT void sim_step(float dt_s, float depth_m, float temp_c, float heading_deg, float speed_mpm)
{
    dive_set_external_alarms(&D, divplan_alarms(&PL, &D));
    dive_set_wet(&D, depth_m > 0.05f);       /* the wet contacts are on the case */
    dive_tick(&D, dt_s, depth_m, temp_c);
    clock_unix += (uint32_t)dt_s;
    P.now_unix = clock_unix;
    if (D.state == DIVE_ACTIVE) nav_step(&N, heading_deg, speed_mpm, dt_s);
    if ((last_state == DIVE_ACTIVE) != (D.state == DIVE_ACTIVE) && M.open) menu_close(&M); /* menus are per state */
    if (last_state != DIVE_ACTIVE && D.state == DIVE_ACTIVE) log_begin();
    if (D.state == DIVE_ACTIVE && logging >= 0) {
        int at = log_off[logging] + log_len[logging];
        divelog_set_nav(&LW, N.x_m, N.y_m);
        if (at + DIVELOG_SAMPLE + DIVELOG_FOOTER < LOG_STORE && divelog_tick(&LW, &D, dt_s, logmem + at))
            log_len[logging] += DIVELOG_SAMPLE;
    }
    if (last_state == DIVE_ACTIVE && D.state != DIVE_ACTIVE && logging >= 0) {
        int at = log_off[logging] + log_len[logging];
        divelog_end(&LW, &D, logmem + log_off[logging], logmem + at);
        log_len[logging] += DIVELOG_FOOTER;
        at += DIVELOG_FOOTER;
        if (at + GEAR_BLOB_MAX < LOG_STORE) log_len[logging] += divelog_gear_block(&G, logmem + at, GEAR_BLOB_MAX);
        log_used += log_len[logging];
        n_logs++;
        logging = -1;
    }
    if (settings_take_serials(&S, &D)) gear_take_serials(&G, &S); /* pairing happened: remember it, on the cylinder too */
    last_state = D.state;
}

/* ---- settings for the bench ---- */
EXPORT int sim_st_get(int code, int i) { return st_get(&S, code, i); }
EXPORT void sim_st_set(int code, int i, int v) { st_set(&S, code, i, v); }
EXPORT void sim_st_apply(void) { settings_validate(&S); settings_apply(&S, &D); }
EXPORT void sim_st_default(void) { settings_default(&S); }

/* ---- menu ---- */
/* Dive menu underwater, full settings menu on the surface. Returns 2 for the dive menu, 1 otherwise. */
EXPORT int sim_menu_open(int bearing_locked)
{
    M.bearing_locked = bearing_locked != 0;
    menu_open(&M, D.state == DIVE_ACTIVE);
    return M.diving ? 2 : 1;
}
EXPORT int sim_menu_ev_arg(void) { return M.ev_arg; }
/* Bluetooth: the phone may talk only when it is switched on and the computer is on the surface. */
EXPORT int sim_ble_allowed(void) { return S.bluetooth && D.state != DIVE_ACTIVE && D.state != DIVE_SLEEP; }
EXPORT void sim_ble_connected(int on)
{
    phone_connected = on;
    M.ble_status = !sim_ble_allowed() ? "Off" : (on ? "Connected" : "Waiting");
}
/* Pre-dive check: field 0 worst level, 1 warnings, 2 stops, 3 lines. */
EXPORT int sim_predive(int field)
{
    refresh_predive();
    return field == 0 ? PD.worst : field == 1 ? PD.n_warn : field == 2 ? PD.n_fail : PD.n;
}
EXPORT const char *sim_predive_label(int i) { return (i >= 0 && i < PD.n) ? PD.item[i].label : ""; }
EXPORT const char *sim_predive_detail(int i) { return (i >= 0 && i < PD.n) ? PD.item[i].detail : ""; }
EXPORT int sim_predive_level(int i) { return (i >= 0 && i < PD.n) ? PD.item[i].level : 0; }
/* Dive plan from the phone: 0 valid, 1 depth, 2 bottom min, 3 run time, 4 TTS, 5 stops, 6 bottom time left (s), 7 gas ok mask. */
EXPORT int sim_plan(int field)
{
    switch (field) {
    case 0: return PL.valid;
    case 1: return PL.depth_m;
    case 2: return PL.bottom_min;
    case 3: return PL.runtime_min;
    case 4: return PL.tts_min;
    case 5: return PL.n_stops;
    case 6: return (int)divplan_bottom_left_s(&PL, &D);
    default: return PL.gas_ok;
    }
}
EXPORT int sim_plan_stop(int i, int minutes) { return (i < 0 || i >= PL.n_stops) ? 0 : (minutes ? PL.stop[i].minutes : PL.stop[i].depth_m); }
EXPORT int sim_plan_gas(int i) { return (i < 0 || i >= DC_MAX_GASES) ? 0 : PL.gas_bar[i]; }
/* Buzzer and vibration motor right now: bit 0 vibration, bit 1 buzzer. */
EXPORT int sim_notify(double now_ms)
{
    bool v, b;
    alarm_notifier_step(&AN, D.alarms, ALARM_CRITICAL_MASK, (uint32_t)now_ms, S.vibrate, S.sound, &v, &b);
    return (v ? 1 : 0) | (b ? 2 : 0);
}
EXPORT int sim_backlight(float lux) { return backlight_pct(S.brightness, lux, S.auto_bright); }
EXPORT void sim_set_gnss(double lat, double lon) { gnss_lat = lat; gnss_lon = lon; if (D.state != DIVE_ACTIVE) nav_set_origin(&N, lat, lon); }
EXPORT void sim_set_sensors(int n) { depth_sensors = n; P.depth_sensors = n; }
EXPORT void sim_wake(void) { dive_wake(&D); }

EXPORT int sim_gear_count(void) { return G.n; }
EXPORT int sim_gear_on_dive(void) { return gear_on_dive(&G); }
EXPORT int sim_menu_is_open(void) { return M.open ? 1 : 0; }
EXPORT int sim_menu_button(int b)
{
    sim_ble_connected(phone_connected);
    dive_wake(&D);
    refresh_predive();
    menu_event_t e = menu_button(&M, (menu_btn_t)b);
    if (e == MENU_EV_CLEAR_PLAN) memset(&PL, 0, sizeof(PL));
    if (e == MENU_EV_CHANGED) settings_apply(&S, &D);
    if (e == MENU_EV_SWITCH_GAS && !dive_switch_gas(&D, M.ev_arg)) e = MENU_EV_NONE;
    return (int)e;
}
EXPORT int sim_menu_rows(void) { refresh_predive(); sim_ble_connected(phone_connected); n_rows = menu_rows(&M, rows, MENU_MAX_ROWS, menu_title, sizeof(menu_title)); return n_rows; }
EXPORT const char *sim_menu_title(void) { return menu_title; }
EXPORT const char *sim_menu_label(int i) { return (i >= 0 && i < n_rows) ? rows[i].label : ""; }
EXPORT const char *sim_menu_value(int i) { return (i >= 0 && i < n_rows) ? rows[i].value : ""; }
EXPORT int sim_menu_flags(int i)
{
    if (i < 0 || i >= n_rows) return 0;
    return (rows[i].selected ? 1 : 0) | (rows[i].editing ? 2 : 0) | (rows[i].submenu ? 4 : 0) | (rows[i].disabled ? 8 : 0) | (rows[i].level << 4);
}

/* ---- logs and phone protocol ---- */
EXPORT int sim_log_count(void) { return n_logs; }
EXPORT float sim_turn(float heading, float bearing) { return nav_turn_deg(heading, bearing); }
EXPORT uint8_t *sim_io_req(void) { return io_req; }
EXPORT uint8_t *sim_io_resp(void) { return io_resp; }
EXPORT int sim_proto(int req_len) { return proto_handle(&P, io_req, req_len, io_resp, sizeof(io_resp)); }

/* Transmit one packet from tank i's transmitter through the real receive chain: synthesise the
 * 38 kHz signal with noise, run txdsp, pair by serial and hand the pressure to the dive.
 * Returns decoded bar or -1. */
EXPORT float sim_tank_packet(int tank, float bar, float noise, int battery_nibble)
{
    uint32_t serial = 104300u + (uint32_t)tank * 1111u;
    uint16_t psi = (uint16_t)(bar / 0.0689476f + 0.5f);
    psi &= (uint16_t)~1u;
    int n = txdsp_synthesize(serial, psi, (uint8_t)battery_nibble, 96000.0f, 38000.0f, 1.0f, noise, &seed, sig, 24000);
    txdsp_t rx;
    txdsp_init(&rx, 96000.0f, 38000.0f, 0.1f, 5000);
    pelagic_packet_t p;
    for (int i = 0; i < n; i += 256) {
        if (txdsp_feed(&rx, sig + i, (n - i) < 256 ? (n - i) : 256, &p)) {
            int idx = dive_tank_for_serial(&D, p.serial, S.pairing && D.state != DIVE_ACTIVE);
            if (idx < 0) break;
            tx_ok++;
            dive_tank_reading(&D, idx, pelagic_psi_to_bar(p.psi));
            dive_tank_battery(&D, idx, pelagic_battery_state(p.battery));
            return pelagic_psi_to_bar(p.psi);
        }
    }
    tx_bad++;
    return -1.0f;
}

/* Tank read-outs: 0 bar (-1 when no data), 1 seconds since last packet, 2 fill, 3 reserve,
 * 4 drop rate bar/min, 5 paired (0/1), 6 serial, 7 transmitter battery (TX_BATT_*). */
EXPORT float sim_tank(int i, int field)
{
    if (i < 0 || i >= DIVE_MAX_TANKS) return 0.0f;
    const dive_tank_t *t = &D.tanks[i];
    switch (field) {
    case 0: return t->present ? t->bar : -1.0f;
    case 1: return t->age_s;
    case 2: return t->full_bar;
    case 3: return t->reserve_bar;
    case 4: return t->rate_bar_min;
    case 5: return t->serial ? 1.0f : 0.0f;
    case 7: return (float)t->battery;
    default: return (float)t->serial;
    }
}

/* ---- read-outs ---- */
enum {
    O_STATE, O_DEPTH, O_MAXDEPTH, O_TIME, O_TEMP, O_ASCENT, O_NDL, O_INDECO, O_CEILING, O_TTS, O_NSTOPS,
    O_GF_NOW, O_GF_SURF, O_PPO2, O_CNS, O_OTU, O_GAS, O_TANK, O_SAC, O_GASTIME, O_ALARMS, O_INTERVAL,
    O_NOFLY, O_DIVES, O_FIRSTSTOP, O_HOME_BRG, O_HOME_DIST, O_NAV_X, O_NAV_Y, O_NAV_ERR, O_TX_OK, O_TX_BAD,
    O_MOD, O_LEAD, O_ANCHOR, O_NEEDED, O_SAFETY_STOP
};

EXPORT float sim_out(int k)
{
    float brg = 0, dist = 0;
    switch (k) {
    case O_STATE: return (float)D.state;
    case O_DEPTH: return D.depth_m;
    case O_MAXDEPTH: return D.max_depth_m;
    case O_TIME: return D.dive_time_s;
    case O_TEMP: return D.temp_c;
    case O_ASCENT: return D.ascent_mpm;
    case O_NDL: return (float)D.plan.ndl_min;
    case O_INDECO: return D.plan.in_deco ? 1.0f : 0.0f;
    case O_CEILING: return D.plan.ceiling_m;
    case O_TTS: return (float)D.plan.tts_min;
    case O_NSTOPS: return (float)D.plan.n_stops;
    case O_GF_NOW: return D.plan.gf_now * 100.0f;
    case O_GF_SURF: return D.plan.gf_surface * 100.0f;
    case O_PPO2: return dive_ppo2(&D);
    case O_CNS: return D.ox.cns_pct;
    case O_OTU: return D.ox.otu;
    case O_GAS: return (float)D.gas;
    case O_TANK: return dive_active_tank(&D) ? dive_active_tank(&D)->bar : -1.0f;
    case O_SAC: return D.sac_l_min;
    case O_GASTIME: return D.gas_time_min;
    case O_ALARMS: return (float)D.alarms;
    case O_INTERVAL: return D.interval_s;
    case O_NOFLY: return D.nofly_min;
    case O_DIVES: return (float)D.dive_count;
    case O_FIRSTSTOP: return D.plan.first_stop_m;
    case O_HOME_BRG: nav_home(&N, &brg, &dist); return brg;
    case O_HOME_DIST: nav_home(&N, &brg, &dist); return dist;
    case O_NAV_X: return N.x_m;
    case O_NAV_Y: return N.y_m;
    case O_NAV_ERR: return nav_error_radius_m(&N);
    case O_TX_OK: return (float)tx_ok;
    case O_TX_BAD: return (float)tx_bad;
    case O_MOD: return dive_current_mod(&D);
    case O_NEEDED: return D.gas_needed_bar;
    case O_SAFETY_STOP: return D.set.safety_stop ? 1.0f : 0.0f;
    case O_LEAD: return (float)D.plan.leading_tissue;
    case O_ANCHOR: return D.gf_anchor_m;
    default: return 0.0f;
    }
}

EXPORT float sim_stop(int i, int field)
{
    if (i < 0 || i >= D.plan.n_stops) return 0.0f;
    if (field == 0) return D.plan.stops[i].depth_m;
    if (field == 1) return (float)D.plan.stops[i].minutes;
    return (float)D.plan.stops[i].gas;
}

EXPORT float sim_tissue(int i)
{
    if (i == 0) dc_tissue_load_pct(&D.tissues, &D.cfg, load_pct);
    return (i >= 0 && i < DC_NUM_TISSUES) ? load_pct[i] : 0.0f;
}

EXPORT float sim_gas(int i, int field)
{
    if (i < 0 || i >= DC_MAX_GASES) return 0.0f;
    if (field == 0) return D.gases[i].o2;
    if (field == 1) return D.gases[i].he;
    if (field == 2) return D.gases[i].enabled ? 1.0f : 0.0f;
    return dc_mod_m(&D.gases[i], i == 0 ? D.cfg.bottom_ppo2_max : D.cfg.deco_ppo2_max, &D.cfg);
}
