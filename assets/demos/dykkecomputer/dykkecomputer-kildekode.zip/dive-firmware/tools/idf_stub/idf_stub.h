/*
 * idf_stub.h — a minimal imitation of the ESP-IDF 5.3 and NimBLE declarations that main/ uses.
 *
 * Purpose: `tools/check_main.sh` type-checks the files in main/ on a laptop with plain gcc, so typos,
 * missing declarations and mismatches with divecore are caught without the ESP32 toolchain.
 * It does NOT prove the code builds under ESP-IDF: these declarations were written by hand from
 * the IDF documentation. `idf.py build` is still the real test.
 */
#ifndef IDF_STUB_H
#define IDF_STUB_H
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>

typedef int esp_err_t;
#define ESP_OK 0
#define ESP_FAIL (-1)
#define ESP_ERR_INVALID_STATE 0x103
#define ESP_ERR_INVALID_CRC 0x109
#define ESP_ERR_NVS_NOT_FOUND 0x1102
#define ESP_ERR_NVS_NO_FREE_PAGES 0x110d
#define ESP_ERR_NVS_NEW_VERSION_FOUND 0x1110
const char *esp_err_to_name(esp_err_t e);
#define ESP_LOGI(tag, ...) do { (void)(tag); printf(__VA_ARGS__); } while (0)
#define ESP_LOGW(tag, ...) do { (void)(tag); printf(__VA_ARGS__); } while (0)
#define ESP_LOGE(tag, ...) do { (void)(tag); printf(__VA_ARGS__); } while (0)
#define ESP_ERROR_CHECK(x) do { esp_err_t e_ = (x); (void)e_; } while (0)
#define ESP_RETURN_ON_ERROR(x, tag, ...) do { esp_err_t e_ = (x); if (e_ != ESP_OK) { (void)(tag); return e_; } } while (0)
void esp_restart(void);
int64_t esp_timer_get_time(void);

/* FreeRTOS */
typedef uint32_t TickType_t;
typedef int BaseType_t;
typedef void *SemaphoreHandle_t;
typedef void *TaskHandle_t;
#define portMAX_DELAY 0xffffffffu
#define pdMS_TO_TICKS(ms) ((TickType_t)(ms))
#define pdTRUE 1
SemaphoreHandle_t xSemaphoreCreateMutex(void);
BaseType_t xSemaphoreTake(SemaphoreHandle_t s, TickType_t t);
BaseType_t xSemaphoreGive(SemaphoreHandle_t s);
void vTaskDelete(void *task);
void vTaskDelay(TickType_t t);
BaseType_t vTaskDelayUntil(TickType_t *prev, TickType_t inc);
TickType_t xTaskGetTickCount(void);
TaskHandle_t xTaskGetCurrentTaskHandle(void);
BaseType_t xTaskCreatePinnedToCore(void (*fn)(void *), const char *name, uint32_t stack, void *arg, unsigned prio, TaskHandle_t *h, int core);

/* GPIO */
typedef enum { GPIO_NUM_NC = -1, GPIO_NUM_0, GPIO_NUM_1, GPIO_NUM_2, GPIO_NUM_3, GPIO_NUM_4, GPIO_NUM_5, GPIO_NUM_6, GPIO_NUM_7, GPIO_NUM_8,
    GPIO_NUM_9, GPIO_NUM_10, GPIO_NUM_11, GPIO_NUM_12, GPIO_NUM_13, GPIO_NUM_14, GPIO_NUM_15, GPIO_NUM_16, GPIO_NUM_17, GPIO_NUM_18,
    GPIO_NUM_19, GPIO_NUM_20, GPIO_NUM_21, GPIO_NUM_38 = 38, GPIO_NUM_39, GPIO_NUM_40, GPIO_NUM_41, GPIO_NUM_42, GPIO_NUM_43, GPIO_NUM_44,
    GPIO_NUM_45, GPIO_NUM_46, GPIO_NUM_47, GPIO_NUM_48 } gpio_num_t;
typedef enum { GPIO_MODE_INPUT = 1, GPIO_MODE_OUTPUT = 2 } gpio_mode_t;
typedef enum { GPIO_PULLUP_DISABLE, GPIO_PULLUP_ENABLE } gpio_pullup_t;
typedef struct { uint64_t pin_bit_mask; gpio_mode_t mode; gpio_pullup_t pull_up_en; int pull_down_en; int intr_type; } gpio_config_t;
esp_err_t gpio_config(const gpio_config_t *c);
int gpio_get_level(gpio_num_t n);
esp_err_t gpio_set_level(gpio_num_t n, uint32_t level);

/* I2C master (new driver) */
typedef struct i2c_master_bus_t *i2c_master_bus_handle_t;
typedef struct i2c_master_dev_t *i2c_master_dev_handle_t;
#define I2C_NUM_0 0
#define I2C_CLK_SRC_DEFAULT 0
#define I2C_ADDR_BIT_LEN_7 0
typedef struct { int i2c_port; gpio_num_t sda_io_num, scl_io_num; int clk_source; uint8_t glitch_ignore_cnt; struct { uint32_t enable_internal_pullup : 1; } flags; } i2c_master_bus_config_t;
typedef struct { int dev_addr_length; uint16_t device_address; uint32_t scl_speed_hz; } i2c_device_config_t;
esp_err_t i2c_new_master_bus(const i2c_master_bus_config_t *c, i2c_master_bus_handle_t *h);
esp_err_t i2c_master_bus_add_device(i2c_master_bus_handle_t b, const i2c_device_config_t *c, i2c_master_dev_handle_t *d);
esp_err_t i2c_master_transmit(i2c_master_dev_handle_t d, const uint8_t *w, size_t n, int timeout_ms);
esp_err_t i2c_master_receive(i2c_master_dev_handle_t d, uint8_t *r, size_t n, int timeout_ms);
esp_err_t i2c_master_transmit_receive(i2c_master_dev_handle_t d, const uint8_t *w, size_t wn, uint8_t *r, size_t rn, int timeout_ms);

/* I2S std */
typedef struct i2s_chan_t *i2s_chan_handle_t;
#define I2S_NUM_0 0
#define I2S_ROLE_MASTER 0
#define I2S_GPIO_UNUSED GPIO_NUM_NC
#define I2S_DATA_BIT_WIDTH_32BIT 32
#define I2S_SLOT_MODE_STEREO 2
#define I2S_MCLK_MULTIPLE_256 256
typedef struct { int id, role; } i2s_chan_config_t;
typedef struct { uint32_t sample_rate_hz; int clk_src; int mclk_multiple; } i2s_std_clk_config_t;
typedef struct { int data_bit_width, slot_mode; } i2s_std_slot_config_t;
typedef struct { gpio_num_t mclk, bclk, ws, dout, din; } i2s_std_gpio_config_t;
typedef struct { i2s_std_clk_config_t clk_cfg; i2s_std_slot_config_t slot_cfg; i2s_std_gpio_config_t gpio_cfg; } i2s_std_config_t;
#define I2S_CHANNEL_DEFAULT_CONFIG(id_, role_) { .id = (id_), .role = (role_) }
#define I2S_STD_CLK_DEFAULT_CONFIG(rate) { .sample_rate_hz = (rate), .clk_src = 0, .mclk_multiple = 256 }
#define I2S_STD_PHILIPS_SLOT_DEFAULT_CONFIG(bits, mode) { .data_bit_width = (bits), .slot_mode = (mode) }
esp_err_t i2s_new_channel(const i2s_chan_config_t *c, i2s_chan_handle_t *tx, i2s_chan_handle_t *rx);
esp_err_t i2s_channel_init_std_mode(i2s_chan_handle_t h, const i2s_std_config_t *c);
esp_err_t i2s_channel_enable(i2s_chan_handle_t h);
esp_err_t i2s_channel_read(i2s_chan_handle_t h, void *dest, size_t size, size_t *got, uint32_t timeout);

/* UART */
#define UART_NUM_1 1
#define UART_NUM_2 2
#define UART_DATA_8_BITS 3
#define UART_PARITY_DISABLE 0
#define UART_STOP_BITS_1 1
#define UART_HW_FLOWCTRL_DISABLE 0
#define UART_PIN_NO_CHANGE (-1)
typedef struct { int baud_rate, data_bits, parity, stop_bits, flow_ctrl; } uart_config_t;
esp_err_t uart_driver_install(int port, int rx, int tx, int qsize, void *q, int flags);
esp_err_t uart_param_config(int port, const uart_config_t *c);
esp_err_t uart_set_pin(int port, int tx, int rx, int rts, int cts);
int uart_write_bytes(int port, const void *src, size_t n);
int uart_read_bytes(int port, void *buf, uint32_t length, uint32_t ticks_to_wait);

/* LEDC */
#define LEDC_LOW_SPEED_MODE 0
#define LEDC_TIMER_10_BIT 10
#define LEDC_TIMER_0 0
#define LEDC_CHANNEL_0 0
#define LEDC_AUTO_CLK 0
typedef struct { int speed_mode, duty_resolution, timer_num; uint32_t freq_hz; int clk_cfg; } ledc_timer_config_t;
typedef struct { int gpio_num, speed_mode, channel, timer_sel; uint32_t duty; int hpoint; } ledc_channel_config_t;
esp_err_t ledc_timer_config(const ledc_timer_config_t *c);
esp_err_t ledc_channel_config(const ledc_channel_config_t *c);
esp_err_t ledc_set_duty(int mode, int ch, uint32_t duty);
esp_err_t ledc_update_duty(int mode, int ch);

/* Touch (legacy driver, ESP32-S3) */
typedef enum { TOUCH_PAD_NUM0, TOUCH_PAD_NUM1, TOUCH_PAD_NUM2, TOUCH_PAD_NUM3 } touch_pad_t;
#define TOUCH_FSM_MODE_TIMER 0
esp_err_t touch_pad_init(void);
esp_err_t touch_pad_config(touch_pad_t p);
esp_err_t touch_pad_set_fsm_mode(int m);
esp_err_t touch_pad_fsm_start(void);
esp_err_t touch_pad_read_raw_data(touch_pad_t p, uint32_t *v);

/* NVS */
typedef uint32_t nvs_handle_t;
typedef enum { NVS_READONLY, NVS_READWRITE } nvs_open_mode_t;
esp_err_t nvs_flash_init(void);
esp_err_t nvs_flash_erase(void);
esp_err_t nvs_open(const char *ns, nvs_open_mode_t m, nvs_handle_t *h);
esp_err_t nvs_get_blob(nvs_handle_t h, const char *key, void *out, size_t *len);
esp_err_t nvs_set_blob(nvs_handle_t h, const char *key, const void *v, size_t len);
esp_err_t nvs_erase_key(nvs_handle_t h, const char *key);
esp_err_t nvs_get_u16(nvs_handle_t h, const char *key, uint16_t *out);
esp_err_t nvs_set_u16(nvs_handle_t h, const char *key, uint16_t v);
esp_err_t nvs_commit(nvs_handle_t h);
void nvs_close(nvs_handle_t h);

/* SPI bus, SD over SPI, FAT */
#define SPI2_HOST 1
#define SPI_DMA_CH_AUTO 3
typedef struct { int mosi_io_num, miso_io_num, sclk_io_num, quadwp_io_num, quadhd_io_num; int max_transfer_sz; } spi_bus_config_t;
esp_err_t spi_bus_initialize(int host, const spi_bus_config_t *c, int dma);
typedef struct { int slot; int max_freq_khz; } sdmmc_host_t;
typedef struct { gpio_num_t gpio_cs; int host_id; } sdspi_device_config_t;
typedef struct sdmmc_card sdmmc_card_t;
#define SDSPI_HOST_DEFAULT() { .slot = SPI2_HOST, .max_freq_khz = 20000 }
#define SDSPI_DEVICE_CONFIG_DEFAULT() { .gpio_cs = GPIO_NUM_NC, .host_id = SPI2_HOST }
typedef struct { bool format_if_mount_failed; int max_files; size_t allocation_unit_size; } esp_vfs_fat_sdmmc_mount_config_t;
esp_err_t esp_vfs_fat_sdspi_mount(const char *base, const sdmmc_host_t *host, const sdspi_device_config_t *slot,
                                  const esp_vfs_fat_sdmmc_mount_config_t *mnt, sdmmc_card_t **card);

/* OTA */
typedef uint32_t esp_ota_handle_t;
typedef struct esp_partition { uint32_t address, size; char label[17]; } esp_partition_t;
#define OTA_SIZE_UNKNOWN 0xffffffff
#define OTA_WITH_SEQUENTIAL_WRITES 0xfffffffe
const esp_partition_t *esp_ota_get_next_update_partition(const esp_partition_t *start);
esp_err_t esp_ota_begin(const esp_partition_t *p, size_t size, esp_ota_handle_t *h);
esp_err_t esp_ota_write(esp_ota_handle_t h, const void *data, size_t n);
esp_err_t esp_ota_end(esp_ota_handle_t h);
esp_err_t esp_ota_abort(esp_ota_handle_t h);
esp_err_t esp_ota_set_boot_partition(const esp_partition_t *p);
esp_err_t esp_ota_mark_app_valid_cancel_rollback(void);

/* NimBLE */
struct os_mbuf { uint16_t om_len; };
#define OS_MBUF_PKTLEN(om) ((om)->om_len)
typedef struct { uint8_t type; } ble_uuid_t;
typedef struct { ble_uuid_t u; uint8_t value[16]; } ble_uuid128_t;
#define BLE_UUID128_INIT(...) { .u = { .type = 128 }, .value = { __VA_ARGS__ } }
#define BLE_GATT_SVC_TYPE_PRIMARY 1
#define BLE_GATT_CHR_F_WRITE 0x0008
#define BLE_GATT_CHR_F_WRITE_NO_RSP 0x0004
#define BLE_GATT_CHR_F_NOTIFY 0x0010
#define BLE_GATT_ACCESS_OP_WRITE_CHR 1
#define BLE_ATT_ERR_UNLIKELY 0x0e
#define BLE_ERR_REM_USER_CONN_TERM 0x13
#define BLE_HS_CONN_HANDLE_NONE 0xffff
#define BLE_HS_FOREVER INT32_MAX
#define BLE_HS_ADV_F_DISC_GEN 0x02
#define BLE_HS_ADV_F_BREDR_UNSUP 0x04
#define BLE_GAP_CONN_MODE_UND 2
#define BLE_GAP_DISC_MODE_GEN 2
#define BLE_GAP_EVENT_CONNECT 0
#define BLE_GAP_EVENT_DISCONNECT 1
#define BLE_GAP_EVENT_SUBSCRIBE 14
#define BLE_GAP_EVENT_MTU 15
#define BLE_SM_IO_CAP_DISP_ONLY 0
struct ble_gatt_access_ctxt { uint8_t op; struct os_mbuf *om; };
typedef int ble_gatt_access_fn(uint16_t conn, uint16_t attr, struct ble_gatt_access_ctxt *ctxt, void *arg);
struct ble_gatt_chr_def { const ble_uuid_t *uuid; ble_gatt_access_fn *access_cb; void *arg; uint16_t flags; uint16_t *val_handle; };
struct ble_gatt_svc_def { uint8_t type; const ble_uuid_t *uuid; const struct ble_gatt_chr_def *characteristics; };
struct ble_gap_conn_desc { uint16_t conn_handle; };
struct ble_gap_event { uint8_t type; union { struct { int status; uint16_t conn_handle; } connect; struct { int reason; struct ble_gap_conn_desc conn; } disconnect;
    struct { uint16_t conn_handle; uint16_t value; } mtu; struct { uint16_t conn_handle; uint16_t attr_handle; uint8_t cur_notify; } subscribe; }; };
struct ble_gap_adv_params { uint8_t conn_mode, disc_mode; uint16_t itvl_min, itvl_max; };
struct ble_hs_adv_fields { uint8_t flags; const ble_uuid128_t *uuids128; uint8_t num_uuids128; unsigned uuids128_is_complete : 1;
    const uint8_t *name; uint8_t name_len; unsigned name_is_complete : 1; };
struct ble_hs_cfg_t { void (*sync_cb)(void); void (*reset_cb)(int reason); uint8_t sm_io_cap; unsigned sm_bonding : 1, sm_mitm : 1, sm_sc : 1; };
extern struct ble_hs_cfg_t ble_hs_cfg;
typedef int ble_gap_event_fn(struct ble_gap_event *ev, void *arg);
int ble_gatts_count_cfg(const struct ble_gatt_svc_def *defs);
int ble_gatts_add_svcs(const struct ble_gatt_svc_def *defs);
int ble_gatts_notify_custom(uint16_t conn, uint16_t attr, struct os_mbuf *om);
struct os_mbuf *ble_hs_mbuf_from_flat(const void *buf, uint16_t len);
int ble_hs_mbuf_to_flat(const struct os_mbuf *om, void *flat, uint16_t max, uint16_t *out_len);
uint16_t ble_att_mtu(uint16_t conn);
int ble_att_set_preferred_mtu(uint16_t mtu);
int ble_hs_id_infer_auto(int privacy, uint8_t *addr_type);
int ble_gap_adv_set_fields(const struct ble_hs_adv_fields *f);
int ble_gap_adv_rsp_set_fields(const struct ble_hs_adv_fields *f);
int ble_gap_adv_start(uint8_t own_addr_type, const void *direct, int32_t dur, const struct ble_gap_adv_params *p, ble_gap_event_fn *cb, void *arg);
int ble_gap_adv_stop(void);
int ble_gap_adv_active(void);
int ble_gap_terminate(uint16_t conn, uint8_t reason);
void ble_svc_gap_init(void);
void ble_svc_gatt_init(void);
int ble_svc_gap_device_name_set(const char *name);
const char *ble_svc_gap_device_name(void);
esp_err_t nimble_port_init(void);
void nimble_port_run(void);
void nimble_port_freertos_init(void (*fn)(void *));
void nimble_port_freertos_deinit(void);
#endif
