#!/bin/sh
# Type-checks main/*.c with plain gcc against tools/idf_stub (hand-written ESP-IDF declarations).
# Catches typos and mismatches with divecore on a laptop; it does not replace `idf.py build`.
set -e
cd "$(dirname "$0")/.."
fail=0
for f in main/*.c; do
  gcc -std=gnu17 -fsyntax-only -Wall -Wextra -Wno-unused-parameter -Wno-missing-field-initializers \
      -Itools/idf_stub -Itools/idf_stub/inc -Icomponents/divecore/include -Imain "$f" || fail=1
done
[ $fail = 0 ] && echo "main/: type-check passed (stub headers, not the real ESP-IDF)"
exit $fail
