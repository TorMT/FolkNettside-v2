#!/bin/sh
# Everything that can be checked without the hardware. Run from anywhere: tools/ci.sh
#   1 unit tests            2 the same under AddressSanitizer + UBSan     3 deco planner vs decotengu
#   4 firmware type-check   5 simulator build                             6 simulator + phone app tests
# Needs: cmake, gcc, python3 (pip install ziglang decotengu), node 20+.
set -e
cd "$(dirname "$0")/.."
step() { printf '\n== %s ==\n' "$1"; }

step "1 unit tests"
cmake -S test -B build -DCMAKE_BUILD_TYPE=Release > /dev/null
cmake --build build > /dev/null
./build/test_divecore | tail -1

step "2 unit tests with sanitizers"
mkdir -p build/san
gcc -std=gnu99 -g -O1 -fsanitize=address,undefined -fno-sanitize-recover=undefined -Icomponents/divecore/include \
    components/divecore/src/*.c test/test_main.c -lm -o build/san/test 2> /dev/null
./build/san/test | tail -1

step "3 deco planner against decotengu (54 dives)"
if python3 -c "import decotengu" 2> /dev/null; then python3 tools/crosscheck.py build/divecli_1a | tail -1
else echo "skipped: pip install decotengu"; fi

step "4 firmware type-check (stub ESP-IDF headers)"
sh tools/check_main.sh | tail -1

step "5 simulator build"
if python3 -c "import ziglang" 2> /dev/null; then ./sim/build.sh | tail -1; python3 sim/make_page.py | tail -2
else echo "skipped: pip install ziglang"; fi

step "6 simulator and phone app tests"
if command -v node > /dev/null; then
  (cd sim/tests && [ -d node_modules ] || npm install --silent)
  mkdir -p sim/tests/out
  for t in sim/tests/*.mjs; do
    printf '%s: ' "$(basename "$t")"
    (cd sim/tests/out && node "../$(basename "$t")" 2>&1 | grep -E 'FAILED|ALL PASSED' | tail -1) || { echo FAILED; exit 1; }
  done
else echo "skipped: node not found"; fi
printf '\nAll checks done.\n'
