"""Cross-check the C planner (built with compartment 1a) against decotengu's ZHL-16C-GF.
Usage: python3 tools/crosscheck.py build/divecli_1a"""
import itertools, json, subprocess, sys
import decotengu, decotengu.model as model

cli = sys.argv[1]
cases = []
for gf in [(30, 70), (50, 80), (100, 100)]:
    for depth, bottom in [(18, 60), (24, 45), (30, 25), (30, 40), (40, 20), (40, 30), (45, 25), (50, 20)]:
        cases.append((gf, depth, bottom, (21, 0), []))
        cases.append((gf, depth, bottom, (21, 0), [50]))
    for depth, bottom in [(32, 40), (36, 30)]:
        cases.append((gf, depth, bottom, (32, 0), []))

worst_tts, worst_stop, rows = 0, 0, []
for (gl, gh), depth, bottom, (o2, he), deco in cases:
    e = decotengu.create()
    e.model = model.ZH_L16C_GF(); e.model.gf_low = gl / 100; e.model.gf_high = gh / 100
    e.ascent_rate = 9.0; e.descent_rate = 20.0
    e.add_gas(0, o2, he)
    for d in list(deco):
        mod = int((1.6 / (d / 100) - 1.01325) / 0.09985) // 3 * 3
        if mod >= depth:
            deco = []  # deco gas would be breathable at the bottom; skip it
            break
        e.add_gas(mod, d)
    prof = list(e.calculate(depth, bottom))
    ref_stops = [(round(s.depth), round(s.time)) for s in e.deco_table]
    out = json.loads(subprocess.check_output([cli, str(gl), str(gh), str(depth), str(bottom), str(o2), str(he)] + [str(d) for d in deco]))
    my_stops = [(int(d), m) for d, m in out["stops"]]
    my_tts = out["tts"]
    ref_total = sum(m for _, m in ref_stops); my_total = sum(m for _, m in my_stops)
    worst_tts = max(worst_tts, abs(my_total - ref_total))
    d_ref = dict(ref_stops); d_my = dict(my_stops)
    per = max([abs(d_ref.get(k, 0) - d_my.get(k, 0)) for k in set(d_ref) | set(d_my)] or [0])
    worst_stop = max(worst_stop, per)
    rows.append(f"GF{gl}/{gh} {depth}m {bottom}min {o2}/{he} deco={deco}: ref {ref_total:3d} min {ref_stops} | ours {my_total:3d} min {my_stops}  diff {my_total-ref_total:+d}")
print("\n".join(rows))
print(f"\n{len(cases)} profiles; worst total-stop-time difference {worst_tts} min; worst single-stop difference {worst_stop} min")
