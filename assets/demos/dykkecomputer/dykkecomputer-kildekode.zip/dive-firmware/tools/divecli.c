/* divecli — plan a square dive from the command line, for cross-checks.
 * usage: divecli gf_low gf_high depth_m bottom_min o2 he [deco_o2 ...]
 * Bottom time includes the descent at 20 m/min. Prints one JSON line. */
#include <stdio.h>
#include <stdlib.h>

#include "divecore/deco.h"

int main(int argc, char **argv)
{
    if (argc < 7) {
        fprintf(stderr, "usage: %s gf_low gf_high depth bottom_min o2 he [deco_o2 ...]\n", argv[0]);
        return 2;
    }
    dc_cfg_t cfg;
    dc_cfg_default(&cfg);
    cfg.gf_low = (float)atof(argv[1]) / 100.0f;
    cfg.gf_high = (float)atof(argv[2]) / 100.0f;
    cfg.bar_per_m = 0.09985f; /* match the reference planner */
    cfg.gas_switch_min = 0.0f;
    float depth = (float)atof(argv[3]), bottom = (float)atof(argv[4]);
    dc_gas_t gases[DC_MAX_GASES] = {{0}};
    gases[0] = (dc_gas_t){(float)atof(argv[5]) / 100.0f, (float)atof(argv[6]) / 100.0f, true};
    for (int i = 7, g = 1; i < argc && g < DC_MAX_GASES; i++, g++)
        gases[g] = (dc_gas_t){(float)atof(argv[i]) / 100.0f, 0.0f, true};

    dc_tissues_t t;
    dc_tissues_init(&t, cfg.surface_bar);
    float descent_min = depth / 20.0f;
    dc_tissues_update(&t, cfg.surface_bar, dc_ambient_bar(depth, &cfg), descent_min * 60.0f, &gases[0]);
    dc_tissues_update(&t, dc_ambient_bar(depth, &cfg), dc_ambient_bar(depth, &cfg), (bottom - descent_min) * 60.0f, &gases[0]);
    dc_plan_t p;
    dc_plan(&t, depth, 0, gases, &cfg, 0.0f, &p);
    printf("{\"ndl\":%d,\"tts\":%d,\"stops\":[", p.ndl_min, p.tts_min);
    for (int i = 0; i < p.n_stops; i++) printf("%s[%.0f,%d]", i ? "," : "", p.stops[i].depth_m, p.stops[i].minutes);
    printf("]}\n");
    return 0;
}
