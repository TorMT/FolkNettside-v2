# Testing the breadboard build in Cirkit Designer

Cirkit Designer (app.cirkitdesigner.com) simulates an ESP32-S3 running an **Arduino sketch**: GPIO, I2C, SPI, LEDC PWM, ADC and UART. It does **not** run ESP-IDF projects yet, has no Bluetooth or I2S, and has no MS5837 or PCM1808 model. So it can check the wiring, the pins and the buttons/buzzer/vibration/backlight logic, but not the dive firmware, the deco code (use the web simulator for that) or the tank receiver.

## Build the circuit

1. New project, place **ESP32-S3 DevKitC-1**.
2. Place and wire (pins as `main/board.h`):

| Part | Wire to |
| --- | --- |
| 3 push buttons | GPIO 39 (UP), 41 (SELECT), 42 (DOWN); other leg to GND |
| Buzzer (piezo) | GPIO 40 and GND |
| Vibration motor (via the motor module or an NPN/MOSFET + diode) | GPIO 47 |
| LED + 220 Ω as backlight stand-in | GPIO 16 |
| TCA9548A (if in the library), otherwise skip | SDA 8, SCL 9, 3V3, GND |
| Any I2C sensor the library has (e.g. DS1307/DS3231 RTC at 0x68) | SDA 8, SCL 9 |
| Two wires as wet contacts | GPIO 3, and GND |

3. Code tab: paste `benktest.ino`. Start the simulation and open the serial monitor (115200).

## What to look for

- The scan names each expected I2C address as OK or missing (missing is normal for parts Cirkit does not have).
- Each button prints a line and beeps; SELECT also runs the motor and rescans.
- The LED dims and brightens with UP/DOWN.

## Prompt for Cirkit's AI assistant

> Build an ESP32-S3 DevKitC-1 circuit: three push buttons from GPIO 39, 41 and 42 to GND; a piezo buzzer on GPIO 40; a vibration motor driven by an N-MOSFET with a flyback diode from GPIO 47; an LED with 220 Ω on GPIO 16; an I2C bus on SDA 8 / SCL 9 with 2.2 kΩ pull-ups to 3.3 V, a TCA9548A multiplexer at 0x70 and a DS3231 RTC; and two bare wires on GPIO 3 and GND as a wet contact.

The same sketch runs on the real breadboard build (stage 1 and 3 in `docs/DEMO_BUILD.md`).
