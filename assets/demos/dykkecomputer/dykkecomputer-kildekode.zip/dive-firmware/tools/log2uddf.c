/* log2uddf — convert dive log files from the SD card (D0001.DLG ...) to one UDDF file for Subsurface.
 * usage: log2uddf out.uddf D0001.DLG [D0002.DLG ...] */
#include <stdio.h>
#include <stdlib.h>

#include "divecore/divelog.h"

int main(int argc, char **argv)
{
    if (argc < 3) {
        fprintf(stderr, "usage: %s out.uddf log.DLG [log.DLG ...]\n", argv[0]);
        return 2;
    }
    int n = argc - 2;
    const uint8_t **logs = calloc((size_t)n, sizeof(*logs));
    int *lens = calloc((size_t)n, sizeof(*lens));
    for (int i = 0; i < n; i++) {
        FILE *f = fopen(argv[i + 2], "rb");
        if (!f) { perror(argv[i + 2]); return 1; }
        fseek(f, 0, SEEK_END);
        lens[i] = (int)ftell(f);
        fseek(f, 0, SEEK_SET);
        uint8_t *b = malloc((size_t)lens[i]);
        if (fread(b, 1, (size_t)lens[i], f) != (size_t)lens[i]) { perror("read"); return 1; }
        fclose(f);
        logs[i] = b;
    }
    int cap = 1 << 20;
    for (;;) {
        char *xml = malloc((size_t)cap);
        int r = divelog_uddf(logs, lens, n, xml, cap);
        if (r == -1) { fprintf(stderr, "a log is corrupt (CRC mismatch)\n"); return 1; }
        if (r == -2) { free(xml); cap *= 2; continue; }
        FILE *o = fopen(argv[1], "w");
        fwrite(xml, 1, (size_t)r, o);
        fclose(o);
        printf("wrote %s: %d dive(s), %d bytes\n", argv[1], n, r);
        return 0;
    }
}
