/* divelog.c — see divelog.h. */
#include "divecore/divelog.h"

#include <math.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>

#include "divecore/pelagic.h"
#include "divecore/settings.h"

void dc_crc32_feed(uint32_t *c, const uint8_t *p, int n)
{
    for (int i = 0; i < n; i++) {
        *c ^= p[i];
        for (int k = 0; k < 8; k++) *c = (*c >> 1) ^ (0xEDB88320u & (0u - (*c & 1u)));
    }
}

static void put16(uint8_t *p, uint16_t v) { p[0] = (uint8_t)v; p[1] = (uint8_t)(v >> 8); }
static void put32(uint8_t *p, uint32_t v) { put16(p, (uint16_t)v); put16(p + 2, (uint16_t)(v >> 16)); }
static uint16_t get16(const uint8_t *p) { return (uint16_t)(p[0] | (p[1] << 8)); }
static uint32_t get32(const uint8_t *p) { return (uint32_t)get16(p) | ((uint32_t)get16(p + 2) << 16); }

static void put24(uint8_t *p, int32_t v) { p[0] = (uint8_t)v; p[1] = (uint8_t)(v >> 8); p[2] = (uint8_t)(v >> 16); }
static int32_t get24(const uint8_t *p)
{
    int32_t v = p[0] | p[1] << 8 | p[2] << 16;
    return (v & 0x800000) ? v - 0x1000000 : v;
}

/* Header: "DLG" ver | dive_no16 start32 dur32 maxdepth16 mintemp16 surf16 | interval gfl gfh water |
 *         o2[5] he[5] en[5] cyl[5] | nsamples32 | had_deco cns_end batt_start batt_end tx_low | pad | crc32 */
static void header_write(const divelog_header_t *h, uint8_t *b)
{
    memset(b, 0, DIVELOG_HEADER);
    b[0] = 'D'; b[1] = 'L'; b[2] = 'G'; b[3] = DIVELOG_VERSION;
    put16(b + 4, h->dive_no);
    put32(b + 6, h->start_unix);
    put32(b + 10, h->duration_s);
    put16(b + 14, h->max_depth_cm);
    put16(b + 16, (uint16_t)h->min_temp_dc);
    put16(b + 18, h->surface_mbar);
    b[20] = h->interval_s; b[21] = h->gf_low; b[22] = h->gf_high; b[23] = h->water;
    for (int i = 0; i < DC_MAX_GASES; i++) {
        b[24 + i] = h->o2[i];
        b[29 + i] = h->he[i];
        b[34 + i] = h->enabled[i];
        b[39 + i] = h->cylinder_l[i];
    }
    put32(b + 44, h->n_samples);
    b[48] = h->had_deco;
    b[49] = h->cns_end;
    b[50] = h->battery_start;
    b[51] = h->battery_end;
    b[52] = h->tx_low;
    put24(b + 53, h->lat_e4);
    put24(b + 56, h->lon_e4);
    b[59] = h->has_pos;
    put32(b + 60, dc_crc32(b, 60));
}

static bool header_read(const uint8_t *b, divelog_header_t *h)
{
    if (b[0] != 'D' || b[1] != 'L' || b[2] != 'G' || b[3] != DIVELOG_VERSION) return false;
    if (get32(b + 60) != dc_crc32(b, 60)) return false;
    h->dive_no = get16(b + 4);
    h->start_unix = get32(b + 6);
    h->duration_s = get32(b + 10);
    h->max_depth_cm = get16(b + 14);
    h->min_temp_dc = (int16_t)get16(b + 16);
    h->surface_mbar = get16(b + 18);
    h->interval_s = b[20]; h->gf_low = b[21]; h->gf_high = b[22]; h->water = b[23];
    for (int i = 0; i < DC_MAX_GASES; i++) {
        h->o2[i] = b[24 + i];
        h->he[i] = b[29 + i];
        h->enabled[i] = b[34 + i];
        h->cylinder_l[i] = b[39 + i];
    }
    h->n_samples = get32(b + 44);
    h->had_deco = b[48];
    h->cns_end = b[49];
    h->battery_start = b[50];
    h->battery_end = b[51];
    h->tx_low = b[52];
    h->lat_e4 = get24(b + 53);
    h->lon_e4 = get24(b + 56);
    h->has_pos = b[59];
    return true;
}

static int16_t i16clamp(float v) { return v <= -32767.0f ? -32767 : (v >= 32767.0f ? 32767 : (int16_t)lroundf(v)); }

static uint16_t u16clamp(float v) { return v <= 0 ? 0 : (v >= 65534.0f ? 65534 : (uint16_t)lroundf(v)); }

void divelog_begin(divelog_writer_t *w, const dive_t *d, uint16_t dive_no, uint32_t start_unix, uint8_t interval_s,
                   uint8_t hdr_out[DIVELOG_HEADER])
{
    memset(w, 0, sizeof(*w));
    divelog_header_t *h = &w->h;
    h->dive_no = dive_no;
    h->start_unix = start_unix;
    h->surface_mbar = u16clamp(d->cfg.surface_bar * 1000.0f);
    h->interval_s = interval_s ? interval_s : 2;
    h->gf_low = (uint8_t)lroundf(d->cfg.gf_low * 100.0f);
    h->gf_high = (uint8_t)lroundf(d->cfg.gf_high * 100.0f);
    h->water = d->cfg.bar_per_m > 0.1003f ? WATER_SALT : (d->cfg.bar_per_m < 0.0990f ? WATER_FRESH : WATER_EN13319);
    for (int i = 0; i < DC_MAX_GASES; i++) {
        h->o2[i] = (uint8_t)lroundf(d->gases[i].o2 * 100.0f);
        h->he[i] = (uint8_t)lroundf(d->gases[i].he * 100.0f);
        h->enabled[i] = d->gases[i].enabled;
        h->cylinder_l[i] = (uint8_t)lroundf(d->tanks[i].cylinder_l);
    }
    h->min_temp_dc = 32767;
    h->battery_start = d->battery_pct < 0 ? 255 : (uint8_t)d->battery_pct;
    h->battery_end = 255;
    w->crc = 0xFFFFFFFFu;
    w->since_sample_s = (float)h->interval_s; /* first sample right away */
    header_write(h, hdr_out);
}

void divelog_set_entry(divelog_writer_t *w, double lat, double lon)
{
    w->h.has_pos = 1;
    w->h.lat_e4 = (int32_t)lround(lat * 1e4);
    w->h.lon_e4 = (int32_t)lround(lon * 1e4);
}

void divelog_set_nav(divelog_writer_t *w, float x_m, float y_m)
{
    w->x_m = x_m;
    w->y_m = y_m;
}

bool divelog_tick(divelog_writer_t *w, const dive_t *d, float dt_s, uint8_t out[DIVELOG_SAMPLE])
{
    w->since_sample_s += dt_s;
    if (w->since_sample_s + 1e-3f < (float)w->h.interval_s) return false;
    w->since_sample_s = 0.0f;

    uint16_t depth = u16clamp(d->depth_m * 100.0f);
    int16_t temp = (int16_t)lroundf(d->temp_c * 10.0f);
    memset(out, 0, DIVELOG_SAMPLE);
    put16(out, depth);
    put16(out + 2, (uint16_t)temp);
    put16(out + 4, u16clamp(d->plan.ceiling_m * 100.0f));
    put16(out + 6, (uint16_t)d->alarms);
    out[8] = (uint8_t)d->gas;
    out[9] = (uint8_t)((d->plan.in_deco ? 1 : 0) | ((d->alarms & ALARM_TIME_LIMIT) ? 2 : 0));
    for (int i = 0; i < DC_MAX_GASES; i++)
        put16(out + 10 + 2 * i, d->tanks[i].present && d->tanks[i].age_s < 30.0f ? u16clamp(d->tanks[i].bar * 10.0f) : DIVELOG_NO_TANK);
    put16(out + 20, (uint16_t)i16clamp(w->x_m * 10.0f));
    put16(out + 22, (uint16_t)i16clamp(w->y_m * 10.0f));
    dc_crc32_feed(&w->crc, out, DIVELOG_SAMPLE);

    w->h.n_samples++;
    if (depth > w->h.max_depth_cm) w->h.max_depth_cm = depth;
    if (temp < w->h.min_temp_dc) w->h.min_temp_dc = temp;
    if (d->plan.in_deco) w->h.had_deco = 1;
    return true;
}

void divelog_end(divelog_writer_t *w, const dive_t *d, uint8_t hdr_out[DIVELOG_HEADER], uint8_t footer_out[DIVELOG_FOOTER])
{
    w->h.duration_s = w->h.n_samples * w->h.interval_s;
    float cns = d->ox.cns_pct;
    w->h.cns_end = (uint8_t)(cns > 255.0f ? 255 : (cns < 0 ? 0 : lroundf(cns)));
    w->h.battery_end = d->battery_pct < 0 ? 255 : (uint8_t)d->battery_pct;
    for (int i = 0; i < DC_MAX_GASES; i++)
        if (d->tanks[i].battery == TX_BATT_LOW) w->h.tx_low |= (uint8_t)(1u << i);
    if (w->h.min_temp_dc == 32767) w->h.min_temp_dc = 0;
    header_write(&w->h, hdr_out);
    put32(footer_out, ~w->crc);
}

bool divelog_parse_header(const uint8_t hdr[DIVELOG_HEADER], divelog_header_t *h)
{
    return header_read(hdr, h);
}

static int base_len(const divelog_header_t *h) { return (int)(DIVELOG_HEADER + h->n_samples * DIVELOG_SAMPLE + DIVELOG_FOOTER); }

bool divelog_parse(const uint8_t *log, int len, divelog_header_t *h)
{
    if (len < DIVELOG_HEADER + DIVELOG_FOOTER || !header_read(log, h)) return false;
    int base = base_len(h);
    if (len < base) return false;
    if (len > base) {
        dc_gear_t g;
        if (!gear_deserialize(log + base, len - base, &g)) return false;
    }
    return get32(log + base - 4) == dc_crc32(log + DIVELOG_HEADER, (int)(h->n_samples * DIVELOG_SAMPLE));
}

int divelog_gear_block(const dc_gear_t *g, uint8_t *out, int cap)
{
    dc_gear_t used = *g;
    for (int i = 0; i < used.n; i++) {
        bool carries = false;
        for (int k = 0; k < DC_MAX_GASES; k++) carries |= used.gas_cyl[k] == i + 1;
        if (carries) used.item[i].flags |= GEAR_ON_DIVE;
        if (!(used.item[i].flags & GEAR_ON_DIVE)) used.item[i].type = 0;   /* dropped by validate */
    }
    gear_validate(&used);
    if (!used.n) return 0;
    return gear_serialize(&used, out, cap);
}

bool divelog_gear(const uint8_t *log, int len, dc_gear_t *out)
{
    divelog_header_t h;
    if (len < DIVELOG_HEADER || !header_read(log, &h)) return false;
    int base = base_len(&h);
    return len > base && gear_deserialize(log + base, len - base, out);
}

void divelog_get_sample(const uint8_t *log, uint32_t i, divelog_sample_t *s)
{
    const uint8_t *p = log + DIVELOG_HEADER + i * DIVELOG_SAMPLE;
    s->depth_cm = get16(p);
    s->temp_dc = (int16_t)get16(p + 2);
    s->ceiling_cm = get16(p + 4);
    s->alarms = get16(p + 6);
    s->gas = p[8];
    s->flags = p[9];
    for (int k = 0; k < DC_MAX_GASES; k++) s->tank_dbar[k] = get16(p + 10 + 2 * k);
    s->x_dm = (int16_t)get16(p + 20);
    s->y_dm = (int16_t)get16(p + 22);
}

/* ---- UDDF ---- */

typedef struct {
    char *out;
    int cap, n;
    bool overflow;
} sbuf_t;

static void emit(sbuf_t *b, const char *fmt, ...)
{
    if (b->overflow) return;
    va_list ap;
    va_start(ap, fmt);
    int r = vsnprintf(b->out + b->n, (size_t)(b->cap - b->n), fmt, ap);
    va_end(ap);
    if (r < 0 || b->n + r >= b->cap) b->overflow = true;
    else b->n += r;
}

/* Civil date from days since 1970-01-01 (Howard Hinnant's algorithm). */
static void civil(int32_t z, int *y, int *m, int *d)
{
    z += 719468;
    int32_t era = (z >= 0 ? z : z - 146096) / 146097;
    uint32_t doe = (uint32_t)(z - era * 146097);
    uint32_t yoe = (doe - doe / 1460 + doe / 36524 - doe / 146096) / 365;
    int32_t yy = (int32_t)yoe + era * 400;
    uint32_t doy = doe - (365 * yoe + yoe / 4 - yoe / 100);
    uint32_t mp = (5 * doy + 2) / 153;
    *d = (int)(doy - (153 * mp + 2) / 5 + 1);
    *m = (int)(mp < 10 ? mp + 3 : mp - 9);
    *y = (int)(yy + (*m <= 2));
}

static void mixname(char *buf, int cap, int o2, int he)
{
    if (he) snprintf(buf, (size_t)cap, "Tx%d/%d", o2, he);
    else if (o2 == 21) snprintf(buf, (size_t)cap, "Air");
    else if (o2 == 100) snprintf(buf, (size_t)cap, "Oxygen");
    else snprintf(buf, (size_t)cap, "EAN%d", o2);
}

int divelog_uddf(const uint8_t *const logs[], const int lens[], int n, char *out, int cap)
{
    sbuf_t b = {out, cap, 0, false};
    divelog_header_t h;
    for (int k = 0; k < n; k++)
        if (!divelog_parse(logs[k], lens[k], &h)) return -1;

    emit(&b, "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n");
    emit(&b, "<uddf xmlns=\"http://www.streit.cc/uddf/3.2/\" version=\"3.2.3\">\n");
    emit(&b, "  <generator>\n    <name>NTNU student dive computer</name>\n    <type>divecomputer</type>\n"
             "    <version>0.1</version>\n  </generator>\n");

    /* Equipment of every dive, ids d<dive>_g<item>. */
    bool any_gear = false;
    dc_gear_t g;
    for (int k = 0; k < n; k++) any_gear |= divelog_gear(logs[k], lens[k], &g);
    if (any_gear) {
        static const char *tag[] = {"", "tank", "regulator", "buoyancycontroldevice", "suit", "lead", "light", "camera",
                                    "variouspieces"};
        emit(&b, "  <diver>\n    <owner id=\"owner\">\n      <personal><firstname>Diver</firstname></personal>\n"
                 "      <equipment>\n");
        for (int k = 0; k < n; k++) {
            if (!divelog_parse_header(logs[k], &h) || !divelog_gear(logs[k], lens[k], &g)) continue;
            for (int i = 0; i < g.n; i++) {
                const gear_item_t *it = &g.item[i];
                char name[GEAR_NAME * 6 + 1];
                int w = 0;
                for (const char *p = it->name[0] ? it->name : gear_type_name(it->type); *p && w < (int)sizeof(name) - 7; p++) {
                    const char *esc = *p == '&' ? "&amp;" : *p == '<' ? "&lt;" : *p == '>' ? "&gt;" : *p == '"' ? "&quot;" : NULL;
                    if (esc) { strcpy(name + w, esc); w += (int)strlen(esc); }
                    else name[w++] = *p;
                }
                name[w] = 0;
                emit(&b, "        <%s id=\"d%u_g%d\"><name>%s</name>", tag[it->type], h.dive_no, i, name);
                if (it->type == GEAR_CYLINDER) emit(&b, "<tankvolume>%.4f</tankvolume>", it->size_x10 / 10000.0);
                emit(&b, "</%s>\n", tag[it->type]);
            }
        }
        emit(&b, "      </equipment>\n    </owner>\n  </diver>\n");
    }

    emit(&b, "  <gasdefinitions>\n");
    for (int k = 0; k < n; k++) {
        divelog_parse(logs[k], lens[k], &h);
        for (int i = 0; i < DC_MAX_GASES; i++) {
            if (!h.enabled[i]) continue;
            char name[16];
            mixname(name, sizeof(name), h.o2[i], h.he[i]);
            emit(&b, "    <mix id=\"d%u_mix%d\">\n      <name>%s</name>\n      <o2>%.2f</o2>\n      <n2>%.2f</n2>\n"
                     "      <he>%.2f</he>\n    </mix>\n",
                 h.dive_no, i, name, h.o2[i] / 100.0, (100 - h.o2[i] - h.he[i]) / 100.0, h.he[i] / 100.0);
        }
    }
    emit(&b, "  </gasdefinitions>\n  <profiledata>\n    <repetitiongroup id=\"rg1\">\n");

    for (int k = 0; k < n; k++) {
        const uint8_t *log = logs[k];
        divelog_parse(log, lens[k], &h);
        int y, mo, d;
        civil((int32_t)(h.start_unix / 86400u), &y, &mo, &d);
        uint32_t sod = h.start_unix % 86400u;
        emit(&b, "      <dive id=\"dive%u\">\n        <informationbeforedive>\n", h.dive_no);
        emit(&b, "          <datetime>%04d-%02d-%02dT%02u:%02u:%02u</datetime>\n", y, mo, d, sod / 3600, (sod / 60) % 60, sod % 60);
        emit(&b, "          <divenumber>%u</divenumber>\n", h.dive_no);
        emit(&b, "          <surfacepressure>%u</surfacepressure>\n", h.surface_mbar * 100u);
        bool has_gear = divelog_gear(log, lens[k], &g);
        if (has_gear) {
            emit(&b, "          <equipmentused>\n");
            if (gear_lead_x10(&g)) emit(&b, "            <leadquantity>%.1f</leadquantity>\n", gear_lead_x10(&g) / 10.0);
            for (int i = 0; i < g.n; i++) emit(&b, "            <link ref=\"d%u_g%d\"/>\n", h.dive_no, i);
            emit(&b, "          </equipmentused>\n");
        }
        emit(&b, "        </informationbeforedive>\n");

        emit(&b, "        <samples>\n");
        int prev_gas = -1;
        divelog_sample_t s;
        for (uint32_t j = 0; j < h.n_samples; j++) {
            divelog_get_sample(log, j, &s);
            emit(&b, "          <waypoint><divetime>%u</divetime><depth>%.2f</depth><temperature>%.2f</temperature>",
                 j * h.interval_s, s.depth_cm / 100.0, s.temp_dc / 10.0 + 273.15);
            if (s.gas != prev_gas && s.gas < DC_MAX_GASES) {
                emit(&b, "<switchmix ref=\"d%u_mix%u\"/>", h.dive_no, s.gas);
                prev_gas = s.gas;
            }
            for (int i = 0; i < DC_MAX_GASES; i++)
                if (h.enabled[i] && s.tank_dbar[i] != DIVELOG_NO_TANK)
                    emit(&b, "<tankpressure ref=\"d%u_tank%d\">%d</tankpressure>", h.dive_no, i, s.tank_dbar[i] * 10000);
            if (s.ceiling_cm > 0) emit(&b, "<decostop kind=\"mandatory\" decodepth=\"%.1f\" duration=\"0\"/>", s.ceiling_cm / 100.0);
            emit(&b, "</waypoint>\n");
        }
        emit(&b, "        </samples>\n");
        /* Tank start and end pressure from the first and last sample that heard it. */
        for (int i = 0; i < DC_MAX_GASES; i++) {
            if (!h.enabled[i]) continue;
            int first = -1, last = -1;
            for (uint32_t j = 0; j < h.n_samples; j++) {
                divelog_get_sample(log, j, &s);
                if (s.tank_dbar[i] != DIVELOG_NO_TANK) {
                    if (first < 0) first = s.tank_dbar[i];
                    last = s.tank_dbar[i];
                }
            }
            emit(&b, "        <tankdata id=\"d%u_tank%d\">\n          <link ref=\"d%u_mix%d\"/>\n", h.dive_no, i, h.dive_no, i);
            if (has_gear && g.gas_cyl[i]) emit(&b, "          <link ref=\"d%u_g%d\"/>\n", h.dive_no, g.gas_cyl[i] - 1);
            emit(&b, "          <tankvolume>%.4f</tankvolume>\n", h.cylinder_l[i] / 1000.0);
            if (first >= 0)
                emit(&b, "          <tankpressurebegin>%d</tankpressurebegin>\n          <tankpressureend>%d</tankpressureend>\n",
                     first * 10000, last * 10000);
            emit(&b, "        </tankdata>\n");
        }

        emit(&b, "        <informationafterdive>\n");
        emit(&b, "          <greatestdepth>%.2f</greatestdepth>\n          <diveduration>%u</diveduration>\n",
             h.max_depth_cm / 100.0, h.duration_s);
        emit(&b, "          <lowesttemperature>%.2f</lowesttemperature>\n        </informationafterdive>\n      </dive>\n",
             h.min_temp_dc / 10.0 + 273.15);
    }
    emit(&b, "    </repetitiongroup>\n  </profiledata>\n</uddf>\n");
    return b.overflow ? -2 : b.n;
}
