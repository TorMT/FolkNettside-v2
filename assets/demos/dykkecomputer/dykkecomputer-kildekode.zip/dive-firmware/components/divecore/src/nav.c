/* nav.c — see nav.h. */
#include "divecore/nav.h"

#include <math.h>

#define DEG (3.14159265358979f / 180.0f)
#define EARTH_R 6371000.0

static float wrap360(float d)
{
    d = fmodf(d, 360.0f);
    return d < 0.0f ? d + 360.0f : d;
}

float compass_heading_deg(float ax, float ay, float az, float mx, float my, float mz, float declination_deg)
{
    /* Roll and pitch from gravity, then rotate the magnetic vector into the horizontal plane. */
    float roll = atan2f(ay, az);
    float pitch = atan2f(-ax, ay * sinf(roll) + az * cosf(roll));
    float xh = mx * cosf(pitch) + my * sinf(roll) * sinf(pitch) + mz * cosf(roll) * sinf(pitch);
    float yh = my * cosf(roll) - mz * sinf(roll);
    float h = atan2f(-yh, xh) / DEG;
    return wrap360(h + declination_deg);
}

float nav_turn_deg(float heading_deg, float bearing_deg)
{
    float d = fmodf(bearing_deg - heading_deg, 360.0f);
    if (d > 180.0f) d -= 360.0f;
    if (d <= -180.0f) d += 360.0f;
    return d;
}

void nav_init(nav_t *n, float drift_frac)
{
    n->lat0 = n->lon0 = 0.0;
    n->has_origin = false;
    n->x_m = n->y_m = 0.0f;
    n->swum_m = 0.0f;
    n->drift_frac = drift_frac;
}

void nav_set_origin(nav_t *n, double lat, double lon)
{
    n->lat0 = lat;
    n->lon0 = lon;
    n->has_origin = true;
    n->x_m = n->y_m = 0.0f;
    n->swum_m = 0.0f;
}

void nav_step(nav_t *n, float heading_deg, float speed_m_per_min, float dt_s)
{
    float d = speed_m_per_min * dt_s / 60.0f;
    n->x_m += d * sinf(heading_deg * DEG);
    n->y_m += d * cosf(heading_deg * DEG);
    n->swum_m += fabsf(d);
}

void nav_home(const nav_t *n, float *bearing_deg, float *dist_m)
{
    float dx = -n->x_m, dy = -n->y_m;
    *dist_m = sqrtf(dx * dx + dy * dy);
    *bearing_deg = wrap360(atan2f(dx, dy) / DEG);
}

float nav_error_radius_m(const nav_t *n)
{
    return n->swum_m * n->drift_frac;
}

void nav_position(const nav_t *n, double *lat, double *lon)
{
    *lat = n->lat0 + ((double)n->y_m / EARTH_R) * (180.0 / 3.14159265358979);
    *lon = n->lon0 + ((double)n->x_m / (EARTH_R * cos(n->lat0 * 3.14159265358979 / 180.0))) * (180.0 / 3.14159265358979);
}

void magcal_begin(magcal_t *c)
{
    for (int i = 0; i < 3; i++) { c->min[i] = 1e9f; c->max[i] = -1e9f; }
    c->n = 0;
}

void magcal_feed(magcal_t *c, float mx, float my, float mz)
{
    const float v[3] = {mx, my, mz};
    for (int i = 0; i < 3; i++) {
        if (v[i] < c->min[i]) c->min[i] = v[i];
        if (v[i] > c->max[i]) c->max[i] = v[i];
    }
    c->n++;
}

bool magcal_finish(const magcal_t *c, magcal_result_t *out)
{
    if (c->n < 50) return false;
    float span[3], avg = 0.0f;
    for (int i = 0; i < 3; i++) {
        span[i] = c->max[i] - c->min[i];
        /* The Earth's field is 25-65 uT, so a full turn spans at least ~40 uT on every axis. */
        if (span[i] < 30.0f) return false;
        avg += span[i] / 3.0f;
    }
    for (int i = 0; i < 3; i++) {
        out->offset[i] = (c->max[i] + c->min[i]) / 2.0f;
        out->scale[i] = avg / span[i];
    }
    return true;
}
