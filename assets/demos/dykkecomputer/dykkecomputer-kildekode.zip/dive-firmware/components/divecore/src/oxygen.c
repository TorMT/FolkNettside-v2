/* oxygen.c — CNS and OTU. See oxygen.h. */
#include "divecore/oxygen.h"

#include <math.h>

/* NOAA single-exposure limits: ppO2 (bar) -> minutes. */
static const float PPO2_TAB[] = {0.6f, 0.7f, 0.8f, 0.9f, 1.0f, 1.1f, 1.2f, 1.3f, 1.4f, 1.5f, 1.6f};
static const float LIMIT_TAB[] = {720, 570, 450, 360, 300, 240, 210, 180, 150, 120, 45};
#define TAB_N (sizeof(PPO2_TAB) / sizeof(PPO2_TAB[0]))

void dc_oxygen_reset(dc_oxygen_t *o)
{
    o->cns_pct = 0.0f;
    o->otu = 0.0f;
}

float dc_cns_limit_min(float ppo2)
{
    if (ppo2 < 0.5f) return 0.0f;
    if (ppo2 <= PPO2_TAB[0]) return LIMIT_TAB[0];
    for (unsigned i = 1; i < TAB_N; i++) {
        if (ppo2 <= PPO2_TAB[i]) {
            float f = (ppo2 - PPO2_TAB[i - 1]) / (PPO2_TAB[i] - PPO2_TAB[i - 1]);
            return LIMIT_TAB[i - 1] + f * (LIMIT_TAB[i] - LIMIT_TAB[i - 1]);
        }
    }
    /* Above 1.6 bar the limit collapses; extrapolate steeply and floor at 1 min. */
    float lim = 45.0f - (ppo2 - 1.6f) * 880.0f;
    return lim < 1.0f ? 1.0f : lim;
}

void dc_oxygen_update(dc_oxygen_t *o, float ppo2, float seconds)
{
    float minutes = seconds / 60.0f;
    if (ppo2 >= 0.5f) {
        o->cns_pct += 100.0f * minutes / dc_cns_limit_min(ppo2);
        o->otu += minutes * powf((ppo2 - 0.5f) / 0.5f, 0.83f);
    } else {
        o->cns_pct *= powf(0.5f, minutes / 90.0f);
    }
}
