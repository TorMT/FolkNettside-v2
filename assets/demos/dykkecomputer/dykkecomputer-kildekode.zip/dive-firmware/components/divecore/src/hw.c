/* hw.c — see hw.h. */
#include "divecore/hw.h"

#include <math.h>

void alarm_notifier_init(alarm_notifier_t *n)
{
    n->prev = 0;
    n->warn_start_ms = 0;
    n->warn_burst = false;
}

void alarm_notifier_step(alarm_notifier_t *n, uint32_t alarms, uint32_t critical_mask, uint32_t now_ms, bool vibrate_on,
                         bool sound_on, bool *vibrate, bool *buzz)
{
    bool on = false;
    bool critical = (alarms & critical_mask) != 0;
    uint32_t warnings = alarms & ~critical_mask;
    uint32_t fresh = warnings & ~(n->prev & ~critical_mask);
    if (fresh || (warnings && !n->warn_burst && now_ms - n->warn_start_ms >= 60000u)) {
        n->warn_start_ms = now_ms;
        n->warn_burst = true;
    }
    if (!warnings) n->warn_burst = false;
    if (critical) {
        on = (now_ms % 600u) < 400u;
    } else if (n->warn_burst) {
        uint32_t t = now_ms - n->warn_start_ms;
        if (t >= 720u) n->warn_burst = false;       /* 3 x (120 on + 120 off) */
        else on = (t % 240u) < 120u;
    }
    n->prev = alarms;
    *vibrate = on && (vibrate_on || critical);
    *buzz = on && sound_on;
}

int backlight_pct(int level, float lux, bool auto_on)
{
    if (level < 1) level = 1;
    if (level > 5) level = 5;
    if (!auto_on) return level * 20;
    if (lux < 0.1f) lux = 0.1f;
    /* 0.1 lux -> 15 %, 10 000 lux -> 100 %, straight line in log10(lux) */
    float pct = 15.0f + (log10f(lux) + 1.0f) * (85.0f / 5.0f);
    pct *= powf(1.25f, (float)(level - 3));
    if (pct < 5.0f) pct = 5.0f;
    if (pct > 100.0f) pct = 100.0f;
    return (int)lroundf(pct);
}
