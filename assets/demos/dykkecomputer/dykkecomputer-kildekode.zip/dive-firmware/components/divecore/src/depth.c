/* depth.c — MS5837-30BA maths, sensor cross-check and ascent rate. See depth.h. */
#include "divecore/depth.h"

#include <math.h>
#include <string.h>

static uint8_t ms5837_crc4(const ms5837_prom_t *prom)
{
    uint16_t n[8];
    memcpy(n, prom->c, sizeof(n));
    uint16_t rem = 0;
    n[0] &= 0x0FFF;
    n[7] = 0;
    for (int i = 0; i < 16; i++) {
        if (i % 2 == 1) rem ^= (uint16_t)(n[i >> 1] & 0x00FF);
        else rem ^= (uint16_t)(n[i >> 1] >> 8);
        for (int bit = 8; bit > 0; bit--) {
            if (rem & 0x8000) rem = (uint16_t)((rem << 1) ^ 0x3000);
            else rem = (uint16_t)(rem << 1);
        }
    }
    return (uint8_t)((rem >> 12) & 0x0F);
}

bool ms5837_prom_ok(const ms5837_prom_t *prom)
{
    return ms5837_crc4(prom) == (prom->c[0] >> 12);
}

typedef struct {
    int64_t off2, sens2, temp2;
} comp_t;

static comp_t compensate_terms(const ms5837_prom_t *p, uint32_t d2)
{
    const uint16_t *C = p->c;
    int64_t dT = (int64_t)d2 - (int64_t)C[5] * 256;
    int64_t sens = (int64_t)C[1] * 32768 + ((int64_t)C[3] * dT) / 256;
    int64_t off = (int64_t)C[2] * 65536 + ((int64_t)C[4] * dT) / 128;
    int64_t temp = 2000 + dT * (int64_t)C[6] / 8388608LL;

    int64_t ti, offi, sensi;
    if (temp < 2000) {
        ti = (3 * dT * dT) / 8589934592LL;
        offi = (3 * (temp - 2000) * (temp - 2000)) / 2;
        sensi = (5 * (temp - 2000) * (temp - 2000)) / 8;
        if (temp < -1500) {
            offi += 7 * (temp + 1500) * (temp + 1500);
            sensi += 4 * (temp + 1500) * (temp + 1500);
        }
    } else {
        ti = (2 * dT * dT) / 137438953472LL;
        offi = ((temp - 2000) * (temp - 2000)) / 16;
        sensi = 0;
    }
    comp_t r = {off - offi, sens - sensi, temp - ti};
    return r;
}

void ms5837_30ba_compensate(const ms5837_prom_t *prom, uint32_t d1, uint32_t d2, float *mbar, float *celsius)
{
    comp_t c = compensate_terms(prom, d2);
    int64_t p = (((int64_t)d1 * c.sens2) / 2097152 - c.off2) / 8192; /* 0.1 mbar */
    if (mbar) *mbar = (float)p / 10.0f;
    if (celsius) *celsius = (float)c.temp2 / 100.0f;
}

uint32_t ms5837_30ba_d1_for(const ms5837_prom_t *prom, uint32_t d2, float mbar)
{
    comp_t c = compensate_terms(prom, d2);
    int64_t p = (int64_t)llroundf(mbar * 10.0f);
    int64_t d1 = ((p * 8192 + c.off2) * 2097152 + c.sens2 - 1) / c.sens2;
    if (d1 < 0) d1 = 0;
    if (d1 > 0xFFFFFF) d1 = 0xFFFFFF;
    return (uint32_t)d1;
}

void depth_check_init(depth_check_t *c)
{
    c->tol_m = 0.3f;
    c->tol_frac = 0.03f;
    c->persist_s = 5.0f;
    c->disagree_s = 0.0f;
}

float depth_check(depth_check_t *c, float a, float b, float dt_s, depth_status_t *status)
{
    bool ha = !isnan(a), hb = !isnan(b);
    if (!ha && !hb) {
        *status = DEPTH_NONE;
        return NAN;
    }
    if (!hb) {
        *status = DEPTH_ONLY_A;
        return a;
    }
    if (!ha) {
        *status = DEPTH_ONLY_B;
        return b;
    }
    float deeper = a > b ? a : b;
    float diff = fabsf(a - b);
    float tol = c->tol_m > c->tol_frac * deeper ? c->tol_m : c->tol_frac * deeper;
    if (diff > tol) c->disagree_s += dt_s;
    else c->disagree_s = 0.0f;
    *status = c->disagree_s >= c->persist_s ? DEPTH_DISAGREE : DEPTH_OK;
    return *status == DEPTH_DISAGREE ? deeper : 0.5f * (a + b);
}

void ascent_rate_init(ascent_rate_t *a, float window_s)
{
    memset(a, 0, sizeof(*a));
    a->window_s = window_s;
}

float ascent_rate_push(ascent_rate_t *a, float t_s, float depth_m)
{
    a->depth[a->head] = depth_m;
    a->t[a->head] = t_s;
    a->head = (a->head + 1) % ASCENT_WIN;
    if (a->n < ASCENT_WIN) a->n++;
    /* Oldest sample still inside the window. */
    int oldest = -1;
    for (int k = 0; k < a->n; k++) {
        int idx = (a->head - 1 - k + 2 * ASCENT_WIN) % ASCENT_WIN;
        if (t_s - a->t[idx] <= a->window_s + 1e-3f) oldest = idx;
        else break;
    }
    if (oldest < 0) return 0.0f;
    float dt = t_s - a->t[oldest];
    if (dt < 0.5f) return 0.0f;
    return (a->depth[oldest] - depth_m) / dt * 60.0f;
}
