/* pelagic.c — see pelagic.h. */
#include "divecore/pelagic.h"

int pelagic_nibble_to_digit(uint8_t nib)
{
    switch (nib) {
    case 10: return 0;
    case 11: return 1;
    case 12: return 2;
    case 3: return 3;
    case 13: return 4;
    case 5: return 5;
    case 6: return 6;
    case 7: return 7;
    case 14: return 8;
    case 9: return 9;
    default: return -1;
    }
}

uint8_t pelagic_digit_to_nibble(int d)
{
    static const uint8_t map[10] = {10, 11, 12, 3, 13, 5, 6, 7, 14, 9};
    return (d >= 0 && d <= 9) ? map[d] : 0;
}

static uint8_t nibble_at(const uint8_t *bits, int start)
{
    return (uint8_t)((bits[start] << 3) | (bits[start + 1] << 2) | (bits[start + 2] << 1) | bits[start + 3]);
}

pelagic_result_t pelagic_decode_bits(const uint8_t *bits, int n, pelagic_packet_t *out)
{
    if (n != PELAGIC_BITS) return PELAGIC_BAD_LENGTH;
    uint8_t nib[12];
    unsigned sum = 0;
    for (int i = 0; i < 12; i++) {
        nib[i] = nibble_at(bits, 2 + 4 * i);
        sum += nib[i];
    }
    uint8_t ck = 0;
    for (int i = 0; i < 8; i++) ck = (uint8_t)((ck << 1) | bits[50 + i]);
    out->checksum = ck;
    if ((uint8_t)(sum & 0xFF) != ck) return PELAGIC_BAD_CHECKSUM;

    uint32_t serial = 0;
    for (int i = 2; i < 8; i++) {
        int d = pelagic_nibble_to_digit(nib[i]);
        if (d < 0) return PELAGIC_BAD_DIGIT;
        serial = serial * 10 + (uint32_t)d;
    }
    out->header[0] = nib[0];
    out->header[1] = nib[1];
    out->serial = serial;
    out->psi = (uint16_t)(((nib[8] << 8) | (nib[9] << 4) | nib[10]) * 2);
    out->battery = nib[11];
    return PELAGIC_OK;
}

int pelagic_bits_from_pauses(const uint16_t *pause_us, int n, uint8_t *bits_out)
{
    if (n <= 0) return 0;
    uint16_t lo = pause_us[0], hi = pause_us[0];
    for (int i = 1; i < n; i++) {
        if (pause_us[i] < lo) lo = pause_us[i];
        if (pause_us[i] > hi) hi = pause_us[i];
    }
    /* Two-means refinement of the threshold. */
    float thr = 0.5f * (lo + hi);
    for (int it = 0; it < 8; it++) {
        float s0 = 0, s1 = 0;
        int n0 = 0, n1 = 0;
        for (int i = 0; i < n; i++) {
            if (pause_us[i] < thr) { s0 += pause_us[i]; n0++; }
            else { s1 += pause_us[i]; n1++; }
        }
        if (n0 == 0 || n1 == 0) break;
        thr = 0.5f * (s0 / n0 + s1 / n1);
    }
    for (int i = 0; i < n; i++) bits_out[i] = pause_us[i] >= thr ? 1 : 0;
    return n;
}

bool pelagic_encode_bits(uint32_t serial, uint16_t psi, uint8_t battery, const uint8_t header[2], uint8_t bits[PELAGIC_BITS])
{
    if (serial > 999999u || psi / 2 > 0xFFF) return false;
    uint8_t nib[12];
    nib[0] = header ? (header[0] & 0xF) : 8;
    nib[1] = header ? (header[1] & 0xF) : 1;
    uint32_t s = serial;
    for (int i = 7; i >= 2; i--) {
        nib[i] = pelagic_digit_to_nibble((int)(s % 10));
        s /= 10;
    }
    uint16_t count = psi / 2;
    nib[8] = (uint8_t)((count >> 8) & 0xF);
    nib[9] = (uint8_t)((count >> 4) & 0xF);
    nib[10] = (uint8_t)(count & 0xF);
    nib[11] = battery & 0xF;
    unsigned sum = 0;
    bits[0] = 0;
    bits[1] = 0;
    for (int i = 0; i < 12; i++) {
        sum += nib[i];
        for (int b = 0; b < 4; b++) bits[2 + 4 * i + b] = (uint8_t)((nib[i] >> (3 - b)) & 1);
    }
    uint8_t ck = (uint8_t)(sum & 0xFF);
    for (int b = 0; b < 8; b++) bits[50 + b] = (uint8_t)((ck >> (7 - b)) & 1);
    return true;
}
