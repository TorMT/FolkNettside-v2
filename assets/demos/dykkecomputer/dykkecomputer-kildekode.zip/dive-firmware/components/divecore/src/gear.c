/* gear.c — see gear.h. */
#include "divecore/gear.h"

#include <string.h>

static void put16(uint8_t *p, uint16_t v) { p[0] = (uint8_t)v; p[1] = (uint8_t)(v >> 8); }
static void put32(uint8_t *p, uint32_t v) { put16(p, (uint16_t)v); put16(p + 2, (uint16_t)(v >> 16)); }
static uint16_t get16(const uint8_t *p) { return (uint16_t)(p[0] | (p[1] << 8)); }
static uint32_t get32(const uint8_t *p) { return (uint32_t)get16(p) | ((uint32_t)get16(p + 2) << 16); }

void gear_init(dc_gear_t *g) { memset(g, 0, sizeof(*g)); }

const char *gear_type_name(int type)
{
    static const char *n[] = {"?", "Cylinder", "Regulator", "BCD", "Suit", "Weights", "Light", "Camera", "Other"};
    return type >= 1 && type <= GEAR_TYPE_MAX ? n[type] : n[0];
}

void gear_validate(dc_gear_t *g)
{
    int w = 0;
    int map[GEAR_MAX];
    if (g->n > GEAR_MAX) g->n = GEAR_MAX;
    for (int i = 0; i < g->n; i++) {
        gear_item_t it = g->item[i];
        map[i] = -1;
        if (it.type < 1 || it.type > GEAR_TYPE_MAX) continue;
        it.name[GEAR_NAME] = 0;
        for (int k = 0; k < GEAR_NAME && it.name[k]; k++)
            if ((unsigned char)it.name[k] < 32 || (unsigned char)it.name[k] > 126) it.name[k] = '?';
        it.flags &= GEAR_ON_DIVE;
        if (it.type == GEAR_CYLINDER) {
            if (it.size_x10 < 10) it.size_x10 = 10;
            if (it.size_x10 > 300) it.size_x10 = 300;
            if (it.work_bar < 50 || it.work_bar > 300) it.work_bar = 200;
        } else {
            it.work_bar = 0;
            it.tx_serial = 0;
        }
        map[i] = w;
        g->item[w++] = it;
    }
    for (int i = 0; i < DC_MAX_GASES; i++) {
        int k = g->gas_cyl[i];
        if (k < 1 || k > g->n || map[k - 1] < 0 || g->item[map[k - 1]].type != GEAR_CYLINDER) g->gas_cyl[i] = 0;
        else g->gas_cyl[i] = (uint8_t)(map[k - 1] + 1);
    }
    g->n = (uint8_t)w;
    /* One cylinder carries one gas. */
    for (int i = 0; i < DC_MAX_GASES; i++)
        for (int j = 0; j < i; j++)
            if (g->gas_cyl[i] && g->gas_cyl[i] == g->gas_cyl[j]) g->gas_cyl[i] = 0;
}

int gear_serialize(const dc_gear_t *g, uint8_t *buf, int cap)
{
    int n = g->n > GEAR_MAX ? GEAR_MAX : g->n;
    int size = 13 + n * GEAR_ITEM_BYTES + 4;
    if (cap < size) return 0;
    memset(buf, 0, (size_t)size);
    buf[0] = 'D';
    buf[1] = 'G';
    buf[2] = GEAR_VERSION;
    buf[3] = (uint8_t)n;
    put32(buf + 4, g->synced_unix);
    memcpy(buf + 8, g->gas_cyl, DC_MAX_GASES);
    uint8_t *p = buf + 13;
    for (int i = 0; i < n; i++, p += GEAR_ITEM_BYTES) {
        const gear_item_t *it = &g->item[i];
        p[0] = it->type;
        p[1] = it->flags;
        put16(p + 2, it->size_x10);
        put16(p + 4, it->work_bar);
        put32(p + 6, it->tx_serial);
        strncpy((char *)p + 10, it->name, GEAR_NAME);
    }
    put32(buf + size - 4, dc_crc32(buf, size - 4));
    return size;
}

bool gear_deserialize(const uint8_t *buf, int len, dc_gear_t *out)
{
    if (len < 17 || buf[0] != 'D' || buf[1] != 'G' || buf[2] != GEAR_VERSION) return false;
    int n = buf[3];
    int size = 13 + n * GEAR_ITEM_BYTES + 4;
    if (n > GEAR_MAX || len < size) return false;
    if (get32(buf + size - 4) != dc_crc32(buf, size - 4)) return false;
    gear_init(out);
    out->n = (uint8_t)n;
    out->synced_unix = get32(buf + 4);
    memcpy(out->gas_cyl, buf + 8, DC_MAX_GASES);
    const uint8_t *p = buf + 13;
    for (int i = 0; i < n; i++, p += GEAR_ITEM_BYTES) {
        gear_item_t *it = &out->item[i];
        it->type = p[0];
        it->flags = p[1];
        it->size_x10 = get16(p + 2);
        it->work_bar = get16(p + 4);
        it->tx_serial = get32(p + 6);
        memcpy(it->name, p + 10, GEAR_NAME);
        it->name[GEAR_NAME] = 0;
    }
    gear_validate(out);
    return true;
}

bool gear_apply(const dc_gear_t *g, dc_settings_t *s)
{
    dc_settings_t before = *s;
    for (int i = 0; i < DC_MAX_GASES; i++) {
        if (!g->gas_cyl[i]) continue;
        const gear_item_t *c = &g->item[g->gas_cyl[i] - 1];
        s->gas[i].cylinder_l = (uint8_t)((c->size_x10 + 5) / 10);
        if (c->tx_serial) s->gas[i].tx_serial = c->tx_serial;
        s->gas[i].enabled = 1;
        if (s->gas[i].fill_bar > c->work_bar) s->gas[i].fill_bar = c->work_bar;
    }
    settings_validate(s);
    return memcmp(&before, s, sizeof(before)) != 0;
}

bool gear_take_serials(dc_gear_t *g, const dc_settings_t *s)
{
    bool changed = false;
    for (int i = 0; i < DC_MAX_GASES; i++) {
        if (!g->gas_cyl[i] || !s->gas[i].tx_serial) continue;
        gear_item_t *c = &g->item[g->gas_cyl[i] - 1];
        if (c->tx_serial != s->gas[i].tx_serial) {
            c->tx_serial = s->gas[i].tx_serial;
            changed = true;
        }
    }
    return changed;
}

int gear_on_dive(const dc_gear_t *g)
{
    int n = 0;
    for (int i = 0; i < g->n; i++) n += (g->item[i].flags & GEAR_ON_DIVE) ? 1 : 0;
    return n;
}

int gear_lead_x10(const dc_gear_t *g)
{
    int kg = 0;
    for (int i = 0; i < g->n; i++)
        if (g->item[i].type == GEAR_WEIGHTS && (g->item[i].flags & GEAR_ON_DIVE)) kg += g->item[i].size_x10;
    return kg;
}
