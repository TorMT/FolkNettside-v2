/* nmea.c — see nmea.h. */
#include "divecore/nmea.h"

#include <stdlib.h>
#include <string.h>

void nmea_init(nmea_parser_t *p, nmea_fix_t *fix)
{
    p->n = 0;
    memset(fix, 0, sizeof(*fix));
}

static int hexval(char c)
{
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'A' && c <= 'F') return c - 'A' + 10;
    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
    return -1;
}

/* ddmm.mmmm or dddmm.mmmm to degrees */
static double degmin(const char *s)
{
    double v = atof(s);
    int deg = (int)(v / 100.0);
    return deg + (v - deg * 100.0) / 60.0;
}

/* Days from 1970-01-01 to y-m-d (proleptic Gregorian). */
static int32_t days_from_civil(int y, int m, int d)
{
    y -= m <= 2;
    int32_t era = (y >= 0 ? y : y - 399) / 400;
    int32_t yoe = y - era * 400;
    int32_t doy = (153 * (m + (m > 2 ? -3 : 9)) + 2) / 5 + d - 1;
    int32_t doe = yoe * 365 + yoe / 4 - yoe / 100 + doy;
    return era * 146097 + doe - 719468;
}

static bool sentence(char *s, nmea_fix_t *fix)
{
    /* s: "GPGGA,..." without '$' and checksum */
    char *f[20];
    int nf = 0;
    f[nf++] = s;
    for (char *p = s; *p && nf < 20; p++)
        if (*p == ',') { *p = 0; f[nf++] = p + 1; }
    if (strlen(f[0]) < 5) return false;
    const char *type = f[0] + 2;
    if (strcmp(type, "GGA") == 0 && nf >= 9) {
        int q = atoi(f[6]);
        if (q <= 0 || !*f[2] || !*f[4]) {
            bool had = fix->has_fix;
            fix->has_fix = false;
            return had;
        }
        fix->lat = degmin(f[2]) * (f[3][0] == 'S' ? -1.0 : 1.0);
        fix->lon = degmin(f[4]) * (f[5][0] == 'W' ? -1.0 : 1.0);
        fix->sats = atoi(f[7]);
        fix->hdop = (float)atof(f[8]);
        fix->has_fix = true;
        return true;
    }
    if (strcmp(type, "RMC") == 0 && nf >= 10 && f[2][0] == 'A' && strlen(f[1]) >= 6 && strlen(f[9]) == 6) {
        int hh = (f[1][0] - '0') * 10 + (f[1][1] - '0'), mm = (f[1][2] - '0') * 10 + (f[1][3] - '0'), ss = (f[1][4] - '0') * 10 + (f[1][5] - '0');
        int dd = (f[9][0] - '0') * 10 + (f[9][1] - '0'), mo = (f[9][2] - '0') * 10 + (f[9][3] - '0'), yy = (f[9][4] - '0') * 10 + (f[9][5] - '0');
        if (hh > 23 || mm > 59 || ss > 60 || dd < 1 || dd > 31 || mo < 1 || mo > 12) return false;
        fix->unix_time = (uint32_t)days_from_civil(2000 + yy, mo, dd) * 86400u + (uint32_t)(hh * 3600 + mm * 60 + ss);
        return true;
    }
    return false;
}

bool nmea_feed(nmea_parser_t *p, char c, nmea_fix_t *fix)
{
    if (c == '$') {
        p->n = 0;
        p->line[p->n++] = c;
        return false;
    }
    if (p->n == 0) return false;                      /* waiting for '$' */
    if (c != '\r' && c != '\n') {
        if (p->n < (int)sizeof(p->line) - 1) p->line[p->n++] = c;
        else p->n = 0;                                /* too long: not NMEA */
        return false;
    }
    p->line[p->n] = 0;
    int n = p->n;
    p->n = 0;
    /* "$....*HH" */
    if (n < 9 || p->line[n - 3] != '*') return false;
    uint8_t sum = 0;
    for (int i = 1; i < n - 3; i++) sum ^= (uint8_t)p->line[i];
    int hi = hexval(p->line[n - 2]), lo = hexval(p->line[n - 1]);
    if (hi < 0 || lo < 0 || sum != (uint8_t)(hi << 4 | lo)) return false;
    p->line[n - 3] = 0;
    return sentence(p->line + 1, fix);
}
