/* proto.c — see proto.h. */
#include "divecore/proto.h"

#include <math.h>
#include <string.h>

#include "divecore/divelog.h"

static void put16(uint8_t *p, uint16_t v) { p[0] = (uint8_t)v; p[1] = (uint8_t)(v >> 8); }
static void put32(uint8_t *p, uint32_t v) { put16(p, (uint16_t)v); put16(p + 2, (uint16_t)(v >> 16)); }
static uint16_t get16(const uint8_t *p) { return (uint16_t)(p[0] | (p[1] << 8)); }
static uint32_t get32(const uint8_t *p) { return (uint32_t)get16(p) | ((uint32_t)get16(p + 2) << 16); }

static int reply(uint8_t *resp, int cap, uint8_t cmd, uint8_t seq, uint8_t status, int len)
{
    if (len < 0 || 5 + len > cap) {
        status = ST_FAILED;
        len = 0;
    }
    resp[0] = (uint8_t)(cmd | 0x80);
    resp[1] = seq;
    resp[2] = status;
    put16(resp + 3, (uint16_t)len);
    return 5 + len;
}

int proto_handle(proto_dev_t *dev, const uint8_t *req, int req_len, uint8_t *resp, int cap)
{
    if (req_len < 4 || cap < 5) return 0;
    uint8_t cmd = req[0], seq = req[1];
    uint16_t len = get16(req + 2);
    if (4 + len > req_len) return reply(resp, cap, cmd, seq, ST_BAD_REQUEST, 0);
    const uint8_t *in = req + 4;
    uint8_t *out = resp + 5;
    int room = cap - 5;
    const dive_t *d = dev->dive;
    bool diving = d && d->state == DIVE_ACTIVE;

    switch (cmd) {
    case CMD_INFO: {
        const char *fw = dev->fw_version ? dev->fw_version : "";
        int fl = (int)strlen(fw);
        if (fl > 40) fl = 40;
        if (room < 5 + fl) return reply(resp, cap, cmd, seq, ST_FAILED, 0);
        out[0] = PROTO_VERSION;
        out[1] = d ? (uint8_t)d->state : 0;
        out[2] = d && d->battery_pct >= 0 ? (uint8_t)d->battery_pct : dev->battery_pct;
        put16(out + 3, (uint16_t)(dev->log_count ? dev->log_count(dev->ctx) : 0));
        memcpy(out + 5, fw, (size_t)fl);
        return reply(resp, cap, cmd, seq, ST_OK, 5 + fl);
    }
    case CMD_GET_SETTINGS: {
        int n = settings_serialize(dev->settings, out, room);
        return reply(resp, cap, cmd, seq, n ? ST_OK : ST_FAILED, n);
    }
    case CMD_SET_SETTINGS: {
        if (diving) return reply(resp, cap, cmd, seq, ST_BUSY_DIVING, 0);
        dc_settings_t s;
        if (!settings_deserialize(in, len, &s)) return reply(resp, cap, cmd, seq, ST_CRC, 0);
        *dev->settings = s;
        bool ok = dev->settings_store ? dev->settings_store(dev->ctx, &s) : true;
        return reply(resp, cap, cmd, seq, ok ? ST_OK : ST_FAILED, 0);
    }
    case CMD_GET_GEAR: {
        if (!dev->gear) return reply(resp, cap, cmd, seq, ST_FAILED, 0);
        int n = gear_serialize(dev->gear, out, room);
        return reply(resp, cap, cmd, seq, n ? ST_OK : ST_FAILED, n);
    }
    case CMD_SET_GEAR: {
        if (diving) return reply(resp, cap, cmd, seq, ST_BUSY_DIVING, 0);
        if (!dev->gear) return reply(resp, cap, cmd, seq, ST_FAILED, 0);
        dc_gear_t g;
        if (!gear_deserialize(in, len, &g)) return reply(resp, cap, cmd, seq, ST_CRC, 0);
        *dev->gear = g;
        bool ok = dev->gear_store ? dev->gear_store(dev->ctx, &g) : true;
        if (gear_apply(&g, dev->settings) && dev->settings_store) ok = dev->settings_store(dev->ctx, dev->settings) && ok;
        return reply(resp, cap, cmd, seq, ok ? ST_OK : ST_FAILED, 0);
    }
    case CMD_LIST_LOGS: {
        int n = dev->log_count ? dev->log_count(dev->ctx) : 0;
        int w = 0;
        for (int i = 0; i < n && w + 16 <= room && w + 16 <= PROTO_MAX_CHUNK * 4; i++) {
            uint8_t hb[DIVELOG_HEADER];
            divelog_header_t h;
            if (dev->log_read(dev->ctx, i, 0, hb, DIVELOG_HEADER) != DIVELOG_HEADER) continue;
            /* Header CRC only; the full log is checked by the phone after download. */
            if (!divelog_parse_header(hb, &h)) continue;
            put16(out + w, (uint16_t)i);
            put16(out + w + 2, h.dive_no);
            put32(out + w + 4, h.start_unix);
            put32(out + w + 8, h.duration_s);
            put16(out + w + 12, h.max_depth_cm);
            out[w + 14] = h.had_deco;
            out[w + 15] = 0;
            w += 16;
        }
        return reply(resp, cap, cmd, seq, ST_OK, w);
    }
    case CMD_LOG_SIZE: {
        if (len < 2) return reply(resp, cap, cmd, seq, ST_BAD_REQUEST, 0);
        int idx = get16(in);
        int n = dev->log_count ? dev->log_count(dev->ctx) : 0;
        if (idx >= n) return reply(resp, cap, cmd, seq, ST_NOT_FOUND, 0);
        put32(out, (uint32_t)dev->log_size(dev->ctx, idx));
        return reply(resp, cap, cmd, seq, ST_OK, 4);
    }
    case CMD_READ_LOG: {
        if (len < 8) return reply(resp, cap, cmd, seq, ST_BAD_REQUEST, 0);
        int idx = get16(in);
        uint32_t off = get32(in + 2);
        int want = get16(in + 6);
        if (want > PROTO_MAX_CHUNK) want = PROTO_MAX_CHUNK;
        if (want > room) want = room;
        int n = dev->log_count ? dev->log_count(dev->ctx) : 0;
        if (idx >= n) return reply(resp, cap, cmd, seq, ST_NOT_FOUND, 0);
        int got = dev->log_read(dev->ctx, idx, off, out, want);
        return reply(resp, cap, cmd, seq, got >= 0 ? ST_OK : ST_FAILED, got >= 0 ? got : 0);
    }
    case CMD_LIVE: {
        if (!d || room < 14) return reply(resp, cap, cmd, seq, ST_FAILED, 0);
        const dive_tank_t *t = dive_active_tank(d);
        out[0] = (uint8_t)d->state;
        put16(out + 1, (uint16_t)lroundf(d->depth_m * 100.0f));
        out[3] = (uint8_t)(d->plan.ndl_min > 255 ? 255 : d->plan.ndl_min);
        put16(out + 4, (uint16_t)d->plan.tts_min);
        out[6] = (uint8_t)d->gas;
        put16(out + 7, t ? (uint16_t)lroundf(t->bar * 10.0f) : 0xFFFF);
        out[9] = (uint8_t)(d->ox.cns_pct > 255.0f ? 255 : lroundf(d->ox.cns_pct));
        put16(out + 10, (uint16_t)d->alarms);
        out[12] = d->plan.in_deco ? 1 : 0;
        out[13] = (uint8_t)(d->alarms >> 16);
        return reply(resp, cap, cmd, seq, ST_OK, 14);
    }
    case CMD_TANKS: {
        if (!d || room < 12 * DIVE_MAX_TANKS) return reply(resp, cap, cmd, seq, ST_FAILED, 0);
        for (int i = 0; i < DIVE_MAX_TANKS; i++) {
            const dive_tank_t *t = &d->tanks[i];
            uint8_t *o = out + 12 * i;
            o[0] = t->present ? 1 : 0;
            o[1] = t->battery;
            put32(o + 2, t->serial);
            put16(o + 6, t->present ? (uint16_t)lroundf(t->bar * 10.0f) : 0xFFFF);
            put16(o + 8, (uint16_t)(t->age_s > 65000.0f ? 65000 : lroundf(t->age_s)));
            o[10] = d->gases[i].enabled ? 1 : 0;
            o[11] = 0;
        }
        return reply(resp, cap, cmd, seq, ST_OK, 12 * DIVE_MAX_TANKS);
    }
    case CMD_PREDIVE: {
        if (!d) return reply(resp, cap, cmd, seq, ST_FAILED, 0);
        predive_t pd;
        predive_env_t env = {.depth_sensors = dev->depth_sensors, .now_unix = dev->now_unix};
        predive_run(d, dev->settings, dev->gear, dev->plan, &env, &pd);
        int n = predive_serialize(&pd, out, room);
        return reply(resp, cap, cmd, seq, n ? ST_OK : ST_FAILED, n);
    }
    case CMD_GET_PLAN: {
        if (!dev->plan || !dev->plan->valid) return reply(resp, cap, cmd, seq, ST_OK, 0);
        int n = divplan_serialize(dev->plan, out, room);
        return reply(resp, cap, cmd, seq, n ? ST_OK : ST_FAILED, n);
    }
    case CMD_SET_PLAN: {
        if (diving) return reply(resp, cap, cmd, seq, ST_BUSY_DIVING, 0);
        if (!dev->plan) return reply(resp, cap, cmd, seq, ST_BAD_REQUEST, 0);
        dc_divplan_t p;
        if (len == 0) memset(&p, 0, sizeof(p));
        else if (!divplan_deserialize(in, len, &p)) return reply(resp, cap, cmd, seq, ST_CRC, 0);
        *dev->plan = p;
        bool ok = dev->plan_store ? dev->plan_store(dev->ctx, &p) : true;
        return reply(resp, cap, cmd, seq, ok ? ST_OK : ST_FAILED, 0);
    }
    case CMD_SET_TIME: {
        if (len < 4) return reply(resp, cap, cmd, seq, ST_BAD_REQUEST, 0);
        uint32_t t = get32(in);
        if (t < 1600000000u) return reply(resp, cap, cmd, seq, ST_BAD_REQUEST, 0);   /* before 2020: a phone with no clock */
        if (dev->set_time) dev->set_time(dev->ctx, t);
        dev->now_unix = t;
        return reply(resp, cap, cmd, seq, ST_OK, 0);
    }
    case CMD_OTA_BEGIN:
    case CMD_OTA_DATA:
    case CMD_OTA_END: {
        if (diving) return reply(resp, cap, cmd, seq, ST_BUSY_DIVING, 0);
        if (len < 4 || !dev->ota) return reply(resp, cap, cmd, seq, ST_BAD_REQUEST, 0);
        int step = cmd == CMD_OTA_BEGIN ? OTA_BEGIN : (cmd == CMD_OTA_DATA ? OTA_DATA : OTA_END);
        int st = dev->ota(dev->ctx, step, get32(in), in + 4, len - 4);
        return reply(resp, cap, cmd, seq, (uint8_t)st, 0);
    }
    default:
        return reply(resp, cap, cmd, seq, ST_BAD_REQUEST, 0);
    }
}
