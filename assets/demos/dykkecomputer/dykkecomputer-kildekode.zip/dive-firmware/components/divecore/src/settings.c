/* settings.c — see settings.h. */
#include "divecore/settings.h"

#include <string.h>

uint32_t dc_crc32(const uint8_t *p, int n)
{
    uint32_t c = 0xFFFFFFFFu;
    for (int i = 0; i < n; i++) {
        c ^= p[i];
        for (int k = 0; k < 8; k++) c = (c >> 1) ^ (0xEDB88320u & (0u - (c & 1u)));
    }
    return ~c;
}

void settings_default(dc_settings_t *s)
{
    memset(s, 0, sizeof(*s));
    static const uint8_t o2[DC_MAX_GASES] = {21, 50, 100, 32, 21};
    for (int i = 0; i < DC_MAX_GASES; i++) {
        s->gas[i].o2_pct = o2[i];
        s->gas[i].he_pct = 0;
        s->gas[i].enabled = i == 0;
        s->gas[i].cylinder_l = i == 0 ? 12 : (i == 2 ? 7 : 11);
        s->gas[i].fill_bar = i == 0 ? 220 : 200;
    }
    s->gf_low = 50;
    s->gf_high = 80;
    s->water = WATER_SALT;
    s->last_stop_m = 3;
    s->ppo2_bottom_x100 = 140;
    s->ppo2_deco_x100 = 160;
    s->reserve_bar = 50;
    s->ascent_alarm_mpm = 10;
    s->brightness = 3;
    s->pairing = 1;
    s->declination_deg = 2; /* Trondheim, roughly; set it for your site */
    s->safety_stop = 1;
    s->bluetooth = 1;
    s->depth_alarm_m = 0;
    s->time_alarm_min = 0;
    s->ndl_warn_min = 5;
    s->turn_margin_bar = 20;
    s->flip = 0;
    s->log_interval_s = 2;
    s->vibrate = 1;
    s->sound = 1;
    s->auto_bright = 1;
    s->sleep_min = 10;
}

#define CLAMP(v, lo, hi) ((v) < (lo) ? (lo) : ((v) > (hi) ? (hi) : (v)))

void settings_validate(dc_settings_t *s)
{
    for (int i = 0; i < DC_MAX_GASES; i++) {
        dc_gas_setting_t *g = &s->gas[i];
        g->o2_pct = CLAMP(g->o2_pct, 5, 100);
        g->he_pct = CLAMP(g->he_pct, 0, 95);
        if (g->o2_pct + g->he_pct > 100) g->he_pct = (uint8_t)(100 - g->o2_pct);
        g->enabled = i == 0 ? 1 : (g->enabled ? 1 : 0);
        g->cylinder_l = CLAMP(g->cylinder_l, 1, 30);
        g->fill_bar = CLAMP(g->fill_bar, 50, 300);
    }
    s->gf_low = CLAMP(s->gf_low, 10, 100);
    s->gf_high = CLAMP(s->gf_high, 40, 100);
    if (s->gf_low > s->gf_high) s->gf_low = s->gf_high;
    s->water = CLAMP(s->water, 0, 2);
    s->last_stop_m = s->last_stop_m >= 6 ? 6 : 3;
    s->ppo2_bottom_x100 = CLAMP(s->ppo2_bottom_x100, 100, 160);
    s->ppo2_deco_x100 = CLAMP(s->ppo2_deco_x100, 120, 160);
    s->reserve_bar = CLAMP(s->reserve_bar, 20, 100);
    s->ascent_alarm_mpm = CLAMP(s->ascent_alarm_mpm, 6, 18);
    s->brightness = CLAMP(s->brightness, 1, 5);
    s->pairing = s->pairing ? 1 : 0;
    s->declination_deg = CLAMP(s->declination_deg, -30, 30);
    s->safety_stop = s->safety_stop ? 1 : 0;
    s->bluetooth = s->bluetooth ? 1 : 0;
    if (s->depth_alarm_m) s->depth_alarm_m = CLAMP(s->depth_alarm_m, 10, 150);
    if (s->time_alarm_min) s->time_alarm_min = CLAMP(s->time_alarm_min, 10, 300);
    s->ndl_warn_min = CLAMP(s->ndl_warn_min, 0, 10);
    s->turn_margin_bar = CLAMP(s->turn_margin_bar, 10, 50);
    s->flip = s->flip ? 1 : 0;
    s->log_interval_s = CLAMP(s->log_interval_s, 1, 10);
    s->vibrate = s->vibrate ? 1 : 0;
    s->sound = s->sound ? 1 : 0;
    s->auto_bright = s->auto_bright ? 1 : 0;
    if (s->sleep_min) s->sleep_min = CLAMP(s->sleep_min, 2, 60);
}

static void put16(uint8_t *p, uint16_t v) { p[0] = (uint8_t)v; p[1] = (uint8_t)(v >> 8); }
static void put32(uint8_t *p, uint32_t v) { put16(p, (uint16_t)v); put16(p + 2, (uint16_t)(v >> 16)); }
static uint16_t get16(const uint8_t *p) { return (uint16_t)(p[0] | (p[1] << 8)); }
static uint32_t get32(const uint8_t *p) { return (uint32_t)get16(p) | ((uint32_t)get16(p + 2) << 16); }

/* Layout: "DS" ver | 5 x (o2 he en cyl fill16 serial32) = 50 | 12 one-byte fields
 *         | v2: bluetooth depth_alarm time_alarm16 ndl_warn turn_margin flip log_interval | pad | crc32 */
int settings_serialize(const dc_settings_t *s, uint8_t *buf, int cap)
{
    if (cap < DC_SETTINGS_BLOB_SIZE) return 0;
    memset(buf, 0, DC_SETTINGS_BLOB_SIZE);
    buf[0] = 'D';
    buf[1] = 'S';
    buf[2] = DC_SETTINGS_VERSION;
    uint8_t *p = buf + 3;
    for (int i = 0; i < DC_MAX_GASES; i++) {
        p[0] = s->gas[i].o2_pct;
        p[1] = s->gas[i].he_pct;
        p[2] = s->gas[i].enabled;
        p[3] = s->gas[i].cylinder_l;
        put16(p + 4, s->gas[i].fill_bar);
        put32(p + 6, s->gas[i].tx_serial);
        p += 10;
    }
    *p++ = s->gf_low;
    *p++ = s->gf_high;
    *p++ = s->water;
    *p++ = s->last_stop_m;
    *p++ = s->ppo2_bottom_x100;
    *p++ = s->ppo2_deco_x100;
    *p++ = s->reserve_bar;
    *p++ = s->ascent_alarm_mpm;
    *p++ = s->brightness;
    *p++ = s->pairing;
    *p++ = (uint8_t)s->declination_deg;
    *p++ = s->safety_stop;
    *p++ = s->bluetooth;
    *p++ = s->depth_alarm_m;
    put16(p, s->time_alarm_min);
    p += 2;
    *p++ = s->ndl_warn_min;
    *p++ = s->turn_margin_bar;
    *p++ = s->flip;
    *p++ = s->log_interval_s;
    /* stored inverted / offset so that blobs written before these existed read as the defaults */
    *p++ = (uint8_t)((s->vibrate ? 0 : 1) | (s->sound ? 0 : 2) | (s->auto_bright ? 0 : 4));
    *p++ = (uint8_t)(s->sleep_min ? s->sleep_min : 255);
    put32(buf + DC_SETTINGS_BLOB_SIZE - 4, dc_crc32(buf, DC_SETTINGS_BLOB_SIZE - 4));
    return DC_SETTINGS_BLOB_SIZE;
}

bool settings_deserialize(const uint8_t *buf, int len, dc_settings_t *out)
{
    if (len < DC_SETTINGS_BLOB_V1 || buf[0] != 'D' || buf[1] != 'S') return false;
    int size = buf[2] == 1 ? DC_SETTINGS_BLOB_V1 : (buf[2] == DC_SETTINGS_VERSION ? DC_SETTINGS_BLOB_SIZE : 0);
    if (!size || len < size) return false;
    if (get32(buf + size - 4) != dc_crc32(buf, size - 4)) return false;
    settings_default(out);   /* fields a version 1 blob does not have */
    const uint8_t *p = buf + 3;
    for (int i = 0; i < DC_MAX_GASES; i++) {
        out->gas[i].o2_pct = p[0];
        out->gas[i].he_pct = p[1];
        out->gas[i].enabled = p[2];
        out->gas[i].cylinder_l = p[3];
        out->gas[i].fill_bar = get16(p + 4);
        out->gas[i].tx_serial = get32(p + 6);
        p += 10;
    }
    out->gf_low = *p++;
    out->gf_high = *p++;
    out->water = *p++;
    out->last_stop_m = *p++;
    out->ppo2_bottom_x100 = *p++;
    out->ppo2_deco_x100 = *p++;
    out->reserve_bar = *p++;
    out->ascent_alarm_mpm = *p++;
    out->brightness = *p++;
    out->pairing = *p++;
    out->declination_deg = (int8_t)*p++;
    out->safety_stop = *p++;
    if (buf[2] >= 2) {
        out->bluetooth = *p++;
        out->depth_alarm_m = *p++;
        out->time_alarm_min = get16(p);
        p += 2;
        out->ndl_warn_min = *p++;
        out->turn_margin_bar = *p++;
        out->flip = *p++;
        out->log_interval_s = *p++;
        uint8_t off = *p++, sl = *p++;
        out->vibrate = (off & 1) ? 0 : 1;
        out->sound = (off & 2) ? 0 : 1;
        out->auto_bright = (off & 4) ? 0 : 1;
        out->sleep_min = sl == 0 ? 10 : (sl == 255 ? 0 : sl);
    }
    settings_validate(out);
    return true;
}

void settings_apply(const dc_settings_t *s, dive_t *d)
{
    d->cfg.gf_low = s->gf_low / 100.0f;
    d->cfg.gf_high = s->gf_high / 100.0f;
    d->cfg.bar_per_m = s->water == WATER_SALT ? 0.10052f : (s->water == WATER_FRESH ? 0.09807f : 0.1000f);
    d->cfg.last_stop_m = (float)s->last_stop_m;
    d->cfg.bottom_ppo2_max = s->ppo2_bottom_x100 / 100.0f;
    d->cfg.deco_ppo2_max = s->ppo2_deco_x100 / 100.0f;
    d->set.ascent_alarm_mpm = (float)s->ascent_alarm_mpm;
    d->set.safety_stop = s->safety_stop != 0;
    d->set.depth_alarm_m = (float)s->depth_alarm_m;
    d->set.time_alarm_min = (float)s->time_alarm_min;
    d->set.ndl_warn_min = (float)s->ndl_warn_min;
    d->set.turn_margin_bar = (float)s->turn_margin_bar;
    d->set.sleep_after_s = (float)s->sleep_min * 60.0f;
    for (int i = 0; i < DC_MAX_GASES; i++) {
        d->gases[i].o2 = s->gas[i].o2_pct / 100.0f;
        d->gases[i].he = s->gas[i].he_pct / 100.0f;
        d->gases[i].enabled = s->gas[i].enabled != 0;
        d->tanks[i].cylinder_l = (float)s->gas[i].cylinder_l;
        d->tanks[i].full_bar = (float)s->gas[i].fill_bar;
        d->tanks[i].reserve_bar = (float)s->reserve_bar;
        d->tanks[i].serial = s->gas[i].tx_serial;
    }
    if (!d->gases[d->gas].enabled) d->gas = 0;
    d->since_plan_s = d->set.plan_every_s; /* replan with the new settings */
}

bool settings_take_serials(dc_settings_t *s, const dive_t *d)
{
    bool changed = false;
    for (int i = 0; i < DC_MAX_GASES; i++) {
        if (s->gas[i].tx_serial != d->tanks[i].serial) {
            s->gas[i].tx_serial = d->tanks[i].serial;
            changed = true;
        }
    }
    return changed;
}
