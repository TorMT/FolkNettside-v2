/* txdsp.c — see txdsp.h. */
#include "divecore/txdsp.h"

#include <math.h>
#include <string.h>

void txdsp_init(txdsp_t *d, float fs, float fc, float min_level, uint32_t idle_us)
{
    memset(d, 0, sizeof(*d));
    d->fs = fs;
    d->fc = fc;
    float w = 2.0f * 3.14159265f * fc / fs;
    d->cos_d = cosf(w);
    d->sin_d = sinf(w);
    d->c = 1.0f;
    d->s = 0.0f;
    d->alpha = 1.0f - expf(-2.0f * 3.14159265f * 3000.0f / fs); /* ~3 kHz envelope bandwidth */
    d->peak_decay = expf(-1.0f / (0.2f * fs));                  /* 200 ms peak memory */
    d->min_level = min_level;
    d->idle_samples = (uint32_t)(idle_us * 1e-6f * fs);
}

static bool finish_packet(txdsp_t *d, pelagic_packet_t *out)
{
    bool ok = false;
    if (d->n_pauses == PELAGIC_BITS) {
        uint8_t bits[PELAGIC_BITS];
        pelagic_bits_from_pauses(d->pauses, d->n_pauses, bits);
        ok = pelagic_decode_bits(bits, PELAGIC_BITS, out) == PELAGIC_OK;
    }
    if (d->bursts > 4) {
        if (ok) d->packets_ok++;
        else d->packets_bad++;
    }
    d->n_pauses = 0;
    d->bursts = 0;
    return ok;
}

bool txdsp_feed(txdsp_t *d, const float *x, int n, pelagic_packet_t *out)
{
    bool got = false;
    for (int k = 0; k < n; k++) {
        /* NCO, re-normalised now and then so it does not drift. */
        float c = d->c * d->cos_d - d->s * d->sin_d;
        float s = d->s * d->cos_d + d->c * d->sin_d;
        d->c = c;
        d->s = s;
        if ((d->n & 1023u) == 0) {
            float m = 1.0f / sqrtf(c * c + s * s);
            d->c *= m;
            d->s *= m;
        }
        d->i_lp += d->alpha * (x[k] * c - d->i_lp);
        d->q_lp += d->alpha * (x[k] * s - d->q_lp);
        float env = 2.0f * sqrtf(d->i_lp * d->i_lp + d->q_lp * d->q_lp);

        d->peak = env > d->peak ? env : d->peak * d->peak_decay;
        float hi = 0.5f * d->peak, lo = 0.3f * d->peak;
        bool signal = d->peak > d->min_level;

        if (!d->on && signal && env > hi) {
            /* Rising edge: the pause since the last falling edge belongs to the previous bit. */
            if (d->bursts > 0 && d->n_pauses < TXDSP_MAX_PAUSES) {
                float us = (float)(d->n - d->edge_n) * 1e6f / d->fs;
                d->pauses[d->n_pauses++] = (uint16_t)(us > 65535.0f ? 65535.0f : us);
            }
            d->on = true;
            d->bursts++;
        } else if (d->on && env < lo) {
            d->on = false;
            d->edge_n = d->n;
        }
        if (!d->on && d->bursts > 0 && d->n - d->edge_n > d->idle_samples) {
            if (finish_packet(d, out)) got = true;
        }
        d->n++;
        if (got) {
            /* Hand the packet back now; remaining samples in this block are dropped (block is short). */
            break;
        }
    }
    return got;
}

static float rnd(uint32_t *seed)
{
    *seed = *seed * 1664525u + 1013904223u;
    return (float)(*seed >> 8) / 16777216.0f * 2.0f - 1.0f;
}

int txdsp_synthesize(uint32_t serial, uint16_t psi, uint8_t battery, float fs, float fc, float amplitude, float noise,
                     uint32_t *seed, float *out, int max_samples)
{
    uint8_t bits[PELAGIC_BITS];
    static const uint8_t hdr[2] = {8, 1};
    if (!pelagic_encode_bits(serial, psi, battery, hdr, bits)) return 0;
    int n = 0;
    float w = 2.0f * 3.14159265f * fc / fs;
    int burst = (int)(PELAGIC_SIM_BURST_US * 1e-6f * fs);
    for (int b = 0; b <= PELAGIC_BITS && n < max_samples; b++) {
        for (int k = 0; k < burst && n < max_samples; k++, n++) out[n] = amplitude * sinf(w * (float)n) + noise * rnd(seed);
        if (b == PELAGIC_BITS) break;
        int pause = (int)((bits[b] ? PELAGIC_SIM_LONG_US : PELAGIC_SIM_SHORT_US) * 1e-6f * fs);
        for (int k = 0; k < pause && n < max_samples; k++, n++) out[n] = noise * rnd(seed);
    }
    /* Trailing silence so the receiver sees the end of the packet. */
    int tail = (int)(0.02f * fs);
    for (int k = 0; k < tail && n < max_samples; k++, n++) out[n] = noise * rnd(seed);
    return n;
}
