/* deco.c — Bühlmann ZHL-16C with gradient factors. See deco.h. */
#include "divecore/deco.h"

#include <math.h>
#include <string.h>

/* ZHL-16C coefficients (compartment 1 is "1b", 5.0 min). */
#ifdef DC_ZHL16C_COMP1A /* compartment 1a (4.0 min), only for cross-checks against planners that use it */
static const float N2_HT[DC_NUM_TISSUES] = {4.0f, 8.0f, 12.5f, 18.5f, 27.0f, 38.3f, 54.3f, 77.0f,
                                            109.0f, 146.0f, 187.0f, 239.0f, 305.0f, 390.0f, 498.0f, 635.0f};
static const float N2_A[DC_NUM_TISSUES] = {1.2599f, 1.0000f, 0.8618f, 0.7562f, 0.6200f, 0.5043f, 0.4410f, 0.4000f,
                                           0.3750f, 0.3500f, 0.3295f, 0.3065f, 0.2835f, 0.2610f, 0.2480f, 0.2327f};
static const float N2_B[DC_NUM_TISSUES] = {0.5050f, 0.6514f, 0.7222f, 0.7825f, 0.8126f, 0.8434f, 0.8693f, 0.8910f,
                                           0.9092f, 0.9222f, 0.9319f, 0.9403f, 0.9477f, 0.9544f, 0.9602f, 0.9653f};
static const float HE_HT[DC_NUM_TISSUES] = {1.51f, 3.02f, 4.72f, 6.99f, 10.21f, 14.48f, 20.53f, 29.11f,
                                            41.20f, 55.19f, 70.69f, 90.34f, 115.29f, 147.42f, 188.24f, 240.03f};
static const float HE_A[DC_NUM_TISSUES] = {1.7424f, 1.3830f, 1.1919f, 1.0458f, 0.9220f, 0.8205f, 0.7305f, 0.6502f,
                                           0.5950f, 0.5545f, 0.5333f, 0.5189f, 0.5181f, 0.5176f, 0.5172f, 0.5119f};
static const float HE_B[DC_NUM_TISSUES] = {0.4245f, 0.5747f, 0.6527f, 0.7223f, 0.7582f, 0.7957f, 0.8279f, 0.8553f,
                                           0.8757f, 0.8903f, 0.8997f, 0.9073f, 0.9122f, 0.9171f, 0.9217f, 0.9267f};
#else
static const float N2_HT[DC_NUM_TISSUES] = {5.0f, 8.0f, 12.5f, 18.5f, 27.0f, 38.3f, 54.3f, 77.0f,
                                            109.0f, 146.0f, 187.0f, 239.0f, 305.0f, 390.0f, 498.0f, 635.0f};
static const float N2_A[DC_NUM_TISSUES] = {1.1696f, 1.0000f, 0.8618f, 0.7562f, 0.6200f, 0.5043f, 0.4410f, 0.4000f,
                                           0.3750f, 0.3500f, 0.3295f, 0.3065f, 0.2835f, 0.2610f, 0.2480f, 0.2327f};
static const float N2_B[DC_NUM_TISSUES] = {0.5578f, 0.6514f, 0.7222f, 0.7825f, 0.8126f, 0.8434f, 0.8693f, 0.8910f,
                                           0.9092f, 0.9222f, 0.9319f, 0.9403f, 0.9477f, 0.9544f, 0.9602f, 0.9653f};
static const float HE_HT[DC_NUM_TISSUES] = {1.88f, 3.02f, 4.72f, 6.99f, 10.21f, 14.48f, 20.53f, 29.11f,
                                            41.20f, 55.19f, 70.69f, 90.34f, 115.29f, 147.42f, 188.24f, 240.03f};
static const float HE_A[DC_NUM_TISSUES] = {1.6189f, 1.3830f, 1.1919f, 1.0458f, 0.9220f, 0.8205f, 0.7305f, 0.6502f,
                                           0.5950f, 0.5545f, 0.5333f, 0.5189f, 0.5181f, 0.5176f, 0.5172f, 0.5119f};
static const float HE_B[DC_NUM_TISSUES] = {0.4770f, 0.5747f, 0.6527f, 0.7223f, 0.7582f, 0.7957f, 0.8279f, 0.8553f,
                                           0.8757f, 0.8903f, 0.8997f, 0.9073f, 0.9122f, 0.9171f, 0.9217f, 0.9267f};
#endif

#define LN2 0.69314718f
#define AIR_N2 0.7902f

void dc_cfg_default(dc_cfg_t *cfg)
{
    cfg->gf_low = 0.50f;
    cfg->gf_high = 0.80f;
    cfg->surface_bar = 1.01325f;
    cfg->bar_per_m = 0.10052f; /* 1025 kg/m3 * 9.80665 / 1e5 */
    cfg->ascent_rate_mpm = 9.0f;
    cfg->stop_step_m = 3.0f;
    cfg->last_stop_m = 3.0f;
    cfg->deco_ppo2_max = 1.6f;
    cfg->bottom_ppo2_max = 1.4f;
    cfg->gas_switch_min = 1.0f;
}

void dc_tissues_init(dc_tissues_t *t, float surface_bar)
{
    float pn2 = (surface_bar - DC_WATER_VAPOUR_BAR) * AIR_N2;
    for (int i = 0; i < DC_NUM_TISSUES; i++) {
        t->n2[i] = pn2;
        t->he[i] = 0.0f;
    }
}

/* Schreiner equation for one gas in one compartment. */
static float schreiner(float p0, float pi0, float rate_per_min, float t_min, float half_time)
{
    float k = LN2 / half_time;
    return pi0 + rate_per_min * (t_min - 1.0f / k) - (pi0 - p0 - rate_per_min / k) * expf(-k * t_min);
}

void dc_tissues_update(dc_tissues_t *t, float p_start_bar, float p_end_bar, float seconds, const dc_gas_t *gas)
{
    if (seconds <= 0.0f) return;
    float t_min = seconds / 60.0f;
    float fn2 = 1.0f - gas->o2 - gas->he;
    float amb0 = p_start_bar - DC_WATER_VAPOUR_BAR;
    if (amb0 < 0.0f) amb0 = 0.0f;
    float rate = (p_end_bar - p_start_bar) / t_min; /* bar/min of ambient */
    float pi_n2 = amb0 * fn2, pi_he = amb0 * gas->he;
    float r_n2 = rate * fn2, r_he = rate * gas->he;
    for (int i = 0; i < DC_NUM_TISSUES; i++) {
        t->n2[i] = schreiner(t->n2[i], pi_n2, r_n2, t_min, N2_HT[i]);
        t->he[i] = schreiner(t->he[i], pi_he, r_he, t_min, HE_HT[i]);
    }
}

static void coeffs(const dc_tissues_t *t, int i, float *a, float *b, float *p)
{
    float pn = t->n2[i], ph = t->he[i];
    *p = pn + ph;
    if (*p <= 0.0f) {
        *a = N2_A[i];
        *b = N2_B[i];
        return;
    }
    *a = (N2_A[i] * pn + HE_A[i] * ph) / *p;
    *b = (N2_B[i] * pn + HE_B[i] * ph) / *p;
}

float dc_ceiling_bar(const dc_tissues_t *t, float gf, int *leading)
{
    float best = 0.0f;
    int lead = 0;
    for (int i = 0; i < DC_NUM_TISSUES; i++) {
        float a, b, p;
        coeffs(t, i, &a, &b, &p);
        /* Tolerated ambient pressure with gradient factor (Baker). */
        float tol = (p - a * gf) / (gf / b + 1.0f - gf);
        if (tol > best) {
            best = tol;
            lead = i;
        }
    }
    if (leading) *leading = lead;
    return best;
}

float dc_ceiling_m(const dc_tissues_t *t, float gf, const dc_cfg_t *cfg)
{
    float d = (dc_ceiling_bar(t, gf, NULL) - cfg->surface_bar) / cfg->bar_per_m;
    return d > 0.0f ? d : 0.0f;
}

float dc_gf_at(float depth_m, float anchor_m, const dc_cfg_t *cfg)
{
    if (anchor_m <= 0.0f) return cfg->gf_high;
    if (depth_m >= anchor_m) return cfg->gf_low;
    if (depth_m <= 0.0f) return cfg->gf_high;
    return cfg->gf_high - (cfg->gf_high - cfg->gf_low) * depth_m / anchor_m;
}

float dc_ambient_bar(float depth_m, const dc_cfg_t *cfg)
{
    return cfg->surface_bar + (depth_m > 0.0f ? depth_m : 0.0f) * cfg->bar_per_m;
}

float dc_depth_m(float ambient_bar, const dc_cfg_t *cfg)
{
    float d = (ambient_bar - cfg->surface_bar) / cfg->bar_per_m;
    return d > 0.0f ? d : 0.0f;
}

float dc_ppo2(const dc_gas_t *gas, float depth_m, const dc_cfg_t *cfg)
{
    return dc_ambient_bar(depth_m, cfg) * gas->o2;
}

float dc_mod_m(const dc_gas_t *gas, float ppo2_max, const dc_cfg_t *cfg)
{
    if (gas->o2 <= 0.0f) return 0.0f;
    return (ppo2_max / gas->o2 - cfg->surface_bar) / cfg->bar_per_m;
}

int dc_best_gas(const dc_gas_t gases[DC_MAX_GASES], float depth_m, const dc_cfg_t *cfg)
{
    int best = -1;
    for (int i = 0; i < DC_MAX_GASES; i++) {
        if (!gases[i].enabled) continue;
        if (dc_ppo2(&gases[i], depth_m, cfg) > cfg->deco_ppo2_max + 0.005f) continue;
        if (best < 0 || gases[i].o2 > gases[best].o2 + 1e-4f ||
            (fabsf(gases[i].o2 - gases[best].o2) < 1e-4f && gases[i].he < gases[best].he))
            best = i;
    }
    return best;
}

static float round_up(float v, float step)
{
    if (v <= 0.0f) return 0.0f;
    return ceilf(v / step - 1e-4f) * step;
}

/* Gradient of the leading compartment at ambient pressure p_amb, as a fraction of the M-value gradient. */
static float gradient_at(const dc_tissues_t *t, float p_amb, int *lead_out)
{
    float best = -10.0f;
    int lead = 0;
    for (int i = 0; i < DC_NUM_TISSUES; i++) {
        float a, b, p;
        coeffs(t, i, &a, &b, &p);
        float m = a + p_amb / b;
        float g = (m - p_amb) > 1e-6f ? (p - p_amb) / (m - p_amb) : 0.0f;
        if (g > best) {
            best = g;
            lead = i;
        }
    }
    if (lead_out) *lead_out = lead;
    return best < 0.0f ? 0.0f : best;
}

static void ascend(dc_tissues_t *t, float from_m, float to_m, const dc_gas_t *gas, const dc_cfg_t *cfg, float *time_min)
{
    if (to_m >= from_m) return;
    float minutes = (from_m - to_m) / cfg->ascent_rate_mpm;
    dc_tissues_update(t, dc_ambient_bar(from_m, cfg), dc_ambient_bar(to_m, cfg), minutes * 60.0f, gas);
    *time_min += minutes;
}

void dc_plan(const dc_tissues_t *tissues, float depth_m, int gas_idx, const dc_gas_t gases[DC_MAX_GASES],
             const dc_cfg_t *cfg, float gf_anchor_m, dc_plan_t *out)
{
    memset(out, 0, sizeof(*out));
    if (gas_idx < 0 || gas_idx >= DC_MAX_GASES) gas_idx = 0;
    float amb = dc_ambient_bar(depth_m, cfg);

    out->gf_now = gradient_at(tissues, amb, &out->leading_tissue);
    out->gf_surface = gradient_at(tissues, cfg->surface_bar, NULL);

    out->in_deco = dc_ceiling_m(tissues, cfg->gf_high, cfg) > 0.0f;

    /* No-deco limit: stay at depth minute by minute until the surface is no longer allowed. */
    if (!out->in_deco) {
        dc_tissues_t sim = *tissues;
        int ndl = 0;
        while (ndl < 99) {
            dc_tissues_update(&sim, amb, amb, 60.0f, &gases[gas_idx]);
            if (dc_ceiling_m(&sim, cfg->gf_high, cfg) > 0.0f) break;
            ndl++;
        }
        out->ndl_min = ndl;
    }

    /* Simulated ascent. Before each 3 m step the ascent is simulated and only taken if the
     * tissues, as they arrive, respect the ceiling there. Slow tissues keep loading on the way
     * up, so checking before the ascent would be optimistic. */
    dc_tissues_t sim = *tissues;
    float time_min = 0.0f;
    float d = depth_m;
    int gas = gas_idx;
    float anchor = gf_anchor_m;

    if (!out->in_deco && anchor <= 0.0f) {
        dc_tissues_t chk = *tissues;
        float t_dummy = 0.0f;
        ascend(&chk, d, 0.0f, &gases[gas], cfg, &t_dummy);
        if (dc_ceiling_m(&chk, cfg->gf_high, cfg) <= 0.0f) {
            ascend(&sim, d, 0.0f, &gases[gas], cfg, &time_min);
            out->tts_min = (int)ceilf(time_min);
            out->ceiling_m = 0.0f;
            return;
        }
    }

    int guard = 0;
    while (d > 1e-3f && guard++ < 400) {
        int g = dc_best_gas(gases, d, cfg);
        if (g >= 0 && g != gas && gases[g].o2 > gases[gas].o2 + 1e-4f) {
            gas = g;
            dc_tissues_update(&sim, dc_ambient_bar(d, cfg), dc_ambient_bar(d, cfg), cfg->gas_switch_min * 60.0f, &gases[gas]);
            time_min += cfg->gas_switch_min;
        }
        /* Next point on the stop grid; from the last stop go straight up. */
        float next = round_up(d, cfg->stop_step_m) - cfg->stop_step_m;
        if (d <= cfg->last_stop_m + 1e-3f || next < cfg->last_stop_m - 1e-3f) next = d <= cfg->last_stop_m + 1e-3f ? 0.0f : cfg->last_stop_m;
        if (next < 0.0f) next = 0.0f;

        int minutes = 0;
        for (;;) {
            /* GF low applies at the anchor and anywhere deeper; an anchor from earlier in the dive that is
             * shallower than here is not in force yet. */
            float gf_next = (anchor > 0.0f && next < anchor) ? dc_gf_at(next, anchor, cfg) : cfg->gf_low;
            dc_tissues_t chk = sim;
            float t_dummy = 0.0f;
            ascend(&chk, d, next, &gases[gas], cfg, &t_dummy);
            /* Both the tissues now and the tissues on arrival must respect the next ceiling. */
            if (dc_ceiling_m(&sim, gf_next, cfg) <= next + 1e-3f && dc_ceiling_m(&chk, gf_next, cfg) <= next + 1e-3f) break;
            /* First stop found: anchor GF low here. The anchor only ever moves deeper: early in the bottom
             * time the first stop is shallow, and it deepens as the dive goes on. */
            if (round_up(d, cfg->stop_step_m) > anchor) anchor = round_up(d, cfg->stop_step_m);
            if (minutes >= 999) break;
            dc_tissues_update(&sim, dc_ambient_bar(d, cfg), dc_ambient_bar(d, cfg), 60.0f, &gases[gas]);
            minutes++;
        }
        time_min += (float)minutes;
        if (minutes > 0 && out->n_stops < DC_MAX_STOPS) {
            out->stops[out->n_stops].depth_m = d;
            out->stops[out->n_stops].minutes = (uint16_t)minutes;
            out->stops[out->n_stops].gas = (uint8_t)gas;
            out->n_stops++;
        }
        ascend(&sim, d, next, &gases[gas], cfg, &time_min);
        d = next;
    }
    out->first_stop_m = out->n_stops > 0 ? out->stops[0].depth_m : 0.0f;
    out->gf_anchor_m = anchor;
    out->ceiling_m = dc_ceiling_m(tissues, dc_gf_at(depth_m, anchor, cfg), cfg);
    out->tts_min = (int)ceilf(time_min);
}

void dc_tissue_load_pct(const dc_tissues_t *t, const dc_cfg_t *cfg, float out_pct[DC_NUM_TISSUES])
{
    for (int i = 0; i < DC_NUM_TISSUES; i++) {
        float a, b, p;
        coeffs(t, i, &a, &b, &p);
        float m = a + cfg->surface_bar / b;
        float m_gf = cfg->surface_bar + cfg->gf_high * (m - cfg->surface_bar);
        out_pct[i] = 100.0f * p / m_gf;
    }
}
