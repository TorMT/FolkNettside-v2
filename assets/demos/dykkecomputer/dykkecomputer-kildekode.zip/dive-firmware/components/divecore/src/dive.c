/* dive.c — see dive.h. */
#include "divecore/dive.h"
#include "divecore/pelagic.h"

#include <math.h>
#include <string.h>

void dive_settings_default(dive_settings_t *s)
{
    s->start_depth_m = 1.2f;
    s->start_hold_s = 20.0f;
    s->end_depth_m = 1.0f;
    s->end_hold_s = 300.0f;
    s->ascent_alarm_mpm = 10.0f;
    s->plan_every_s = 2.0f;
    s->default_sac_l_min = 20.0f;
    s->min_sac_l_min = 15.0f;
    s->safety_stop = true;
    s->depth_alarm_m = 0.0f;
    s->time_alarm_min = 0.0f;
    s->ndl_warn_min = 5.0f;
    s->turn_margin_bar = 20.0f;
    s->sleep_after_s = 600.0f;
}

void dive_init(dive_t *d)
{
    memset(d, 0, sizeof(*d));
    dc_cfg_default(&d->cfg);
    dive_settings_default(&d->set);
    d->gases[0].o2 = 0.21f;
    d->gases[0].he = 0.0f;
    d->gases[0].enabled = true;
    d->gas = 0;
    dc_tissues_init(&d->tissues, d->cfg.surface_bar);
    dc_oxygen_reset(&d->ox);
    ascent_rate_init(&d->ar, 4.0f);
    d->state = DIVE_SURFACE;
    d->plan.ndl_min = 99;
    d->battery_pct = -1;
    for (int i = 0; i < DIVE_MAX_TANKS; i++) {
        d->tanks[i].cylinder_l = i == 0 ? 12.0f : 11.0f;
        d->tanks[i].full_bar = i == 0 ? 220.0f : 200.0f;
        d->tanks[i].reserve_bar = 50.0f;
    }
}

/* Gas actually breathed: the selected gas during a dive, air on the surface. */
static const dc_gas_t AIR = {0.21f, 0.0f, true};
static const dc_gas_t *breathing(const dive_t *d)
{
    return d->state == DIVE_ACTIVE ? &d->gases[d->gas] : &AIR;
}

float dive_ppo2(const dive_t *d)
{
    return dc_ppo2(breathing(d), d->depth_m, &d->cfg);
}

bool dive_switch_gas(dive_t *d, int idx)
{
    if (idx < 0 || idx >= DC_MAX_GASES || !d->gases[idx].enabled) return false;
    if (dc_ppo2(&d->gases[idx], d->depth_m, &d->cfg) > d->cfg.deco_ppo2_max + 0.005f) return false;
    d->gas = idx;
    d->since_plan_s = d->set.plan_every_s; /* replan now */
    return true;
}

static void use_gas(const dive_t *d, float litres[DC_MAX_GASES], int gas, float from_m, float to_m, float minutes,
                    float sac)
{
    float amb = dc_ambient_bar(0.5f * (from_m + to_m), &d->cfg);
    litres[gas] += sac * amb * minutes;
}

void dive_ascent_gas(const dive_t *d, float sac, float litres[DC_MAX_GASES])
{
    for (int i = 0; i < DC_MAX_GASES; i++) litres[i] = 0.0f;
    float rate = d->cfg.ascent_rate_mpm;
    float depth = d->depth_m;
    int gas = d->gas;
    for (int i = 0; i < d->plan.n_stops; i++) {
        const dc_stop_t *st = &d->plan.stops[i];
        if (st->depth_m < depth) {
            use_gas(d, litres, gas, depth, st->depth_m, (depth - st->depth_m) / rate, sac);
            depth = st->depth_m;
        }
        gas = st->gas;
        use_gas(d, litres, gas, depth, depth, (float)st->minutes, sac);
    }
    if (d->plan.n_stops == 0 && d->set.safety_stop && d->max_depth_m > 10.0f && depth > 5.0f) {
        use_gas(d, litres, gas, depth, 5.0f, (depth - 5.0f) / rate, sac);
        use_gas(d, litres, gas, 5.0f, 5.0f, 3.0f, sac);
        depth = 5.0f;
    }
    use_gas(d, litres, gas, depth, 0.0f, depth / rate, sac);
}

float dive_current_mod(const dive_t *d)
{
    float limit = d->gas == 0 ? d->cfg.bottom_ppo2_max : d->cfg.deco_ppo2_max;
    return dc_mod_m(&d->gases[d->gas], limit, &d->cfg);
}

void dive_wake(dive_t *d)
{
    d->idle_s = 0.0f;
    if (d->state == DIVE_SLEEP) d->state = DIVE_SURFACE;
}

void dive_set_wet(dive_t *d, bool wet)
{
    if (wet && !d->wet) dive_wake(d);
    d->wet = wet;
}

void dive_set_charging(dive_t *d, bool on)
{
    if (on && d->state != DIVE_ACTIVE) d->state = DIVE_CHARGING;
    else if (!on && d->state == DIVE_CHARGING) d->state = d->dive_count > 0 ? DIVE_INTERVAL : DIVE_SURFACE;
}

void dive_set_external_alarms(dive_t *d, uint32_t alarms)
{
    d->external_alarms = alarms;
}

int dive_tank_for_serial(dive_t *d, uint32_t serial, bool pairing)
{
    if (serial == 0) return -1;
    for (int i = 0; i < DIVE_MAX_TANKS; i++)
        if (d->tanks[i].serial == serial) return i;
    if (!pairing) return -1;
    for (int i = 0; i < DIVE_MAX_TANKS; i++) {
        if (d->gases[i].enabled && d->tanks[i].serial == 0) {
            d->tanks[i].serial = serial;
            return i;
        }
    }
    return -1;
}

void dive_tank_battery(dive_t *d, int i, int state)
{
    if (i >= 0 && i < DIVE_MAX_TANKS) d->tanks[i].battery = (uint8_t)state;
}

void dive_set_battery(dive_t *d, int pct)
{
    d->battery_pct = pct < -1 ? -1 : (pct > 100 ? 100 : pct);
}

bool dive_battery_ok_for_dive(const dive_t *d)
{
    return d->battery_pct < 0 || d->battery_pct >= 30;
}

void dive_tank_reading(dive_t *d, int i, float bar)
{
    if (i < 0 || i >= DIVE_MAX_TANKS) return;
    dive_tank_t *t = &d->tanks[i];
    if (t->present && d->state == DIVE_ACTIVE && i == d->gas && t->age_s > 0.0f) {
        float drop_per_min = (t->bar - bar) / (t->age_s / 60.0f);
        if (drop_per_min >= 0.0f && drop_per_min < 50.0f) {
            /* Smooth over roughly a minute of 5 s packets. */
            float k = t->age_s / 60.0f;
            if (k > 1.0f) k = 1.0f;
            t->rate_bar_min += k * (drop_per_min - t->rate_bar_min);
        }
    }
    t->bar = bar;
    t->age_s = 0.0f;
    t->present = true;
}

const dive_tank_t *dive_active_tank(const dive_t *d)
{
    const dive_tank_t *t = &d->tanks[d->gas];
    return t->present ? t : NULL;
}

void dive_tick(dive_t *d, float dt_s, float depth_m, float temp_c)
{
    if (dt_s <= 0.0f) return;
    if (!isnan(depth_m)) d->depth_m = depth_m < 0.0f ? 0.0f : depth_m;
    if (!isnan(temp_c)) d->temp_c = temp_c;
    d->t_s += dt_s;

    /* Tissues and oxygen always run, also on the surface. */
    dc_tissues_update(&d->tissues, dc_ambient_bar(d->prev_depth_m, &d->cfg), dc_ambient_bar(d->depth_m, &d->cfg), dt_s,
                      breathing(d));
    dc_oxygen_update(&d->ox, dive_ppo2(d), dt_s);
    d->ascent_mpm = ascent_rate_push(&d->ar, d->t_s, d->depth_m);
    d->prev_depth_m = d->depth_m;
    for (int i = 0; i < DIVE_MAX_TANKS; i++)
        if (d->tanks[i].present) d->tanks[i].age_s += dt_s;

    /* State machine. */
    switch (d->state) {
    case DIVE_SLEEP:
    case DIVE_SURFACE:
    case DIVE_INTERVAL:
        /* Sleep: only from a plain surface state (not during a surface interval, where the screen
         * shows no-fly and desaturation), dry and untouched for the set time. */
        if (d->state == DIVE_SURFACE && !d->wet && d->depth_m < 0.5f) {
            d->idle_s += dt_s;
            if (d->set.sleep_after_s > 0.0f && d->idle_s >= d->set.sleep_after_s) d->state = DIVE_SLEEP;
        } else if (d->state != DIVE_SLEEP) {
            d->idle_s = 0.0f;
        }
        if (d->state == DIVE_SLEEP && (d->wet || d->depth_m >= 0.5f)) dive_wake(d);
        if (d->state == DIVE_INTERVAL) d->interval_s += dt_s;
        if (d->nofly_min > 0.0f) d->nofly_min -= dt_s / 60.0f;
        if (d->depth_m > d->set.start_depth_m) {
            d->below_s += dt_s;
            if (d->below_s >= d->set.start_hold_s) {
                d->state = DIVE_ACTIVE;
                d->dive_time_s = d->below_s;
                d->max_depth_m = d->depth_m;
                d->avg_depth_sum = 0.0f;
                d->gf_anchor_m = 0.0f;
                d->above_s = 0.0f;
                d->had_deco = false;
                for (int i = 0; i < DIVE_MAX_TANKS; i++) d->tanks[i].rate_bar_min = 0.0f;
                d->since_plan_s = d->set.plan_every_s;
            }
        } else {
            d->below_s = 0.0f;
        }
        break;
    case DIVE_ACTIVE:
        d->dive_time_s += dt_s;
        d->avg_depth_sum += d->depth_m * dt_s;
        if (d->depth_m > d->max_depth_m) d->max_depth_m = d->depth_m;
        if (d->depth_m < d->set.end_depth_m) {
            d->above_s += dt_s;
            if (d->above_s >= d->set.end_hold_s) {
                d->state = DIVE_INTERVAL;
                d->dive_count++;
                d->gas = 0; /* next dive starts on the bottom gas */
                d->interval_s = d->above_s;
                d->below_s = 0.0f;
                /* DAN-style no-fly guidance: 12 h single no-deco dive, 18 h repetitive or deco. */
                float nf = (d->had_deco || d->dive_count > 1) ? 18.0f * 60.0f : 12.0f * 60.0f;
                if (nf > d->nofly_min) d->nofly_min = nf;
            }
        } else {
            d->above_s = 0.0f;
        }
        break;
    case DIVE_CHARGING:
        if (d->nofly_min > 0.0f) d->nofly_min -= dt_s / 60.0f;
        break;
    }
    if (d->nofly_min < 0.0f) d->nofly_min = 0.0f;

    /* Plan. */
    d->since_plan_s += dt_s;
    if (d->since_plan_s >= d->set.plan_every_s) {
        d->since_plan_s = 0.0f;
        dc_plan(&d->tissues, d->depth_m, d->gas, d->gases, &d->cfg, d->gf_anchor_m, &d->plan);
        if (d->state == DIVE_ACTIVE) {
            if (d->plan.in_deco) d->had_deco = true;
            if (d->plan.n_stops > 0 && d->plan.gf_anchor_m > d->gf_anchor_m) d->gf_anchor_m = d->plan.gf_anchor_m;
        }
    }

    /* Gas use. */
    float amb = dc_ambient_bar(d->depth_m, &d->cfg);
    const dive_tank_t *tk = dive_active_tank(d);
    if (tk && tk->rate_bar_min > 0.01f) d->sac_l_min = tk->rate_bar_min * tk->cylinder_l / amb;
    d->gas_needed_bar = 0.0f;
    d->gas_time_min = 0.0f;
    if (tk && d->state == DIVE_ACTIVE) {
        /* Rock bottom: gas for the ascent from here (incl. stops and safety stop) plus the reserve. */
        float sac = d->sac_l_min > 0.0f ? d->sac_l_min : d->set.default_sac_l_min;
        if (sac < d->set.min_sac_l_min) sac = d->set.min_sac_l_min;
        float litres[DC_MAX_GASES];
        dive_ascent_gas(d, sac, litres);
        d->gas_needed_bar = litres[d->gas] / tk->cylinder_l + tk->reserve_bar;
        /* Time at this depth before the tank reaches that pressure. */
        float use_bar_min = sac * amb / tk->cylinder_l;
        float spare = tk->bar - d->gas_needed_bar;
        d->gas_time_min = spare > 0.0f ? spare / use_bar_min : 0.0f;
    }

    /* Alarms. */
    uint32_t a = 0;
    float ppo2 = dive_ppo2(d);
    if (d->state == DIVE_ACTIVE) {
        if (d->ascent_mpm > d->set.ascent_alarm_mpm) a |= ALARM_ASCENT_FAST;
        else if (d->ascent_mpm > 0.8f * d->set.ascent_alarm_mpm) a |= ALARM_ASCENT_WARN;
        if (d->plan.ceiling_m > 0.0f && d->depth_m < d->plan.ceiling_m - 0.3f) a |= ALARM_CEILING;
        if (!d->plan.in_deco && d->set.ndl_warn_min > 0.0f && (float)d->plan.ndl_min < d->set.ndl_warn_min) a |= ALARM_NDL_LOW;
        if (d->set.depth_alarm_m > 0.0f && d->depth_m > d->set.depth_alarm_m) a |= ALARM_DEPTH_LIMIT;
        if (d->set.time_alarm_min > 0.0f && d->dive_time_s >= d->set.time_alarm_min * 60.0f) a |= ALARM_TIME_LIMIT;
        if (d->depth_m > dive_current_mod(d) + 0.5f) a |= ALARM_MOD;
        if (tk && tk->age_s > 30.0f) a |= ALARM_TANK_LOST;
    }
    if (ppo2 > d->cfg.deco_ppo2_max + 0.05f) a |= ALARM_PPO2_HIGH;
    if (ppo2 < 0.18f) a |= ALARM_PPO2_LOW;
    if (d->ox.cns_pct >= 100.0f) a |= ALARM_CNS_100;
    else if (d->ox.cns_pct >= 80.0f) a |= ALARM_CNS_80;
    if (tk && tk->bar < tk->reserve_bar) a |= ALARM_TANK_RESERVE;
    if (tk && d->state == DIVE_ACTIVE && d->gas_needed_bar > 0.0f && tk->age_s < 30.0f) {
        if (tk->bar <= d->gas_needed_bar) a |= ALARM_GAS_LOW;
        else if (tk->bar <= d->gas_needed_bar + d->set.turn_margin_bar) a |= ALARM_GAS_TURN;
    }
    if (d->battery_pct >= 0 && d->battery_pct < 15 && d->state != DIVE_CHARGING) a |= ALARM_BATTERY_LOW;
    for (int i = 0; i < DIVE_MAX_TANKS; i++)
        if (d->gases[i].enabled && d->tanks[i].present && d->tanks[i].battery == TX_BATT_LOW) a |= ALARM_TX_BATTERY;
    d->alarms = a | d->external_alarms;
}
