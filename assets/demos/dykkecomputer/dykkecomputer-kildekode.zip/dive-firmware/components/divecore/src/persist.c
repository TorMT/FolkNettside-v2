/* persist.c — see persist.h. */
#include "divecore/persist.h"

#include <string.h>

#include "divecore/settings.h"

static void put32(uint8_t *b, uint32_t v) { b[0] = (uint8_t)v; b[1] = (uint8_t)(v >> 8); b[2] = (uint8_t)(v >> 16); b[3] = (uint8_t)(v >> 24); }
static uint32_t get32(const uint8_t *b) { return (uint32_t)b[0] | (uint32_t)b[1] << 8 | (uint32_t)b[2] << 16 | (uint32_t)b[3] << 24; }
static void putf(uint8_t *b, float f) { uint32_t u; memcpy(&u, &f, 4); put32(b, u); }
static float getf(const uint8_t *b) { uint32_t u = get32(b); float f; memcpy(&f, &u, 4); return f; }

int persist_save(const dive_t *d, uint32_t now_unix, uint8_t *b, int cap)
{
    if (cap < PERSIST_BLOB) return 0;
    memset(b, 0, PERSIST_BLOB);
    b[0] = 'D'; b[1] = 'T'; b[2] = 1;
    b[3] = (uint8_t)((d->state == DIVE_ACTIVE ? PERSIST_IN_DIVE : 0) | (d->had_deco ? PERSIST_HAD_DECO : 0));
    put32(b + 4, now_unix);
    for (int i = 0; i < DC_NUM_TISSUES; i++) {
        putf(b + 8 + 4 * i, d->tissues.n2[i]);
        putf(b + 72 + 4 * i, d->tissues.he[i]);
    }
    putf(b + 136, d->ox.cns_pct);
    putf(b + 140, d->ox.otu);
    putf(b + 144, d->nofly_min);
    putf(b + 148, d->interval_s);
    b[152] = (uint8_t)d->dive_count;
    b[153] = (uint8_t)(d->dive_count >> 8);
    put32(b + PERSIST_BLOB - 4, dc_crc32(b, PERSIST_BLOB - 4));
    return PERSIST_BLOB;
}

persist_result_t persist_restore(dive_t *d, const uint8_t *b, int len, uint32_t now_unix)
{
    if (len < PERSIST_BLOB || b[0] != 'D' || b[1] != 'T' || b[2] != 1) return PERSIST_NONE;
    if (get32(b + PERSIST_BLOB - 4) != dc_crc32(b, PERSIST_BLOB - 4)) return PERSIST_NONE;
    dc_tissues_t t;
    for (int i = 0; i < DC_NUM_TISSUES; i++) {
        t.n2[i] = getf(b + 8 + 4 * i);
        t.he[i] = getf(b + 72 + 4 * i);
        /* a sane tissue pressure: between nothing and 20 bar; anything else is a damaged blob */
        if (!(t.n2[i] >= 0.0f && t.n2[i] < 20.0f) || !(t.he[i] >= 0.0f && t.he[i] < 20.0f)) return PERSIST_NONE;
    }
    uint32_t saved = get32(b + 4);
    bool in_dive = (b[3] & PERSIST_IN_DIVE) != 0;
    d->tissues = t;
    d->ox.cns_pct = getf(b + 136);
    d->ox.otu = getf(b + 140);
    d->nofly_min = getf(b + 144);
    d->interval_s = getf(b + 148);
    d->dive_count = b[152] | b[153] << 8;
    d->had_deco = (b[3] & PERSIST_HAD_DECO) != 0;
    if (in_dive) {
        /* The dive that was interrupted counts, and its no-fly time is the long one. */
        d->dive_count++;
        d->had_deco = true;
        d->interval_s = 0.0f;
        if (d->nofly_min < 18.0f * 60.0f) d->nofly_min = 18.0f * 60.0f;
    }
    d->state = d->dive_count > 0 ? DIVE_INTERVAL : DIVE_SURFACE;

    persist_result_t res = in_dive ? PERSIST_INTERRUPTED_DIVE : PERSIST_RESTORED;
    /* Credit the time spent switched off, at most 7 days (after that the tissues are clear anyway). */
    if (now_unix > 1600000000u && saved > 1600000000u && now_unix >= saved) {
        uint32_t off = now_unix - saved;
        if (off > 7u * 86400u) off = 7u * 86400u;
        static const dc_gas_t air = {0.21f, 0.0f, true};
        dc_tissues_update(&d->tissues, d->cfg.surface_bar, d->cfg.surface_bar, (float)off, &air);
        dc_oxygen_update(&d->ox, 0.21f, (float)off);
        d->nofly_min -= (float)off / 60.0f;
        if (d->nofly_min < 0.0f) d->nofly_min = 0.0f;
        d->interval_s += (float)off;
    } else if (!in_dive) {
        res = PERSIST_RESTORED_NO_CLOCK;
    }
    d->since_plan_s = d->set.plan_every_s;   /* replan from the restored tissues */
    return res;
}
