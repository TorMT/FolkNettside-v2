/* menu.c — see menu.h. */
#include "divecore/menu.h"

#include <stdio.h>
#include <string.h>

#include "divecore/deco.h"
#include "divecore/proto.h"

enum { SM_ROOT, SM_GASES, SM_GAS, SM_DECO, SM_ALARMS, SM_TX, SM_COMPASS, SM_DISPLAY, SM_BT, SM_SYSTEM, SM_GEAR, SM_DIVE, SM_PLAN, SM_LOG, SM_CHECK, SM_DIVEPLAN };
enum { K_SUB, K_NUM, K_ENUM, K_BOOL, K_ACTION, K_BACK, K_INFO, K_GAS, K_GEAR, K_PLAN, K_LOG, K_CHECK, K_PSTOP };
enum {
    F_NONE, F_GAS_O2, F_GAS_HE, F_GAS_ON, F_GAS_CYL, F_GAS_FILL, F_GF_LOW, F_GF_HIGH, F_LAST_STOP, F_PPO2_BOTTOM,
    F_PPO2_DECO, F_RESERVE, F_ASCENT, F_BRIGHT, F_PAIRING, F_DECL, F_WATER, F_SAFETY, F_TX_SERIAL, F_BT, F_BT_STATUS,
    F_BT_DIVE, F_DEPTH_AL, F_TIME_AL, F_NDL_WARN, F_TURN, F_FLIP, F_LOG_INT, F_GEAR_HEAD, F_LEAD, F_GAS_CYL_NAME,
    F_NOFLY, F_PLAN_GAS, F_LOG_HEAD, F_DP_DEPTH, F_DP_RUN, F_DP_GAS,
    F_VIB, F_SOUND, F_AUTOBR, F_SLEEP
};
enum { A_RESET, A_FORGET, A_CALIBRATE, A_LOCK, A_CLEAR_PLAN };

typedef struct {
    const char *label;
    int kind;
    int field;   /* field, target submenu or action */
    int arg;     /* gas or gear index */
} item_t;

#define IT(l, k, f, a) (item_t){l, k, f, a}

static void gas_name(const dc_gas_setting_t *g, char *out, size_t cap)
{
    if (g->he_pct) snprintf(out, cap, "Tx%u/%u", g->o2_pct, g->he_pct);
    else if (g->o2_pct == 21) snprintf(out, cap, "Air");
    else if (g->o2_pct == 100) snprintf(out, cap, "O2");
    else snprintf(out, cap, "EAN%u", g->o2_pct);
}

/* Depths the planner shows NDLs for; rows deeper than gas 1's MOD are left out. */
static const float PLAN_DEPTH[] = {12, 15, 18, 21, 24, 27, 30, 33, 36, 40, 45, 50};
#define PLAN_DEPTHS (int)(sizeof(PLAN_DEPTH) / sizeof(PLAN_DEPTH[0]))

/* Days since 1970-01-01 to a calendar date (Howard Hinnant's algorithm). */
static void civil_date(int32_t z, int *y, int *mo, int *d)
{
    z += 719468;
    int32_t era = (z >= 0 ? z : z - 146096) / 146097;
    uint32_t doe = (uint32_t)(z - era * 146097);
    uint32_t yoe = (doe - doe / 1460 + doe / 36524 - doe / 146096) / 365;
    uint32_t doy = doe - (365 * yoe + yoe / 4 - yoe / 100);
    uint32_t mp = (5 * doy + 2) / 153;
    *d = (int)(doy - (153 * mp + 2) / 5 + 1);
    *mo = (int)(mp < 10 ? mp + 3 : mp - 9);
    *y = (int)(yoe + (uint32_t)era * 400u + (*mo <= 2));
}

static int items(const menu_t *m, int sub, int arg, item_t *it)
{
    int n = 0;
    switch (sub) {
    case SM_ROOT:
        if (m->predive) it[n++] = IT("Pre-dive check", K_SUB, SM_CHECK, 0);
        if (m->plan && m->plan->valid) it[n++] = IT("Dive plan", K_SUB, SM_DIVEPLAN, 0);
        it[n++] = IT("Gases", K_SUB, SM_GASES, 0);
        it[n++] = IT("Gear check", K_SUB, SM_GEAR, 0);
        if (m->dive) it[n++] = IT("Dive planner", K_SUB, SM_PLAN, 0);
        if (m->logbook) it[n++] = IT("Logbook", K_SUB, SM_LOG, 0);
        it[n++] = IT("Deco", K_SUB, SM_DECO, 0);
        it[n++] = IT("Alarms", K_SUB, SM_ALARMS, 0);
        it[n++] = IT("Transmitters", K_SUB, SM_TX, 0);
        it[n++] = IT("Compass", K_SUB, SM_COMPASS, 0);
        it[n++] = IT("Display", K_SUB, SM_DISPLAY, 0);
        it[n++] = IT("Bluetooth", K_SUB, SM_BT, 0);
        it[n++] = IT("System", K_SUB, SM_SYSTEM, 0);
        it[n++] = IT("Exit", K_BACK, 0, 0);
        break;
    case SM_GASES:
        for (int i = 0; i < DC_MAX_GASES; i++) it[n++] = IT("Gas", K_SUB, SM_GAS, i);
        it[n++] = IT("Back", K_BACK, 0, 0);
        break;
    case SM_GAS:
        it[n++] = IT("Oxygen", K_NUM, F_GAS_O2, arg);
        it[n++] = IT("Helium", K_NUM, F_GAS_HE, arg);
        it[n++] = arg == 0 ? IT("In use", K_INFO, F_GAS_ON, arg) : IT("In use", K_BOOL, F_GAS_ON, arg);
        if (m->gear && m->gear->gas_cyl[arg]) it[n++] = IT("Cylinder", K_INFO, F_GAS_CYL_NAME, arg);
        else it[n++] = IT("Cylinder", K_NUM, F_GAS_CYL, arg);
        it[n++] = IT("Fill pressure", K_NUM, F_GAS_FILL, arg);
        it[n++] = IT("Back", K_BACK, 0, 0);
        break;
    case SM_GEAR:
        it[n++] = IT("On this dive", K_INFO, F_GEAR_HEAD, 0);
        if (m->gear) {
            for (int i = 0; i < m->gear->n && n < MENU_MAX_ROWS - 2; i++)
                if (m->gear->item[i].flags & GEAR_ON_DIVE) it[n++] = IT("", K_GEAR, 0, i);
            if (gear_lead_x10(m->gear)) it[n++] = IT("Lead total", K_INFO, F_LEAD, 0);
        }
        it[n++] = IT("Back", K_BACK, 0, 0);
        break;
    case SM_DECO:
        it[n++] = IT("GF low", K_NUM, F_GF_LOW, 0);
        it[n++] = IT("GF high", K_NUM, F_GF_HIGH, 0);
        it[n++] = IT("Last stop", K_ENUM, F_LAST_STOP, 0);
        it[n++] = IT("ppO2 bottom", K_NUM, F_PPO2_BOTTOM, 0);
        it[n++] = IT("ppO2 deco", K_NUM, F_PPO2_DECO, 0);
        it[n++] = IT("Safety stop", K_BOOL, F_SAFETY, 0);
        it[n++] = IT("Back", K_BACK, 0, 0);
        break;
    case SM_ALARMS:
        it[n++] = IT("Reserve at surface", K_NUM, F_RESERVE, 0);
        it[n++] = IT("Turn-soon margin", K_NUM, F_TURN, 0);
        it[n++] = IT("Ascent alarm", K_NUM, F_ASCENT, 0);
        it[n++] = IT("Depth alarm", K_NUM, F_DEPTH_AL, 0);
        it[n++] = IT("Dive time alarm", K_NUM, F_TIME_AL, 0);
        it[n++] = IT("NDL warning", K_NUM, F_NDL_WARN, 0);
        it[n++] = IT("Vibration", K_BOOL, F_VIB, 0);
        it[n++] = IT("Sound", K_BOOL, F_SOUND, 0);
        it[n++] = IT("Back", K_BACK, 0, 0);
        break;
    case SM_TX:
        it[n++] = IT("Pair new", K_BOOL, F_PAIRING, 0);
        it[n++] = IT("T1", K_INFO, F_TX_SERIAL, 0);
        it[n++] = IT("T2", K_INFO, F_TX_SERIAL, 1);
        it[n++] = IT("T3", K_INFO, F_TX_SERIAL, 2);
        it[n++] = IT("T4", K_INFO, F_TX_SERIAL, 3);
        it[n++] = IT("T5", K_INFO, F_TX_SERIAL, 4);
        it[n++] = IT("Forget all", K_ACTION, A_FORGET, 0);
        it[n++] = IT("Back", K_BACK, 0, 0);
        break;
    case SM_COMPASS:
        it[n++] = IT("Declination", K_NUM, F_DECL, 0);
        it[n++] = IT("Calibrate", K_ACTION, A_CALIBRATE, 0);
        it[n++] = IT("Back", K_BACK, 0, 0);
        break;
    case SM_DISPLAY:
        it[n++] = IT("Brightness", K_NUM, F_BRIGHT, 0);
        it[n++] = IT("Auto brightness", K_BOOL, F_AUTOBR, 0);
        it[n++] = IT("Flip screen", K_BOOL, F_FLIP, 0);
        it[n++] = IT("Back", K_BACK, 0, 0);
        break;
    case SM_BT:
        it[n++] = IT("Bluetooth", K_BOOL, F_BT, 0);
        it[n++] = IT("Phone", K_INFO, F_BT_STATUS, 0);
        it[n++] = IT("During dives", K_INFO, F_BT_DIVE, 0);
        it[n++] = IT("Back", K_BACK, 0, 0);
        break;
    case SM_SYSTEM:
        it[n++] = IT("Water", K_ENUM, F_WATER, 0);
        it[n++] = IT("Log interval", K_NUM, F_LOG_INT, 0);
        it[n++] = IT("Sleep when dry", K_NUM, F_SLEEP, 0);
        it[n++] = IT("Reset to defaults", K_ACTION, A_RESET, 0);
        it[n++] = IT("Back", K_BACK, 0, 0);
        break;
    case SM_PLAN:
        it[n++] = IT("No-fly", K_INFO, F_NOFLY, 0);
        it[n++] = IT("Gas 1", K_INFO, F_PLAN_GAS, 0);
        if (m->dive) {
            float mod = dc_mod_m(&m->dive->gases[0], m->dive->cfg.bottom_ppo2_max, &m->dive->cfg);
            for (int i = 0; i < PLAN_DEPTHS && PLAN_DEPTH[i] <= mod + 0.01f; i++) it[n++] = IT("", K_PLAN, 0, i);
        }
        it[n++] = IT("Back", K_BACK, 0, 0);
        break;
    case SM_CHECK:
        for (int i = 0; m->predive && i < m->predive->n && n < MENU_MAX_ROWS - 1; i++) it[n++] = IT("", K_CHECK, 0, i);
        it[n++] = IT("Back", K_BACK, 0, 0);
        break;
    case SM_DIVEPLAN:
        it[n++] = IT("Plan", K_INFO, F_DP_DEPTH, 0);
        it[n++] = IT("Run time", K_INFO, F_DP_RUN, 0);
        for (int i = 0; i < m->plan->n_stops && n < MENU_MAX_ROWS - 8; i++) it[n++] = IT("", K_PSTOP, 0, i);
        for (int i = 0; i < DC_MAX_GASES; i++)
            if (m->plan->gas_bar[i]) it[n++] = IT("", K_INFO, F_DP_GAS, i);
        it[n++] = IT("Clear plan", K_ACTION, A_CLEAR_PLAN, 0);
        it[n++] = IT("Back", K_BACK, 0, 0);
        break;
    case SM_LOG: {
        int count = m->logbook ? m->logbook(m->log_ctx, -1, NULL) : 0;
        it[n++] = IT("Dives stored", K_INFO, F_LOG_HEAD, count);
        for (int i = 0; i < count && n < MENU_MAX_ROWS - 1; i++) it[n++] = IT("", K_LOG, 0, i);
        it[n++] = IT("Back", K_BACK, 0, 0);
        break;
    }
    case SM_DIVE:
        if (m->dive)
            for (int i = 0; i < DC_MAX_GASES; i++)
                if (m->dive->gases[i].enabled && i != m->dive->gas) it[n++] = IT("", K_GAS, 0, i);
        it[n++] = IT(m->bearing_locked ? "Unlock bearing" : "Lock bearing", K_ACTION, A_LOCK, 0);
        it[n++] = IT("Brightness", K_NUM, F_BRIGHT, 0);
        it[n++] = IT("Back to dive", K_BACK, 0, 0);
        break;
    }
    return n;
}

static void sub_title(const menu_t *m, char *buf, int cap)
{
    static const char *names[] = {"Settings", "Gases", "Gas", "Deco", "Alarms", "Transmitters", "Compass", "Display",
                                  "Bluetooth", "System", "Gear check", "Dive menu", "Dive planner", "Logbook", "Pre-dive check", "Dive plan"};
    if (m->sub == SM_GAS) snprintf(buf, (size_t)cap, "Gas %d", m->arg + 1);
    else snprintf(buf, (size_t)cap, "%s", names[m->sub]);
}

static int get(const dc_settings_t *s, int f, int a)
{
    switch (f) {
    case F_GAS_O2: return s->gas[a].o2_pct;
    case F_GAS_HE: return s->gas[a].he_pct;
    case F_GAS_ON: return s->gas[a].enabled;
    case F_GAS_CYL: return s->gas[a].cylinder_l;
    case F_GAS_FILL: return s->gas[a].fill_bar;
    case F_GF_LOW: return s->gf_low;
    case F_GF_HIGH: return s->gf_high;
    case F_LAST_STOP: return s->last_stop_m == 6 ? 1 : 0;
    case F_PPO2_BOTTOM: return s->ppo2_bottom_x100;
    case F_PPO2_DECO: return s->ppo2_deco_x100;
    case F_RESERVE: return s->reserve_bar;
    case F_ASCENT: return s->ascent_alarm_mpm;
    case F_BRIGHT: return s->brightness;
    case F_PAIRING: return s->pairing;
    case F_DECL: return s->declination_deg;
    case F_WATER: return s->water;
    case F_SAFETY: return s->safety_stop;
    case F_BT: return s->bluetooth;
    case F_DEPTH_AL: return s->depth_alarm_m;
    case F_TIME_AL: return s->time_alarm_min;
    case F_NDL_WARN: return s->ndl_warn_min;
    case F_TURN: return s->turn_margin_bar;
    case F_FLIP: return s->flip;
    case F_LOG_INT: return s->log_interval_s;
    case F_VIB: return s->vibrate;
    case F_SOUND: return s->sound;
    case F_AUTOBR: return s->auto_bright;
    case F_SLEEP: return s->sleep_min;
    default: return 0;
    }
}

static void set(dc_settings_t *s, int f, int a, int v)
{
    switch (f) {
    case F_GAS_O2: s->gas[a].o2_pct = (uint8_t)v; break;
    case F_GAS_HE: s->gas[a].he_pct = (uint8_t)v; break;
    case F_GAS_ON: s->gas[a].enabled = (uint8_t)v; break;
    case F_GAS_CYL: s->gas[a].cylinder_l = (uint8_t)v; break;
    case F_GAS_FILL: s->gas[a].fill_bar = (uint16_t)v; break;
    case F_GF_LOW: s->gf_low = (uint8_t)v; break;
    case F_GF_HIGH: s->gf_high = (uint8_t)v; break;
    case F_LAST_STOP: s->last_stop_m = v ? 6 : 3; break;
    case F_PPO2_BOTTOM: s->ppo2_bottom_x100 = (uint8_t)v; break;
    case F_PPO2_DECO: s->ppo2_deco_x100 = (uint8_t)v; break;
    case F_RESERVE: s->reserve_bar = (uint8_t)v; break;
    case F_ASCENT: s->ascent_alarm_mpm = (uint8_t)v; break;
    case F_BRIGHT: s->brightness = (uint8_t)v; break;
    case F_PAIRING: s->pairing = (uint8_t)v; break;
    case F_DECL: s->declination_deg = (int8_t)v; break;
    case F_WATER: s->water = (uint8_t)v; break;
    case F_SAFETY: s->safety_stop = (uint8_t)v; break;
    case F_BT: s->bluetooth = (uint8_t)v; break;
    case F_DEPTH_AL: s->depth_alarm_m = (uint8_t)v; break;
    case F_TIME_AL: s->time_alarm_min = (uint16_t)v; break;
    case F_NDL_WARN: s->ndl_warn_min = (uint8_t)v; break;
    case F_TURN: s->turn_margin_bar = (uint8_t)v; break;
    case F_FLIP: s->flip = (uint8_t)v; break;
    case F_LOG_INT: s->log_interval_s = (uint8_t)v; break;
    case F_VIB: s->vibrate = (uint8_t)v; break;
    case F_SOUND: s->sound = (uint8_t)v; break;
    case F_AUTOBR: s->auto_bright = (uint8_t)v; break;
    case F_SLEEP: s->sleep_min = (uint8_t)(v == 1 ? 0 : v); break;   /* stepping down from 2 lands on Never */
    }
    settings_validate(s);
}

static void range(int f, int *lo, int *hi, int *step)
{
    *step = 1;
    switch (f) {
    case F_GAS_O2: *lo = 5; *hi = 100; break;
    case F_GAS_HE: *lo = 0; *hi = 95; break;
    case F_GAS_CYL: *lo = 1; *hi = 30; break;
    case F_GAS_FILL: *lo = 50; *hi = 300; *step = 10; break;
    case F_GF_LOW: *lo = 10; *hi = 100; *step = 5; break;
    case F_GF_HIGH: *lo = 40; *hi = 100; *step = 5; break;
    case F_LAST_STOP: *lo = 0; *hi = 1; break;
    case F_PPO2_BOTTOM: *lo = 100; *hi = 160; *step = 5; break;
    case F_PPO2_DECO: *lo = 120; *hi = 160; *step = 5; break;
    case F_RESERVE: *lo = 20; *hi = 100; *step = 5; break;
    case F_ASCENT: *lo = 6; *hi = 18; break;
    case F_BRIGHT: *lo = 1; *hi = 5; break;
    case F_DECL: *lo = -30; *hi = 30; break;
    case F_WATER: *lo = 0; *hi = 2; break;
    case F_DEPTH_AL: *lo = 0; *hi = 150; *step = 10; break;
    case F_TIME_AL: *lo = 0; *hi = 300; *step = 10; break;
    case F_NDL_WARN: *lo = 0; *hi = 10; break;
    case F_TURN: *lo = 10; *hi = 50; *step = 5; break;
    case F_LOG_INT: *lo = 1; *hi = 10; break;
    case F_SLEEP: *lo = 0; *hi = 60; break;
    default: *lo = 0; *hi = 1; break;
    }
}

static void label_of(const menu_t *m, const item_t *it, char *out, size_t cap)
{
    char g[12];
    if (it->kind == K_SUB && it->field == SM_GAS) {
        snprintf(out, cap, "Gas %d", it->arg + 1);
    } else if (it->kind == K_GAS) {
        gas_name(&m->s->gas[it->arg], g, sizeof(g));
        snprintf(out, cap, "Switch to %s", g);
    } else if (it->kind == K_CHECK) {
        snprintf(out, cap, "%s", m->predive->item[it->arg].label);
    } else if (it->kind == K_PSTOP) {
        snprintf(out, cap, "Stop %d m", m->plan->stop[it->arg].depth_m);
    } else if (it->field == F_DP_GAS && it->kind == K_INFO) {
        gas_name(&m->s->gas[it->arg], g, sizeof(g));
        snprintf(out, cap, "Gas %u %s", (unsigned)(it->arg + 1) % 10u, g);
    } else if (it->kind == K_PLAN) {
        snprintf(out, cap, "%d m", (int)PLAN_DEPTH[it->arg]);
    } else if (it->kind == K_LOG) {
        divelog_header_t h;
        static const char *mon[] = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
        if (m->logbook(m->log_ctx, it->arg, &h)) {
            int y, mo, d;
            civil_date((int32_t)(h.start_unix / 86400u), &y, &mo, &d);
            snprintf(out, cap, "#%u  %d %s %02u:%02u", h.dive_no, d, mon[mo - 1], (unsigned)(h.start_unix % 86400u / 3600u),
                     (unsigned)(h.start_unix % 3600u / 60u));
        } else {
            snprintf(out, cap, "unreadable");
        }
    } else if (it->kind == K_GEAR) {
        snprintf(out, cap, "%s", m->gear->item[it->arg].name[0] ? m->gear->item[it->arg].name
                                                               : gear_type_name(m->gear->item[it->arg].type));
    } else {
        snprintf(out, cap, "%s", it->label);
    }
}

/* Gas switch allowed now? Same rule as dive_switch_gas(). */
static bool gas_ok(const menu_t *m, int i, float *mod)
{
    const dive_t *d = m->dive;
    *mod = dc_mod_m(&d->gases[i], i == 0 ? d->cfg.bottom_ppo2_max : d->cfg.deco_ppo2_max, &d->cfg);
    return dc_ppo2(&d->gases[i], d->depth_m, &d->cfg) <= d->cfg.deco_ppo2_max + 0.005f;
}

static int gas_of_cylinder(const dc_gear_t *g, int item)
{
    for (int i = 0; i < DC_MAX_GASES; i++)
        if (g->gas_cyl[i] == item + 1) return i;
    return -1;
}

static void format(const menu_t *m, const item_t *it, int v, char *out, int cap, bool *disabled)
{
    const dc_settings_t *s = m->s;
    size_t c = (size_t)cap;
    *disabled = false;
    switch (it->kind) {
    case K_SUB:
        if (it->field == SM_GAS) {
            char name[12];
            gas_name(&s->gas[it->arg], name, sizeof(name));
            snprintf(out, c, "%s%s", name, s->gas[it->arg].enabled ? "" : " off");
        } else if (it->field == SM_GEAR && m->gear) {
            snprintf(out, c, "%d items", gear_on_dive(m->gear));
        } else if (it->field == SM_CHECK && m->predive) {
            const predive_t *pd = m->predive;
            if (pd->n_fail) snprintf(out, c, "STOP: %d", pd->n_fail);
            else if (pd->n_warn) snprintf(out, c, "%d to check", pd->n_warn);
            else snprintf(out, c, "Ready");
        } else if (it->field == SM_DIVEPLAN && m->plan) {
            snprintf(out, c, "%u m %u min", m->plan->depth_m, m->plan->bottom_min);
        } else if (it->field == SM_BT) {
            snprintf(out, c, "%s", s->bluetooth ? "On" : "Off");
        } else {
            snprintf(out, c, ">");
        }
        return;
    case K_BOOL: snprintf(out, c, "%s", v ? "On" : "Off"); return;
    case K_ACTION:
    case K_BACK: out[0] = 0; return;
    case K_GAS: {
        float mod;
        bool ok = gas_ok(m, it->arg, &mod);
        if (ok) snprintf(out, c, "MOD %d m", (int)mod);
        else snprintf(out, c, "too deep");
        *disabled = !ok;
        return;
    }
    case K_CHECK: snprintf(out, c, "%s", m->predive->item[it->arg].detail); return;
    case K_PSTOP: snprintf(out, c, "%d min", m->plan->stop[it->arg].minutes); return;
    case K_PLAN: {
        dc_plan_t p;
        const dive_t *d = m->dive;
        dc_plan(&d->tissues, PLAN_DEPTH[it->arg], 0, d->gases, &d->cfg, 0.0f, &p);
        if (p.in_deco || p.ndl_min <= 0) snprintf(out, c, "deco");
        else if (p.ndl_min >= 99) snprintf(out, c, "99+ min");
        else snprintf(out, c, "%d min", p.ndl_min);
        return;
    }
    case K_LOG: {
        divelog_header_t h;
        if (m->logbook(m->log_ctx, it->arg, &h))
            snprintf(out, c, "%u.%u m %lu'%s", h.max_depth_cm / 100u, h.max_depth_cm % 100u / 10u,
                     (unsigned long)((h.duration_s + 30u) / 60u), h.had_deco ? " D" : "");
        else out[0] = 0;
        return;
    }
    case K_GEAR: {
        const gear_item_t *g = &m->gear->item[it->arg];
        if (g->type == GEAR_CYLINDER) {
            int gas = gas_of_cylinder(m->gear, it->arg);
            if (gas >= 0) snprintf(out, c, "%d L  gas %d%s", (g->size_x10 + 5) / 10, gas + 1, g->tx_serial ? " TX" : "");
            else snprintf(out, c, "%d L  spare", (g->size_x10 + 5) / 10);
        } else if (g->type == GEAR_WEIGHTS) {
            snprintf(out, c, "%d.%d kg", g->size_x10 / 10, g->size_x10 % 10);
        } else if (g->type == GEAR_SUIT && g->size_x10) {
            snprintf(out, c, "%d mm", (g->size_x10 + 5) / 10);
        } else {
            snprintf(out, c, "%s", gear_type_name(g->type));
        }
        return;
    }
    default: break;
    }
    switch (it->field) {
    case F_GAS_O2: case F_GAS_HE: case F_GF_LOW: case F_GF_HIGH: snprintf(out, c, "%d %%", v); break;
    case F_GAS_ON: snprintf(out, c, "always"); break;
    case F_GAS_CYL: snprintf(out, c, "%d L", v); break;
    case F_GAS_CYL_NAME: {
        const gear_item_t *g = &m->gear->item[m->gear->gas_cyl[it->arg] - 1];
        snprintf(out, c, "%.12s", g->name[0] ? g->name : "from phone");
        break;
    }
    case F_GAS_FILL: case F_RESERVE: case F_TURN: snprintf(out, c, "%d bar", v); break;
    case F_LAST_STOP: snprintf(out, c, "%d m", v ? 6 : 3); break;
    case F_PPO2_BOTTOM: case F_PPO2_DECO: snprintf(out, c, "%d.%02d", v / 100, v % 100); break;
    case F_ASCENT: snprintf(out, c, "%d m/min", v); break;
    case F_BRIGHT: snprintf(out, c, "%d / 5", v); break;
    case F_DECL: snprintf(out, c, "%+d deg", v); break;
    case F_WATER: snprintf(out, c, "%s", v == 0 ? "Salt" : (v == 1 ? "Fresh" : "EN 13319")); break;
    case F_DEPTH_AL: if (v) snprintf(out, c, "%d m", v); else snprintf(out, c, "Off"); break;
    case F_TIME_AL: if (v) snprintf(out, c, "%d min", v); else snprintf(out, c, "Off"); break;
    case F_NDL_WARN: if (v) snprintf(out, c, "< %d min", v); else snprintf(out, c, "Off"); break;
    case F_LOG_INT: snprintf(out, c, "%d s", v); break;
    case F_SLEEP: if (v) snprintf(out, c, "%d min", v < 2 ? 2 : v); else snprintf(out, c, "Never"); break;
    case F_BT_STATUS:
        snprintf(out, c, "%s", !s->bluetooth ? "Off" : (m->ble_status ? m->ble_status : "Waiting"));
        break;
    case F_BT_DIVE: snprintf(out, c, "always off"); break;
    case F_GEAR_HEAD:
        if (m->gear && m->gear->n) snprintf(out, c, "%d of %d", gear_on_dive(m->gear), m->gear->n);
        else snprintf(out, c, "sync from app");
        break;
    case F_NOFLY: {
        int mins = m->dive ? (int)(m->dive->nofly_min + 0.99f) : 0;
        if (mins > 0) snprintf(out, c, "%d h %02d min", mins / 60, mins % 60);
        else snprintf(out, c, "clear");
        break;
    }
    case F_PLAN_GAS: {
        char g[12];
        gas_name(&s->gas[0], g, sizeof(g));
        snprintf(out, c, "%s  GF %d/%d", g, s->gf_low, s->gf_high);
        break;
    }
    case F_DP_DEPTH: snprintf(out, c, "%u m  %u min", m->plan->depth_m, m->plan->bottom_min); break;
    case F_DP_RUN: snprintf(out, c, "%u min  GF %u/%u", m->plan->runtime_min, m->plan->gf_low, m->plan->gf_high); break;
    case F_DP_GAS:
        snprintf(out, c, "%u bar%s", m->plan->gas_bar[it->arg], (m->plan->gas_ok & (1u << it->arg)) ? "" : " SHORT");
        break;
    case F_LOG_HEAD: snprintf(out, c, "%d", it->arg); break;
    case F_LEAD: { int kg = m->gear ? gear_lead_x10(m->gear) : 0; snprintf(out, c, "%d.%d kg", kg / 10, kg % 10); break; }
    case F_TX_SERIAL:
        if (s->gas[it->arg].tx_serial) snprintf(out, c, "%06lu", (unsigned long)s->gas[it->arg].tx_serial);
        else snprintf(out, c, "-");
        break;
    default: snprintf(out, c, "%d", v); break;
    }
}

void menu_init(menu_t *m, dc_settings_t *s)
{
    memset(m, 0, sizeof(*m));
    m->s = s;
}

void menu_open(menu_t *m, bool diving)
{
    m->open = true;
    m->diving = diving;
    m->sub = diving ? SM_DIVE : SM_ROOT;
    m->arg = 0;
    m->cursor = 0;
    m->depth = 0;
    m->editing = false;
}

void menu_close(menu_t *m)
{
    m->open = false;
    m->editing = false;
}

menu_event_t menu_button(menu_t *m, menu_btn_t b)
{
    if (!m->open) return MENU_EV_NONE;
    item_t it[MENU_MAX_ROWS];
    int n = items(m, m->sub, m->arg, it);
    if (m->cursor >= n) m->cursor = n - 1;
    item_t *cur = &it[m->cursor];

    if (m->editing) {
        int lo, hi, step;
        range(cur->field, &lo, &hi, &step);
        if (b == BTN_UP) m->edit_val = m->edit_val + step > hi ? (cur->kind == K_ENUM ? lo : hi) : m->edit_val + step;
        else if (b == BTN_DOWN) m->edit_val = m->edit_val - step < lo ? (cur->kind == K_ENUM ? hi : lo) : m->edit_val - step;
        else {
            m->editing = false;
            int before = get(m->s, cur->field, cur->arg);
            set(m->s, cur->field, cur->arg, m->edit_val);
            return get(m->s, cur->field, cur->arg) != before ? MENU_EV_CHANGED : MENU_EV_NONE;
        }
        return MENU_EV_NONE;
    }

    if (b == BTN_UP) {
        m->cursor = (m->cursor + n - 1) % n;
        return MENU_EV_NONE;
    }
    if (b == BTN_DOWN) {
        m->cursor = (m->cursor + 1) % n;
        return MENU_EV_NONE;
    }

    switch (cur->kind) {
    case K_SUB:
        if (m->depth < MENU_DEPTH) {
            m->stack_sub[m->depth] = m->sub;
            m->stack_arg[m->depth] = m->arg;
            m->stack_cursor[m->depth] = m->cursor;
            m->depth++;
            m->sub = cur->field;
            m->arg = cur->arg;
            m->cursor = 0;
        }
        return MENU_EV_NONE;
    case K_BACK:
        if (m->depth == 0) {
            m->open = false;
            return MENU_EV_CLOSED;
        }
        m->depth--;
        m->sub = m->stack_sub[m->depth];
        m->arg = m->stack_arg[m->depth];
        m->cursor = m->stack_cursor[m->depth];
        return MENU_EV_NONE;
    case K_NUM:
    case K_ENUM:
        m->editing = true;
        m->edit_val = get(m->s, cur->field, cur->arg);
        return MENU_EV_NONE;
    case K_BOOL:
        set(m->s, cur->field, cur->arg, !get(m->s, cur->field, cur->arg));
        return MENU_EV_CHANGED;
    case K_GAS: {
        float mod;
        if (!m->dive || !gas_ok(m, cur->arg, &mod)) return MENU_EV_NONE;
        m->ev_arg = cur->arg;
        m->open = false;
        return MENU_EV_SWITCH_GAS;
    }
    case K_ACTION:
        if (cur->field == A_RESET) {
            dc_settings_t keep = *m->s;
            settings_default(m->s);
            for (int i = 0; i < DC_MAX_GASES; i++) m->s->gas[i].tx_serial = keep.gas[i].tx_serial;
            return MENU_EV_CHANGED;
        }
        if (cur->field == A_FORGET) {
            for (int i = 0; i < DC_MAX_GASES; i++) m->s->gas[i].tx_serial = 0;
            return MENU_EV_CHANGED;
        }
        if (cur->field == A_CLEAR_PLAN) {
            m->depth = 0;              /* the plan page is gone: back to the top */
            m->sub = SM_ROOT;
            m->arg = 0;
            m->cursor = 0;
            return MENU_EV_CLEAR_PLAN;
        }
        if (cur->field == A_LOCK) {
            m->open = false;
            return MENU_EV_LOCK;
        }
        return MENU_EV_CALIBRATE;
    default:
        return MENU_EV_NONE;
    }
}

int menu_rows(const menu_t *m, menu_row_t *rows, int max, char *title, int title_cap)
{
    item_t it[MENU_MAX_ROWS];
    int n = items(m, m->sub, m->arg, it);
    if (title) sub_title(m, title, title_cap);
    if (n > max) n = max;
    for (int i = 0; i < n; i++) {
        menu_row_t *r = &rows[i];
        label_of(m, &it[i], r->label, sizeof(r->label));
        int v = (m->editing && i == m->cursor) ? m->edit_val : get(m->s, it[i].field, it[i].arg);
        format(m, &it[i], v, r->value, sizeof(r->value), &r->disabled);
        r->selected = i == m->cursor;
        r->editing = m->editing && i == m->cursor;
        r->submenu = it[i].kind == K_SUB;
        if (it[i].kind == K_INFO || it[i].kind == K_GEAR || it[i].kind == K_PLAN || it[i].kind == K_LOG || it[i].kind == K_CHECK || it[i].kind == K_PSTOP) r->disabled = true;
        r->level = 0;
        if (it[i].kind == K_CHECK) r->level = m->predive->item[it[i].arg].level == PD_OK ? 3 : m->predive->item[it[i].arg].level;
        if (it[i].kind == K_INFO && it[i].field == F_DP_GAS && !(m->plan->gas_ok & (1u << it[i].arg))) r->level = 2;
        if (it[i].kind == K_SUB && it[i].field == SM_CHECK) r->level = m->predive->worst == PD_OK ? 3 : (uint8_t)m->predive->worst;
    }
    return n;
}

int menu_logbook_proto(void *ctx, int i, divelog_header_t *h)
{
    const proto_dev_t *p = (const proto_dev_t *)ctx;
    int n = p->log_count ? p->log_count(p->ctx) : 0;
    if (i < 0) return n;
    if (i >= n || !p->log_read) return 0;
    uint8_t hb[DIVELOG_HEADER];
    if (p->log_read(p->ctx, n - 1 - i, 0, hb, DIVELOG_HEADER) != DIVELOG_HEADER) return 0;
    return divelog_parse_header(hb, h) ? 1 : 0;
}
