/* predive.c — see predive.h. */
#include "divecore/predive.h"

#include <math.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>

#include "divecore/pelagic.h"

#if defined(__GNUC__)
static void add(predive_t *p, int level, const char *label, const char *fmt, ...) __attribute__((format(printf, 4, 5)));
#endif
static void add(predive_t *p, int level, const char *label, const char *fmt, ...)
{
    if (p->n >= PREDIVE_MAX) return;
    predive_item_t *it = &p->item[p->n++];
    snprintf(it->label, sizeof(it->label), "%s", label);
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(it->detail, sizeof(it->detail), fmt, ap);
    va_end(ap);
    it->level = (uint8_t)level;
    if (level > p->worst) p->worst = level;
    if (level == PD_WARN) p->n_warn++;
    if (level == PD_FAIL) p->n_fail++;
}

static void gas_name(const dc_gas_setting_t *g, char *out, size_t cap)
{
    if (g->he_pct) snprintf(out, cap, "Tx%u/%u", g->o2_pct, g->he_pct);
    else if (g->o2_pct == 21) snprintf(out, cap, "Air");
    else if (g->o2_pct == 100) snprintf(out, cap, "O2");
    else snprintf(out, cap, "EAN%u", g->o2_pct);
}

void predive_run(const dive_t *d, const dc_settings_t *s, const dc_gear_t *g, const dc_divplan_t *plan,
                 const predive_env_t *env, predive_t *out)
{
    memset(out, 0, sizeof(*out));

    if (d->battery_pct < 0) add(out, PD_WARN, "Battery", "unknown");
    else if (d->battery_pct < 15) add(out, PD_FAIL, "Battery", "%d %%: charge first", d->battery_pct);
    else if (d->battery_pct < 30) add(out, PD_WARN, "Battery", "%d %%: charge soon", d->battery_pct);
    else add(out, PD_OK, "Battery", "%d %%", d->battery_pct);

    int ns = env ? env->depth_sensors : 2;
    if (ns >= 2) add(out, PD_OK, "Depth sensors", "both agree");
    else if (ns == 1) add(out, PD_WARN, "Depth sensors", "only one answers");
    else add(out, PD_FAIL, "Depth sensors", "none answers");

    bool any_hypoxic_only = s->gas[0].o2_pct < 18;
    for (int i = 0; i < DC_MAX_GASES; i++) {
        const dc_gas_setting_t *gs = &s->gas[i];
        if (!gs->enabled) continue;
        if (i > 0 && gs->o2_pct >= 18) any_hypoxic_only = false;
        char label[20], name[12];
        gas_name(gs, name, sizeof(name));
        snprintf(label, sizeof(label), "T%u %s", (unsigned)(i + 1) % 10u, name);
        const dive_tank_t *t = &d->tanks[i];
        if (!t->serial) {
            add(out, PD_WARN, label, "no transmitter paired");
        } else if (!t->present || t->age_s > 60.0f) {
            add(out, PD_WARN, label, "not heard: valve open?");
        } else if (t->bar < 2.0f * (float)s->reserve_bar) {
            add(out, PD_FAIL, label, "only %.0f bar", (double)t->bar);
        } else if (t->bar < 0.9f * (float)gs->fill_bar) {
            add(out, PD_WARN, label, "%.0f of %u bar", (double)t->bar, gs->fill_bar);
        } else if (t->battery == TX_BATT_LOW) {
            add(out, PD_WARN, label, "%.0f bar, TX battery weak", (double)t->bar);
        } else {
            add(out, PD_OK, label, "%.0f bar", (double)t->bar);
        }
        if (g && g->n) {
            int c = g->gas_cyl[i] - 1;
            if (c < 0 || c >= g->n) add(out, PD_WARN, "Gear", "gas %d: no cylinder", i + 1);
            else if (g->item[c].tx_serial && gs->tx_serial && g->item[c].tx_serial != gs->tx_serial)
                add(out, PD_FAIL, "Gear", "gas %d: wrong transmitter", i + 1);
        }
    }
    if (any_hypoxic_only) add(out, PD_FAIL, "Gases", "gas 1 hypoxic, no travel gas");

    if (!g || !g->synced_unix) add(out, PD_WARN, "Phone sync", "never synced");
    else if (env && env->now_unix && env->now_unix > g->synced_unix) {
        uint32_t age_h = (env->now_unix - g->synced_unix) / 3600u;
        if (age_h >= 24) add(out, PD_WARN, "Phone sync", "%lu days ago", (unsigned long)(age_h / 24));
        else add(out, PD_OK, "Phone sync", age_h ? "%lu h ago" : "just now", (unsigned long)age_h);
    } else add(out, PD_OK, "Phone sync", "done");

    if (plan && plan->valid) {
        bool fits = true;
        for (int i = 0; i < DC_MAX_GASES; i++)
            if (plan->gas_bar[i] && !(plan->gas_ok & (1u << i))) fits = false;
        if (fits) add(out, PD_OK, "Plan", "%u m %u min, gas fits", plan->depth_m, plan->bottom_min);
        else add(out, PD_FAIL, "Plan", "%u m %u min: not enough gas", plan->depth_m, plan->bottom_min);
    }

    if (env && env->interrupted_dive) add(out, PD_FAIL, "Last dive", "restarted in the dive");
    if (env && env->compass_uncalibrated) add(out, PD_WARN, "Compass", "not calibrated");
    if (env && !env->now_unix) add(out, PD_WARN, "Clock", "not set: connect phone");
    if (d->ox.cns_pct >= 50.0f) add(out, PD_WARN, "Oxygen (CNS)", "%.0f %% left from last dive", (double)d->ox.cns_pct);
}

int predive_serialize(const predive_t *p, uint8_t *b, int cap)
{
    int need = 2 + p->n * 49;
    if (cap < need) return 0;
    b[0] = (uint8_t)p->n;
    b[1] = (uint8_t)p->worst;
    for (int i = 0; i < p->n; i++) {
        uint8_t *o = b + 2 + i * 49;
        o[0] = p->item[i].level;
        memcpy(o + 1, p->item[i].label, 20);
        memcpy(o + 21, p->item[i].detail, 28);
    }
    return need;
}
