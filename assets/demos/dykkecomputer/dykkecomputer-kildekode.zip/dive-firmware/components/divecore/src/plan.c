/* plan.c — see plan.h. */
#include "divecore/plan.h"

#include <math.h>
#include <string.h>

static void put16(uint8_t *b, uint16_t v) { b[0] = (uint8_t)v; b[1] = (uint8_t)(v >> 8); }
static void put32(uint8_t *b, uint32_t v) { put16(b, (uint16_t)v); put16(b + 2, (uint16_t)(v >> 16)); }
static uint16_t get16(const uint8_t *b) { return (uint16_t)(b[0] | b[1] << 8); }
static uint32_t get32(const uint8_t *b) { return get16(b) | (uint32_t)get16(b + 2) << 16; }

bool divplan_compute(dc_divplan_t *p, int depth_m, int bottom_min, int sac_l_min, const dc_settings_t *s,
                     const dc_tissues_t *tissues)
{
    memset(p, 0, sizeof(*p));
    if (depth_m < 3 || depth_m > 150 || bottom_min < 1 || bottom_min > 240 || sac_l_min < 5 || sac_l_min > 40) return false;
    dive_t d;
    dive_init(&d);
    settings_apply(s, &d);
    float depth = (float)depth_m, sac = (float)sac_l_min;
    float p_bottom = d.cfg.surface_bar + depth * d.cfg.bar_per_m;
    float descent_s = depth / DIVPLAN_DESCENT_MPM * 60.0f;
    float bottom_s = (float)bottom_min * 60.0f - descent_s;
    if (bottom_s < 0.0f) bottom_s = 0.0f;

    if (tissues) d.tissues = *tissues;
    dc_tissues_update(&d.tissues, d.cfg.surface_bar, p_bottom, descent_s, &d.gases[0]);
    dc_tissues_update(&d.tissues, p_bottom, p_bottom, bottom_s, &d.gases[0]);

    dc_plan(&d.tissues, depth, 0, d.gases, &d.cfg, 0.0f, &d.plan);
    d.depth_m = depth;
    d.max_depth_m = depth;
    d.gas = 0;

    float litres[DC_MAX_GASES];
    dive_ascent_gas(&d, sac, litres);
    /* descent and bottom on gas 1 */
    litres[0] += sac * (d.cfg.surface_bar + p_bottom) / 2.0f * descent_s / 60.0f + sac * p_bottom * bottom_s / 60.0f;

    p->valid = 1;
    p->depth_m = (uint8_t)depth_m;
    p->bottom_min = (uint8_t)bottom_min;
    p->gf_low = s->gf_low;
    p->gf_high = s->gf_high;
    p->sac_l_min = (uint8_t)sac_l_min;
    for (int i = 0; i < d.plan.n_stops && p->n_stops < DIVPLAN_STOPS; i++) {
        p->stop[p->n_stops].depth_m = (uint8_t)lroundf(d.plan.stops[i].depth_m);
        p->stop[p->n_stops].minutes = (uint8_t)(d.plan.stops[i].minutes > 255 ? 255 : d.plan.stops[i].minutes);
        p->n_stops++;
    }
    p->tts_min = (uint16_t)d.plan.tts_min;
    p->runtime_min = (uint16_t)(bottom_min + d.plan.tts_min);
    for (int i = 0; i < DC_MAX_GASES; i++) {
        if (litres[i] <= 0.0f || !s->gas[i].enabled) continue;
        float bar = litres[i] / (float)s->gas[i].cylinder_l + (float)s->reserve_bar;
        p->gas_bar[i] = (uint16_t)lroundf(bar);
        if (bar <= (float)s->gas[i].fill_bar) p->gas_ok |= (uint8_t)(1u << i);
    }
    return true;
}

int divplan_serialize(const dc_divplan_t *p, uint8_t *b, int cap)
{
    if (cap < DIVPLAN_BLOB) return 0;
    memset(b, 0, DIVPLAN_BLOB);
    b[0] = 'D'; b[1] = 'P'; b[2] = 1;
    b[3] = p->depth_m; b[4] = p->bottom_min; b[5] = p->gf_low; b[6] = p->gf_high; b[7] = p->sac_l_min; b[8] = p->n_stops;
    for (int i = 0; i < DIVPLAN_STOPS; i++) { b[9 + 2 * i] = p->stop[i].depth_m; b[10 + 2 * i] = p->stop[i].minutes; }
    put16(b + 41, p->runtime_min);
    put16(b + 43, p->tts_min);
    for (int i = 0; i < DC_MAX_GASES; i++) put16(b + 45 + 2 * i, p->gas_bar[i]);
    b[55] = p->gas_ok;
    put32(b + 56, p->created_unix);
    put32(b + 60, dc_crc32(b, 60));
    return DIVPLAN_BLOB;
}

bool divplan_deserialize(const uint8_t *b, int len, dc_divplan_t *p)
{
    if (len < DIVPLAN_BLOB || b[0] != 'D' || b[1] != 'P' || b[2] != 1 || get32(b + 60) != dc_crc32(b, 60)) return false;
    memset(p, 0, sizeof(*p));
    p->depth_m = b[3]; p->bottom_min = b[4]; p->gf_low = b[5]; p->gf_high = b[6]; p->sac_l_min = b[7];
    p->n_stops = b[8] > DIVPLAN_STOPS ? DIVPLAN_STOPS : b[8];
    for (int i = 0; i < DIVPLAN_STOPS; i++) { p->stop[i].depth_m = b[9 + 2 * i]; p->stop[i].minutes = b[10 + 2 * i]; }
    p->runtime_min = get16(b + 41);
    p->tts_min = get16(b + 43);
    for (int i = 0; i < DC_MAX_GASES; i++) p->gas_bar[i] = get16(b + 45 + 2 * i);
    p->gas_ok = b[55];
    p->created_unix = get32(b + 56);
    p->valid = p->depth_m > 0;
    return true;
}

float divplan_bottom_left_s(const dc_divplan_t *p, const dive_t *d)
{
    return (float)p->bottom_min * 60.0f - d->dive_time_s;
}

uint32_t divplan_alarms(const dc_divplan_t *p, const dive_t *d)
{
    if (!p || !p->valid || d->state != DIVE_ACTIVE) return 0;
    uint32_t a = 0;
    if (d->depth_m > (float)p->depth_m + 1.0f) a |= ALARM_PLAN_DEEPER;
    /* Over time while still near the bottom (an ascent in progress is what we want). */
    /* a minute's grace: leaving on the minute still reads as near the bottom for a few seconds */
    if (divplan_bottom_left_s(p, d) < -60.0f && d->depth_m > 0.66f * (float)p->depth_m && d->ascent_mpm < 3.0f) a |= ALARM_PLAN_TIME;
    if (d->plan.tts_min > (int)p->tts_min + 3) a |= ALARM_PLAN_DECO;
    return a;
}
