/*
 * menu.h — the menus, driven by the three buttons (UP, DOWN, SELECT).
 *
 * Two menus, chosen when the menu opens:
 *   surface  all settings: gases, gear checklist, NDL planner (from the tissues now, so it
 *            accounts for repeat dives) with no-fly time, logbook, deco, alarms, transmitters,
 *            compass, display, Bluetooth and system/reset.
 *   dive     only what a diver needs underwater: switch gas (gases too rich for the current
 *            depth are shown but refused), lock or unlock the compass bearing, brightness.
 *            Nothing that changes the deco model can be changed during a dive.
 * When the dive state changes while a menu is open, the caller closes it (menu_close).
 *
 * Moving: UP / DOWN move the cursor, SELECT opens a submenu, starts editing a value,
 * toggles an on/off item or runs an action. Editing: UP / DOWN change the value,
 * SELECT stores it. "Back" leaves a submenu; "Exit" on the top level closes the menu.
 *
 * The menu only knows about dc_settings_t; the caller saves and applies the settings
 * when menu_button() reports MENU_EV_CHANGED. Rendering is up to the caller: menu_rows()
 * gives the visible rows as text, so the LVGL screen and the simulator draw the same menu.
 */
#ifndef DIVECORE_MENU_H
#define DIVECORE_MENU_H

#include <stdbool.h>

#include "divecore/dive.h"
#include "divecore/divelog.h"
#include "divecore/gear.h"
#include "divecore/plan.h"
#include "divecore/predive.h"
#include "divecore/settings.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef enum { BTN_UP = 0, BTN_DOWN = 1, BTN_SELECT = 2 } menu_btn_t;

typedef enum {
    MENU_EV_NONE = 0,
    MENU_EV_CHANGED,      /* a setting changed: save and apply */
    MENU_EV_CLOSED,
    MENU_EV_CALIBRATE,    /* start the compass figure-8 calibration */
    MENU_EV_SWITCH_GAS,   /* dive menu: switch to gas ev_arg (already checked as breathable); menu closed */
    MENU_EV_LOCK,         /* dive menu: lock the current heading, or unlock; menu closed */
    MENU_EV_CLEAR_PLAN,   /* surface menu: forget the dive plan from the phone */
} menu_event_t;

#define MENU_MAX_ROWS 16
#define MENU_DEPTH 4

typedef struct {
    char label[24];
    char value[28];
    bool selected;
    bool editing;
    bool submenu;
    bool disabled;        /* shown, but SELECT does nothing (e.g. a gas too rich for this depth) */
    uint8_t level;        /* 0 normal, 1 warning (amber), 2 stop (red), 3 OK (green): pre-dive check rows */
} menu_row_t;

typedef struct {
    dc_settings_t *s;
    const dc_gear_t *gear;     /* optional: the synced gear list for the checklist */
    const dive_t *dive;        /* optional: needed by the dive menu */
    const predive_t *predive;  /* optional: latest pre-dive check, refreshed by the caller */
    const dc_divplan_t *plan;  /* optional: dive plan from the phone */
    const char *ble_status;    /* optional: shown on the Bluetooth page, e.g. "Connected" */
    /* optional logbook, newest first: i = -1 returns the count; otherwise fills h and returns 1 (0 = unreadable) */
    int (*logbook)(void *ctx, int i, divelog_header_t *h);
    void *log_ctx;
    bool bearing_locked;       /* set by the caller, decides "Lock" or "Unlock" */
    bool diving;               /* which menu is open */
    int ev_arg;                /* argument of the last event (gas index) */
    bool open;
    int sub, arg;          /* current submenu and its argument (gas index) */
    int cursor;
    bool editing;
    int edit_val;
    int stack_sub[MENU_DEPTH], stack_arg[MENU_DEPTH], stack_cursor[MENU_DEPTH];
    int depth;
} menu_t;

void menu_init(menu_t *m, dc_settings_t *s);
/* Opens the dive menu when diving is true, otherwise the surface menu. */
void menu_open(menu_t *m, bool diving);
void menu_close(menu_t *m);
menu_event_t menu_button(menu_t *m, menu_btn_t b);
/* Fills rows for the current submenu; returns the row count. title gets the submenu's name. */
int menu_rows(const menu_t *m, menu_row_t *rows, int max, char *title, int title_cap);
/* Ready-made logbook callback over the phone protocol's log storage: set logbook to this and
 * log_ctx to the proto_dev_t. Newest dive first. */
int menu_logbook_proto(void *ctx, int i, divelog_header_t *h);

#ifdef __cplusplus
}
#endif
#endif
