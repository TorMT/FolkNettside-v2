/* depth.h — MS5837-30BA compensation, dual-sensor cross-check and ascent rate. */
#ifndef DIVECORE_DEPTH_H
#define DIVECORE_DEPTH_H

#include <stdbool.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Factory calibration words C0..C6 read from the sensor PROM. */
typedef struct {
    uint16_t c[8];
} ms5837_prom_t;

/* CRC-4 check of the PROM (datasheet algorithm). True when the stored CRC matches. */
bool ms5837_prom_ok(const ms5837_prom_t *prom);

/* First- and second-order compensation of raw D1 (pressure) and D2 (temperature).
 * Outputs pressure in mbar and temperature in degrees C. */
void ms5837_30ba_compensate(const ms5837_prom_t *prom, uint32_t d1, uint32_t d2,
                            float *mbar, float *celsius);

/* Inverse used by the simulator: raw D1 for a wanted pressure at a given D2. */
uint32_t ms5837_30ba_d1_for(const ms5837_prom_t *prom, uint32_t d2, float mbar);

typedef enum {
    DEPTH_OK = 0,
    DEPTH_ONLY_A,
    DEPTH_ONLY_B,
    DEPTH_DISAGREE,
    DEPTH_NONE
} depth_status_t;

typedef struct {
    float tol_m;           /* 0.3 m */
    float tol_frac;        /* 0.03 */
    float persist_s;       /* 5 s before a disagreement is reported */
    float disagree_s;      /* running time the sensors have disagreed */
} depth_check_t;

void depth_check_init(depth_check_t *c);
/* Combine two depths (NaN = sensor missing). Returns the depth to use (the deeper when they disagree). */
float depth_check(depth_check_t *c, float a_m, float b_m, float dt_s, depth_status_t *status);

/* Ascent rate from a short ring buffer: positive = ascending, m/min. */
#define ASCENT_WIN 16
typedef struct {
    float depth[ASCENT_WIN];
    float t[ASCENT_WIN];
    int n, head;
    float window_s;  /* 4 s */
} ascent_rate_t;

void ascent_rate_init(ascent_rate_t *a, float window_s);
float ascent_rate_push(ascent_rate_t *a, float t_s, float depth_m);

#ifdef __cplusplus
}
#endif
#endif
