/*
 * divelog.h — compact binary dive log and UDDF export.
 *
 * File layout (little-endian):
 *   header   64 bytes, the last 4 are a CRC-32 of the first 60
 *   samples  24 bytes each (format 2: adds the dead-reckoned position), one every `interval` seconds
 *   footer   4 bytes, CRC-32 of all sample bytes
 *   gear     optional: the gear on this dive, a gear blob (gear.h, own CRC), appended at the end
 *
 * The writer only builds bytes; the caller stores them (a file on the SD card on the ESP32,
 * memory in the simulator). The header is written once at the start and again, completed,
 * at the end of the dive.
 *
 * UDDF is the open dive-log format Subsurface and other log programs import.
 */
#ifndef DIVECORE_DIVELOG_H
#define DIVECORE_DIVELOG_H

#include <stdbool.h>
#include <stdint.h>

#include "divecore/dive.h"
#include "divecore/gear.h"

#ifdef __cplusplus
extern "C" {
#endif

#define DIVELOG_HEADER 64
#define DIVELOG_SAMPLE 24
#define DIVELOG_VERSION 2
#define DIVELOG_FOOTER 4
#define DIVELOG_NO_TANK 0xFFFFu

typedef struct {
    uint16_t dive_no;
    uint32_t start_unix;       /* UTC seconds */
    uint32_t duration_s;
    uint16_t max_depth_cm;
    int16_t min_temp_dc;       /* 0.1 degC */
    uint16_t surface_mbar;
    uint8_t interval_s;
    uint8_t gf_low, gf_high, water;
    uint8_t o2[DC_MAX_GASES], he[DC_MAX_GASES], enabled[DC_MAX_GASES], cylinder_l[DC_MAX_GASES];
    uint32_t n_samples;
    uint8_t had_deco;
    uint8_t cns_end;
    uint8_t battery_start, battery_end;   /* dive computer %, 255 = unknown */
    uint8_t has_pos;                      /* entry position known (GNSS fix before the dive) */
    int32_t lat_e4, lon_e4;               /* entry position, 1e-4 degrees (about 11 m) */
    uint8_t tx_low;                       /* bit i: tank i's transmitter reported a weak battery */
} divelog_header_t;

typedef struct {
    uint16_t depth_cm;
    int16_t temp_dc;
    uint16_t ceiling_cm;
    uint16_t alarms;
    uint8_t gas;
    uint8_t flags;             /* bit 0: in deco, bit 1: dive time alarm */
    uint16_t tank_dbar[DC_MAX_GASES]; /* 0.1 bar, DIVELOG_NO_TANK when no data */
    int16_t x_dm, y_dm;        /* east, north of the entry point in 0.1 m (dead reckoning) */
} divelog_sample_t;

typedef struct {
    divelog_header_t h;
    uint32_t crc;              /* running CRC over sample bytes */
    float since_sample_s;
    float x_m, y_m;            /* latest dead-reckoned position, set by divelog_set_nav() */
} divelog_writer_t;

/* Start a log. Writes the provisional header into hdr_out[64]. */
void divelog_begin(divelog_writer_t *w, const dive_t *d, uint16_t dive_no, uint32_t start_unix, uint8_t interval_s,
                   uint8_t hdr_out[DIVELOG_HEADER]);
/* Entry position from the GNSS fix: call after divelog_begin(); the completed header from divelog_end() carries it. */
void divelog_set_entry(divelog_writer_t *w, double lat, double lon);
/* Latest dead-reckoned position (metres east and north of the entry), stored with the next sample. */
void divelog_set_nav(divelog_writer_t *w, float x_m, float y_m);
/* Call every dive tick. Returns true and fills out[20] when a sample is due. */
bool divelog_tick(divelog_writer_t *w, const dive_t *d, float dt_s, uint8_t out[DIVELOG_SAMPLE]);
/* Finish: the completed header (to overwrite the first 64 bytes) and the 4-byte footer to append. */
void divelog_end(divelog_writer_t *w, const dive_t *d, uint8_t hdr_out[DIVELOG_HEADER], uint8_t footer_out[DIVELOG_FOOTER]);

/* Gear block to append after the footer: only the items on this dive (and cylinders carrying a
 * gas). Returns its length, 0 when there is no gear. */
int divelog_gear_block(const dc_gear_t *g, uint8_t *out, int cap);
/* The gear stored with a log; false when the log has none. */
bool divelog_gear(const uint8_t *log, int len, dc_gear_t *out);

/* Header only (its own CRC). */
bool divelog_parse_header(const uint8_t hdr[DIVELOG_HEADER], divelog_header_t *h);
/* Checks both CRCs and the length (a gear block after the footer is allowed). */
bool divelog_parse(const uint8_t *log, int len, divelog_header_t *h);
void divelog_get_sample(const uint8_t *log, uint32_t i, divelog_sample_t *s);

/* UDDF 3.2 for n logs. Returns characters written (excluding the terminating 0), or -1 when a
 * log is corrupt, or -2 when cap is too small. */
int divelog_uddf(const uint8_t *const logs[], const int lens[], int n, char *out, int cap);

void dc_crc32_feed(uint32_t *state, const uint8_t *p, int n);   /* state starts at 0xFFFFFFFF */

#ifdef __cplusplus
}
#endif
#endif
