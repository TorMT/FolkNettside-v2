/*
 * predive.h — "ready to dive?" check, run on the surface.
 *
 * Looks at what the computer knows right now: its battery, both depth sensors, every gas in
 * use (transmitter paired, heard in the last minute, cylinder full enough, transmitter battery),
 * whether the gases match the cylinders synced from the phone, how long ago the phone synced,
 * the dive plan (does the gas fit) and leftover oxygen exposure. Each line is OK, a warning or
 * a stop. The surface screen shows the summary; the menu and the phone show every line.
 */
#ifndef DIVECORE_PREDIVE_H
#define DIVECORE_PREDIVE_H

#include <stdbool.h>
#include <stdint.h>

#include "divecore/dive.h"
#include "divecore/gear.h"
#include "divecore/plan.h"
#include "divecore/settings.h"

#ifdef __cplusplus
extern "C" {
#endif

enum { PD_OK = 0, PD_WARN = 1, PD_FAIL = 2 };
#define PREDIVE_MAX 14

typedef struct {
    char label[20];
    char detail[28];
    uint8_t level;
} predive_item_t;

typedef struct {
    predive_item_t item[PREDIVE_MAX];
    int n;
    int worst;          /* PD_* */
    int n_warn, n_fail;
} predive_t;

typedef struct {
    int depth_sensors;      /* how many answered: 0, 1 or 2 */
    uint32_t now_unix;      /* 0 = clock not set */
    bool interrupted_dive;  /* the computer restarted during the last dive: its deco state is unknown */
    bool compass_uncalibrated;
} predive_env_t;

void predive_run(const dive_t *d, const dc_settings_t *s, const dc_gear_t *g, const dc_divplan_t *plan,
                 const predive_env_t *env, predive_t *out);
/* Blob for the phone: n u8 | worst u8 | n x (level u8, label[20], detail[28]) */
int predive_serialize(const predive_t *p, uint8_t *buf, int cap);

#ifdef __cplusplus
}
#endif
#endif
