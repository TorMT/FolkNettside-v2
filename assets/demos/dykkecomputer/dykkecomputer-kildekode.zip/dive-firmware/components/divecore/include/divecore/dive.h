/*
 * dive.h — dive state machine: ties depth, tissues, oxygen, gases, tank and alarms together.
 * Call dive_tick() once a second (or faster) with the current depth.
 */
#ifndef DIVECORE_DIVE_H
#define DIVECORE_DIVE_H

#include <stdbool.h>
#include <stdint.h>

#include "divecore/deco.h"
#include "divecore/depth.h"
#include "divecore/oxygen.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef enum {
    DIVE_SLEEP = 0,
    DIVE_SURFACE,
    DIVE_ACTIVE,
    DIVE_INTERVAL,
    DIVE_CHARGING
} dive_state_t;

enum {
    ALARM_ASCENT_FAST    = 1u << 0,  /* critical */
    ALARM_CEILING        = 1u << 1,  /* critical */
    ALARM_PPO2_HIGH      = 1u << 2,  /* critical */
    ALARM_PPO2_LOW       = 1u << 3,  /* critical */
    ALARM_CNS_100        = 1u << 4,  /* critical */
    ALARM_CNS_80         = 1u << 5,  /* warning */
    ALARM_NDL_LOW        = 1u << 6,  /* warning */
    ALARM_TANK_RESERVE   = 1u << 7,  /* warning */
    ALARM_TANK_LOST      = 1u << 8,  /* warning */
    ALARM_DEPTH_SENSOR   = 1u << 9,  /* warning, set by the caller */
    ALARM_BATTERY_LOW    = 1u << 10, /* warning: dive computer battery below 15 % (dive_set_battery) */
    ALARM_MOD            = 1u << 11, /* warning: deeper than the gas's MOD */
    ALARM_ASCENT_WARN    = 1u << 12, /* warning: ascent above 80 % of the alarm rate */
    ALARM_GAS_TURN       = 1u << 13, /* warning: within the turn margin (20 bar) of the gas needed to surface */
    ALARM_GAS_LOW        = 1u << 14, /* critical: only the gas needed to surface with the reserve is left */
    ALARM_DEPTH_LIMIT    = 1u << 15, /* warning: deeper than the depth alarm set by the diver */
    ALARM_TIME_LIMIT     = 1u << 16, /* warning: dive time past the time alarm set by the diver */
    ALARM_TX_BATTERY     = 1u << 17  /* warning: a transmitter on a gas in use reports a weak battery */
};
#define ALARM_CRITICAL_MASK (ALARM_ASCENT_FAST | ALARM_CEILING | ALARM_PPO2_HIGH | ALARM_PPO2_LOW | ALARM_CNS_100 | ALARM_GAS_LOW)

typedef struct {
    float start_depth_m;     /* 1.2 m */
    float start_hold_s;      /* 20 s */
    float end_depth_m;       /* 1.0 m */
    float end_hold_s;        /* 300 s */
    float ascent_alarm_mpm;  /* 10 m/min */
    float plan_every_s;      /* 2 s */
    float default_sac_l_min; /* used until a SAC has been measured, 20 L/min */
    float min_sac_l_min;     /* never plan with less than this, 15 L/min */
    bool safety_stop;        /* include 3 min at 5 m in the gas needed */
    float depth_alarm_m;     /* 0 = off */
    float time_alarm_min;    /* 0 = off */
    float ndl_warn_min;      /* NDL warning below this, 5 min; 0 = off */
    float turn_margin_bar;   /* "turn soon" margin above the gas needed, 20 bar */
    float sleep_after_s;     /* dry and idle on the surface this long -> DIVE_SLEEP; 0 = never */
} dive_settings_t;

/* One cylinder per gas: tank i holds gas i and has its own transmitter. */
#define DIVE_MAX_TANKS DC_MAX_GASES
typedef struct {
    uint32_t serial;      /* paired transmitter serial, 0 = not paired */
    float cylinder_l;     /* water volume, e.g. 12 L */
    float full_bar;       /* fill pressure, sets the scale of the bar gauge */
    float reserve_bar;    /* e.g. 50 bar */
    float bar;            /* last good reading */
    float age_s;          /* time since the last good packet */
    float rate_bar_min;   /* smoothed pressure drop while this tank is breathed */
    bool present;         /* at least one packet received */
    uint8_t battery;      /* TX_BATT_* from the transmitter's packets */
} dive_tank_t;

typedef struct {
    dc_cfg_t cfg;
    dive_settings_t set;
    dc_gas_t gases[DC_MAX_GASES];
    int gas;

    dc_tissues_t tissues;
    dc_oxygen_t ox;
    dc_plan_t plan;
    float gf_anchor_m;

    dive_state_t state;
    float t_s;
    float depth_m, prev_depth_m, max_depth_m, temp_c;
    float ascent_mpm;
    float dive_time_s, interval_s;
    float below_s, above_s, since_plan_s;
    float avg_depth_sum;
    int dive_count;
    bool had_deco;
    float nofly_min;

    dive_tank_t tanks[DIVE_MAX_TANKS];
    float sac_l_min, gas_time_min;   /* from the tank being breathed */
    float gas_needed_bar;            /* pressure the breathed tank must hold to surface with its reserve */

    bool wet;                        /* wet contacts bridged */
    float idle_s;                    /* on the surface, dry, no button */
    int battery_pct;                 /* dive computer battery, -1 = unknown */
    bool battery_charging;

    uint32_t alarms;
    uint32_t external_alarms;
    ascent_rate_t ar;
} dive_t;

void dive_settings_default(dive_settings_t *s);
void dive_init(dive_t *d);
/* depth_m may be NAN when no sensor answered (keeps the last value). */
void dive_tick(dive_t *d, float dt_s, float depth_m, float temp_c);
/* Tank index for a transmitter serial, or -1. With pairing on, an unknown serial is paired to the
 * lowest enabled gas whose tank has no transmitter yet. */
int dive_tank_for_serial(dive_t *d, uint32_t serial, bool pairing);
void dive_tank_reading(dive_t *d, int tank, float bar);
/* Battery state reported by the tank's transmitter (TX_BATT_*). */
void dive_tank_battery(dive_t *d, int tank, int state);
/* Dive computer battery from the fuel gauge, 0..100 (-1 = unknown). Below 15 % raises ALARM_BATTERY_LOW. */
void dive_set_battery(dive_t *d, int pct);
/* Enough battery to start a dive? False below 30 % so a full dive plus a margin is left. */
bool dive_battery_ok_for_dive(const dive_t *d);
/* The tank of the gas being breathed, or NULL when it has no transmitter data. */
const dive_tank_t *dive_active_tank(const dive_t *d);
/* Refused (false) when the gas is off or its ppO2 at the current depth would exceed the deco limit. */
bool dive_switch_gas(dive_t *d, int idx);
/* MOD of the gas being breathed, using the bottom limit for gas 1 and the deco limit for the others. */
float dive_current_mod(const dive_t *d);
/* Litres of gas each tank needs for the ascent from the current depth (plan stops, ascent,
 * safety stop) at sac_l_min, written to litres_out[DC_MAX_GASES]. */
void dive_ascent_gas(const dive_t *d, float sac_l_min, float litres_out[DC_MAX_GASES]);
void dive_set_charging(dive_t *d, bool on);
/* Wet contacts. Getting wet wakes the computer from sleep at once, so it is awake and sampling
 * fast before the diver is under; the dive itself still starts on depth. */
void dive_set_wet(dive_t *d, bool wet);
/* A button press: wakes from sleep and restarts the idle timer. */
void dive_wake(dive_t *d);
void dive_set_external_alarms(dive_t *d, uint32_t alarms);
float dive_ppo2(const dive_t *d);
static inline bool dive_alarm_critical(uint32_t a) { return (a & ALARM_CRITICAL_MASK) != 0; }

#ifdef __cplusplus
}
#endif
#endif
