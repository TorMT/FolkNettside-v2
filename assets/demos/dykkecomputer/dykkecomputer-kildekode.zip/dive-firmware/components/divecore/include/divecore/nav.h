/* nav.h — tilt-compensated heading and dead-reckoning navigation. */
#ifndef DIVECORE_NAV_H
#define DIVECORE_NAV_H

#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Calibrated sensor axes in the unit's frame: x forward, y right, z down.
 * accel in any unit (only direction matters), mag in uT after hard/soft-iron correction.
 * Returns heading in degrees 0..360 from true north (declination added). */
float compass_heading_deg(float ax, float ay, float az, float mx, float my, float mz, float declination_deg);

/* Hard-iron calibration: turn the computer through a figure 8 while feeding raw readings; the
 * centre of the readings' range on each axis is the offset, and the axes are scaled to the same span. */
typedef struct {
    float min[3], max[3];
    int n;
} magcal_t;
typedef struct {
    float offset[3];
    float scale[3];
} magcal_result_t;
void magcal_begin(magcal_t *c);
void magcal_feed(magcal_t *c, float mx, float my, float mz);
/* False when the readings did not cover enough of each axis (keep the old calibration). */
bool magcal_finish(const magcal_t *c, magcal_result_t *out);
static inline void magcal_apply(const magcal_result_t *r, float *mx, float *my, float *mz)
{
    *mx = (*mx - r->offset[0]) * r->scale[0];
    *my = (*my - r->offset[1]) * r->scale[1];
    *mz = (*mz - r->offset[2]) * r->scale[2];
}

typedef struct {
    double lat0, lon0;    /* entry point (last surface GNSS fix) */
    bool has_origin;
    float x_m, y_m;       /* east, north of the entry point */
    float swum_m;         /* distance swum since the last fix, for the error circle */
    float drift_frac;     /* expected error as a fraction of distance, e.g. 0.15 */
} nav_t;

/* Signed turn from heading to bearing, -180..180 degrees: positive = turn right (clockwise). */
float nav_turn_deg(float heading_deg, float bearing_deg);

void nav_init(nav_t *n, float drift_frac);
void nav_set_origin(nav_t *n, double lat, double lon);
void nav_step(nav_t *n, float heading_deg, float speed_m_per_min, float dt_s);
void nav_home(const nav_t *n, float *bearing_deg, float *dist_m);
float nav_error_radius_m(const nav_t *n);
void nav_position(const nav_t *n, double *lat, double *lon);

#ifdef __cplusplus
}
#endif
#endif
