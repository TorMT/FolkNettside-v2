/*
 * hw.h — hardware behaviour that is worth testing off the board: the buzzer/vibration
 * pattern for alarms and the display backlight level from the ambient light sensor.
 */
#ifndef DIVECORE_HW_H
#define DIVECORE_HW_H

#include <stdbool.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/*
 * Alarm signalling. Call every 50 ms or faster with the current alarm bits.
 *   critical alarm   long pulses (400 ms on, 200 ms off) for as long as it is active
 *   new warning      three short pulses (120 ms on, 120 ms off), repeated once a minute while active
 * Vibration follows the pattern; the buzzer too, when sound is on. A critical alarm always
 * vibrates, even with vibration switched off for warnings.
 */
typedef struct {
    uint32_t prev;            /* alarm bits last time */
    uint32_t warn_start_ms;   /* start of the current warning burst */
    bool warn_burst;
} alarm_notifier_t;

void alarm_notifier_init(alarm_notifier_t *n);
void alarm_notifier_step(alarm_notifier_t *n, uint32_t alarms, uint32_t critical_mask, uint32_t now_ms, bool vibrate_on,
                         bool sound_on, bool *vibrate, bool *buzz);

/*
 * Backlight in percent (5..100).
 *   auto off: level 1..5 -> 20..100 %
 *   auto on:  from ambient light on a log scale (dark water 15 %, daylight at the surface 100 %),
 *             shifted by the level (3 = as is, each step about a quarter brighter or dimmer)
 */
int backlight_pct(int level, float lux, bool auto_on);

#ifdef __cplusplus
}
#endif
#endif
