/*
 * plan.h — a dive plan made on the phone and sent to the dive computer, and how the dive
 * compares with it.
 *
 * The phone (or the computer itself) works the plan out with the same Bühlmann code the
 * computer dives with: descent at 18 m/min, bottom time counted from leaving the surface,
 * then the stops at the settings' gradient factors and gases. It also works out the gas each
 * cylinder needs (SAC x ambient pressure, plus the reserve) and whether it fits the fill.
 *
 * During the dive divplan_alarms() says when the diver is deeper than planned, past the planned
 * bottom time, or has more deco than planned; the computer shows the plan next to the dive.
 *
 * Blob (little-endian, 64 bytes): "DP" ver | depth bottom gfl gfh sac n_stops | 16 x (depth min) |
 *   runtime u16 tts u16 | gas_bar[5] u16 | gas_ok u8 | created u32 | pad | crc32
 */
#ifndef DIVECORE_PLAN_H
#define DIVECORE_PLAN_H

#include <stdbool.h>
#include <stdint.h>

#include "divecore/dive.h"
#include "divecore/settings.h"

#ifdef __cplusplus
extern "C" {
#endif

#define DIVPLAN_STOPS 16
#define DIVPLAN_BLOB 64
#define DIVPLAN_DESCENT_MPM 18.0f

enum {
    ALARM_PLAN_DEEPER = 1u << 18,   /* warning: more than 1 m deeper than the planned depth */
    ALARM_PLAN_TIME = 1u << 19,     /* warning: more than a minute past the planned bottom time and not ascending */
    ALARM_PLAN_DECO = 1u << 20,     /* warning: time to surface more than 3 min above the plan */
};

typedef struct {
    uint8_t valid;
    uint8_t depth_m, bottom_min, gf_low, gf_high, sac_l_min;
    uint8_t n_stops;
    struct { uint8_t depth_m, minutes; } stop[DIVPLAN_STOPS];
    uint16_t runtime_min;           /* whole dive, surface to surface */
    uint16_t tts_min;               /* from the end of the bottom time */
    uint16_t gas_bar[DC_MAX_GASES]; /* pressure each cylinder needs, incl. reserve; 0 = not used */
    uint8_t gas_ok;                 /* bit i: gas i fits its fill pressure */
    uint32_t created_unix;
} dc_divplan_t;

/* Plan from fresh tissues, or from `tissues` (e.g. the computer's now, for a repeat dive) when not NULL. */
bool divplan_compute(dc_divplan_t *p, int depth_m, int bottom_min, int sac_l_min, const dc_settings_t *s,
                     const dc_tissues_t *tissues);
int divplan_serialize(const dc_divplan_t *p, uint8_t *buf, int cap);
bool divplan_deserialize(const uint8_t *buf, int len, dc_divplan_t *p);
/* ALARM_PLAN_* bits for the dive as it is now (0 when no plan or not diving). */
uint32_t divplan_alarms(const dc_divplan_t *p, const dive_t *d);
/* Planned bottom time left in seconds (negative when over). */
float divplan_bottom_left_s(const dc_divplan_t *p, const dive_t *d);

#ifdef __cplusplus
}
#endif
#endif
