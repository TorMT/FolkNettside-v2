/*
 * pelagic.h — decoder for Pelagic MH8A-family tank transmitters (38 kHz),
 * used by Oceanic, Aqualung, Shearwater (Swift is compatible) and others.
 *
 * Packet, as worked out publicly (github.com/rg422/PPS-MH8A-Transmitter and
 * the ScubaBoard "Reading Wireless Air Transmitter using Arduino" thread):
 *   2 lead-in bits, then 12 nibbles, then an 8-bit checksum (58 bits).
 *   nibbles 0-1  header (meaning not yet known)
 *   nibbles 2-7  serial number, one recoded digit per nibble
 *   nibbles 8-10 pressure, 12 bits, 2 psi per count (inferred from one example)
 *   nibble  11   probably battery
 *   checksum     sum of the 12 nibbles, low 8 bits
 * Each bit is a 38 kHz burst followed by a short pause (0) or long pause (1).
 *
 * The pause lengths below are PLACEHOLDERS until you measure real transmitters;
 * the decoder finds its own threshold from the pauses it receives.
 */
#ifndef DIVECORE_PELAGIC_H
#define DIVECORE_PELAGIC_H

#include <stdbool.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define PELAGIC_BITS 58

typedef struct {
    uint8_t header[2];
    uint32_t serial;     /* 6 decimal digits */
    uint16_t psi;
    uint8_t battery;     /* raw nibble */
    uint8_t checksum;
} pelagic_packet_t;

/* Battery nibble: what the values mean has not been confirmed. This treats 0 and 1 as "low";
 * check it against a transmitter with a weak battery before trusting the warning. */
#define PELAGIC_BATT_LOW_MAX 1
enum { TX_BATT_UNKNOWN = 0, TX_BATT_OK = 1, TX_BATT_LOW = 2 };
static inline int pelagic_battery_state(uint8_t nibble) { return nibble <= PELAGIC_BATT_LOW_MAX ? TX_BATT_LOW : TX_BATT_OK; }

typedef enum {
    PELAGIC_OK = 0,
    PELAGIC_BAD_LENGTH,
    PELAGIC_BAD_DIGIT,
    PELAGIC_BAD_CHECKSUM
} pelagic_result_t;

/* Placeholder timing for the simulator's encoder, microseconds. */
#define PELAGIC_SIM_BURST_US 500
#define PELAGIC_SIM_SHORT_US 500
#define PELAGIC_SIM_LONG_US 1500

/* Decode 58 bits (values 0/1). */
pelagic_result_t pelagic_decode_bits(const uint8_t *bits, int n, pelagic_packet_t *out);

/* Turn measured pause lengths (one per bit, microseconds) into bits using a
 * threshold half-way between the short and long clusters. Returns bit count. */
int pelagic_bits_from_pauses(const uint16_t *pause_us, int n, uint8_t *bits_out);

/* Build the 58 bits for a packet (used by the simulator and tests). Checksum is computed. */
bool pelagic_encode_bits(uint32_t serial, uint16_t psi, uint8_t battery, const uint8_t header[2], uint8_t bits_out[PELAGIC_BITS]);

/* Digit <-> nibble recoding. -1 for nibbles that are not a digit. */
int pelagic_nibble_to_digit(uint8_t nib);
uint8_t pelagic_digit_to_nibble(int digit);

static inline float pelagic_psi_to_bar(uint16_t psi) { return psi * 0.0689476f; }

#ifdef __cplusplus
}
#endif
#endif
