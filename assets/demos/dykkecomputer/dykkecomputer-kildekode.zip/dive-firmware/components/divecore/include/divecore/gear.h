/*
 * gear.h — the diver's gear list, edited on the phone and synced to the dive computer before
 * a dive.
 *
 * Each item has a type and a name. Cylinders also have a size, a working pressure and the
 * serial of the transmitter screwed onto them. Items marked "on this dive" form the
 * checklist shown on the surface menu and are written into the dive log (and into the UDDF
 * export as equipment).
 *
 * gas_cyl[] says which cylinder carries which gas: assigning a cylinder sets that gas's
 * cylinder size and transmitter in the settings (gear_apply).
 *
 * Blob (little-endian): "DG" ver u8 | n u8 | synced_unix u32 | gas_cyl[5] | n x 26-byte item | crc32
 *   item: type u8 | flags u8 | size_x10 u16 | work_bar u16 | tx_serial u32 | name[16] (zero-padded)
 */
#ifndef DIVECORE_GEAR_H
#define DIVECORE_GEAR_H

#include <stdbool.h>
#include <stdint.h>

#include "divecore/settings.h"

#ifdef __cplusplus
extern "C" {
#endif

#define GEAR_MAX 12
#define GEAR_NAME 16
#define GEAR_VERSION 1
#define GEAR_ITEM_BYTES 26
#define GEAR_BLOB_MAX (13 + GEAR_MAX * GEAR_ITEM_BYTES + 4)

typedef enum {
    GEAR_CYLINDER = 1,
    GEAR_REGULATOR,
    GEAR_BCD,
    GEAR_SUIT,
    GEAR_WEIGHTS,
    GEAR_LIGHT,
    GEAR_CAMERA,
    GEAR_OTHER,
    GEAR_TYPE_MAX = GEAR_OTHER
} gear_type_t;

#define GEAR_ON_DIVE 0x01

typedef struct {
    uint8_t type;            /* gear_type_t */
    uint8_t flags;           /* GEAR_ON_DIVE */
    uint16_t size_x10;       /* cylinder: litres x10; weights: kg x10; suit: mm x10 */
    uint16_t work_bar;       /* cylinder working pressure */
    uint32_t tx_serial;      /* cylinder transmitter, 0 = none */
    char name[GEAR_NAME + 1];
} gear_item_t;

typedef struct {
    gear_item_t item[GEAR_MAX];
    uint8_t n;
    uint8_t gas_cyl[DC_MAX_GASES]; /* item index + 1 of the cylinder carrying each gas, 0 = none */
    uint32_t synced_unix;          /* when the phone last sent the list */
} dc_gear_t;

void gear_init(dc_gear_t *g);
const char *gear_type_name(int type);
/* Drops invalid items and references; names are made printable ASCII. */
void gear_validate(dc_gear_t *g);
int gear_serialize(const dc_gear_t *g, uint8_t *buf, int cap);
bool gear_deserialize(const uint8_t *buf, int len, dc_gear_t *out);
/* Copy cylinder sizes and transmitter serials of assigned cylinders into the settings and turn
 * those gases on. Returns true when the settings changed. */
bool gear_apply(const dc_gear_t *g, dc_settings_t *s);
/* Transmitters paired on the dive computer are copied onto the assigned cylinders. */
bool gear_take_serials(dc_gear_t *g, const dc_settings_t *s);
/* Items on this dive, total lead in kg x10. */
int gear_on_dive(const dc_gear_t *g);
int gear_lead_x10(const dc_gear_t *g);

#ifdef __cplusplus
}
#endif
#endif
