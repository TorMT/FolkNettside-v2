/*
 * proto.h — the phone protocol, independent of the transport.
 *
 * Over Bluetooth LE the phone writes a request to the RX characteristic and the dive computer
 * answers with notifications on the TX characteristic, split into MTU-sized pieces; the phone
 * joins them using the length field. The simulator calls proto_handle() directly.
 *
 *   request:  cmd u8 | seq u8 | len u16 | payload[len]
 *   response: cmd|0x80 u8 | seq u8 | status u8 | len u16 | payload[len]
 *
 * All integers little-endian.
 */
#ifndef DIVECORE_PROTO_H
#define DIVECORE_PROTO_H

#include <stdbool.h>
#include <stdint.h>

#include "divecore/dive.h"
#include "divecore/gear.h"
#include "divecore/plan.h"
#include "divecore/predive.h"
#include "divecore/settings.h"

#ifdef __cplusplus
extern "C" {
#endif

#define PROTO_VERSION 2
#define PROTO_MAX_CHUNK 512

enum {
    CMD_INFO = 0x01,          /* -> proto u8, state u8, battery u8 (%, 255 unknown), n_logs u16, fw version string */
    CMD_GET_SETTINGS = 0x02,  /* -> settings blob (72 bytes) */
    CMD_SET_SETTINGS = 0x03,  /* blob -> status; refused during a dive */
    CMD_LIST_LOGS = 0x04,     /* -> n x 16 bytes: idx u16, dive_no u16, start u32, duration u32 (s), max_depth u16 (cm), had_deco u8, pad u8 */
    CMD_READ_LOG = 0x05,      /* idx u16, offset u32, len u16 -> bytes (len <= 512); a short read means the end */
    CMD_LOG_SIZE = 0x06,      /* idx u16 -> size u32 */
    CMD_LIVE = 0x07,          /* -> state u8, depth_cm u16, ndl u8, tts u16, gas u8, tank_dbar u16, cns u8, alarms u16, deco u8, alarms_hi u8 */
    CMD_GET_GEAR = 0x08,      /* -> gear blob (gear.h) */
    CMD_SET_GEAR = 0x09,      /* gear blob -> status; refused during a dive. Assigned cylinders update the gas settings. */
    CMD_TANKS = 0x0A,         /* -> 5 x 12 bytes: present u8, battery u8 (TX_BATT_*), serial u32, dbar u16 (0xFFFF none), age_s u16, gas_on u8, pad u8 */
    CMD_PREDIVE = 0x0B,       /* -> pre-dive check (predive_serialize) */
    CMD_SET_PLAN = 0x0C,      /* plan blob (plan.h) -> status; empty payload clears the plan; refused during a dive */
    CMD_GET_PLAN = 0x0D,      /* -> plan blob, or empty when there is none */
    CMD_SET_TIME = 0x0E,      /* unix seconds u32 (UTC) -> status; the phone sends it on every connect */
    CMD_OTA_BEGIN = 0x10,     /* size u32 -> status */
    CMD_OTA_DATA = 0x11,      /* offset u32, bytes -> status */
    CMD_OTA_END = 0x12,       /* crc32 u32 -> status; the device reboots into the new image after this */
};

enum {
    ST_OK = 0,
    ST_BAD_REQUEST = 1,
    ST_BUSY_DIVING = 2,
    ST_NOT_FOUND = 3,
    ST_CRC = 4,
    ST_FAILED = 5,
};

enum { OTA_BEGIN = 0, OTA_DATA = 1, OTA_END = 2 };

typedef struct {
    /* Log storage, provided by the platform (SD card files on the ESP32, memory in the simulator). */
    int (*log_count)(void *ctx);
    int (*log_size)(void *ctx, int idx);
    int (*log_read)(void *ctx, int idx, uint32_t off, uint8_t *buf, int len);
    /* Persist settings (NVS on the ESP32) and apply them. Return false on failure. */
    bool (*settings_store)(void *ctx, const dc_settings_t *s);
    /* Firmware update steps; return an ST_* code. */
    int (*ota)(void *ctx, int step, uint32_t value, const uint8_t *data, int len);
    /* Persist the gear list (NVS on the ESP32). Return false on failure. */
    bool (*gear_store)(void *ctx, const dc_gear_t *g);
    void *ctx;

    dc_settings_t *settings;
    dc_gear_t *gear;
    dc_divplan_t *plan;             /* optional */
    bool (*plan_store)(void *ctx, const dc_divplan_t *p);
    void (*set_time)(void *ctx, uint32_t unix_s);    /* set the wall clock (and the RTC) */
    int depth_sensors;              /* for the pre-dive check: 0..2 answering */
    uint32_t now_unix;              /* wall clock, 0 = not set */
    const dive_t *dive;
    const char *fw_version;
    uint8_t battery_pct;
} proto_dev_t;

/* Handle one complete request. Returns the response length, or 0 if the request is too short. */
int proto_handle(proto_dev_t *dev, const uint8_t *req, int req_len, uint8_t *resp, int cap);

#ifdef __cplusplus
}
#endif
#endif
