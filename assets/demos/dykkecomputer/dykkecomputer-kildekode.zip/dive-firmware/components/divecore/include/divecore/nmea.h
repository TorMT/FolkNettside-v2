/*
 * nmea.h — just enough NMEA 0183 for the GNSS module: position from GGA, date and time from RMC.
 * Feed it the UART bytes one at a time. Sentences with a bad checksum are ignored.
 */
#ifndef DIVECORE_NMEA_H
#define DIVECORE_NMEA_H

#include <stdbool.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    bool has_fix;          /* GGA quality > 0 */
    double lat, lon;       /* degrees, north and east positive */
    int sats;
    float hdop;
    uint32_t unix_time;    /* UTC from the last valid RMC, 0 when none yet */
} nmea_fix_t;

typedef struct {
    char line[100];
    int n;
} nmea_parser_t;

void nmea_init(nmea_parser_t *p, nmea_fix_t *fix);
/* True when this byte completed a sentence that changed *fix. */
bool nmea_feed(nmea_parser_t *p, char c, nmea_fix_t *fix);

#ifdef __cplusplus
}
#endif
#endif
