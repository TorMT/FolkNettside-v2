/*
 * persist.h — what must survive a power loss or a restart between dives: tissue loading,
 * oxygen exposure, no-fly time, the surface interval and the dive counter.
 *
 * Without it a restart between two dives would give the second dive the no-deco limits of a
 * fresh diver. The computer saves the blob when a dive ends and every few minutes on the
 * surface, and saves during the dive too (FRAM on the final board; NVS on the breadboard, where
 * the minute-scale wear is acceptable for a prototype).
 *
 * On restore the tissues are brought forward to now: off-gassing on air at surface pressure
 * for the time the computer was off (the saved wall-clock time against the clock now). If the
 * clock is not set or went backwards, no time is credited: the tissues stay as saved, which is
 * the cautious side. A blob saved during a dive is restored as "surfaced now": the dive is
 * over, deco state unknown, so the caller must show a warning.
 *
 * Blob (little-endian, 168 bytes): "DT" ver | flags | saved_unix u32 | n2[16] f32 | he[16] f32 |
 *   cns f32 otu f32 nofly_min f32 interval_s f32 | dive_count u16 | pad | crc32
 */
#ifndef DIVECORE_PERSIST_H
#define DIVECORE_PERSIST_H

#include <stdbool.h>
#include <stdint.h>

#include "divecore/dive.h"

#ifdef __cplusplus
extern "C" {
#endif

#define PERSIST_BLOB 168
#define PERSIST_IN_DIVE 0x01      /* saved while diving */
#define PERSIST_HAD_DECO 0x02

typedef enum {
    PERSIST_NONE = 0,         /* nothing valid stored: fresh tissues */
    PERSIST_RESTORED,         /* restored and brought forward to now */
    PERSIST_RESTORED_NO_CLOCK,/* restored, but no time credited (clock unknown) */
    PERSIST_INTERRUPTED_DIVE, /* the computer restarted during a dive: treat the next dive with great caution */
} persist_result_t;

int persist_save(const dive_t *d, uint32_t now_unix, uint8_t *buf, int cap);
persist_result_t persist_restore(dive_t *d, const uint8_t *buf, int len, uint32_t now_unix);

#ifdef __cplusplus
}
#endif
#endif
