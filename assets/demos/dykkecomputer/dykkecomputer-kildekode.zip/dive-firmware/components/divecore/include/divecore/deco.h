/*
 * deco.h — Bühlmann ZHL-16C with gradient factors, plus gas helpers.
 *
 * Portable C99: no ESP-IDF calls, no heap. Runs on the ESP32-S3, on a laptop
 * for unit tests, and in the browser simulator (compiled to WebAssembly).
 *
 * Units: pressure in bar (absolute), depth in metres, time in seconds unless
 * a name says _min. Gas fractions 0..1.
 *
 * NOT VALIDATED FOR DIVING. Use only as a backup to a commercial computer until
 * the comparison tests in test/ pass against an independent planner.
 */
#ifndef DIVECORE_DECO_H
#define DIVECORE_DECO_H

#include <stdbool.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define DC_NUM_TISSUES 16
#define DC_MAX_GASES 5
#define DC_MAX_STOPS 24
#define DC_WATER_VAPOUR_BAR 0.0627f

typedef struct {
    float o2;      /* fraction O2 */
    float he;      /* fraction He */
    bool enabled;
} dc_gas_t;

typedef struct {
    float n2[DC_NUM_TISSUES]; /* inert gas partial pressure in each compartment, bar */
    float he[DC_NUM_TISSUES];
} dc_tissues_t;

typedef struct {
    float gf_low;           /* 0..1, e.g. 0.50 */
    float gf_high;          /* 0..1, e.g. 0.80 */
    float surface_bar;      /* measured before the dive, e.g. 1.013 */
    float bar_per_m;        /* 0.10052 salt (1025 kg/m3), 0.09807 fresh, 0.1000 EN13319 */
    float ascent_rate_mpm;  /* planned ascent speed, 9 m/min */
    float stop_step_m;      /* 3 m */
    float last_stop_m;      /* 3 or 6 m */
    float deco_ppo2_max;    /* deco gas switch limit, 1.6 bar */
    float bottom_ppo2_max;  /* bottom gas limit, 1.4 bar */
    float gas_switch_min;   /* time spent at a gas switch, 1 min */
} dc_cfg_t;

typedef struct {
    float depth_m;
    uint16_t minutes;
    uint8_t gas;
} dc_stop_t;

typedef struct {
    int ndl_min;                 /* no-deco limit; 0 when in deco; capped at 99 */
    bool in_deco;
    float ceiling_m;             /* ceiling at the current gradient factor */
    float first_stop_m;          /* 0 when no stop is required */
    float gf_anchor_m;           /* depth where GF low applies (first stop); keep it for the rest of the dive */
    int n_stops;
    dc_stop_t stops[DC_MAX_STOPS];
    int tts_min;                 /* time to surface incl. ascent and stops */
    float gf_now;                /* gradient of the leading tissue at current depth, 0..1+ */
    float gf_surface;            /* gradient the leading tissue would have at the surface */
    int leading_tissue;          /* 0..15 */
} dc_plan_t;

/* Fill a config with sensible defaults (GF 50/80, salt water, 9 m/min). */
void dc_cfg_default(dc_cfg_t *cfg);

/* Tissues saturated with air at the given surface pressure. */
void dc_tissues_init(dc_tissues_t *t, float surface_bar);

/* Advance tissues over `seconds` while ambient pressure moves linearly
 * from p_start_bar to p_end_bar breathing `gas` (Schreiner equation). */
void dc_tissues_update(dc_tissues_t *t, float p_start_bar, float p_end_bar,
                       float seconds, const dc_gas_t *gas);

/* Tolerated ambient pressure (bar) of the leading compartment at gradient factor gf. */
float dc_ceiling_bar(const dc_tissues_t *t, float gf, int *leading);

/* Ceiling as a depth below the surface, never negative. */
float dc_ceiling_m(const dc_tissues_t *t, float gf, const dc_cfg_t *cfg);

/* Gradient factor at depth d when the first stop (GF low anchor) is at anchor_m. */
float dc_gf_at(float depth_m, float anchor_m, const dc_cfg_t *cfg);

/* Full plan from the current state: NDL or stops, ceiling and TTS.
 * gas_idx = gas being breathed now; deco gases are switched to at their MOD. */
void dc_plan(const dc_tissues_t *t, float depth_m, int gas_idx,
             const dc_gas_t gases[DC_MAX_GASES], const dc_cfg_t *cfg,
             float gf_anchor_m, dc_plan_t *out);

/* Percentage of the surface M-value (at gf_high) each compartment has reached,
 * 0..100+, for the tissue bar graph. */
void dc_tissue_load_pct(const dc_tissues_t *t, const dc_cfg_t *cfg, float out_pct[DC_NUM_TISSUES]);

/* --- gas helpers --- */
float dc_ambient_bar(float depth_m, const dc_cfg_t *cfg);
float dc_depth_m(float ambient_bar, const dc_cfg_t *cfg);
float dc_ppo2(const dc_gas_t *gas, float depth_m, const dc_cfg_t *cfg);
float dc_mod_m(const dc_gas_t *gas, float ppo2_max, const dc_cfg_t *cfg);
/* Richest enabled gas allowed at depth_m (ppO2 <= deco_ppo2_max); -1 if none. */
int dc_best_gas(const dc_gas_t gases[DC_MAX_GASES], float depth_m, const dc_cfg_t *cfg);

#ifdef __cplusplus
}
#endif
#endif
