/* oxygen.h — CNS % (NOAA limits) and OTU tracking. */
#ifndef DIVECORE_OXYGEN_H
#define DIVECORE_OXYGEN_H

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    float cns_pct;  /* central nervous system toxicity, % of the NOAA limit */
    float otu;      /* oxygen tolerance units, whole-body */
} dc_oxygen_t;

void dc_oxygen_reset(dc_oxygen_t *o);
/* Add exposure at ppo2 (bar) for `seconds`. Below 0.5 bar CNS decays with a 90 min half-time. */
void dc_oxygen_update(dc_oxygen_t *o, float ppo2, float seconds);
/* NOAA single-exposure limit in minutes for ppo2 (0 = no limit below 0.5 bar, 1 min above 1.65). */
float dc_cns_limit_min(float ppo2);

#ifdef __cplusplus
}
#endif
#endif
