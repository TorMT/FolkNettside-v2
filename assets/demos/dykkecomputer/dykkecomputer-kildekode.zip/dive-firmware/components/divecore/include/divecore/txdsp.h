/*
 * txdsp.h — turns raw ADC samples from the transmitter coil into Pelagic packets.
 *
 * Chain: mix with the carrier (I/Q) -> low-pass -> envelope -> adaptive hysteresis
 * comparator -> pause length between bursts -> bits -> pelagic_decode_bits().
 * A packet ends when the coil is quiet for `idle_us`.
 *
 * Framing assumption until real captures confirm it: one pause per bit, i.e. 58 pauses
 * between 59 bursts.
 */
#ifndef DIVECORE_TXDSP_H
#define DIVECORE_TXDSP_H

#include <stdbool.h>
#include <stdint.h>

#include "divecore/pelagic.h"

#ifdef __cplusplus
extern "C" {
#endif

#define TXDSP_MAX_PAUSES 96

typedef struct {
    float fs, fc;
    float cos_d, sin_d, c, s;      /* NCO rotation */
    float i_lp, q_lp, alpha;
    float peak, peak_decay, min_level;
    bool on;
    uint32_t n, edge_n;            /* sample counters */
    uint32_t idle_samples;
    uint16_t pauses[TXDSP_MAX_PAUSES];
    int n_pauses;
    int bursts;
    uint32_t packets_ok, packets_bad;
} txdsp_t;

/* fs = sample rate (96000), fc = carrier (38000), min_level = smallest envelope treated as signal. */
void txdsp_init(txdsp_t *d, float fs, float fc, float min_level, uint32_t idle_us);

/* Feed n samples. Returns true and fills *out when a packet with a good checksum completes.
 * At most one packet is returned per call; feed small blocks (e.g. 256 samples). */
bool txdsp_feed(txdsp_t *d, const float *x, int n, pelagic_packet_t *out);

/* Simulator/test helper: synthesise the coil signal for one packet (59 bursts at the placeholder
 * timing), plus white noise of the given amplitude. seed is updated. Returns samples written. */
int txdsp_synthesize(uint32_t serial, uint16_t psi, uint8_t battery, float fs, float fc, float amplitude,
                     float noise, uint32_t *seed, float *out, int max_samples);

#ifdef __cplusplus
}
#endif
#endif
