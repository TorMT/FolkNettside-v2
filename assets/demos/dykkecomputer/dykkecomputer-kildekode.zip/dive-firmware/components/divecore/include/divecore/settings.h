/*
 * settings.h — user settings: defaults, validation, a fixed binary format with CRC-32
 * (stored in NVS on the ESP32, sent over Bluetooth, kept in browser storage by the simulator),
 * and applying them to the dive state.
 */
#ifndef DIVECORE_SETTINGS_H
#define DIVECORE_SETTINGS_H

#include <stdbool.h>
#include <stdint.h>

#include "divecore/dive.h"

#ifdef __cplusplus
extern "C" {
#endif

#define DC_SETTINGS_VERSION 2
#define DC_SETTINGS_BLOB_SIZE 96      /* version 2; version 1 blobs (72 bytes) are still read */
#define DC_SETTINGS_BLOB_V1 72

enum { WATER_SALT = 0, WATER_FRESH = 1, WATER_EN13319 = 2 };

typedef struct {
    uint8_t o2_pct;
    uint8_t he_pct;
    uint8_t enabled;
    uint8_t cylinder_l;
    uint16_t fill_bar;
    uint32_t tx_serial;   /* paired transmitter, 0 = none */
} dc_gas_setting_t;

typedef struct {
    dc_gas_setting_t gas[DC_MAX_GASES];
    uint8_t gf_low, gf_high;     /* % */
    uint8_t water;               /* WATER_* */
    uint8_t last_stop_m;         /* 3 or 6 */
    uint8_t ppo2_bottom_x100;    /* 100..160 */
    uint8_t ppo2_deco_x100;      /* 120..160 */
    uint8_t reserve_bar;         /* 20..100, every tank */
    uint8_t ascent_alarm_mpm;    /* 6..18 */
    uint8_t brightness;          /* 1..5 */
    uint8_t pairing;             /* 1 = pair unknown transmitters to free gases */
    int8_t declination_deg;      /* -30..30 */
    uint8_t safety_stop;         /* 1 = remind 3 min at 5 m */
    /* version 2 */
    uint8_t bluetooth;           /* 1 = phone can connect while on the surface (never during a dive) */
    uint8_t depth_alarm_m;       /* 0 = off, 10..150 */
    uint16_t time_alarm_min;     /* 0 = off, 10..300 */
    uint8_t ndl_warn_min;        /* 0 = off, 1..10 */
    uint8_t turn_margin_bar;     /* "turn soon" this far above the gas needed to surface, 10..50 */
    uint8_t flip;                /* 1 = screen turned 180 deg (worn on the other arm) */
    uint8_t log_interval_s;      /* 1..10 */
    uint8_t vibrate;             /* 1 = vibrate on warnings (critical alarms always vibrate) */
    uint8_t sound;               /* 1 = buzzer on alarms */
    uint8_t auto_bright;         /* 1 = backlight follows the light sensor, brightness shifts it */
    uint8_t sleep_min;           /* dry and idle on the surface this long -> sleep; 0 = never, 2..60 */
} dc_settings_t;

void settings_default(dc_settings_t *s);
/* Clamp every field into range; gas 1 always on; O2 + He <= 100; GF low <= GF high. */
void settings_validate(dc_settings_t *s);
/* Fixed little-endian layout + CRC-32. Returns bytes written (DC_SETTINGS_BLOB_SIZE) or 0. */
int settings_serialize(const dc_settings_t *s, uint8_t *buf, int cap);
/* False when magic, version or CRC do not match. The result is validated. */
bool settings_deserialize(const uint8_t *buf, int len, dc_settings_t *out);
/* Push settings into the dive state: GF, water, limits, gases, tanks, paired serials. */
void settings_apply(const dc_settings_t *s, dive_t *d);
/* Copy serials the dive paired during the dive back into the settings. True when changed. */
bool settings_take_serials(dc_settings_t *s, const dive_t *d);

uint32_t dc_crc32(const uint8_t *p, int n);

#ifdef __cplusplus
}
#endif
#endif
