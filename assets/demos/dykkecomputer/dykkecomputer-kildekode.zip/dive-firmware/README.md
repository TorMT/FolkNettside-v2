# Dive computer firmware

ESP32-S3 firmware for the student dive computer, the phone app, host tests, and a browser simulator that runs the same C code as the computer.

> **Not validated for diving.** Dive it only as a backup next to a commercial computer, after the housing has been pressure-tested and the checks below pass on your own profiles. See `docs/DEMO_BUILD.md` for the list of what must be true before it goes in the water.

## Status

| Part | State |
| --- | --- |
| `components/divecore/` (all the logic) | Done and tested: 191 unit checks, the same under AddressSanitizer/UBSan, 400 000 random protocol requests, deco planner within 1 min of decotengu on 54 dives |
| Simulator and phone app | Done and tested headless (4 suites in `sim/tests/`) |
| `main/` (ESP-IDF application) | Written and type-checked against stub headers (`tools/check_main.sh`). **Never built with `idf.py` or run on hardware.** Expect small fixes on the first build |
| Display screens (LVGL) | Not written. The firmware prints the dive screen to the serial console; the simulator shows what the screens should look like |
| Safety MCU (CH32V003) firmware | Not written. The ESP32 sends the heartbeat frame it will listen to |
| Suunto / Scubapro / Mares transmitters, FRAM and RTC drivers, Bluetooth passkey bonding | Not written |

One command runs everything that can be checked without hardware: `tools/ci.sh`.

## Layout

| Path | What it is |
| --- | --- |
| `components/divecore/` | Portable C99 core: no ESP-IDF calls, no heap. Used by the firmware, the tests and the simulator |
| `src/deco.c`, `oxygen.c` | Bühlmann ZHL-16C with gradient factors (tissues, ceiling, NDL, stops, gas switches, TTS); CNS % and OTU |
| `src/depth.c` | MS5837-30BA compensation and PROM CRC, two-sensor cross-check, ascent rate |
| `src/dive.c` | Dive state machine, alarms, tanks, SAC, gas needed to surface with the reserve, battery, sleep and wake |
| `src/plan.c`, `predive.c` | Dive plan (stops and gas per cylinder) and plan-versus-dive warnings; the "ready to dive?" check |
| `src/pelagic.c`, `txdsp.c` | Pelagic MH8A tank-transmitter packets and the 38 kHz receiver DSP |
| `src/nav.c`, `nmea.c` | Tilt-compensated compass, figure-8 calibration, dead reckoning; GNSS sentence parser |
| `src/settings.c`, `gear.c`, `persist.c` | Settings, the gear list from the phone, and tissue state that survives a restart, each a CRC-protected blob |
| `src/menu.c` | Three-button menus: full menu on the surface, short dive menu underwater |
| `src/divelog.c` | Dive log writer/parser and UDDF 3.2 export for Subsurface |
| `src/proto.c` | Bluetooth protocol (DCP): info, settings, gear, plan, pre-dive check, logs, live data, clock, firmware update |
| `src/hw.c` | Alarm buzz/vibration patterns and automatic backlight level |
| `main/` | ESP-IDF application: pin map (`board.h`), sensor drivers, tasks, NVS/SD storage, NimBLE, OTA |
| `test/` | Unit tests, the `divecli` planner for cross-checks, the protocol fuzzer |
| `tools/` | `ci.sh`, `check_main.sh`, `crosscheck.py` (decotengu), `log2uddf.c` |
| `sim/` | WebAssembly build of the core, the simulator page, the phone app (`phone.js`), headless tests |
| `docs/DEMO_BUILD.md` | Building the breadboard demo stage by stage, and the list before diving |

## Checks without hardware

```
pip install ziglang decotengu
tools/ci.sh
```

It runs the unit tests (plain and with sanitizers), compares the deco planner with the independent decotengu planner, type-checks `main/`, builds the simulator and runs the simulator and phone-app tests. `test/fuzz.c` (random requests into the protocol and the blob parsers under sanitizers, about 10 minutes) is run by hand; the command is at the top of that file.

The decotengu cross-check plans 54 dives (18–60 m, air, EAN32, EAN50 deco, GF 30/70, 50/80, 100/100). Total stop time differs by at most 1 min. `divecli_1a` is built with ZHL-16C compartment 1a because decotengu uses it; the firmware uses 1b, as most dive computers do.

## Firmware (ESP32-S3)

Needs ESP-IDF 5.3 or newer and an ESP32-S3 with 16 MB flash and octal PSRAM (DevKitC-1 N16R8).

```
idf.py set-target esp32s3
idf.py build flash monitor
```

`sdkconfig.defaults` sets the custom partition table (two 3 MB application slots for updates with rollback), NimBLE, the task watchdog and brown-out reset. Follow `docs/DEMO_BUILD.md` for wiring and the order to bring things up.

## Simulator

```
./sim/build.sh               # core -> sim/build/divecore.wasm
python3 sim/make_page.py     # -> sim/build/simulator.html and sim/build/app.html
```

The page dives five presets on autopilot or under manual control and shows the computer's screens, the dive profile with ceiling, and alarms. Tank packets go through the real 38 kHz receiver with adjustable noise. Battery, weak transmitter batteries, light level and the charger are on the bench controls. The phone panel talks to the simulated computer over the same protocol the firmware uses.

## What the computer does

- **Surface screen:** interval, no-fly time, battery, and the result of the pre-dive check ("Ready", "Check n items" or "Do not dive").
- **Pre-dive check:** battery, both depth sensors, every gas in use (transmitter paired, heard in the last minute, cylinder full enough, transmitter battery), gases against the cylinders synced from the phone, time since the last sync, whether the plan's gas fits, compass calibration, and a restart during the last dive.
- **Dive screens:** main, tanks (bars with reserve and gas-needed markers), deco plan, compass with turn-to-bearing, map, tissues, gases.
- **Alarms:** ascent too fast and slow-down, ceiling, ppO2, CNS, too deep for the gas, NDL, tank reserve, turn soon and low gas (gas needed to surface with the reserve), depth and time limits, weak batteries, lost transmitter, and deeper / longer / more deco than the plan. Critical alarms pulse the buzzer and vibration continuously; a new warning gives three short pulses.
- **Menus** (hold SELECT 1 s). On the surface: pre-dive check, dive plan, gases, gear check, NDL planner, logbook, deco, alarms, transmitters, compass, display, Bluetooth, system. During a dive: switch gas (gases too rich for the depth are refused), lock or unlock the bearing, brightness. Nothing that changes the deco model can be changed underwater.
- **Sleep and wake:** sleeps after 10 dry, idle minutes on the surface (not during a surface interval); wakes on a button, the wet contacts or depth. A dive starts on depth alone, whatever the state.
- **Restart safety:** tissue loading, CNS, no-fly time and the dive counter are saved when a dive ends, every minute during a dive and every 10 minutes while loaded. After a restart they are restored and brought forward to now; if the clock is unknown, no off-gassing is credited.
- **Bluetooth** only on the surface and only when switched on. The phone is dropped when a dive starts; settings, gear, plan and updates are refused during a dive.

## Phone app

`sim/build/app.html` is the Web Bluetooth app. It needs Chrome (Android, Windows, macOS, Linux) and must be served over https or from `localhost`, e.g. `python3 -m http.server -d sim/build`. iPhone Safari has no Web Bluetooth, so iOS needs a native app speaking the same protocol (`proto.h`).

- **Ready to dive?** the computer's pre-dive check, line by line.
- **Gear:** add your gear once, tick what you bring, choose the cylinder for each gas, sync. Cylinder size and transmitter go into that gas's settings; the list is stored with each dive log.
- **Dive plan:** depth, bottom time and SAC give the stops, run time and the pressure each cylinder needs, computed by the same code as the computer. Send it to the computer to see the plan next to the dive.
- **Settings, live values, transmitters** (pressure, battery, last heard).
- **Dive logs:** download, export UDDF for Subsurface, and **Share**: a 4:5 picture with the numbers, the profile, the gases and a map of the swum track from the entry point.
- **Statistics and dive sites:** totals, dives per month, records, and a map of the sites. The phone stores its position at sync and after a dive when the computer has no GNSS fix. Map tiles are OpenStreetMap when the page can load them; otherwise a plain chart.
- **Firmware update** with rollback if the new image does not start.
- The phone sets the computer's clock on every connect.

## Things to measure on real hardware

- **Pelagic pause lengths.** They are placeholders in `pelagic.h`. The receiver finds its own threshold, but check the framing of 58 pauses between 59 bursts against your own captures.
- **The Pelagic header nibbles, battery nibble (what counts as weak) and 2 psi per count.** These come from one published example.
- **Battery life:** the current draw while diving, to replace the 20 h assumption behind "about N h of diving".
- **Swim speed for dead reckoning** (`NAV_SWIM_SPEED_MPM`, 15 m/min): time a known distance per diver.
- **Sensor axes** (`ACCEL_TO_BODY`, `MAG_TO_BODY` in `board.h`): check that north is north and that tilting does not move the heading.
- **Wet-contact threshold:** the dry baseline is taken at power-on; measure wet and dry readings on the real case.
- **Suunto Tank POD (123 kHz), Scubapro and Mares:** not decoded yet; see the firmware plan.
