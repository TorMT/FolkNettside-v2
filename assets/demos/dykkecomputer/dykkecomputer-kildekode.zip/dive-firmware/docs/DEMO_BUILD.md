# Building the breadboard demo

Parts, prices and wiring are in the **Dive Computer BOM** sheet: the *Breadboard prototype* tab lists every part with its build stage, and *Breadboard wiring* lists every wire. The pins there are the pins in `main/board.h`.

Build one stage at a time. Each stage has a test you can do on the desk; do not go on until it passes.

## Before you start

1. Install ESP-IDF 5.3 or newer (`idf.py --version`).
2. Run `tools/ci.sh` on your laptop. Everything should pass before you touch hardware; then a later failure is in the wiring or the drivers, not in the logic.
3. `idf.py set-target esp32s3 && idf.py build`. This is the **first real build** of `main/`: it has only been type-checked against stub headers. Fix what the compiler reports (missing includes and component names in `main/CMakeLists.txt` are the likely ones) before wiring anything.

## Stage 1 — core: depth, alarms, buttons

Wire: ESP32-S3 DevKit, TCA9548A, both MS5837 breakouts, three push buttons, buzzer, vibration motor module, wet-contact pins. The display can wait: the firmware prints the dive screen to the serial monitor once a second.

| Test | Expected |
| --- | --- |
| `idf.py flash monitor` | `depth sensor A ok, B ok` and a plausible `surface pressure` (about 1000 mbar) |
| Unplug one depth sensor | The depth-sensor alarm bit appears; the pre-dive check says "only one answers" |
| Press the sensor tip gently, or put it in a syringe and push | Depth rises; above 1.2 m for 20 s the state changes to `DIVE` |
| Let it go back to 0 m | After 5 minutes above 1 m the dive ends; a log file appears on the SD card once stage 4 is wired |
| Raise the depth quickly, then drop it fast | Ascent alarm: buzzer and vibration pulse continuously |
| Dip the wet contacts in a glass of water after 10 idle minutes | The computer wakes from sleep |
| Hold SELECT 1 s | The menu opens (seen on the monitor until the display works) |

A pressure pot or a 10 m length of water-filled hose is the proper depth test. Only the gel-filled sensor tip may get wet: seal the breakout's solder joints first.

## Stage 2 — tank pressure

Wire: PCM1808 module, op-amp preamp, ferrite rod coil.

| Test | Expected |
| --- | --- |
| Pressurised transmitter within 0.5 m of the coil | `tank 1 (serial): … psi (… bar)` every 5 s or so |
| Nothing received | Look at the preamp output on a scope or the logic analyser: 38 kHz bursts should be visible. Then check the burst and pause lengths against `pelagic.h`: **those timings are placeholders** and probably need changing to what you measure |
| Second transmitter | It pairs to the next gas that is switched on |

Record a few seconds of the raw I2S samples from a real transmitter early. `txdsp.c` and `pelagic.c` run on a laptop, so you can tune them against the recording without the hardware.

## Stage 3 — compass, GPS, light sensor

Wire: QMI8658, MMC5603, VEML7700, ATGM336H.

| Test | Expected |
| --- | --- |
| Boot | No "no accelerometer or magnetometer" warning |
| Menu → Compass → Calibrate, turn the board through a figure 8 for 20 s | `compass calibrated` |
| Point the board north, east, south, west | Heading 0, 90, 180, 270 within a few degrees. If it is mirrored or off by 90°, fix `ACCEL_TO_BODY` / `MAG_TO_BODY` in `board.h` |
| Tilt the board 30° while pointing north | Heading stays within about 5° |
| GNSS antenna near a window, wait a few minutes | A position fix: the clock is set (log dates are right) and the next dive is logged with its entry point |
| Cover the light sensor | The backlight dims over about a second |

## Stage 4 — power and storage

Wire: microSD (3.3 V module), MAX17048, LiPo, TP4056, Qi pair.

| Test | Expected |
| --- | --- |
| Boot with a card | No "no SD card" warning; a simulated dive leaves `DIVES/D0001.DLG` |
| `./build/log2uddf D0001.DLG > dive.uddf` | Opens in Subsurface |
| Battery connected | Battery percentage on the surface screen and in the app |
| Measure the current while "diving" with the backlight at 100 % | Replace the 20 h battery-life assumption with your number |

## Stage 5 — phone

Serve the app: `python3 -m http.server -d sim/build`, open `http://localhost:8000/app.html` in Chrome, press Connect.

| Test | Expected |
| --- | --- |
| Connect | Firmware version, battery, state; the computer's clock is set |
| Sync gear, change a setting | Shown in the computer's menu; still there after a restart |
| Send a plan | Menu → Dive plan shows it; the pre-dive check says whether the gas fits |
| Start a simulated dive while connected | The phone is dropped |
| Download the dive, Share | Picture with profile; UDDF opens in Subsurface |
| Firmware update with a new build | Restarts into it. Then flash an image that crashes at boot: the computer must come back on the old one |

## What is still missing for a dive-ready unit

- **Display screens.** LVGL screens for the pages the simulator shows. The data they need is in `dive_t`; the menu rows come from `menu_rows()`.
- **Safety MCU firmware** (CH32V003): listen for the heartbeat, read depth sensor B itself, sound the buzzer if the ESP32 stops.
- **Bluetooth pairing with a passkey.** Today anyone in range on the surface can connect and change settings.
- **FRAM and RTC drivers** for the final board (the breadboard uses flash and the phone/GNSS clock).
- **A PCB and a housing.** Read the *Pin budget* tab before choosing the 5" RGB panel, and the CAD package's README before machining.

## Before anyone dives it

Every line must be true, and written down with a date and a name.

1. `tools/ci.sh` passes on the exact code that is flashed.
2. The firmware has run 20 simulated dives on the bench (pressure pot or syringe) without a restart, and one deliberate power cut during a dive: after the restart the pre-dive check must say the last dive was interrupted.
3. Depth reads within 1 % of a reference gauge at three pressures, on both sensors.
4. Ten real profiles from your own logbook, replayed through `divecli`, give stops no shorter than your commercial computer showed at the same gradient factors.
5. Tank pressure agrees with an analogue gauge within 5 bar at full and at 50 bar.
6. The housing, empty, has held 1.5 × its design depth for 30 minutes in a pressure chamber, three times, and is dry.
7. The alarms can be felt and heard through a 7 mm hood and gloves.
8. The dive is planned on, and led by, a commercial dive computer and tables. This computer is carried as a logger. Keep it that way until a second person has reviewed the deco code and the test records.
