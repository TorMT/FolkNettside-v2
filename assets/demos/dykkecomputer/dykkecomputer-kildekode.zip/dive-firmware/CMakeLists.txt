# ESP-IDF project (idf.py build). Host tests live in test/, the simulator in sim/.
cmake_minimum_required(VERSION 3.16)
include($ENV{IDF_PATH}/tools/cmake/project.cmake)
project(dive_computer)
