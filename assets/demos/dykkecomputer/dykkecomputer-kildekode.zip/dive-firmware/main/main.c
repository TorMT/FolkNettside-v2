/*
 * main.c — ESP32-S3 dive computer, breadboard build (ESP-IDF 5.3+).
 *
 * Tasks (highest priority first):
 *   sensors  4 Hz depth from both MS5837 through the TCA9548A mux
 *   dive     1 Hz dive state machine + deco (divecore)
 *   tank     I2S samples from the PCM1808 -> txdsp -> Pelagic packets (core 1)
 *   safety   1 s heartbeat to the CH32V003
 *   compass  10 Hz accelerometer + magnetometer -> heading, dead reckoning, figure-8 calibration
 *   gnss     NMEA from the GNSS module: entry position and the clock (surface only)
 *   alerts   buzzer/vibration patterns, wet contacts, backlight
 *   ui       display (LVGL port is the next step; logs to the console for now)
 *
 * STATUS: written against the ESP-IDF 5.3 APIs and type-checked with tools/check_main.sh (stub
 * headers), but not yet built with idf.py or run on hardware. Everything except the LVGL screens
 * is wired in; the screens are the next step (the simulator shows what they should look like).
 *
 * Bluetooth is only on when the diver has it switched on AND the computer is on the surface
 * (surface, surface interval or charging). It is switched off when a dive starts.
 */
#include <math.h>
#include <stdio.h>
#include <string.h>

#include <time.h>

#include "ble.h"
#include "board.h"
#include "divecore/gear.h"
#include "divecore/menu.h"
#include "divecore/settings.h"
#include "storage.h"
#include "divecore/dive.h"
#include "divecore/txdsp.h"
#include "driver/gpio.h"
#include "driver/i2c_master.h"
#include "fuelgauge.h"
#include "imu.h"
#include "divecore/nav.h"
#include "divecore/nmea.h"
#include "divecore/persist.h"
#include "lightsensor.h"
#include "driver/ledc.h"
#include "driver/touch_pad.h"
#include "divecore/hw.h"
#include "divecore/plan.h"
#include "divecore/predive.h"
#include "driver/i2s_std.h"
#include "driver/uart.h"
#include "esp_log.h"
#include "esp_timer.h"
#include "freertos/FreeRTOS.h"
#include "freertos/semphr.h"
#include "freertos/task.h"
#include "ms5837.h"

static const char *TAG = "dive";

static dive_t g_dive;
static SemaphoreHandle_t g_lock;
static float g_depth_a = NAN, g_depth_b = NAN, g_temp = NAN;
static dc_settings_t g_settings;
static dc_gear_t g_gear;
static float g_heading = 0.0f;          /* degrees true, from the compass task */
static nav_t g_nav;                     /* dead reckoning from the entry point */
static nmea_fix_t g_fix;                /* last GNSS fix (surface only: no reception underwater) */
static bool g_cal_running = false;      /* figure-8 compass calibration in progress */
static bool g_interrupted_dive = false; /* restarted during a dive: shown by the pre-dive check */
static bool g_compass_ok = false;
static bool g_compass_calibrated = false;
static bool g_bearing_locked = false;
static float g_bearing = 0.0f;
static menu_t g_menu;
static logfile_t g_log;
static proto_dev_t g_proto;
static dc_divplan_t g_plan;            /* from the phone */
static predive_t g_predive;            /* refreshed every second on the surface */
static int g_depth_sensors = 0;        /* how many answered last time */
static float g_lux = 100.0f;

static bool g_state_ready = false;      /* surface pressure measured and saved state restored */
static i2c_master_bus_handle_t g_bus;
static ms5837_t g_sensor_a, g_sensor_b;
static i2c_master_dev_handle_t g_gauge;

static float pressure_to_depth(float mbar)
{
    float bar = mbar / 1000.0f;
    return dc_depth_m(bar, &g_dive.cfg);
}

/* ---------- sensors: both depth sensors at 4 Hz ---------- */
static void sensors_task(void *arg)
{
    bool ok_a = ms5837_init(&g_sensor_a, g_bus, ADDR_TCA9548A, MUX_CH_DEPTH_A) == ESP_OK;
    bool ok_b = ms5837_init(&g_sensor_b, g_bus, ADDR_TCA9548A, MUX_CH_DEPTH_B) == ESP_OK;
    ESP_LOGI(TAG, "depth sensor A %s, B %s", ok_a ? "ok" : "MISSING", ok_b ? "ok" : "MISSING");
    bool ok_gauge = fuelgauge_init(g_bus, &g_gauge) == ESP_OK;
    if (!ok_gauge) ESP_LOGW(TAG, "no fuel gauge: battery shown as unknown");
    int tick = 0;

    /* Surface pressure: average for ~5 s before anything else (30 s in the final build). */
    float sum = 0;
    int n = 0;
    for (int i = 0; i < 20; i++) {
        float mbar, c;
        if (ok_a && ms5837_read(&g_sensor_a, &mbar, &c) == ESP_OK) { sum += mbar; n++; }
        vTaskDelay(pdMS_TO_TICKS(250));
    }
    /* Only trust it as surface pressure when it is plausible air pressure (sea level to ~2500 m):
     * a computer switched on underwater must not take the depth as its surface. */
    float surf = n > 0 ? sum / n : 0.0f;
    xSemaphoreTake(g_lock, portMAX_DELAY);
    if (surf > 740.0f && surf < 1085.0f) {
        g_dive.cfg.surface_bar = surf / 1000.0f;
        dc_tissues_init(&g_dive.tissues, g_dive.cfg.surface_bar);
        ESP_LOGI(TAG, "surface pressure %.1f mbar", surf);
    } else {
        ESP_LOGW(TAG, "surface pressure reading %.1f mbar not plausible: using 1013 mbar", surf);
    }
    /* Tissues, CNS, no-fly and the dive counter from before the restart, brought forward to now. */
    static uint8_t blob[PERSIST_BLOB];
    int len = state_load(blob, sizeof(blob));
    persist_result_t pr = persist_restore(&g_dive, blob, len, (uint32_t)time(NULL) > 1600000000u ? (uint32_t)time(NULL) : 0);
    g_interrupted_dive = pr == PERSIST_INTERRUPTED_DIVE;
    ESP_LOGI(TAG, "saved state: %s", pr == PERSIST_NONE ? "none (fresh tissues)" : pr == PERSIST_RESTORED ? "restored" :
             pr == PERSIST_RESTORED_NO_CLOCK ? "restored, clock unknown (no off-gassing credited)" : "RESTARTED DURING A DIVE");
    g_state_ready = true;
    xSemaphoreGive(g_lock);

    TickType_t wake = xTaskGetTickCount();
    for (;;) {
        float mbar, c;
        float a = NAN, b = NAN, t = NAN;
        if (ok_a && ms5837_read(&g_sensor_a, &mbar, &c) == ESP_OK) { a = pressure_to_depth(mbar); t = c; }
        if (ok_b && ms5837_read(&g_sensor_b, &mbar, &c) == ESP_OK) { b = pressure_to_depth(mbar); if (isnan(t)) t = c; }
        xSemaphoreTake(g_lock, portMAX_DELAY);
        g_depth_a = a;
        g_depth_b = b;
        g_temp = t;
        g_depth_sensors = (isnan(a) ? 0 : 1) + (isnan(b) ? 0 : 1);
        xSemaphoreGive(g_lock);
        if (ok_gauge && tick++ % 40 == 0) {           /* every 10 s */
            int pct, mv;
            if (fuelgauge_read(g_gauge, &pct, &mv) == ESP_OK) {
                xSemaphoreTake(g_lock, portMAX_DELAY);
                dive_set_battery(&g_dive, pct);
                g_proto.battery_pct = (uint8_t)pct;
                xSemaphoreGive(g_lock);
            }
        }
        vTaskDelayUntil(&wake, pdMS_TO_TICKS(250));
    }
}

/* Bluetooth on only on the surface and only when the diver has it on. Caller holds g_lock. */
static void ble_policy(void)
{
    bool surface = g_dive.state == DIVE_SURFACE || g_dive.state == DIVE_INTERVAL || g_dive.state == DIVE_CHARGING;
    if (g_settings.bluetooth && surface) ble_resume();
    else ble_stop();
}

static uint32_t now_unix(void)
{
    time_t t = time(NULL);
    return t > 1600000000 ? (uint32_t)t : 0;    /* 0 = clock not set yet */
}

/* Caller holds g_lock. */
static void save_state(void)
{
    uint8_t blob[PERSIST_BLOB];
    int len = persist_save(&g_dive, now_unix(), blob, sizeof(blob));
    if (len > 0) state_save(blob, len);
}

/* ---------- dive: state machine and deco at 1 Hz ---------- */
static void dive_task(void *arg)
{
    depth_check_t chk;
    depth_check_init(&chk);
    while (!g_state_ready) vTaskDelay(pdMS_TO_TICKS(100));   /* surface pressure and saved tissues first */
    int since_save = 0;
    TickType_t wake = xTaskGetTickCount();
    for (;;) {
        xSemaphoreTake(g_lock, portMAX_DELAY);
        depth_status_t st;
        float depth = depth_check(&chk, g_depth_a, g_depth_b, 1.0f, &st);
        uint32_t ext = (st == DEPTH_DISAGREE || st == DEPTH_ONLY_A || st == DEPTH_ONLY_B) ? ALARM_DEPTH_SENSOR : 0;
        ext |= divplan_alarms(&g_plan, &g_dive);            /* deeper, longer or more deco than the plan from the phone */
        dive_set_external_alarms(&g_dive, ext);
        if (strcmp(ble_status(), "Connected") == 0) dive_wake(&g_dive);   /* a connected phone keeps it awake */
        dive_state_t before = g_dive.state;
        dive_tick(&g_dive, 1.0f, depth, g_temp);
        bool was_diving = before == DIVE_ACTIVE, diving = g_dive.state == DIVE_ACTIVE;
        if (was_diving != diving && g_menu.open) menu_close(&g_menu);  /* surface menu never underwater, dive menu never on land */
        if (!was_diving && diving) {
            double entry[2] = {g_fix.lat, g_fix.lon};
            if (g_fix.has_fix) nav_set_origin(&g_nav, g_fix.lat, g_fix.lon);
            g_nav.x_m = g_nav.y_m = g_nav.swum_m = 0.0f;
            log_start(&g_log, &g_dive, now_unix(), g_settings.log_interval_s, g_fix.has_fix ? entry : NULL);
            g_interrupted_dive = false;
        }
        if (diving) {
            /* Dead reckoning: heading from the compass, assumed swim speed while roughly level. */
            float speed = fabsf(g_dive.ascent_mpm) < 3.0f && g_compass_ok ? NAV_SWIM_SPEED_MPM : 0.0f;
            nav_step(&g_nav, g_heading, speed, 1.0f);
            log_nav(&g_log, g_nav.x_m, g_nav.y_m);
            log_tick(&g_log, &g_dive, 1.0f);
        }
        if (was_diving && !diving) {
            log_finish(&g_log, &g_dive, &g_gear);
            g_bearing_locked = false;
        }
        /* Save tissues: when a dive ends, every minute during a dive (so a restart is noticed and the
         * loading is not lost) and every 10 minutes on the surface while there is anything to lose. */
        since_save++;
        bool loaded = g_dive.state == DIVE_INTERVAL || g_dive.nofly_min > 0.0f;
        if ((was_diving && !diving) || (diving && since_save >= 60) || (!diving && loaded && since_save >= 600)) {
            save_state();
            since_save = 0;
        }
        if (before != g_dive.state) ble_policy();
        g_proto.depth_sensors = g_depth_sensors;
        g_proto.now_unix = now_unix();
        if (!diving) {
            predive_env_t env = {.depth_sensors = g_depth_sensors, .now_unix = g_proto.now_unix, .interrupted_dive = g_interrupted_dive,
                                 .compass_uncalibrated = !g_compass_calibrated};
            predive_run(&g_dive, &g_settings, &g_gear, &g_plan, &env, &g_predive);
        }
        xSemaphoreGive(g_lock);
        vTaskDelayUntil(&wake, pdMS_TO_TICKS(1000));
    }
}

/* ---------- tank: PCM1808 over I2S -> txdsp ---------- */
static void tank_task(void *arg)
{
    i2s_chan_handle_t rx;
    i2s_chan_config_t chan_cfg = I2S_CHANNEL_DEFAULT_CONFIG(I2S_NUM_0, I2S_ROLE_MASTER);
    ESP_ERROR_CHECK(i2s_new_channel(&chan_cfg, NULL, &rx));
    i2s_std_config_t std_cfg = {
        .clk_cfg = I2S_STD_CLK_DEFAULT_CONFIG(TX_SAMPLE_RATE),
        .slot_cfg = I2S_STD_PHILIPS_SLOT_DEFAULT_CONFIG(I2S_DATA_BIT_WIDTH_32BIT, I2S_SLOT_MODE_STEREO),
        .gpio_cfg = {.mclk = PIN_I2S_MCLK, .bclk = PIN_I2S_BCK, .ws = PIN_I2S_LRCK, .dout = I2S_GPIO_UNUSED, .din = PIN_I2S_DIN},
    };
    std_cfg.clk_cfg.mclk_multiple = I2S_MCLK_MULTIPLE_256; /* PCM1808 needs 256 fs */
    ESP_ERROR_CHECK(i2s_channel_init_std_mode(rx, &std_cfg));
    ESP_ERROR_CHECK(i2s_channel_enable(rx));

    static int32_t raw[512];   /* 256 stereo frames */
    static float left[256];
    txdsp_t dsp;
    txdsp_init(&dsp, TX_SAMPLE_RATE, 38000.0f, 0.002f, 5000);
    for (;;) {
        size_t got = 0;
        if (i2s_channel_read(rx, raw, sizeof(raw), &got, portMAX_DELAY) != ESP_OK) continue;
        int frames = (int)(got / sizeof(int32_t) / 2);
        for (int i = 0; i < frames; i++) left[i] = (float)(raw[2 * i] >> 8) / 8388608.0f; /* 24-bit left-justified */
        pelagic_packet_t p;
        if (txdsp_feed(&dsp, left, frames, &p)) {
            xSemaphoreTake(g_lock, portMAX_DELAY);
            int idx = dive_tank_for_serial(&g_dive, p.serial, g_settings.pairing && g_dive.state != DIVE_ACTIVE);
            if (idx >= 0 && settings_take_serials(&g_settings, &g_dive)) {
                settings_save(&g_settings);
                if (gear_take_serials(&g_gear, &g_settings)) gear_save(&g_gear);   /* the phone sees it on the cylinder */
            }
            if (idx >= 0) {
                dive_tank_reading(&g_dive, idx, pelagic_psi_to_bar(p.psi));
                dive_tank_battery(&g_dive, idx, pelagic_battery_state(p.battery));
            }
            xSemaphoreGive(g_lock);
            if (idx >= 0)
                ESP_LOGI(TAG, "tank %d (%06lu): %u psi (%.0f bar), battery nibble %u", idx + 1, (unsigned long)p.serial,
                         p.psi, pelagic_psi_to_bar(p.psi), p.battery);
        }
    }
}

/* ---------- buttons: screens and the menus (hold SELECT 1 s) ---------- */
static bool store_settings(void *ctx, const dc_settings_t *s)
{
    settings_apply(s, &g_dive); /* caller holds g_lock */
    bool ok = settings_save(s);
    ble_policy();               /* Bluetooth may have been switched */
    return ok;
}

static bool store_gear(void *ctx, const dc_gear_t *g)
{
    return gear_save(g);        /* caller holds g_lock; proto applies the cylinders to the settings */
}

static bool store_plan(void *ctx, const dc_divplan_t *p)
{
    return plan_save(p);        /* caller holds g_lock; proto has already copied it into g_plan */
}

static void set_time(void *ctx, uint32_t unix_s)
{
    clock_set(unix_s);          /* from the phone on every connect */
}

/* ---------- compass: accelerometer + magnetometer at 10 Hz ---------- */
static void compass_task(void *arg)
{
    i2c_master_dev_handle_t acc, mag;
    bool ok = accel_init(g_bus, &acc) == ESP_OK && mag_init(g_bus, &mag) == ESP_OK;
    if (!ok) {
        ESP_LOGW(TAG, "no accelerometer or magnetometer: compass and dead reckoning off");
        vTaskDelete(NULL);
        return;
    }
    magcal_result_t cal = {.offset = {0, 0, 0}, .scale = {1, 1, 1}};
    float v[6];
    if (magcal_load(v)) {
        memcpy(cal.offset, v, sizeof(cal.offset));
        memcpy(cal.scale, v + 3, sizeof(cal.scale));
        g_compass_calibrated = true;
    } else {
        ESP_LOGW(TAG, "compass not calibrated: Settings > Compass > Calibrate");
    }
    magcal_t run;
    int cal_ticks = 0;
    float hx = 1.0f, hy = 0.0f;      /* low-passed heading as a unit vector, so 359 -> 1 degrees does not swing through 180 */
    for (;;) {
        float a[3], m[3];
        if (accel_read(acc, a) == ESP_OK && mag_read(mag, m) == ESP_OK) {
            xSemaphoreTake(g_lock, portMAX_DELAY);
            if (g_cal_running) {
                if (cal_ticks == 0) magcal_begin(&run);
                magcal_feed(&run, m[0], m[1], m[2]);
                if (++cal_ticks >= 200) {            /* 20 s of figure 8 */
                    magcal_result_t r;
                    if (magcal_finish(&run, &r)) {
                        cal = r;
                        memcpy(v, r.offset, sizeof(r.offset));
                        memcpy(v + 3, r.scale, sizeof(r.scale));
                        magcal_save(v);
                        g_compass_calibrated = true;
                        ESP_LOGI(TAG, "compass calibrated");
                    } else {
                        ESP_LOGW(TAG, "calibration did not cover all directions: kept the old one");
                    }
                    g_cal_running = false;
                    cal_ticks = 0;
                }
            }
            float decl = (float)g_settings.declination_deg;
            xSemaphoreGive(g_lock);
            magcal_apply(&cal, &m[0], &m[1], &m[2]);
            float ab[3], mb[3];
            ACCEL_TO_BODY(a, ab);                /* sensor axes -> x forward, y right, z down (board.h) */
            MAG_TO_BODY(m, mb);
            float h = compass_heading_deg(ab[0], ab[1], ab[2], mb[0], mb[1], mb[2], decl) * (float)M_PI / 180.0f;
            hx += 0.2f * (cosf(h) - hx);
            hy += 0.2f * (sinf(h) - hy);
            float deg = atan2f(hy, hx) * 180.0f / (float)M_PI;
            xSemaphoreTake(g_lock, portMAX_DELAY);
            g_heading = deg < 0.0f ? deg + 360.0f : deg;
            g_compass_ok = true;
            xSemaphoreGive(g_lock);
        }
        vTaskDelay(pdMS_TO_TICKS(100));
    }
}

/* ---------- GNSS: NMEA from the module; position for the entry point, time for the clock ---------- */
static void gnss_task(void *arg)
{
    uart_config_t cfg = {.baud_rate = GNSS_BAUD, .data_bits = UART_DATA_8_BITS, .parity = UART_PARITY_DISABLE,
                         .stop_bits = UART_STOP_BITS_1, .flow_ctrl = UART_HW_FLOWCTRL_DISABLE};
    ESP_ERROR_CHECK(uart_driver_install(UART_NUM_1, 1024, 0, 0, NULL, 0));
    ESP_ERROR_CHECK(uart_param_config(UART_NUM_1, &cfg));
    ESP_ERROR_CHECK(uart_set_pin(UART_NUM_1, PIN_GNSS_TX, PIN_GNSS_RX, UART_PIN_NO_CHANGE, UART_PIN_NO_CHANGE));
    nmea_parser_t parser;
    nmea_fix_t fix;
    nmea_init(&parser, &fix);
    bool clock_done = false;
    uint8_t buf[128];
    for (;;) {
        int n = uart_read_bytes(UART_NUM_1, buf, sizeof(buf), pdMS_TO_TICKS(200));
        bool changed = false;
        for (int i = 0; i < n; i++) changed |= nmea_feed(&parser, (char)buf[i], &fix);
        if (!changed) continue;
        xSemaphoreTake(g_lock, portMAX_DELAY);
        /* Underwater there is no reception; keep the last surface fix as the entry point. */
        if (g_dive.state != DIVE_ACTIVE && fix.has_fix) g_fix = fix;
        xSemaphoreGive(g_lock);
        if (!clock_done && fix.unix_time > 1600000000u) {
            clock_set(fix.unix_time);
            clock_done = true;
        }
    }
}

static void buttons_task(void *arg)
{
    const gpio_num_t pins[3] = {PIN_BTN_UP, PIN_BTN_DOWN, PIN_BTN_SELECT};
    gpio_config_t in = {.pin_bit_mask = (1ULL << PIN_BTN_UP) | (1ULL << PIN_BTN_DOWN) | (1ULL << PIN_BTN_SELECT),
                        .mode = GPIO_MODE_INPUT, .pull_up_en = GPIO_PULLUP_ENABLE};
    gpio_config(&in);
    int held[3] = {0, 0, 0};
    for (;;) {
        for (int b = 0; b < 3; b++) {
            bool down = gpio_get_level(pins[b]) == 0;
            if (down) held[b]++;
            if (!down && held[b] >= 2) { /* released after >= 40 ms: a press */
                xSemaphoreTake(g_lock, portMAX_DELAY);
                dive_wake(&g_dive);                       /* any button wakes it and restarts the sleep timer */
                g_menu.ble_status = ble_status();
                g_menu.bearing_locked = g_bearing_locked;
                if (b == 2 && held[b] >= 50 && !g_menu.open) {
                    menu_open(&g_menu, g_dive.state == DIVE_ACTIVE);   /* dive menu underwater, full menu on the surface */
                } else if (g_menu.open) {
                    switch (menu_button(&g_menu, (menu_btn_t)b)) {
                    case MENU_EV_CHANGED: store_settings(NULL, &g_settings); break;
                    case MENU_EV_SWITCH_GAS:
                        if (!dive_switch_gas(&g_dive, g_menu.ev_arg)) ESP_LOGW(TAG, "gas switch refused");
                        break;
                    case MENU_EV_LOCK:
                        g_bearing_locked = !g_bearing_locked;
                        g_bearing = g_heading;
                        break;
                    case MENU_EV_CLEAR_PLAN:
                        memset(&g_plan, 0, sizeof(g_plan));
                        plan_save(&g_plan);
                        break;
                    case MENU_EV_CALIBRATE:
                        g_cal_running = true;   /* the compass task collects 20 s of readings */
                        ESP_LOGI(TAG, "compass calibration: turn the computer in a figure 8 for 20 s");
                        break;
                    default: break;
                    }
                } else {
                    /* Screen paging and gas switching go to the UI task once the LVGL screens exist. */
                }
                xSemaphoreGive(g_lock);
            }
            if (!down) held[b] = 0;
        }
        vTaskDelay(pdMS_TO_TICKS(20));
    }
}

/* ---------- alerts, wet contacts and backlight, every 20 ms ---------- */
static void alerts_task(void *arg)
{
    alarm_notifier_t notifier;
    alarm_notifier_init(&notifier);

    /* Wet contacts on a touch channel: water between the two contacts raises the reading well above the dry baseline. */
    touch_pad_init();
    touch_pad_config(WET_TOUCH_CHANNEL);
    touch_pad_set_fsm_mode(TOUCH_FSM_MODE_TIMER);
    touch_pad_fsm_start();
    vTaskDelay(pdMS_TO_TICKS(200));
    uint32_t dry = 0;
    touch_pad_read_raw_data(WET_TOUCH_CHANNEL, &dry);      /* assumes the computer is switched on dry; measure on the real case */

    /* Backlight: LEDC PWM on the display's backlight pin. */
    ledc_timer_config_t tcfg = {.speed_mode = LEDC_LOW_SPEED_MODE, .duty_resolution = LEDC_TIMER_10_BIT, .timer_num = LEDC_TIMER_0,
                                .freq_hz = BACKLIGHT_PWM_HZ, .clk_cfg = LEDC_AUTO_CLK};
    ledc_timer_config(&tcfg);
    ledc_channel_config_t ccfg = {.gpio_num = PIN_LCD_BL, .speed_mode = LEDC_LOW_SPEED_MODE, .channel = LEDC_CHANNEL_0,
                                  .timer_sel = LEDC_TIMER_0, .duty = 512};
    ledc_channel_config(&ccfg);

    i2c_master_dev_handle_t light;
    bool ok_light = lightsensor_init(g_bus, &light) == ESP_OK;
    if (!ok_light) ESP_LOGW(TAG, "no light sensor: backlight follows the brightness setting only");
    float shown = 50.0f;
    int n = 0;
    for (;;) {
        uint32_t now = (uint32_t)(esp_timer_get_time() / 1000);
        uint32_t raw = 0;
        touch_pad_read_raw_data(WET_TOUCH_CHANNEL, &raw);
        bool wet = raw > dry + dry / 2;
        if (ok_light && n % 25 == 0) lightsensor_read(light, &g_lux);       /* twice a second */

        xSemaphoreTake(g_lock, portMAX_DELAY);
        dive_set_wet(&g_dive, wet);
        bool vib, buzz;
        alarm_notifier_step(&notifier, g_dive.alarms, ALARM_CRITICAL_MASK, now, g_settings.vibrate, g_settings.sound, &vib, &buzz);
        int target = g_dive.state == DIVE_SLEEP ? 0 : backlight_pct(g_settings.brightness, g_lux, g_settings.auto_bright && ok_light);
        xSemaphoreGive(g_lock);

        gpio_set_level(PIN_VIBRATION, vib);
        gpio_set_level(PIN_BUZZER, buzz);
        shown += ((float)target - shown) * 0.05f;                          /* about a second to follow, so it does not flicker */
        ledc_set_duty(LEDC_LOW_SPEED_MODE, LEDC_CHANNEL_0, (uint32_t)(shown * 10.23f));
        ledc_update_duty(LEDC_LOW_SPEED_MODE, LEDC_CHANNEL_0);
        n++;
        vTaskDelay(pdMS_TO_TICKS(20));
    }
}

/* ---------- safety heartbeat ---------- */
static void safety_task(void *arg)
{
    uart_config_t cfg = {.baud_rate = 115200, .data_bits = UART_DATA_8_BITS, .parity = UART_PARITY_DISABLE,
                         .stop_bits = UART_STOP_BITS_1, .flow_ctrl = UART_HW_FLOWCTRL_DISABLE};
    ESP_ERROR_CHECK(uart_driver_install(UART_NUM_2, 256, 0, 0, NULL, 0));
    ESP_ERROR_CHECK(uart_param_config(UART_NUM_2, &cfg));
    ESP_ERROR_CHECK(uart_set_pin(UART_NUM_2, PIN_SAFETY_TX, PIN_SAFETY_RX, UART_PIN_NO_CHANGE, UART_PIN_NO_CHANGE));
    uint8_t seq = 0;
    for (;;) {
        xSemaphoreTake(g_lock, portMAX_DELAY);
        /* Frame: 0xA5, seq, state, depth in dm (2 bytes), alarm flags (2 bytes), xor checksum. */
        uint16_t dm = (uint16_t)(g_dive.depth_m * 10.0f);
        uint16_t al = (uint16_t)g_dive.alarms;
        uint8_t f[8] = {0xA5, seq++, (uint8_t)g_dive.state, (uint8_t)(dm >> 8), (uint8_t)dm, (uint8_t)(al >> 8), (uint8_t)al, 0};
        xSemaphoreGive(g_lock);
        for (int i = 0; i < 7; i++) f[7] ^= f[i];
        uart_write_bytes(UART_NUM_2, f, sizeof(f));
        vTaskDelay(pdMS_TO_TICKS(1000));
    }
}

/* ---------- UI placeholder: the LVGL screens come next ---------- */
static void ui_task(void *arg)
{
    static const char *states[] = {"sleep", "surface", "DIVE", "interval", "charging"};
    for (;;) {
        xSemaphoreTake(g_lock, portMAX_DELAY);
        dive_t d = g_dive;
        xSemaphoreGive(g_lock);
        if (d.plan.in_deco)
            ESP_LOGI(TAG, "%s %.1f m  %02d:%02d  STOP %.0f m %u min  TTS %d  ceil %.1f  ppO2 %.2f  CNS %.0f%%  alarms %04lx",
                     states[d.state], d.depth_m, (int)d.dive_time_s / 60, (int)d.dive_time_s % 60,
                     d.plan.n_stops ? d.plan.stops[0].depth_m : 0.0f, d.plan.n_stops ? d.plan.stops[0].minutes : 0,
                     d.plan.tts_min, d.plan.ceiling_m, dive_ppo2(&d), d.ox.cns_pct, (unsigned long)d.alarms);
        else
            ESP_LOGI(TAG, "%s %.1f m  %02d:%02d  NDL %d  ppO2 %.2f  CNS %.0f%%  tank %.0f bar  alarms %04lx", states[d.state],
                     d.depth_m, (int)d.dive_time_s / 60, (int)d.dive_time_s % 60, d.plan.ndl_min, dive_ppo2(&d),
                     d.ox.cns_pct, dive_active_tank(&d) ? dive_active_tank(&d)->bar : -1.0f, (unsigned long)d.alarms);
        /* The LVGL port will use lv_display_set_rotation() from g_settings.flip. Buzzer, vibration and backlight: alerts_task. */
        vTaskDelay(pdMS_TO_TICKS(1000));
    }
}

void app_main(void)
{
    g_lock = xSemaphoreCreateMutex();
    storage_init();
    settings_load(&g_settings);
    gear_load(&g_gear);
    plan_load(&g_plan);
    dive_init(&g_dive);
    settings_apply(&g_settings, &g_dive);
    menu_init(&g_menu, &g_settings);
    g_menu.gear = &g_gear;
    g_menu.dive = &g_dive;
    g_menu.predive = &g_predive;
    g_menu.plan = &g_plan;
    if (!sd_mount()) ESP_LOGW(TAG, "no SD card: dives will not be logged");

    g_proto = (proto_dev_t){.log_count = logs_count, .log_size = logs_size, .log_read = logs_read,
                            .settings_store = store_settings, .ota = ota_step, .gear_store = store_gear,
                            .settings = &g_settings, .gear = &g_gear, .dive = &g_dive, .fw_version = "0.3.0",
                            .battery_pct = 255, .plan = &g_plan, .plan_store = store_plan, .set_time = set_time};
    nav_init(&g_nav, 0.15f);
    g_menu.logbook = menu_logbook_proto;   /* reads headers from the SD card through the same storage callbacks */
    g_menu.log_ctx = &g_proto;
    ble_start(&g_proto, g_lock);
    ble_policy();

    gpio_config_t out = {.pin_bit_mask = (1ULL << PIN_VIBRATION) | (1ULL << PIN_BUZZER), .mode = GPIO_MODE_OUTPUT};
    gpio_config(&out);

    i2c_master_bus_config_t bus_cfg = {.i2c_port = I2C_NUM_0, .sda_io_num = PIN_I2C_SDA, .scl_io_num = PIN_I2C_SCL,
                                       .clk_source = I2C_CLK_SRC_DEFAULT, .glitch_ignore_cnt = 7,
                                       .flags.enable_internal_pullup = true};
    ESP_ERROR_CHECK(i2c_new_master_bus(&bus_cfg, &g_bus));

    xTaskCreatePinnedToCore(sensors_task, "sensors", 4096, NULL, 10, NULL, 0);
    xTaskCreatePinnedToCore(dive_task, "dive", 8192, NULL, 9, NULL, 0);
    xTaskCreatePinnedToCore(tank_task, "tank", 8192, NULL, 8, NULL, 1);
    xTaskCreatePinnedToCore(safety_task, "safety", 3072, NULL, 7, NULL, 0);
    xTaskCreatePinnedToCore(ui_task, "ui", 6144, NULL, 3, NULL, 0);
    xTaskCreatePinnedToCore(buttons_task, "buttons", 3072, NULL, 4, NULL, 0);
    xTaskCreatePinnedToCore(alerts_task, "alerts", 4096, NULL, 6, NULL, 0);
    xTaskCreatePinnedToCore(compass_task, "compass", 4096, NULL, 5, NULL, 0);
    xTaskCreatePinnedToCore(gnss_task, "gnss", 4096, NULL, 2, NULL, 0);

    /* Reaching here with every task started is the self-test for a freshly updated image: keep it.
     * (A stricter check, e.g. a depth sensor answering, belongs here before a field release.) */
    ota_confirm();
}
