/* lightsensor.h — VEML6030 (PCB rev C) or VEML7700 (breadboard) ambient light sensor at I2C 0x10, for the automatic backlight.
 * Same registers; only the lux per count differs. Build with -DLIGHT_VEML7700 for the breadboard module. */
#pragma once

#include "driver/i2c_master.h"
#include "esp_err.h"

#define ADDR_VEML7700 0x10

esp_err_t lightsensor_init(i2c_master_bus_handle_t bus, i2c_master_dev_handle_t *dev);
esp_err_t lightsensor_read(i2c_master_dev_handle_t dev, float *lux);
