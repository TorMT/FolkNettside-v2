/* lightsensor.h — VEML7700 ambient light sensor (I2C 0x10) behind the display window, for the automatic backlight. */
#pragma once

#include "driver/i2c_master.h"
#include "esp_err.h"

#define ADDR_VEML7700 0x10

esp_err_t lightsensor_init(i2c_master_bus_handle_t bus, i2c_master_dev_handle_t *dev);
esp_err_t lightsensor_read(i2c_master_dev_handle_t dev, float *lux);
