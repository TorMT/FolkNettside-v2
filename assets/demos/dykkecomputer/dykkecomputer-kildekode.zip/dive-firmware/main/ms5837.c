/* ms5837.c — see ms5837.h. Commands from the MS5837-30BA datasheet. */
#include "ms5837.h"

#include "esp_check.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#define CMD_RESET 0x1E
#define CMD_ADC_READ 0x00
#define CMD_PROM 0xA0
#define CMD_D1_OSR8192 0x4A
#define CMD_D2_OSR8192 0x5A
#define TIMEOUT_MS 50

static esp_err_t select_channel(ms5837_t *s)
{
    uint8_t v = (uint8_t)(1u << s->mux_channel);
    return i2c_master_transmit(s->mux, &v, 1, TIMEOUT_MS);
}

static esp_err_t cmd(ms5837_t *s, uint8_t c)
{
    return i2c_master_transmit(s->dev, &c, 1, TIMEOUT_MS);
}

static esp_err_t convert(ms5837_t *s, uint8_t c, uint32_t *out)
{
    esp_err_t e = cmd(s, c);
    if (e != ESP_OK) return e;
    vTaskDelay(pdMS_TO_TICKS(20));
    uint8_t r[3];
    uint8_t rd = CMD_ADC_READ;
    e = i2c_master_transmit_receive(s->dev, &rd, 1, r, 3, TIMEOUT_MS);
    if (e == ESP_OK) *out = ((uint32_t)r[0] << 16) | ((uint32_t)r[1] << 8) | r[2];
    return e;
}

esp_err_t ms5837_init(ms5837_t *s, i2c_master_bus_handle_t bus, uint8_t mux_addr, uint8_t mux_channel)
{
    i2c_device_config_t mux_cfg = {.dev_addr_length = I2C_ADDR_BIT_LEN_7, .device_address = mux_addr, .scl_speed_hz = 400000};
    i2c_device_config_t dev_cfg = {.dev_addr_length = I2C_ADDR_BIT_LEN_7, .device_address = 0x76, .scl_speed_hz = 400000};
    s->mux_channel = mux_channel;
    ESP_RETURN_ON_ERROR(i2c_master_bus_add_device(bus, &mux_cfg, &s->mux), "ms5837", "mux");
    ESP_RETURN_ON_ERROR(i2c_master_bus_add_device(bus, &dev_cfg, &s->dev), "ms5837", "dev");
    ESP_RETURN_ON_ERROR(select_channel(s), "ms5837", "mux select");
    ESP_RETURN_ON_ERROR(cmd(s, CMD_RESET), "ms5837", "reset");
    vTaskDelay(pdMS_TO_TICKS(10));
    for (int i = 0; i < 7; i++) {
        uint8_t c = (uint8_t)(CMD_PROM + 2 * i), r[2];
        ESP_RETURN_ON_ERROR(i2c_master_transmit_receive(s->dev, &c, 1, r, 2, TIMEOUT_MS), "ms5837", "prom");
        s->prom.c[i] = (uint16_t)((r[0] << 8) | r[1]);
    }
    s->prom.c[7] = 0;
    return ms5837_prom_ok(&s->prom) ? ESP_OK : ESP_ERR_INVALID_CRC;
}

esp_err_t ms5837_read(ms5837_t *s, float *mbar, float *celsius)
{
    uint32_t d1, d2;
    ESP_RETURN_ON_ERROR(select_channel(s), "ms5837", "mux select");
    ESP_RETURN_ON_ERROR(convert(s, CMD_D1_OSR8192, &d1), "ms5837", "d1");
    ESP_RETURN_ON_ERROR(convert(s, CMD_D2_OSR8192, &d2), "ms5837", "d2");
    ms5837_30ba_compensate(&s->prom, d1, d2, mbar, celsius);
    return ESP_OK;
}
