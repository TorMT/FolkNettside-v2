idf_component_register(SRCS "main.c" "ms5837.c" "fuelgauge.c" "lightsensor.c" "imu.c" "storage.c" "ble.c"
                       INCLUDE_DIRS "."
                       REQUIRES divecore esp_driver_i2c esp_driver_i2s esp_driver_uart esp_driver_gpio esp_driver_ledc driver esp_timer nvs_flash fatfs sdmmc esp_driver_sdspi esp_driver_spi app_update bt)

# Emulator build (idf.py -D DIVE_QEMU=1 ...): skips Bluetooth, which QEMU does not emulate
if(DIVE_QEMU)
    target_compile_definitions(${COMPONENT_LIB} PRIVATE DIVE_QEMU=1)
endif()
