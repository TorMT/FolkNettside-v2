/* storage.c — see storage.h. ESP-IDF 5.3; not yet compiled on hardware. */
#include "storage.h"

#include <dirent.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <time.h>
#include <sys/stat.h>

#include "board.h"
#include "driver/sdspi_host.h"
#include "driver/spi_common.h"
#include "esp_log.h"
#include "esp_ota_ops.h"
#include "esp_system.h"
#include "esp_vfs_fat.h"
#include "nvs.h"
#include "nvs_flash.h"
#include "sdmmc_cmd.h"

static const char *TAG = "storage";
#define MOUNT "/sdcard"
#define DIVES MOUNT "/DIVES"
#define MAX_LOGS 999

/* ---------- settings in NVS ---------- */

void storage_init(void)
{
    esp_err_t e = nvs_flash_init();
    if (e == ESP_ERR_NVS_NO_FREE_PAGES || e == ESP_ERR_NVS_NEW_VERSION_FOUND) {
        nvs_flash_erase();
        nvs_flash_init();
    }
}

void settings_load(dc_settings_t *s)
{
    settings_default(s);
    nvs_handle_t h;
    if (nvs_open("dive", NVS_READONLY, &h) != ESP_OK) return;
    uint8_t blob[DC_SETTINGS_BLOB_SIZE];
    size_t len = sizeof(blob);
    if (nvs_get_blob(h, "settings", blob, &len) == ESP_OK && !settings_deserialize(blob, (int)len, s)) {
        ESP_LOGW(TAG, "stored settings corrupt, using defaults");
        settings_default(s);
    }
    nvs_close(h);
}

bool settings_save(const dc_settings_t *s)
{
    uint8_t blob[DC_SETTINGS_BLOB_SIZE];
    int len = settings_serialize(s, blob, sizeof(blob));
    nvs_handle_t h;
    if (!len || nvs_open("dive", NVS_READWRITE, &h) != ESP_OK) return false;
    bool ok = nvs_set_blob(h, "settings", blob, (size_t)len) == ESP_OK && nvs_commit(h) == ESP_OK;
    nvs_close(h);
    return ok;
}

void gear_load(dc_gear_t *g)
{
    gear_init(g);
    nvs_handle_t h;
    if (nvs_open("dive", NVS_READONLY, &h) != ESP_OK) return;
    uint8_t blob[GEAR_BLOB_MAX];
    size_t len = sizeof(blob);
    if (nvs_get_blob(h, "gear", blob, &len) == ESP_OK && !gear_deserialize(blob, (int)len, g)) {
        ESP_LOGW(TAG, "stored gear list corrupt, starting empty");
        gear_init(g);
    }
    nvs_close(h);
}

static int blob_load(const char *key, void *out, size_t cap)
{
    nvs_handle_t h;
    if (nvs_open("dive", NVS_READONLY, &h) != ESP_OK) return 0;
    size_t len = cap;
    esp_err_t e = nvs_get_blob(h, key, out, &len);
    nvs_close(h);
    return e == ESP_OK ? (int)len : 0;
}
static bool blob_save(const char *key, const void *v, size_t len)
{
    nvs_handle_t h;
    if (nvs_open("dive", NVS_READWRITE, &h) != ESP_OK) return false;
    bool ok = nvs_set_blob(h, key, v, len) == ESP_OK && nvs_commit(h) == ESP_OK;
    nvs_close(h);
    return ok;
}
int state_load(uint8_t *blob, int cap) { return blob_load("state", blob, (size_t)cap); }
bool state_save(const uint8_t *blob, int len) { return blob_save("state", blob, (size_t)len); }
bool magcal_load(float v[6]) { return blob_load("magcal", v, 6 * sizeof(float)) == (int)(6 * sizeof(float)); }
bool magcal_save(const float v[6]) { return blob_save("magcal", v, 6 * sizeof(float)); }

void clock_set(uint32_t unix_s)
{
    struct timeval tv = {.tv_sec = (time_t)unix_s, .tv_usec = 0};
    settimeofday(&tv, NULL);
}

void ota_confirm(void)
{
    esp_ota_mark_app_valid_cancel_rollback();
}

void plan_load(dc_divplan_t *p)
{
    memset(p, 0, sizeof(*p));
    nvs_handle_t h;
    if (nvs_open("dive", NVS_READONLY, &h) != ESP_OK) return;
    uint8_t blob[DIVPLAN_BLOB];
    size_t len = sizeof(blob);
    if (nvs_get_blob(h, "plan", blob, &len) == ESP_OK && !divplan_deserialize(blob, (int)len, p)) memset(p, 0, sizeof(*p));
    nvs_close(h);
}

bool plan_save(const dc_divplan_t *p)
{
    nvs_handle_t h;
    if (nvs_open("dive", NVS_READWRITE, &h) != ESP_OK) return false;
    bool ok;
    if (!p->valid) {
        esp_err_t e = nvs_erase_key(h, "plan");
        ok = e == ESP_OK || e == ESP_ERR_NVS_NOT_FOUND;
    } else {
        uint8_t blob[DIVPLAN_BLOB];
        int len = divplan_serialize(p, blob, sizeof(blob));
        ok = len && nvs_set_blob(h, "plan", blob, (size_t)len) == ESP_OK;
    }
    ok = ok && nvs_commit(h) == ESP_OK;
    nvs_close(h);
    return ok;
}

bool gear_save(const dc_gear_t *g)
{
    uint8_t blob[GEAR_BLOB_MAX];
    int len = gear_serialize(g, blob, sizeof(blob));
    nvs_handle_t h;
    if (!len || nvs_open("dive", NVS_READWRITE, &h) != ESP_OK) return false;
    bool ok = nvs_set_blob(h, "gear", blob, (size_t)len) == ESP_OK && nvs_commit(h) == ESP_OK;
    nvs_close(h);
    return ok;
}

static uint16_t next_dive_no(void)
{
    nvs_handle_t h;
    uint16_t n = 0;
    if (nvs_open("dive", NVS_READWRITE, &h) != ESP_OK) return 1;
    nvs_get_u16(h, "dive_no", &n);
    n++;
    nvs_set_u16(h, "dive_no", n);
    nvs_commit(h);
    nvs_close(h);
    return n;
}

/* ---------- microSD ---------- */

static bool g_sd_ok = false;

bool sd_mount(void)
{
    spi_bus_config_t bus = {.mosi_io_num = PIN_SPI_MOSI, .miso_io_num = PIN_SPI_MISO, .sclk_io_num = PIN_SPI_SCLK,
                            .quadwp_io_num = -1, .quadhd_io_num = -1, .max_transfer_sz = 32768};
    esp_err_t e = spi_bus_initialize(SPI2_HOST, &bus, SPI_DMA_CH_AUTO);
    if (e != ESP_OK && e != ESP_ERR_INVALID_STATE) return false; /* INVALID_STATE: the display already set it up */
    sdmmc_host_t host = SDSPI_HOST_DEFAULT();
    host.slot = SPI2_HOST;
    sdspi_device_config_t slot = SDSPI_DEVICE_CONFIG_DEFAULT();
    slot.gpio_cs = PIN_SD_CS;
    slot.host_id = SPI2_HOST;
    esp_vfs_fat_sdmmc_mount_config_t mc = {.format_if_mount_failed = false, .max_files = 4, .allocation_unit_size = 16 * 1024};
    sdmmc_card_t *card;
    e = esp_vfs_fat_sdspi_mount(MOUNT, &host, &slot, &mc, &card);
    if (e != ESP_OK) {
        ESP_LOGE(TAG, "SD mount failed: %s", esp_err_to_name(e));
        return false;
    }
    mkdir(DIVES, 0775);
    g_sd_ok = true;
    return true;
}

/* Log index i is the i-th D*.DLG file in name order. */
static int list_logs(char names[][16], int max)
{
    if (!g_sd_ok) return 0;
    DIR *dir = opendir(DIVES);
    if (!dir) return 0;
    int n = 0;
    struct dirent *e;
    while ((e = readdir(dir)) && n < max) {
        size_t l = strlen(e->d_name);
        if (l == 9 && e->d_name[0] == 'D' && strcmp(e->d_name + 5, ".DLG") == 0) {
            snprintf(names[n++], 16, "%s", e->d_name);
        }
    }
    closedir(dir);
    qsort(names, (size_t)n, 16, (int (*)(const void *, const void *))strcmp);
    return n;
}

static bool path_for(int idx, char *path, size_t cap)
{
    static char names[MAX_LOGS][16];
    int n = list_logs(names, MAX_LOGS);
    if (idx < 0 || idx >= n) return false;
    snprintf(path, cap, DIVES "/%s", names[idx]);
    return true;
}

int logs_count(void *ctx)
{
    static char names[MAX_LOGS][16];
    return list_logs(names, MAX_LOGS);
}

int logs_size(void *ctx, int idx)
{
    char path[48];
    struct stat st;
    if (!path_for(idx, path, sizeof(path)) || stat(path, &st) != 0) return 0;
    return (int)st.st_size;
}

int logs_read(void *ctx, int idx, uint32_t off, uint8_t *buf, int len)
{
    char path[48];
    if (!path_for(idx, path, sizeof(path))) return -1;
    FILE *f = fopen(path, "rb");
    if (!f) return -1;
    fseek(f, (long)off, SEEK_SET);
    int got = (int)fread(buf, 1, (size_t)len, f);
    fclose(f);
    return got;
}

bool log_start(logfile_t *lf, const dive_t *d, uint32_t unix_time, uint8_t interval_s, const double *entry)
{
    lf->f = NULL;
    if (!g_sd_ok) return false;
    uint16_t no = next_dive_no();
    char path[48];
    snprintf(path, sizeof(path), DIVES "/D%04u.DLG", no % 10000);
    FILE *f = fopen(path, "wb+");
    if (!f) return false;
    uint8_t hdr[DIVELOG_HEADER];
    divelog_begin(&lf->w, d, no, unix_time, interval_s, hdr);
    if (entry) divelog_set_entry(&lf->w, entry[0], entry[1]);   /* goes out with the completed header at the end */
    fwrite(hdr, 1, sizeof(hdr), f);
    lf->f = f;
    ESP_LOGI(TAG, "logging dive %u to %s", no, path);
    return true;
}

void log_nav(logfile_t *lf, float x_m, float y_m)
{
    if (lf->f) divelog_set_nav(&lf->w, x_m, y_m);
}

void log_tick(logfile_t *lf, const dive_t *d, float dt_s)
{
    uint8_t s[DIVELOG_SAMPLE];
    if (lf->f && divelog_tick(&lf->w, d, dt_s, s)) {
        fwrite(s, 1, sizeof(s), (FILE *)lf->f);
        if (lf->w.h.n_samples % 30 == 0) fflush((FILE *)lf->f); /* lose at most a minute on power loss */
    }
}

void log_finish(logfile_t *lf, const dive_t *d, const dc_gear_t *gear)
{
    if (!lf->f) return;
    FILE *f = (FILE *)lf->f;
    uint8_t hdr[DIVELOG_HEADER], ftr[DIVELOG_FOOTER];
    divelog_end(&lf->w, d, hdr, ftr);
    fwrite(ftr, 1, sizeof(ftr), f);
    if (gear) {
        uint8_t gb[GEAR_BLOB_MAX];
        int n = divelog_gear_block(gear, gb, sizeof(gb));
        if (n > 0) fwrite(gb, 1, (size_t)n, f);
    }
    fseek(f, 0, SEEK_SET);
    fwrite(hdr, 1, sizeof(hdr), f);
    fclose(f);
    lf->f = NULL;
}

/* ---------- firmware update ---------- */

static esp_ota_handle_t g_ota;
static const esp_partition_t *g_part;
static uint32_t g_ota_next, g_ota_size, g_ota_crc;

int ota_step(void *ctx, int step, uint32_t value, const uint8_t *data, int len)
{
    switch (step) {
    case OTA_BEGIN:
        g_part = esp_ota_get_next_update_partition(NULL);
        if (!g_part || value > g_part->size) return ST_FAILED;
        if (esp_ota_begin(g_part, value, &g_ota) != ESP_OK) return ST_FAILED;
        g_ota_next = 0;
        g_ota_size = value;
        g_ota_crc = 0xFFFFFFFFu;
        return ST_OK;
    case OTA_DATA:
        if (value != g_ota_next || g_ota_next + (uint32_t)len > g_ota_size) return ST_BAD_REQUEST;
        if (esp_ota_write(g_ota, data, (size_t)len) != ESP_OK) return ST_FAILED;
        dc_crc32_feed(&g_ota_crc, data, len);
        g_ota_next += (uint32_t)len;
        return ST_OK;
    case OTA_END:
        if (g_ota_next != g_ota_size || ~g_ota_crc != value) {
            esp_ota_abort(g_ota);
            return ST_CRC;
        }
        /* esp_ota_end checks the image; secure boot also checks its signature on the final build. */
        if (esp_ota_end(g_ota) != ESP_OK || esp_ota_set_boot_partition(g_part) != ESP_OK) return ST_FAILED;
        ESP_LOGI(TAG, "update written, rebooting");
        return ST_OK; /* the caller restarts after sending the reply */
    }
    return ST_BAD_REQUEST;
}
