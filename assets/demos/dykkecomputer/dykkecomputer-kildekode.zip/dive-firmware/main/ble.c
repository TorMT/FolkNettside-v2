/*
 * ble.c — NimBLE GATT server carrying the phone protocol (divecore/proto.h).
 * One service, an RX characteristic the phone writes requests to and a TX characteristic
 * that notifies responses in MTU-sized pieces. ESP-IDF 5.3; not yet compiled on hardware.
 *
 * TODO before field use: require bonding with a passkey shown on the dive computer
 * (ble_hs_cfg.sm_io_cap = BLE_SM_IO_CAP_DISP_ONLY, sm_mitm = 1) so only your phone can change settings.
 */
#include "ble.h"

#include <string.h>

#include "esp_log.h"
#include "esp_system.h"
#include "host/ble_hs.h"
#include "host/util/util.h"
#include "nimble/nimble_port.h"
#include "nimble/nimble_port_freertos.h"
#include "services/gap/ble_svc_gap.h"
#include "services/gatt/ble_svc_gatt.h"

static const char *TAG = "ble";

/* 6e40000x-d1c0-4c2a-9b1e-7d1f0dc00001, little-endian byte order for NimBLE. */
#define UUID_BYTES(x) 0x01, 0x00, 0xc0, 0x0d, 0x1f, 0x7d, 0x1e, 0x9b, 0x2a, 0x4c, 0xc0, 0xd1, x, 0x00, 0x40, 0x6e
static const ble_uuid128_t SVC = BLE_UUID128_INIT(UUID_BYTES(0x01));
static const ble_uuid128_t RX = BLE_UUID128_INIT(UUID_BYTES(0x02));
static const ble_uuid128_t TX = BLE_UUID128_INIT(UUID_BYTES(0x03));

static proto_dev_t *g_dev;
static SemaphoreHandle_t g_lock;
static uint16_t g_tx_handle, g_conn = BLE_HS_CONN_HANDLE_NONE;
static volatile bool g_enabled = false, g_synced = false;   /* advertising allowed; host ready */
static volatile bool g_drop_after_reply = false;           /* Bluetooth switched off by the phone itself */
static TaskHandle_t g_host_task;
static uint8_t g_req[4 + 600];
static int g_req_len;
static uint8_t g_resp[5 + 2048];

static void send_response(int n)
{
    uint16_t mtu = ble_att_mtu(g_conn);
    int chunk = mtu > 3 ? mtu - 3 : 20;
    for (int off = 0; off < n; off += chunk) {
        int len = n - off < chunk ? n - off : chunk;
        struct os_mbuf *om = ble_hs_mbuf_from_flat(g_resp + off, (uint16_t)len);
        if (ble_gatts_notify_custom(g_conn, g_tx_handle, om) != 0) {
            ESP_LOGW(TAG, "notify failed");
            return;
        }
    }
}

static int rx_access(uint16_t conn, uint16_t attr, struct ble_gatt_access_ctxt *ctxt, void *arg)
{
    if (ctxt->op != BLE_GATT_ACCESS_OP_WRITE_CHR) return BLE_ATT_ERR_UNLIKELY;
    uint16_t len = OS_MBUF_PKTLEN(ctxt->om);
    if (g_req_len + len > (int)sizeof(g_req)) g_req_len = 0; /* oversized: start over */
    ble_hs_mbuf_to_flat(ctxt->om, g_req + g_req_len, len, NULL);
    g_req_len += len;
    /* A request is complete once its length field is satisfied (long writes may arrive in pieces). */
    if (g_req_len >= 4 && g_req_len >= 4 + (g_req[2] | (g_req[3] << 8))) {
        xSemaphoreTake(g_lock, portMAX_DELAY);
        int n = proto_handle(g_dev, g_req, g_req_len, g_resp, sizeof(g_resp));
        xSemaphoreGive(g_lock);
        bool reboot = g_req[0] == CMD_OTA_END && n >= 3 && g_resp[2] == ST_OK;
        g_req_len = 0;
        send_response(n);
        if (g_drop_after_reply) {   /* answer first, then hang up */
            g_drop_after_reply = false;
            vTaskDelay(pdMS_TO_TICKS(200));
            if (g_conn != BLE_HS_CONN_HANDLE_NONE) ble_gap_terminate(g_conn, BLE_ERR_REM_USER_CONN_TERM);
        }
        if (reboot) {
            vTaskDelay(pdMS_TO_TICKS(500));
            esp_restart();
        }
    }
    return 0;
}

static int tx_access(uint16_t conn, uint16_t attr, struct ble_gatt_access_ctxt *ctxt, void *arg) { return 0; }

static const struct ble_gatt_svc_def SERVICES[] = {
    {.type = BLE_GATT_SVC_TYPE_PRIMARY,
     .uuid = &SVC.u,
     .characteristics = (struct ble_gatt_chr_def[]){
         {.uuid = &RX.u, .access_cb = rx_access, .flags = BLE_GATT_CHR_F_WRITE | BLE_GATT_CHR_F_WRITE_NO_RSP},
         {.uuid = &TX.u, .access_cb = tx_access, .val_handle = &g_tx_handle, .flags = BLE_GATT_CHR_F_NOTIFY},
         {0}}},
    {0}};

static void advertise(void);

static int gap_event(struct ble_gap_event *ev, void *arg)
{
    switch (ev->type) {
    case BLE_GAP_EVENT_CONNECT:
        if (ev->connect.status == 0) {
            g_conn = ev->connect.conn_handle;
            g_req_len = 0;
            ESP_LOGI(TAG, "phone connected");
        } else if (g_enabled) {
            advertise();
        }
        break;
    case BLE_GAP_EVENT_DISCONNECT:
        g_conn = BLE_HS_CONN_HANDLE_NONE;
        ESP_LOGI(TAG, "phone disconnected");
        if (g_enabled) advertise();
        break;
    default:
        break;
    }
    return 0;
}

static void advertise(void)
{
    struct ble_hs_adv_fields f = {0};
    const char *name = ble_svc_gap_device_name();
    f.flags = BLE_HS_ADV_F_DISC_GEN | BLE_HS_ADV_F_BREDR_UNSUP;
    f.name = (uint8_t *)name;
    f.name_len = (uint8_t)strlen(name);
    f.name_is_complete = 1;
    ble_gap_adv_set_fields(&f);
    struct ble_hs_adv_fields rsp = {0};
    rsp.uuids128 = (ble_uuid128_t *)&SVC;
    rsp.num_uuids128 = 1;
    rsp.uuids128_is_complete = 1;
    ble_gap_adv_rsp_set_fields(&rsp);
    struct ble_gap_adv_params p = {.conn_mode = BLE_GAP_CONN_MODE_UND, .disc_mode = BLE_GAP_DISC_MODE_GEN};
    uint8_t own;
    ble_hs_id_infer_auto(0, &own);
    ble_gap_adv_start(own, NULL, BLE_HS_FOREVER, &p, gap_event, NULL);
}

static void on_sync(void)
{
    g_synced = true;
    if (g_enabled) advertise();
}

static void host_task(void *arg)
{
    g_host_task = xTaskGetCurrentTaskHandle();
    nimble_port_run();
    nimble_port_freertos_deinit();
}

void ble_start(proto_dev_t *dev, SemaphoreHandle_t lock)
{
    g_dev = dev;
    g_lock = lock;
    ESP_ERROR_CHECK(nimble_port_init());
    ble_hs_cfg.sync_cb = on_sync;
    ble_svc_gap_init();
    ble_svc_gatt_init();
    ble_gatts_count_cfg(SERVICES);
    ble_gatts_add_svcs(SERVICES);
    ble_svc_gap_device_name_set("DiveComputer");
    ble_att_set_preferred_mtu(247);
    nimble_port_freertos_init(host_task);
}

void ble_stop(void)
{
    g_enabled = false;
    if (!g_synced) return;
    if (xTaskGetCurrentTaskHandle() == g_host_task && g_conn != BLE_HS_CONN_HANDLE_NONE) {
        g_drop_after_reply = true;  /* called from a phone request: reply before disconnecting */
        ble_gap_adv_stop();
        return;
    }
    if (g_conn != BLE_HS_CONN_HANDLE_NONE) ble_gap_terminate(g_conn, BLE_ERR_REM_USER_CONN_TERM);
    ble_gap_adv_stop();
}

void ble_resume(void)
{
    g_enabled = true;
    if (g_synced && g_conn == BLE_HS_CONN_HANDLE_NONE && !ble_gap_adv_active()) advertise();
}

const char *ble_status(void)
{
    if (!g_enabled) return "Off";
    return g_conn != BLE_HS_CONN_HANDLE_NONE ? "Connected" : "Waiting";
}
