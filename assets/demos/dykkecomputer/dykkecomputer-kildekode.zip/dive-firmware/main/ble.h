/* ble.h — Bluetooth LE link to the phone app (NimBLE). Surface only. */
#pragma once

#include "divecore/proto.h"
#include "freertos/FreeRTOS.h"
#include "freertos/semphr.h"

/* Service and characteristic UUIDs, shared with the phone app (app/index.html). */
#define DC_SVC_UUID "6e400001-d1c0-4c2a-9b1e-7d1f0dc00001"
#define DC_RX_UUID  "6e400002-d1c0-4c2a-9b1e-7d1f0dc00001" /* phone -> computer, write */
#define DC_TX_UUID  "6e400003-d1c0-4c2a-9b1e-7d1f0dc00001" /* computer -> phone, notify */

/* dev is used under `lock`, which also guards the dive state. */
void ble_start(proto_dev_t *dev, SemaphoreHandle_t lock);
void ble_stop(void);    /* drop the phone and stop advertising (dive starts, or Bluetooth turned off) */
void ble_resume(void);  /* advertise again (on the surface with Bluetooth on) */
const char *ble_status(void); /* "Connected", "Waiting" or "Off", for the menu */
