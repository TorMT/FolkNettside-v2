/*
 * imu.h — accelerometer (QMI8658) and magnetometer (MMC5603) for the tilt-compensated compass.
 * Both on the main I2C bus. Register use follows the datasheets; neither driver has run on
 * hardware yet, so check WHO_AM_I and the raw values on the first bring-up.
 */
#pragma once

#include "driver/i2c_master.h"
#include "esp_err.h"

#define ADDR_QMI8658 0x6B   /* 0x6A when SA0 is pulled low */
#define ADDR_MMC5603 0x30

esp_err_t accel_init(i2c_master_bus_handle_t bus, i2c_master_dev_handle_t *dev);
/* Acceleration in g, sensor axes. */
esp_err_t accel_read(i2c_master_dev_handle_t dev, float a[3]);
esp_err_t mag_init(i2c_master_bus_handle_t bus, i2c_master_dev_handle_t *dev);
/* Field in microtesla, sensor axes. Takes one measurement (about 7 ms). */
esp_err_t mag_read(i2c_master_dev_handle_t dev, float m[3]);
