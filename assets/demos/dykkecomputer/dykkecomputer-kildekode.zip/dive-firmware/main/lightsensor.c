/* lightsensor.c — see lightsensor.h. Gain x1/8, 100 ms integration: 0.4608 lux per count on the VEML6030
 * (0.5376 on the VEML7700), good to about 30 000 lux. */
#ifdef LIGHT_VEML7700
#define LUX_PER_COUNT 0.5376f
#else
#define LUX_PER_COUNT 0.4608f
#endif
#include "lightsensor.h"

esp_err_t lightsensor_init(i2c_master_bus_handle_t bus, i2c_master_dev_handle_t *dev)
{
    i2c_device_config_t cfg = {.dev_addr_length = I2C_ADDR_BIT_LEN_7, .device_address = ADDR_VEML7700, .scl_speed_hz = 400000};
    esp_err_t err = i2c_master_bus_add_device(bus, &cfg, dev);
    if (err != ESP_OK) return err;
    /* ALS_CONF (0x00): gain 1/8 (bits 12:11 = 10), integration 100 ms (bits 9:6 = 0000), power on. Low byte first. */
    const uint8_t conf[3] = {0x00, 0x00, 0x10};
    return i2c_master_transmit(*dev, conf, sizeof(conf), 50);
}

esp_err_t lightsensor_read(i2c_master_dev_handle_t dev, float *lux)
{
    uint8_t reg = 0x04, b[2];
    esp_err_t err = i2c_master_transmit_receive(dev, &reg, 1, b, 2, 50);
    if (err == ESP_OK) *lux = (float)(b[0] | b[1] << 8) * LUX_PER_COUNT;
    return err;
}
