/* fuelgauge.c — see fuelgauge.h. MAX17048 datasheet: VCELL (0x02) 78.125 uV/LSB, SOC (0x04) 1/256 % per LSB. */
#include "fuelgauge.h"

esp_err_t fuelgauge_init(i2c_master_bus_handle_t bus, i2c_master_dev_handle_t *dev)
{
    i2c_device_config_t cfg = {.dev_addr_length = I2C_ADDR_BIT_LEN_7, .device_address = ADDR_MAX17048, .scl_speed_hz = 400000};
    esp_err_t err = i2c_master_bus_add_device(bus, &cfg, dev);
    if (err != ESP_OK) return err;
    uint8_t reg = 0x08, ver[2];                       /* VERSION register answers 0x001x */
    return i2c_master_transmit_receive(*dev, &reg, 1, ver, 2, 50);
}

static esp_err_t read16(i2c_master_dev_handle_t dev, uint8_t reg, uint16_t *v)
{
    uint8_t b[2];
    esp_err_t err = i2c_master_transmit_receive(dev, &reg, 1, b, 2, 50);
    if (err == ESP_OK) *v = (uint16_t)(b[0] << 8 | b[1]);
    return err;
}

esp_err_t fuelgauge_read(i2c_master_dev_handle_t dev, int *pct, int *mv)
{
    uint16_t soc, vcell;
    esp_err_t err = read16(dev, 0x04, &soc);
    if (err == ESP_OK) err = read16(dev, 0x02, &vcell);
    if (err != ESP_OK) return err;
    int p = (soc + 128) >> 8;
    *pct = p > 100 ? 100 : p;
    *mv = (int)((uint32_t)vcell * 78125u / 1000000u);
    return ESP_OK;
}
