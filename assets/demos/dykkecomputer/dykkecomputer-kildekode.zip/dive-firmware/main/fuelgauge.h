/* fuelgauge.h — MAX17048 battery fuel gauge on the main I2C bus (address 0x36). */
#pragma once

#include "driver/i2c_master.h"
#include "esp_err.h"

#define ADDR_MAX17048 0x36

esp_err_t fuelgauge_init(i2c_master_bus_handle_t bus, i2c_master_dev_handle_t *dev);
/* State of charge 0..100 % and cell voltage in mV. */
esp_err_t fuelgauge_read(i2c_master_dev_handle_t dev, int *pct, int *mv);
