/* board.h — breadboard pin map for the ESP32-S3-DevKitC-1 N16R8 (see the firmware plan). */
#pragma once

#include "driver/gpio.h"

/* I2C0: TCA9548A mux -> depth A (ch 0), depth B (ch 1); IMU, magnetometer, FRAM, RTC, fuel gauge on the main bus */
#define PIN_I2C_SDA        GPIO_NUM_8
#define PIN_I2C_SCL        GPIO_NUM_9
#define I2C_FREQ_HZ        400000
#define ADDR_TCA9548A      0x70
#define ADDR_MS5837        0x76
#define ADDR_FUEL_GAUGE    0x36   /* MAX17048, main bus */
#define ADDR_LIGHT_SENSOR  0x10   /* VEML7700, main bus, behind the display window */
#define MUX_CH_DEPTH_A     0
#define MUX_CH_DEPTH_B     1

/* SPI2: display + microSD */
#define PIN_SPI_SCLK       GPIO_NUM_12
#define PIN_SPI_MOSI       GPIO_NUM_11
#define PIN_SPI_MISO       GPIO_NUM_13
#define PIN_LCD_CS         GPIO_NUM_10
#define PIN_LCD_DC         GPIO_NUM_14
#define PIN_LCD_RST        GPIO_NUM_21
#define PIN_SD_CS          GPIO_NUM_15
#define PIN_LCD_BL         GPIO_NUM_16

/* I2S: PCM1808 ADC, transmitter coil on the left channel */
#define PIN_I2S_MCLK       GPIO_NUM_7
#define PIN_I2S_BCK        GPIO_NUM_4
#define PIN_I2S_LRCK       GPIO_NUM_5
#define PIN_I2S_DIN        GPIO_NUM_6
#define TX_SAMPLE_RATE     96000

/* 123 kHz (Suunto Tank POD) envelope comparator, timed by RMT. Use 38 or 48: whichever your board's LED does not. */
#define PIN_TX123_ENV      GPIO_NUM_48

/* Compass: how the sensor axes sit in the case. The compass maths wants x forward (towards the hand when
 * the screen is read on the forearm), y right, z down (into the arm). Set the signs and order for your PCB. */
#define ACCEL_TO_BODY(a, out) do { (out)[0] = (a)[0]; (out)[1] = -(a)[1]; (out)[2] = -(a)[2]; } while (0)
#define MAG_TO_BODY(m, out)   do { (out)[0] = (m)[0]; (out)[1] = -(m)[1]; (out)[2] = -(m)[2]; } while (0)
/* Swim speed assumed for dead reckoning until it is measured per diver (a 100 m timed swim). */
#define NAV_SWIM_SPEED_MPM 15.0f

/* UARTs */
#define GNSS_BAUD           9600      /* ATGM336H default */
#define PIN_GNSS_TX        GPIO_NUM_17
#define PIN_GNSS_RX        GPIO_NUM_18
#define PIN_SAFETY_TX      GPIO_NUM_1
#define PIN_SAFETY_RX      GPIO_NUM_2

/* Buttons (to ground, internal pull-up), alarms, wet contacts */
#define PIN_BTN_UP         GPIO_NUM_39
#define PIN_BTN_SELECT     GPIO_NUM_41
#define PIN_BTN_DOWN       GPIO_NUM_42
#define PIN_BUZZER         GPIO_NUM_40
#define PIN_VIBRATION      GPIO_NUM_47
#define PIN_WET            GPIO_NUM_3   /* touch channel 3: two contacts on the case, bridged by water */
#define WET_TOUCH_CHANNEL  TOUCH_PAD_NUM3
#define BACKLIGHT_PWM_HZ   5000
