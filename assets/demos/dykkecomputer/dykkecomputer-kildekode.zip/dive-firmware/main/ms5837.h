/* ms5837.h — MS5837-30BA over I2C, behind a TCA9548A channel. Maths lives in divecore/depth.c. */
#pragma once

#include "divecore/depth.h"
#include "driver/i2c_master.h"
#include "esp_err.h"

typedef struct {
    i2c_master_dev_handle_t dev;
    i2c_master_dev_handle_t mux;
    uint8_t mux_channel;
    ms5837_prom_t prom;
} ms5837_t;

esp_err_t ms5837_init(ms5837_t *s, i2c_master_bus_handle_t bus, uint8_t mux_addr, uint8_t mux_channel);
/* One conversion of each, OSR 8192 (~20 ms each). */
esp_err_t ms5837_read(ms5837_t *s, float *mbar, float *celsius);
