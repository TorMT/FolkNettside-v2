/* storage.h — settings in NVS, dive logs on the microSD card, firmware updates. */
#pragma once

#include <stdbool.h>
#include <stdint.h>

#include "divecore/divelog.h"
#include "divecore/gear.h"
#include "divecore/proto.h"
#include "divecore/settings.h"

/* Settings: defaults when nothing valid is stored. */
void storage_init(void);
void settings_load(dc_settings_t *s);
bool settings_save(const dc_settings_t *s);
/* Gear list from the phone, also in NVS. */
void gear_load(dc_gear_t *g);
bool gear_save(const dc_gear_t *g);

/* Dive plan from the phone, also in NVS (an invalid plan erases it). */
void plan_load(dc_divplan_t *p);
bool plan_save(const dc_divplan_t *p);

/* Tissue and oxygen state (persist.h). */
int state_load(uint8_t *blob, int cap);
bool state_save(const uint8_t *blob, int len);
/* Compass calibration (6 floats: offsets then scales). False when none is stored. */
bool magcal_load(float v[6]);
bool magcal_save(const float v[6]);
/* Wall clock from the phone or the GNSS receiver. */
void clock_set(uint32_t unix_s);
/* Tell the bootloader this firmware works; without it a freshly updated image is rolled back at the next restart. */
void ota_confirm(void);

/* Dive logs: /sdcard/DIVES/D0001.DLG ... */
bool sd_mount(void);
int logs_count(void *ctx);
int logs_size(void *ctx, int idx);
int logs_read(void *ctx, int idx, uint32_t off, uint8_t *buf, int len);

typedef struct {
    void *f;                 /* FILE * of the open log */
    divelog_writer_t w;
} logfile_t;
/* entry: the GNSS fix from before the dive, or NULL. */
bool log_start(logfile_t *lf, const dive_t *d, uint32_t unix_time, uint8_t interval_s, const double *entry_lat_lon);
/* Dead-reckoned position for the next sample. */
void log_nav(logfile_t *lf, float x_m, float y_m);
void log_tick(logfile_t *lf, const dive_t *d, float dt_s);
/* Completes the log and appends the gear used on the dive (may be NULL). */
void log_finish(logfile_t *lf, const dive_t *d, const dc_gear_t *gear);

/* Firmware update over Bluetooth (proto OTA steps). */
int ota_step(void *ctx, int step, uint32_t value, const uint8_t *data, int len);
