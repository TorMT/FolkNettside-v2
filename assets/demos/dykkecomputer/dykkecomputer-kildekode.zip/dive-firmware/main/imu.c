/* imu.c — see imu.h. */
#include "imu.h"

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

static esp_err_t wr(i2c_master_dev_handle_t d, uint8_t reg, uint8_t v)
{
    const uint8_t b[2] = {reg, v};
    return i2c_master_transmit(d, b, 2, 50);
}
static esp_err_t rd(i2c_master_dev_handle_t d, uint8_t reg, uint8_t *out, size_t n)
{
    return i2c_master_transmit_receive(d, &reg, 1, out, n, 50);
}

/* ---- QMI8658: WHO_AM_I 0x00 = 0x05; CTRL1 0x02; CTRL2 0x03 (accel range/ODR); CTRL7 0x08 (enable); AX_L 0x35 ---- */
esp_err_t accel_init(i2c_master_bus_handle_t bus, i2c_master_dev_handle_t *dev)
{
    i2c_device_config_t cfg = {.dev_addr_length = I2C_ADDR_BIT_LEN_7, .device_address = ADDR_QMI8658, .scl_speed_hz = 400000};
    esp_err_t err = i2c_master_bus_add_device(bus, &cfg, dev);
    if (err != ESP_OK) return err;
    uint8_t id = 0;
    err = rd(*dev, 0x00, &id, 1);
    if (err != ESP_OK) return err;
    if (id != 0x05) return ESP_ERR_INVALID_STATE;
    if ((err = wr(*dev, 0x02, 0x40)) != ESP_OK) return err;   /* CTRL1: address auto-increment */
    if ((err = wr(*dev, 0x03, 0x06)) != ESP_OK) return err;   /* CTRL2: +-2 g, 125 Hz */
    return wr(*dev, 0x08, 0x01);                              /* CTRL7: accelerometer on, gyro off */
}

esp_err_t accel_read(i2c_master_dev_handle_t dev, float a[3])
{
    uint8_t b[6];
    esp_err_t err = rd(dev, 0x35, b, 6);
    if (err != ESP_OK) return err;
    for (int i = 0; i < 3; i++) a[i] = (float)(int16_t)(b[2 * i] | b[2 * i + 1] << 8) / 16384.0f;   /* +-2 g: 16384 LSB/g */
    return ESP_OK;
}

/* ---- MMC5603: product ID 0x39 = 0x10; control 0 0x1B (bit 0 take measurement, bit 5 auto set/reset);
 *      status 0x18 (bit 6 measurement done); Xout0 0x00..: 20-bit, 0.00625 uT/LSB, zero at 524288 ---- */
esp_err_t mag_init(i2c_master_bus_handle_t bus, i2c_master_dev_handle_t *dev)
{
    i2c_device_config_t cfg = {.dev_addr_length = I2C_ADDR_BIT_LEN_7, .device_address = ADDR_MMC5603, .scl_speed_hz = 400000};
    esp_err_t err = i2c_master_bus_add_device(bus, &cfg, dev);
    if (err != ESP_OK) return err;
    uint8_t id = 0;
    err = rd(*dev, 0x39, &id, 1);
    if (err != ESP_OK) return err;
    return id == 0x10 ? ESP_OK : ESP_ERR_INVALID_STATE;
}

esp_err_t mag_read(i2c_master_dev_handle_t dev, float m[3])
{
    esp_err_t err = wr(dev, 0x1B, 0x21);                      /* measure the field, with automatic set/reset */
    if (err != ESP_OK) return err;
    uint8_t st = 0;
    for (int i = 0; i < 5; i++) {
        vTaskDelay(pdMS_TO_TICKS(3));
        if ((err = rd(dev, 0x18, &st, 1)) != ESP_OK) return err;
        if (st & 0x40) break;
    }
    if (!(st & 0x40)) return ESP_ERR_INVALID_STATE;
    uint8_t b[9];
    if ((err = rd(dev, 0x00, b, 9)) != ESP_OK) return err;
    for (int i = 0; i < 3; i++) {
        int32_t raw = (int32_t)b[2 * i] << 12 | (int32_t)b[2 * i + 1] << 4 | (int32_t)(b[6 + i] >> 4);
        m[i] = (float)(raw - 524288) * 0.00625f;
    }
    return ESP_OK;
}
