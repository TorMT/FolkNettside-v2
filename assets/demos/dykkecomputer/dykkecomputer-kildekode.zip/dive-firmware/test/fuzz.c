// Build and run (about 10 minutes), from the repository root:
//   gcc -std=gnu99 -g -O1 -fsanitize=address,undefined -fno-sanitize-recover=undefined -Icomponents/divecore/include components/divecore/src/*.c test/fuzz.c -lm -o build/fuzz && ./build/fuzz
/* Random and mutated requests into the Bluetooth protocol handler and the blob parsers, under ASan/UBSan. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "divecore/proto.h"
#include "divecore/divelog.h"
#include "divecore/persist.h"
#include "divecore/nmea.h"
static uint8_t logbuf[4096]; static int loglen;
static int lc(void *c){(void)c;return 1;} static int ls(void *c,int i){(void)c;(void)i;return loglen;}
static int lr(void *c,int i,uint32_t off,uint8_t *b,int len){(void)c;(void)i;if((int)off>=loglen)return 0;if((int)off+len>loglen)len=loglen-(int)off;memcpy(b,logbuf+off,(size_t)len);return len;}
static int ota(void *c,int s,uint32_t v,const uint8_t *d,int l){(void)c;(void)s;(void)v;(void)d;(void)l;return ST_OK;}
int main(void){
  dc_settings_t s; settings_default(&s); dc_gear_t g; gear_init(&g); dive_t d; dive_init(&d); dc_divplan_t pl; memset(&pl,0,sizeof pl);
  proto_dev_t dev={.log_count=lc,.log_size=ls,.log_read=lr,.ota=ota,.settings=&s,.gear=&g,.dive=&d,.plan=&pl,.fw_version="fuzz"};
  srand(1); uint8_t req[700], resp[4096]; long n=0;
  for(int it=0; it<400000; it++){
    int len=rand()%sizeof(req); for(int i=0;i<len;i++) req[i]=(uint8_t)rand();
    if(it%3==0){ req[0]=(uint8_t)(rand()%0x14); int pl_=len>4?len-4:0; if(rand()%2){req[2]=(uint8_t)pl_;req[3]=(uint8_t)(pl_>>8);} }
    if(it%7==0 && len>100){ settings_serialize(&s,req+4,96); req[0]=CMD_SET_SETTINGS; req[2]=96; req[3]=0; req[4+rand()%96]^=(uint8_t)(1<<(rand()%8)); if(rand()%4==0){/* fix crc */ uint32_t c=dc_crc32(req+4,92); memcpy(req+4+92,&c,4);} }
    if(it%11==0 && len>500){ dc_gear_t gg; gear_init(&gg); gg.n=(uint8_t)(rand()%13); for(int i=0;i<gg.n;i++){gg.item[i].type=(uint8_t)(rand()%10);memset(gg.item[i].name,'A'+i,16);} for(int k=0;k<5;k++) gg.gas_cyl[k]=(uint8_t)(rand()%20);
      int gl=gear_serialize(&gg,req+4,600); req[0]=CMD_SET_GEAR; req[2]=(uint8_t)gl; req[3]=(uint8_t)(gl>>8); if(rand()%2 && gl>8){ req[4+rand()%(gl-4)]=(uint8_t)rand(); uint32_t c=dc_crc32(req+4,gl-4); memcpy(req+4+gl-4,&c,4);} }
    int cap = it%5==0 ? rand()%64 : (int)sizeof(resp);
    d.state = (dive_state_t)(rand()%5);
    n += proto_handle(&dev, req, len, resp, cap);
    /* parsers on raw bytes */
    divelog_header_t h; loglen = rand()%sizeof(logbuf); for(int i=0;i<64&&i<loglen;i++) logbuf[i]=(uint8_t)rand();
    divelog_parse(logbuf, loglen, &h); dc_gear_t og; divelog_gear(logbuf, loglen, &og);
    dive_t d2; dive_init(&d2); persist_restore(&d2, req, len, (uint32_t)rand());
    nmea_parser_t np; nmea_fix_t fx; nmea_init(&np,&fx); for(int i=0;i<len;i++) nmea_feed(&np,(char)(it%2?req[i]:"$GPGA,0123456789.*NSEW\r\n"[req[i]%25]),&fx);
    settings_validate(&s); dive_tick(&d, 1.0f, (float)(rand()%60), 10.0f);
  }
  printf("fuzz done, %ld response bytes\n", n); return 0; }
