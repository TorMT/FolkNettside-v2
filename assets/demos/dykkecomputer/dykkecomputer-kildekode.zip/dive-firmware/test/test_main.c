/* Host unit tests for divecore. Build: cmake -S test -B build && cmake --build build && ./build/test_divecore */
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "divecore/deco.h"
#include "divecore/depth.h"
#include "divecore/dive.h"
#include "divecore/nav.h"
#include "divecore/oxygen.h"
#include "divecore/pelagic.h"
#include "divecore/txdsp.h"
#include "divecore/settings.h"
#include "divecore/gear.h"
#include "divecore/menu.h"
#include "divecore/divelog.h"
#include "divecore/proto.h"
#include "divecore/hw.h"
#include "divecore/nmea.h"
#include "divecore/persist.h"
#include "divecore/plan.h"
#include "divecore/predive.h"

static int fails = 0, checks = 0;
#define CHECK(cond, ...)                                  \
    do {                                                  \
        checks++;                                         \
        if (!(cond)) {                                    \
            fails++;                                      \
            printf("FAIL %s:%d: ", __FILE__, __LINE__);   \
            printf(__VA_ARGS__);                          \
            printf("\n");                                 \
        }                                                 \
    } while (0)
#define NEAR(a, b, tol) (fabs((double)(a) - (double)(b)) <= (tol))

static void test_pelagic(void)
{
    /* Published capture: transmitter 104308 at 248 psi, checksum 89. */
    const char *s = "0010000001101110101101001110101110000001111100000001011001";
    uint8_t bits[PELAGIC_BITS];
    for (int i = 0; i < PELAGIC_BITS; i++) bits[i] = (uint8_t)(s[i] - '0');
    pelagic_packet_t p;
    CHECK(pelagic_decode_bits(bits, PELAGIC_BITS, &p) == PELAGIC_OK, "published packet decodes");
    CHECK(p.serial == 104308u, "serial %u", p.serial);
    CHECK(p.psi == 248, "psi %u", p.psi);
    CHECK(p.checksum == 89, "checksum %u", p.checksum);

    /* Round trip through the encoder. */
    uint8_t hdr[2] = {8, 1};
    uint8_t enc[PELAGIC_BITS];
    CHECK(pelagic_encode_bits(104308u, 248, 0, hdr, enc), "encode");
    CHECK(memcmp(enc, bits, PELAGIC_BITS) == 0, "encoder reproduces the capture");

    /* A flipped bit must fail the checksum or the digit check. */
    enc[20] ^= 1;
    CHECK(pelagic_decode_bits(enc, PELAGIC_BITS, &p) != PELAGIC_OK, "corrupted packet rejected");

    /* Pauses with jitter -> bits. */
    uint16_t pauses[PELAGIC_BITS];
    for (int i = 0; i < PELAGIC_BITS; i++)
        pauses[i] = (uint16_t)((bits[i] ? PELAGIC_SIM_LONG_US : PELAGIC_SIM_SHORT_US) + ((i * 37) % 120) - 60);
    uint8_t got[PELAGIC_BITS];
    pelagic_bits_from_pauses(pauses, PELAGIC_BITS, got);
    CHECK(memcmp(got, bits, PELAGIC_BITS) == 0, "pause slicing");
    CHECK(NEAR(pelagic_psi_to_bar(3000), 206.8, 0.1), "psi to bar");
}

static void test_ms5837(void)
{
    /* Datasheet example values for the MS5837-30BA. */
    ms5837_prom_t prom = {{0, 34982, 36352, 20328, 22354, 26646, 26146, 0}};
    float mbar, c;
    ms5837_30ba_compensate(&prom, 4958179, 6815414, &mbar, &c);
    CHECK(NEAR(mbar, 3999.8, 1.0), "pressure %.1f mbar", mbar);
    CHECK(NEAR(c, 19.81, 0.05), "temperature %.2f C", c); /* TEMP 1981 */
    uint32_t d1 = ms5837_30ba_d1_for(&prom, 6815414, 1013.2f);
    ms5837_30ba_compensate(&prom, d1, 6815414, &mbar, NULL);
    CHECK(NEAR(mbar, 1013.2, 0.2), "inverse gives %.1f mbar", mbar);

    /* CRC: find the nibble that makes the PROM valid, then corrupt it. */
    int good = 0;
    for (int crc = 0; crc < 16; crc++) {
        prom.c[0] = (uint16_t)(crc << 12);
        if (ms5837_prom_ok(&prom)) good++;
    }
    CHECK(good == 1, "exactly one CRC nibble matches (%d)", good);
}

static void test_depth_check(void)
{
    depth_check_t c;
    depth_check_init(&c);
    depth_status_t st;
    float d = depth_check(&c, 20.0f, 20.1f, 1.0f, &st);
    CHECK(st == DEPTH_OK && NEAR(d, 20.05, 0.01), "agreeing sensors");
    for (int i = 0; i < 6; i++) d = depth_check(&c, 20.0f, 21.5f, 1.0f, &st);
    CHECK(st == DEPTH_DISAGREE && NEAR(d, 21.5, 0.01), "disagree uses the deeper");
    d = depth_check(&c, NAN, 18.0f, 1.0f, &st);
    CHECK(st == DEPTH_ONLY_B && NEAR(d, 18.0, 0.01), "one sensor lost");

    ascent_rate_t a;
    ascent_rate_init(&a, 4.0f);
    float r = 0;
    for (int i = 0; i <= 8; i++) r = ascent_rate_push(&a, (float)i, 20.0f - 0.25f * (float)i); /* 15 m/min */
    CHECK(NEAR(r, 15.0, 0.5), "ascent rate %.1f", r);
}

static void test_oxygen(void)
{
    dc_oxygen_t o;
    dc_oxygen_reset(&o);
    dc_oxygen_update(&o, 1.4f, 60.0f * 60.0f);
    CHECK(NEAR(o.cns_pct, 40.0, 0.5), "60 min at 1.4 = 40 %% CNS (%.1f)", o.cns_pct);
    dc_oxygen_reset(&o);
    dc_oxygen_update(&o, 1.0f, 60.0f);
    CHECK(NEAR(o.otu, 1.0, 0.001), "1 min at 1.0 bar = 1 OTU");
    o.cns_pct = 40.0f;
    dc_oxygen_update(&o, 0.21f, 90.0f * 60.0f);
    CHECK(NEAR(o.cns_pct, 20.0, 0.1), "CNS halves in 90 min at the surface");
}

static void test_deco(void)
{
    dc_cfg_t cfg;
    dc_cfg_default(&cfg);
    dc_gas_t gases[DC_MAX_GASES] = {{0.21f, 0.0f, true}};
    dc_tissues_t t;
    dc_tissues_init(&t, cfg.surface_bar);
    dc_plan_t plan;

    dc_plan(&t, 0.0f, 0, gases, &cfg, 0.0f, &plan);
    CHECK(!plan.in_deco && plan.ndl_min == 99, "surface: no deco");

    /* NDL must fall with depth. */
    int prev = 100;
    for (int d = 12; d <= 40; d += 4) {
        dc_tissues_init(&t, cfg.surface_bar);
        dc_tissues_update(&t, cfg.surface_bar, dc_ambient_bar((float)d, &cfg), (float)d / 18.0f * 60.0f, &gases[0]);
        dc_plan(&t, (float)d, 0, gases, &cfg, 0.0f, &plan);
        CHECK(plan.ndl_min <= prev, "NDL falls with depth (%d m: %d min)", d, plan.ndl_min);
        prev = plan.ndl_min;
    }

    /* 40 m for 25 min on air at GF 50/80: decompression with stops, last stop 3 m. */
    dc_tissues_init(&t, cfg.surface_bar);
    dc_tissues_update(&t, cfg.surface_bar, dc_ambient_bar(40.0f, &cfg), 120.0f, &gases[0]);
    dc_tissues_update(&t, dc_ambient_bar(40.0f, &cfg), dc_ambient_bar(40.0f, &cfg), 23.0f * 60.0f, &gases[0]);
    dc_plan(&t, 40.0f, 0, gases, &cfg, 0.0f, &plan);
    CHECK(plan.in_deco && plan.n_stops >= 3, "deco dive has stops (%d)", plan.n_stops);
    CHECK(NEAR(plan.stops[plan.n_stops - 1].depth_m, 3.0, 0.01), "last stop 3 m");
    for (int i = 1; i < plan.n_stops; i++)
        CHECK(plan.stops[i].depth_m < plan.stops[i - 1].depth_m, "stops get shallower");
    int stop_sum = 0;
    for (int i = 0; i < plan.n_stops; i++) stop_sum += plan.stops[i].minutes;
    CHECK(plan.tts_min >= stop_sum + 4, "TTS includes ascent (%d vs %d)", plan.tts_min, stop_sum);

    /* Adding EAN50 shortens the deco. */
    int tts_air = plan.tts_min;
    gases[1] = (dc_gas_t){0.50f, 0.0f, true};
    dc_plan(&t, 40.0f, 0, gases, &cfg, 0.0f, &plan);
    CHECK(plan.tts_min < tts_air, "EAN50 shortens TTS (%d < %d)", plan.tts_min, tts_air);
    int switched = 0;
    for (int i = 0; i < plan.n_stops; i++)
        if (plan.stops[i].gas == 1) switched = 1;
    CHECK(switched, "plan uses the deco gas");
    CHECK(NEAR(dc_mod_m(&gases[1], 1.6f, &cfg), 21.75, 0.3), "EAN50 MOD at 1.6 bar");
    CHECK(dc_best_gas(gases, 21.0f, &cfg) == 1 && dc_best_gas(gases, 30.0f, &cfg) == 0, "best gas by depth");

    /* Ceiling with GF 100 is shallower than with GF 30. */
    CHECK(dc_ceiling_m(&t, 1.0f, &cfg) < dc_ceiling_m(&t, 0.3f, &cfg), "GF ordering");
}

static void test_dive_sm(void)
{
    dive_t d;
    dive_init(&d);
    for (int i = 0; i < 30; i++) dive_tick(&d, 1.0f, 0.0f, 15.0f);
    CHECK(d.state == DIVE_SURFACE, "starts on the surface");
    for (int i = 0; i < 25; i++) dive_tick(&d, 1.0f, (float)i * 0.5f, 12.0f);
    CHECK(d.state == DIVE_ACTIVE, "dive starts after 20 s below 1.2 m");
    for (int i = 0; i < 600; i++) dive_tick(&d, 1.0f, 18.0f, 10.0f);
    CHECK(d.plan.ndl_min > 0 && d.plan.ndl_min < 99, "NDL shown at 18 m (%d)", d.plan.ndl_min);
    /* Rocket ascent sets the alarm. */
    for (int i = 0; i < 6; i++) dive_tick(&d, 1.0f, 18.0f - (float)i * 0.5f, 10.0f);
    CHECK(d.alarms & ALARM_ASCENT_FAST, "fast ascent alarm (%.1f m/min)", d.ascent_mpm);
    for (int i = 0; i < 310; i++) dive_tick(&d, 1.0f, 0.0f, 15.0f);
    CHECK(d.state == DIVE_INTERVAL && d.dive_count == 1, "dive ends after 5 min shallow");
    CHECK(d.nofly_min > 600.0f, "no-fly time set (%.0f min)", d.nofly_min);
    /* On the surface the diver breathes air whatever gas was last selected. */
    d.gases[2] = (dc_gas_t){1.0f, 0.0f, true};
    d.gas = 2;
    float cns0 = d.ox.cns_pct;
    for (int i = 0; i < 600; i++) dive_tick(&d, 1.0f, 0.0f, 15.0f);
    CHECK(d.ox.cns_pct <= cns0, "CNS does not rise on the surface (%.2f -> %.2f)", cns0, d.ox.cns_pct);
    CHECK(!(d.alarms & ALARM_PPO2_LOW), "no hypoxia alarm on the surface");

    /* Tank: 5 s packets dropping 1 bar each -> 12 bar/min. */
    dive_init(&d);
    for (int i = 0; i < 25; i++) dive_tick(&d, 1.0f, 10.0f, 12.0f);
    for (int k = 0; k < 40; k++) {
        dive_tank_reading(&d, 0, 200.0f - (float)k);
        for (int i = 0; i < 5; i++) dive_tick(&d, 1.0f, 10.0f, 12.0f);
    }
    CHECK(NEAR(d.tanks[0].rate_bar_min, 12.0, 0.5), "gas rate %.2f bar/min", d.tanks[0].rate_bar_min);
    CHECK(NEAR(d.sac_l_min, 12.0 * 12.0 / dc_ambient_bar(10.0f, &d.cfg), 3.0), "SAC %.1f L/min", d.sac_l_min);

    /* Pairing: two transmitters go to the two enabled gases; a third is ignored. */
    d.gases[1] = (dc_gas_t){0.50f, 0.0f, true};
    d.tanks[0].serial = 0;
    CHECK(dive_tank_for_serial(&d, 111111u, true) == 0, "first transmitter pairs to the bottom gas");
    CHECK(dive_tank_for_serial(&d, 222222u, true) == 1, "second pairs to the stage");
    CHECK(dive_tank_for_serial(&d, 333333u, true) == -1, "no free tank for a third");
    CHECK(dive_tank_for_serial(&d, 222222u, false) == 1, "known serial found without pairing");
    /* The stage's pressure does not count as gas use while breathing the bottom gas. */
    float r0 = d.tanks[1].rate_bar_min;
    dive_tank_reading(&d, 1, 200.0f);
    for (int i = 0; i < 5; i++) dive_tick(&d, 1.0f, 10.0f, 12.0f);
    dive_tank_reading(&d, 1, 190.0f);
    CHECK(d.tanks[1].rate_bar_min == r0, "stage rate untouched while not breathed");
}

static void test_nav(void)
{
    nav_t n;
    nav_init(&n, 0.15f);
    nav_set_origin(&n, 63.43, 10.39);
    nav_step(&n, 90.0f, 20.0f, 60.0f); /* 20 m east */
    nav_step(&n, 0.0f, 20.0f, 60.0f);  /* 20 m north */
    float b, dist;
    nav_home(&n, &b, &dist);
    CHECK(NEAR(dist, 28.28, 0.05) && NEAR(b, 225.0, 0.5), "home bearing %.1f dist %.1f", b, dist);
    CHECK(NEAR(nav_error_radius_m(&n), 6.0, 0.01), "error radius");
    /* Level unit pointing north: mag field forward and down. */
    CHECK(NEAR(compass_heading_deg(0, 0, 1, 20, 0, 40, 0), 0.0, 0.5), "level north");
    CHECK(NEAR(compass_heading_deg(0, 0, 1, 0, -20, 40, 0), 90.0, 0.5), "level east");
    /* Same heading with the wrist rolled 30 degrees. */
    float r = 30.0f * 3.14159265f / 180.0f;
    float h = compass_heading_deg(0, sinf(r), cosf(r), 20, 40 * sinf(r), 40 * cosf(r), 0);
    CHECK(NEAR(h, 0.0, 1.0) || NEAR(h, 360.0, 1.0), "tilt-compensated %.1f", h);
}

static void test_txdsp(void)
{
    static float buf[20000];
    uint32_t seed = 1;
    txdsp_t rx;
    pelagic_packet_t p;
    int ok = 0, total = 0;
    float noise_levels[] = {0.0f, 0.3f, 0.6f};
    for (int ni = 0; ni < 3; ni++) {
        for (int k = 0; k < 10; k++) {
            uint32_t serial = 100000u + (uint32_t)k * 12345u;
            uint16_t psi = (uint16_t)(3000 - k * 100);
            int n = txdsp_synthesize(serial, psi, 3, 96000.0f, 38000.0f, 1.0f, noise_levels[ni], &seed, buf, 20000);
            txdsp_init(&rx, 96000.0f, 38000.0f, 0.1f, 5000);
            bool got = false;
            for (int i = 0; i < n && !got; i += 256) got = txdsp_feed(&rx, buf + i, (n - i) < 256 ? (n - i) : 256, &p);
            total++;
            if (got && p.serial == serial && p.psi == psi) ok++;
        }
    }
    CHECK(ok == total, "synthesised packets decoded %d/%d (noise up to 0.6 of the carrier)", ok, total);
}

static void test_settings_menu(void)
{
    dc_settings_t s, r;
    settings_default(&s);
    s.gas[1].enabled = 1;
    s.gas[1].tx_serial = 104300u;
    uint8_t blob[DC_SETTINGS_BLOB_SIZE];
    CHECK(settings_serialize(&s, blob, sizeof(blob)) == DC_SETTINGS_BLOB_SIZE, "serialize");
    uint8_t blob2[DC_SETTINGS_BLOB_SIZE];
    CHECK(settings_deserialize(blob, sizeof(blob), &r) && settings_serialize(&r, blob2, sizeof(blob2)) &&
              memcmp(blob, blob2, sizeof(blob)) == 0 && r.gas[1].tx_serial == 104300u, "round trip");
    blob[10] ^= 0x40;
    CHECK(!settings_deserialize(blob, sizeof(blob), &r), "corrupted blob rejected by CRC");

    s.gf_low = 90; s.gf_high = 70; s.gas[2].o2_pct = 60; s.gas[2].he_pct = 60; s.gas[0].enabled = 0;
    settings_validate(&s);
    CHECK(s.gf_low <= s.gf_high && s.gas[2].o2_pct + s.gas[2].he_pct <= 100 && s.gas[0].enabled, "validation");

    /* Menu: Settings > Deco > GF low, raise by 2 steps (5 % each), store. */
    settings_default(&s);
    menu_t m;
    menu_init(&m, &s);
    menu_open(&m, false);
    menu_button(&m, BTN_DOWN);              /* Gear check */
    menu_button(&m, BTN_DOWN);              /* Deco */
    menu_button(&m, BTN_SELECT);            /* open Deco */
    menu_button(&m, BTN_SELECT);            /* edit GF low */
    menu_button(&m, BTN_UP);
    menu_button(&m, BTN_UP);
    menu_row_t rows[MENU_MAX_ROWS];
    char title[24];
    int n = menu_rows(&m, rows, MENU_MAX_ROWS, title, sizeof(title));
    CHECK(n == 7 && strcmp(title, "Deco") == 0 && rows[0].editing && strcmp(rows[0].value, "60 %") == 0, "editing shows 60 %% (%s)", rows[0].value);
    CHECK(s.gf_low == 50, "not stored before SELECT");
    CHECK(menu_button(&m, BTN_SELECT) == MENU_EV_CHANGED && s.gf_low == 60, "GF low stored");

    /* Back out to the top and Exit closes. */
    for (int i = 0; i < 6; i++) menu_button(&m, BTN_DOWN);  /* to Back */
    menu_button(&m, BTN_SELECT);
    menu_button(&m, BTN_UP);                                 /* back on Deco: up to Gear */
    menu_button(&m, BTN_UP);                                 /* Gases */
    menu_button(&m, BTN_UP);                                 /* wraps to Exit */
    CHECK(menu_button(&m, BTN_SELECT) == MENU_EV_CLOSED && !m.open, "Exit closes the menu");

    /* Gas 2 on, apply to a dive. */
    menu_open(&m, false);
    menu_button(&m, BTN_SELECT);            /* Gases */
    menu_button(&m, BTN_DOWN);              /* Gas 2 */
    menu_button(&m, BTN_SELECT);
    menu_button(&m, BTN_DOWN);
    menu_button(&m, BTN_DOWN);              /* In use */
    CHECK(menu_button(&m, BTN_SELECT) == MENU_EV_CHANGED && s.gas[1].enabled, "toggle gas 2 on");
    dive_t d;
    dive_init(&d);
    settings_apply(&s, &d);
    CHECK(d.gases[1].enabled && NEAR(d.gases[1].o2, 0.50, 1e-6) && NEAR(d.cfg.gf_low, 0.60, 1e-6), "settings applied");

    CHECK(NEAR(nav_turn_deg(350, 10), 20, 1e-3) && NEAR(nav_turn_deg(10, 350), -20, 1e-3) && NEAR(nav_turn_deg(90, 270), 180, 1e-3), "turn direction");
}

static void test_divelog(void)
{
    static uint8_t log[DIVELOG_HEADER + 2000 * DIVELOG_SAMPLE + DIVELOG_FOOTER + GEAR_BLOB_MAX];
    static char xml[400000];
    dive_t d;
    dive_init(&d);
    d.gases[1] = (dc_gas_t){0.50f, 0.0f, true};
    divelog_writer_t w;
    divelog_begin(&w, &d, 7, 1794470400u /* 2026-11-12 08:00 UTC */, 2, log);
    int len = DIVELOG_HEADER;
    for (int t = 0; t < 1800; t++) {
        float depth = t < 120 ? t / 4.0f : (t < 1500 ? 30.0f : 30.0f - (float)(t - 1500) / 10.0f);
        if (t % 5 == 0) dive_tank_reading(&d, 0, 220.0f - (float)t / 20.0f);
        if (t == 1600) dive_switch_gas(&d, 1);
        dive_tick(&d, 1.0f, depth, 12.0f);
        if (divelog_tick(&w, &d, 1.0f, log + len)) len += DIVELOG_SAMPLE;
    }
    uint8_t footer[DIVELOG_FOOTER];
    divelog_end(&w, &d, log, footer);
    memcpy(log + len, footer, DIVELOG_FOOTER);
    len += DIVELOG_FOOTER;

    divelog_header_t h;
    CHECK(divelog_parse(log, len, &h), "log parses");
    CHECK(h.n_samples == 900 && h.duration_s == 1800 && h.max_depth_cm == 3000 && h.dive_no == 7, "header (%u samples, %u cm)", h.n_samples, h.max_depth_cm);
    divelog_sample_t s;
    divelog_get_sample(log, 700, &s);
    CHECK(s.depth_cm == 3000 && s.tank_dbar[0] != DIVELOG_NO_TANK && s.tank_dbar[1] == DIVELOG_NO_TANK, "sample content");

    const uint8_t *logs[1] = {log};
    int lens[1] = {len};
    int n = divelog_uddf(logs, lens, 1, xml, sizeof(xml));
    CHECK(n > 0, "UDDF export (%d)", n);
    if (getenv("DIVELOG_DUMP")) {
        FILE *f = fopen(getenv("DIVELOG_DUMP"), "wb");
        if (f) { fwrite(log, 1, (size_t)len, f); fclose(f); }
    }
    CHECK(strstr(xml, "<datetime>2026-11-12T08:00:00</datetime>") != NULL, "UDDF date");
    CHECK(strstr(xml, "<greatestdepth>30.00</greatestdepth>") != NULL, "UDDF max depth");
    CHECK(strstr(xml, "<switchmix ref=\"d7_mix1\"/>") != NULL, "UDDF gas switch");
    CHECK(strstr(xml, "<tankpressurebegin>22000000</tankpressurebegin>") != NULL, "UDDF tank start in pascal");
    CHECK(strstr(xml, "<equipmentused>") == NULL, "no gear block, no equipment");

    /* Gear on this dive appended after the footer; the spare light stays out of the log. */
    dc_gear_t g;
    gear_init(&g);
    g.n = 4;
    g.item[0] = (gear_item_t){GEAR_CYLINDER, 0, 120, 232, 0, "Steel 12L"};
    g.item[1] = (gear_item_t){GEAR_SUIT, GEAR_ON_DIVE, 70, 0, 0, "Wetsuit 7mm <&>"};
    g.item[2] = (gear_item_t){GEAR_WEIGHTS, GEAR_ON_DIVE, 45, 0, 0, "Pockets"};
    g.item[3] = (gear_item_t){GEAR_LIGHT, 0, 0, 0, 0, "Spare light"};
    g.gas_cyl[0] = 1;
    int gb = divelog_gear_block(&g, log + len, GEAR_BLOB_MAX);
    int glen = len + gb;
    dc_gear_t back;
    CHECK(gb > 0 && divelog_parse(log, glen, &h) && divelog_gear(log, glen, &back) && back.n == 3 && back.gas_cyl[0] == 1,
          "gear block stored with the log (%d bytes, %d items)", gb, back.n);
    n = divelog_uddf(logs, (int[]){glen}, 1, xml, sizeof(xml));
    CHECK(n > 0 && strstr(xml, "<suit id=\"d7_g1\"><name>Wetsuit 7mm &lt;&amp;&gt;</name></suit>") &&
              strstr(xml, "<leadquantity>4.5</leadquantity>") && strstr(xml, "<link ref=\"d7_g0\"/>\n          <tankvolume>") &&
              !strstr(xml, "Spare light"), "UDDF equipment, lead and cylinder link");
    log[len + 20] ^= 1;
    CHECK(!divelog_parse(log, glen, &h), "corrupt gear block detected");
    log[len + 20] ^= 1;
    log[DIVELOG_HEADER + 100] ^= 1;
    CHECK(!divelog_parse(log, len, &h), "corrupt sample detected");
    CHECK(divelog_uddf(logs, lens, 1, xml, 100) == -1, "export refuses a corrupt log");
}

static uint8_t g_logs[2][4096];
static int g_log_len[2] = {0, 0};
static int t_count(void *c) { (void)c; return 2; }
static int t_size(void *c, int i) { (void)c; return g_log_len[i]; }
static int t_read(void *c, int i, uint32_t off, uint8_t *buf, int len)
{
    (void)c;
    if ((int)off >= g_log_len[i]) return 0;
    if ((int)off + len > g_log_len[i]) len = g_log_len[i] - (int)off;
    memcpy(buf, g_logs[i] + off, (size_t)len);
    return len;
}
static int g_stored = 0;
static bool t_store(void *c, const dc_settings_t *s) { (void)c; (void)s; g_stored++; return true; }

static void test_proto_and_alarms(void)
{
    /* Two small logs. */
    for (int k = 0; k < 2; k++) {
        dive_t d;
        dive_init(&d);
        divelog_writer_t w;
        divelog_begin(&w, &d, (uint16_t)(k + 1), 1794470400u + (uint32_t)k * 7200u, 2, g_logs[k]);
        int len = DIVELOG_HEADER;
        for (int t = 0; t < 200; t++) {
            dive_tick(&d, 1.0f, t < 100 ? t / 5.0f : 20.0f - (t - 100) / 5.0f, 12.0f);
            if (divelog_tick(&w, &d, 1.0f, g_logs[k] + len)) len += DIVELOG_SAMPLE;
        }
        divelog_end(&w, &d, g_logs[k], g_logs[k] + len);
        g_log_len[k] = len + DIVELOG_FOOTER;
    }
    dc_settings_t s;
    settings_default(&s);
    dive_t d;
    dive_init(&d);
    static dc_gear_t gear;
    gear_init(&gear);
    proto_dev_t dev = {.log_count = t_count, .log_size = t_size, .log_read = t_read, .settings_store = t_store,
                       .settings = &s, .gear = &gear, .dive = &d, .fw_version = "0.1-test", .battery_pct = 87};
    uint8_t req[64], resp[700];

    req[0] = CMD_INFO; req[1] = 9; req[2] = 0; req[3] = 0;
    int n = proto_handle(&dev, req, 4, resp, sizeof(resp));
    CHECK(n == 5 + 5 + 8 && resp[0] == (CMD_INFO | 0x80) && resp[1] == 9 && resp[2] == ST_OK && resp[7] == 87 && resp[8] == 2, "INFO");

    req[0] = CMD_LIST_LOGS; req[2] = 0;
    n = proto_handle(&dev, req, 4, resp, sizeof(resp));
    CHECK(n == 5 + 32 && resp[5 + 2] == 1 && resp[5 + 16 + 2] == 2, "LIST_LOGS has both dives");

    /* Download log 1 in 512-byte pieces and check it. */
    static uint8_t got[4096];
    int total = 0;
    for (;;) {
        req[0] = CMD_READ_LOG; req[2] = 8; req[3] = 0;
        req[4] = 1; req[5] = 0;
        req[6] = (uint8_t)total; req[7] = (uint8_t)(total >> 8); req[8] = 0; req[9] = 0;
        req[10] = 0; req[11] = 2; /* 512 */
        n = proto_handle(&dev, req, 12, resp, sizeof(resp));
        int len = resp[3] | (resp[4] << 8);
        memcpy(got + total, resp + 5, (size_t)len);
        total += len;
        if (len < 512) break;
    }
    divelog_header_t h;
    CHECK(total == g_log_len[1] && divelog_parse(got, total, &h) && h.dive_no == 2, "READ_LOG download (%d bytes)", total);

    /* Settings round trip over the protocol. */
    req[0] = CMD_GET_SETTINGS; req[2] = 0;
    n = proto_handle(&dev, req, 4, resp, sizeof(resp));
    CHECK(n == 5 + DC_SETTINGS_BLOB_SIZE, "GET_SETTINGS");
    dc_settings_t s2;
    settings_deserialize(resp + 5, DC_SETTINGS_BLOB_SIZE, &s2);
    s2.gf_high = 70;
    static uint8_t big[4 + DC_SETTINGS_BLOB_SIZE];
    big[0] = CMD_SET_SETTINGS; big[1] = 3; big[2] = DC_SETTINGS_BLOB_SIZE; big[3] = 0;
    settings_serialize(&s2, big + 4, DC_SETTINGS_BLOB_SIZE);
    n = proto_handle(&dev, big, sizeof(big), resp, sizeof(resp));
    CHECK(resp[2] == ST_OK && s.gf_high == 70 && g_stored == 1, "SET_SETTINGS stored");
    big[20] ^= 1;
    proto_handle(&dev, big, sizeof(big), resp, sizeof(resp));
    CHECK(resp[2] == ST_CRC, "SET_SETTINGS rejects a corrupted blob");
    d.state = DIVE_ACTIVE;
    big[20] ^= 1;
    proto_handle(&dev, big, sizeof(big), resp, sizeof(resp));
    CHECK(resp[2] == ST_BUSY_DIVING, "no settings changes during a dive");

    /* Gear from the phone: a 15 L cylinder with a transmitter carries gas 1, 6 kg lead. */
    d.state = DIVE_SURFACE;
    dc_gear_t pg;
    gear_init(&pg);
    pg.n = 3;
    pg.item[0] = (gear_item_t){GEAR_CYLINDER, GEAR_ON_DIVE, 150, 232, 104300u, "Faber 15L"};
    pg.item[1] = (gear_item_t){GEAR_WEIGHTS, GEAR_ON_DIVE, 60, 0, 0, "Belt"};
    pg.item[2] = (gear_item_t){GEAR_LIGHT, 0, 0, 0, 0, "Backup light"};
    pg.gas_cyl[0] = 1;
    pg.synced_unix = 1794470400u;
    static uint8_t greq[4 + GEAR_BLOB_MAX];
    int gl = gear_serialize(&pg, greq + 4, GEAR_BLOB_MAX);
    greq[0] = CMD_SET_GEAR; greq[1] = 4; greq[2] = (uint8_t)gl; greq[3] = (uint8_t)(gl >> 8);
    int before = g_stored;
    proto_handle(&dev, greq, 4 + gl, resp, sizeof(resp));
    CHECK(resp[2] == ST_OK && gear.n == 3 && s.gas[0].cylinder_l == 15 && s.gas[0].tx_serial == 104300u && g_stored == before + 1,
          "SET_GEAR: cylinder size and transmitter go to gas 1 (%d L, %lu)", s.gas[0].cylinder_l, (unsigned long)s.gas[0].tx_serial);
    req[0] = CMD_GET_GEAR; req[2] = 0; req[3] = 0;
    n = proto_handle(&dev, req, 4, resp, sizeof(resp));
    dc_gear_t back;
    CHECK(resp[2] == ST_OK && gear_deserialize(resp + 5, n - 5, &back) && strcmp(back.item[0].name, "Faber 15L") == 0 &&
              gear_lead_x10(&back) == 60 && gear_on_dive(&back) == 2, "GET_GEAR round trip");
    d.state = DIVE_ACTIVE;
    proto_handle(&dev, greq, 4 + gl, resp, sizeof(resp));
    CHECK(resp[2] == ST_BUSY_DIVING, "no gear changes during a dive");
    greq[4 + 20] ^= 1;
    d.state = DIVE_SURFACE;
    proto_handle(&dev, greq, 4 + gl, resp, sizeof(resp));
    CHECK(resp[2] == ST_CRC, "SET_GEAR rejects a corrupted list");
    /* Bad references are dropped: gas 2 pointing at the light, two gases on one cylinder. */
    pg.gas_cyl[1] = 3; pg.gas_cyl[2] = 1;
    gear_validate(&pg);
    CHECK(pg.gas_cyl[1] == 0 && pg.gas_cyl[2] == 0 && pg.gas_cyl[0] == 1, "gear validation drops bad cylinder links");
    /* A transmitter paired underwater goes back onto the cylinder. */
    pg.item[0].tx_serial = 0;
    s.gas[0].tx_serial = 555123u;
    CHECK(gear_take_serials(&pg, &s) && pg.item[0].tx_serial == 555123u, "paired serial copied to the cylinder");

    /* Alarms: too deep for the gas, graded ascent, refused gas switch. */
    dive_init(&d);
    d.gases[0] = (dc_gas_t){0.32f, 0.0f, true};
    d.gases[1] = (dc_gas_t){0.50f, 0.0f, true};
    for (int t = 0; t < 400; t++) dive_tick(&d, 1.0f, t < 180 ? t / 5.0f : 36.0f, 10.0f);
    CHECK((d.alarms & ALARM_MOD) && NEAR(dive_current_mod(&d), 33.3, 0.3), "EAN32 below its MOD at 36 m (MOD %.1f)", dive_current_mod(&d));
    CHECK(!dive_switch_gas(&d, 1), "EAN50 refused at 36 m");
    for (int t = 0; t < 8; t++) dive_tick(&d, 1.0f, 36.0f - (t + 1) * (8.5f / 60.0f), 10.0f);
    CHECK((d.alarms & ALARM_ASCENT_WARN) && !(d.alarms & ALARM_ASCENT_FAST), "8.5 m/min: warning only (%.1f)", d.ascent_mpm);
    float dd = d.depth_m;
    for (int t = 0; t < 8; t++) dive_tick(&d, 1.0f, dd - (t + 1) * (15.0f / 60.0f), 10.0f);
    CHECK(d.alarms & ALARM_ASCENT_FAST, "15 m/min: alarm (%.1f)", d.ascent_mpm);
    for (int t = 0; t < 600; t++) dive_tick(&d, 1.0f, dd - 2.0f - t / 10.0f > 20 ? dd - 2.0f - t / 10.0f : 20.0f, 10.0f);
    CHECK(dive_switch_gas(&d, 1), "EAN50 allowed at 20 m");

    /* Depth and time alarms set by the diver. */
    dive_init(&d);
    d.set.depth_alarm_m = 30.0f;
    d.set.time_alarm_min = 10.0f;
    for (int t = 0; t < 300; t++) dive_tick(&d, 1.0f, t < 150 ? t / 5.0f : 30.5f, 10.0f);
    CHECK((d.alarms & ALARM_DEPTH_LIMIT) && !(d.alarms & ALARM_TIME_LIMIT), "depth alarm at 30.5 m, no time alarm at 5 min");
    for (int t = 0; t < 330; t++) dive_tick(&d, 1.0f, 25.0f, 10.0f);
    CHECK(!(d.alarms & ALARM_DEPTH_LIMIT) && (d.alarms & ALARM_TIME_LIMIT), "time alarm after 10 min");
}

static int fake_logbook(void *ctx, int i, divelog_header_t *h)
{
    (void)ctx;
    if (i < 0) return 2;
    memset(h, 0, sizeof(*h));
    h->dive_no = (uint16_t)(7 - i);
    h->start_unix = 1794496500u - (uint32_t)i * 86400u;   /* 12 Nov 2026 15:15 UTC, then a day earlier */
    h->max_depth_cm = 4023;
    h->duration_s = 2850;
    h->had_deco = i == 0;
    return 1;
}

static void test_logbook_menu(void)
{
    dc_settings_t s;
    settings_default(&s);
    menu_t m;
    menu_init(&m, &s);
    m.logbook = fake_logbook;
    menu_open(&m, false);
    menu_button(&m, BTN_DOWN);
    menu_button(&m, BTN_DOWN);               /* Logbook (no dive -> no planner) */
    menu_button(&m, BTN_SELECT);
    menu_row_t rows[MENU_MAX_ROWS];
    char title[24];
    int n = menu_rows(&m, rows, MENU_MAX_ROWS, title, sizeof(title));
    CHECK(n == 4 && strcmp(title, "Logbook") == 0 && strcmp(rows[0].value, "2") == 0 &&
              strcmp(rows[1].label, "#7  12 Nov 15:15") == 0 && strcmp(rows[1].value, "40.2 m 48' D") == 0 &&
              strcmp(rows[2].label, "#6  11 Nov 15:15") == 0,
          "logbook rows (%s | %s)", rows[1].label, rows[1].value);
}

static void nmea_line(nmea_parser_t *p, nmea_fix_t *f, const char *body, bool good_sum, bool *changed)
{
    uint8_t sum = 0;
    for (const char *c = body; *c; c++) sum ^= (uint8_t)*c;
    char line[128];
    snprintf(line, sizeof(line), "$%s*%02X\r\n", body, good_sum ? sum : (uint8_t)(sum ^ 0x55));
    *changed = false;
    for (const char *c = line; *c; c++) *changed |= nmea_feed(p, *c, f);
}

static void test_magcal(void)
{
    /* A 45 uT field seen through a sensor with a hard-iron offset and one weak axis. */
    magcal_t c;
    magcal_begin(&c);
    const float off[3] = {30.0f, -12.0f, 5.0f}, gain[3] = {1.0f, 0.8f, 1.1f};
    for (int i = 0; i < 4000; i++) {          /* 10 Hz for a few minutes of turning it every way */
        float a = i * 0.05f, b = i * 0.0031f;
        float v[3] = {45.0f * cosf(a) * cosf(b), 45.0f * sinf(a) * cosf(b), 45.0f * sinf(b)};
        magcal_feed(&c, v[0] * gain[0] + off[0], v[1] * gain[1] + off[1], v[2] * gain[2] + off[2]);
    }
    magcal_result_t r;
    CHECK(magcal_finish(&c, &r) && fabsf(r.offset[0] - 30.0f) < 1.0f && fabsf(r.offset[1] + 12.0f) < 1.0f && fabsf(r.offset[2] - 5.0f) < 1.5f,
          "hard-iron offsets found (%.1f %.1f %.1f)", (double)r.offset[0], (double)r.offset[1], (double)r.offset[2]);
    /* North, level: heading 0 after calibration, far off before. */
    float mx = 20.0f * gain[0] + off[0], my = 0.0f * gain[1] + off[1], mz = 40.0f * gain[2] + off[2];
    float before = compass_heading_deg(0, 0, 1, mx, my, mz, 0);
    magcal_apply(&r, &mx, &my, &mz);
    float after = compass_heading_deg(0, 0, 1, mx, my, mz, 0);
    if (after > 180.0f) after -= 360.0f;
    CHECK(fabsf(after) < 4.0f && before > 8.0f && before < 352.0f, "heading north after calibration (%.1f deg, %.1f before)", (double)after, (double)before);
    magcal_begin(&c);
    for (int i = 0; i < 400; i++) magcal_feed(&c, 20.0f + (i % 5), 3.0f, 40.0f);
    CHECK(!magcal_finish(&c, &r), "a calibration without turning is rejected");
}

static void test_nmea(void)
{
    nmea_parser_t p;
    nmea_fix_t f;
    nmea_init(&p, &f);
    bool ch;
    /* Trondheim harbour: 63 deg 26.340 min N, 10 deg 23.706 min E */
    nmea_line(&p, &f, "GNGGA,151500.00,6326.3400,N,01023.7060,E,1,09,0.9,3.1,M,39.5,M,,", true, &ch);
    CHECK(ch && f.has_fix && fabs(f.lat - 63.4390) < 1e-4 && fabs(f.lon - 10.3951) < 1e-4 && f.sats == 9, "GGA position %.4f %.4f", f.lat, f.lon);
    nmea_line(&p, &f, "GNRMC,151500.00,A,6326.3400,N,01023.7060,E,0.1,0.0,121126,,,A", true, &ch);
    CHECK(ch && f.unix_time == 1794496500u, "RMC time %lu (12 Nov 2026 15:15:00 UTC)", (unsigned long)f.unix_time);
    double lat = f.lat;
    nmea_line(&p, &f, "GNGGA,151501.00,1111.1111,N,01111.1111,E,1,09,0.9,3.1,M,39.5,M,,", false, &ch);
    CHECK(!ch && f.lat == lat, "bad checksum ignored");
    nmea_line(&p, &f, "GPGGA,151502.00,3351.0000,S,15112.0000,W,1,05,1.5,3.1,M,0,M,,", true, &ch);
    CHECK(ch && f.lat < -33.84 && f.lat > -33.86 && f.lon < -151.19, "south and west are negative");
    nmea_line(&p, &f, "GNGGA,151503.00,,,,,0,00,99.9,,,,,,", true, &ch);
    CHECK(ch && !f.has_fix, "fix lost (underwater)");
}

static void test_persist(void)
{
    /* A 30 m dive, then the computer restarts 1 h into the surface interval. */
    dive_t d;
    dive_init(&d);
    for (int t = 0; t < 1500; t++) dive_tick(&d, 1.0f, t < 100 ? t * 0.3f : 30.0f, 10.0f);
    for (int t = 0; t < 400; t++) dive_tick(&d, 1.0f, d.depth_m > 0.15f ? d.depth_m - 0.15f : 0.0f, 10.0f);
    for (int t = 0; t < 400; t++) dive_tick(&d, 1.0f, 0.0f, 10.0f);
    CHECK(d.state == DIVE_INTERVAL && d.dive_count == 1, "dive done");
    uint8_t blob[PERSIST_BLOB];
    uint32_t t0 = 1794496500u;
    CHECK(persist_save(&d, t0, blob, sizeof(blob)) == PERSIST_BLOB, "state saved");

    /* What it should look like an hour later if it had stayed on. */
    dive_t ref = d;
    for (int t = 0; t < 3600; t++) dive_tick(&ref, 1.0f, 0.0f, 10.0f);

    dive_t r;
    dive_init(&r);
    CHECK(persist_restore(&r, blob, sizeof(blob), t0 + 3600) == PERSIST_RESTORED && r.state == DIVE_INTERVAL && r.dive_count == 1,
          "restored after a restart");
    float worst = 0;
    for (int i = 0; i < DC_NUM_TISSUES; i++) { float e = fabsf(r.tissues.n2[i] - ref.tissues.n2[i]); if (e > worst) worst = e; }
    CHECK(worst < 0.002f && fabsf(r.nofly_min - ref.nofly_min) < 1.0f, "tissues brought forward 1 h match a computer that stayed on (%.4f bar)", (double)worst);
    dive_tick(&r, 1.0f, 0.0f, 10.0f);
    dive_t fresh;
    dive_init(&fresh);
    dc_plan_t pr, pf;
    dc_plan(&r.tissues, 18.0f, 0, r.gases, &r.cfg, 0.0f, &pr);     /* 18 m: the slower tissues decide */
    dc_plan(&fresh.tissues, 18.0f, 0, fresh.gases, &fresh.cfg, 0.0f, &pf);
    CHECK(pr.ndl_min < pf.ndl_min, "repeat-dive NDL survives the restart (%d < %d min)", pr.ndl_min, pf.ndl_min);

    /* No clock: nothing credited, tissues exactly as saved (the cautious side). */
    dive_init(&r);
    CHECK(persist_restore(&r, blob, sizeof(blob), 0) == PERSIST_RESTORED_NO_CLOCK && r.tissues.n2[3] == d.tissues.n2[3], "no clock: no time credited");
    /* Damaged blob: fresh tissues, and the caller is told. */
    blob[40] ^= 0x10;
    dive_init(&r);
    CHECK(persist_restore(&r, blob, sizeof(blob), t0) == PERSIST_NONE && r.dive_count == 0, "damaged blob rejected");

    /* Restart during a dive. */
    dive_init(&d);
    for (int t = 0; t < 900; t++) dive_tick(&d, 1.0f, t < 100 ? t * 0.3f : 30.0f, 10.0f);
    persist_save(&d, t0, blob, sizeof(blob));
    dive_init(&r);
    CHECK(persist_restore(&r, blob, sizeof(blob), t0 + 120) == PERSIST_INTERRUPTED_DIVE && r.dive_count == 1 && r.nofly_min >= 17.9f * 60.0f,
          "restart during a dive is flagged, tissues kept");

    /* The phone sets the clock. */
    dc_settings_t s;
    settings_default(&s);
    proto_dev_t dev = {.settings = &s, .dive = &r};
    uint8_t req[8] = {CMD_SET_TIME, 9, 4, 0, 0x34, 0x12, 0xF6, 0x6A}, resp[16];   /* 0x6AF61234 */
    proto_handle(&dev, req, 8, resp, sizeof(resp));
    CHECK(resp[2] == ST_OK && dev.now_unix == 0x6AF61234u, "clock set from the phone");
    req[7] = 0x10;
    proto_handle(&dev, req, 8, resp, sizeof(resp));
    CHECK(resp[2] == ST_BAD_REQUEST, "a clock before 2020 is refused");
}

static void test_hw(void)
{
    alarm_notifier_t n;
    alarm_notifier_init(&n);
    bool vib, buzz;
    int on = 0;
    /* A new warning: three short pulses, then quiet until a minute has passed. */
    for (uint32_t t = 1000; t < 3000; t += 10) { alarm_notifier_step(&n, ALARM_NDL_LOW, ALARM_CRITICAL_MASK, t, true, true, &vib, &buzz); on += vib; }
    CHECK(on == 36, "warning: 3 x 120 ms of vibration (%d ms)", on * 10);
    on = 0;
    for (uint32_t t = 3000; t < 59000; t += 10) { alarm_notifier_step(&n, ALARM_NDL_LOW, ALARM_CRITICAL_MASK, t, true, true, &vib, &buzz); on += vib; }
    CHECK(on == 0, "quiet between reminders");
    for (uint32_t t = 59000; t < 63000; t += 10) { alarm_notifier_step(&n, ALARM_NDL_LOW, ALARM_CRITICAL_MASK, t, true, true, &vib, &buzz); on += vib; }
    CHECK(on == 36, "reminder after a minute");
    /* Critical: pulses for as long as it lasts, and vibrates even with vibration and sound off. */
    on = 0;
    int buzzed = 0;
    for (uint32_t t = 70000; t < 76000; t += 10) { alarm_notifier_step(&n, ALARM_CEILING, ALARM_CRITICAL_MASK, t, false, false, &vib, &buzz); on += vib; buzzed += buzz; }
    CHECK(on == 400 && buzzed == 0, "critical: 400 of 600 ms, always vibrates, no sound when sound is off (%d)", on);
    alarm_notifier_step(&n, 0, ALARM_CRITICAL_MASK, 76000, true, true, &vib, &buzz);
    CHECK(!vib && !buzz, "silent with no alarm");

    CHECK(backlight_pct(3, 0.1f, true) == 15 && backlight_pct(3, 10000.0f, true) == 100 && backlight_pct(3, 30.0f, true) > 35 &&
              backlight_pct(3, 30.0f, true) < 60, "auto backlight: dark 15 %%, daylight 100 %%, 30 lux %d %%", backlight_pct(3, 30.0f, true));
    CHECK(backlight_pct(5, 30.0f, true) > backlight_pct(3, 30.0f, true) && backlight_pct(1, 30.0f, true) < backlight_pct(3, 30.0f, true),
          "brightness level shifts the auto curve");
    CHECK(backlight_pct(2, 5000.0f, false) == 40, "manual backlight ignores the sensor");

    /* Sleep when dry and idle, wake when wet, and a dive still starts from sleep. */
    dive_t d;
    dive_init(&d);
    for (int t = 0; t < 599; t++) dive_tick(&d, 1.0f, 0.0f, 10.0f);
    CHECK(d.state == DIVE_SURFACE, "awake before the sleep time");
    for (int t = 0; t < 5; t++) dive_tick(&d, 1.0f, 0.0f, 10.0f);
    CHECK(d.state == DIVE_SLEEP, "asleep after 10 dry minutes");
    dive_set_wet(&d, true);
    CHECK(d.state == DIVE_SURFACE, "wet contacts wake it");
    for (int t = 0; t < 1200; t++) dive_tick(&d, 1.0f, 0.0f, 10.0f);
    CHECK(d.state == DIVE_SURFACE, "stays awake while wet");
    dive_set_wet(&d, false);
    for (int t = 0; t < 700; t++) dive_tick(&d, 1.0f, 0.0f, 10.0f);
    CHECK(d.state == DIVE_SLEEP, "sleeps again when dry");
    for (int t = 0; t < 40; t++) dive_tick(&d, 1.0f, 3.0f, 10.0f);   /* contacts failed: depth alone */
    CHECK(d.state == DIVE_ACTIVE, "a dive starts from sleep on depth alone");

    dc_settings_t s, r;
    settings_default(&s);
    s.vibrate = 0; s.sleep_min = 0; s.auto_bright = 0;
    uint8_t b[DC_SETTINGS_BLOB_SIZE];
    settings_serialize(&s, b, sizeof(b));
    CHECK(settings_deserialize(b, sizeof(b), &r) && r.vibrate == 0 && r.sound == 1 && r.auto_bright == 0 && r.sleep_min == 0, "hardware settings round trip");
}

static void test_plan(void)
{
    dc_settings_t s;
    settings_default(&s);
    s.gas[0].cylinder_l = 24;
    s.gas[0].fill_bar = 220;
    s.gas[1].enabled = 1;       /* EAN50 */
    dc_divplan_t p;
    CHECK(divplan_compute(&p, 40, 25, 20, &s, NULL) && p.valid && p.n_stops >= 3 && p.stop[p.n_stops - 1].depth_m == 3,
          "40 m 25 min plan has stops (%d, TTS %d)", p.n_stops, p.tts_min);

    /* The same dive through the dive computer's own state machine: TTS at the end of the bottom time agrees. */
    dive_t d;
    dive_init(&d);
    settings_apply(&s, &d);
    float t = 0, depth = 0;
    while (t < 25 * 60) {
        depth = t / 60.0f * DIVPLAN_DESCENT_MPM;
        if (depth > 40.0f) depth = 40.0f;
        dive_tick(&d, 1.0f, depth, 10.0f);
        t += 1.0f;
    }
    /* The live plan must be the planner's plan: same anchor (the first stop, not where deco first began) and stops. */
    dc_plan_t fresh;
    dc_plan(&d.tissues, 40.0f, 0, d.gases, &d.cfg, 0.0f, &fresh);
    dc_plan_t live;
    dc_plan(&d.tissues, 40.0f, 0, d.gases, &d.cfg, d.gf_anchor_m, &live);
    bool same = fresh.n_stops == live.n_stops;
    for (int i = 0; same && i < fresh.n_stops; i++) same = fresh.stops[i].minutes == live.stops[i].minutes && fresh.stops[i].depth_m == live.stops[i].depth_m;
    CHECK(same && live.gf_anchor_m == fresh.gf_anchor_m && live.gf_anchor_m >= fresh.first_stop_m && live.gf_anchor_m >= 9.0f,
          "live GF anchor follows the first stop down (%.0f m, fresh %.0f m, first stop %.0f m)", (double)live.gf_anchor_m,
          (double)fresh.gf_anchor_m, (double)fresh.first_stop_m);
    int diff = d.plan.tts_min - p.tts_min;
    CHECK(diff >= -2 && diff <= 2, "plan TTS %d vs computer at end of bottom %d", p.tts_min, d.plan.tts_min);
    /* Bottom gas by hand: descent 2.2 min at ~3.0 bar avg, 22.8 min at 5.03 bar, x 20 L/min = 2427 L, plus ascent. */
    CHECK(p.gas_bar[0] > 2427 / 24 + 50 && p.gas_bar[0] < 2427 / 24 + 50 + 40 && (p.gas_ok & 1), "bottom gas %u bar of 220", p.gas_bar[0]);
    CHECK(p.gas_bar[1] > 50 && (p.gas_ok & 2), "deco gas %u bar", p.gas_bar[1]);

    uint8_t b[DIVPLAN_BLOB];
    dc_divplan_t r;
    p.created_unix = 1794496500u;
    CHECK(divplan_serialize(&p, b, sizeof(b)) == DIVPLAN_BLOB && divplan_deserialize(b, sizeof(b), &r) && r.tts_min == p.tts_min &&
              r.stop[0].minutes == p.stop[0].minutes && r.gas_bar[0] == p.gas_bar[0], "plan blob round trip");
    b[10] ^= 1;
    CHECK(!divplan_deserialize(b, sizeof(b), &r), "plan blob CRC");

    /* Plan alarms: deeper than planned, then past the bottom time. */
    dc_divplan_t short_plan;
    divplan_compute(&short_plan, 30, 20, 20, &s, NULL);
    CHECK(divplan_alarms(&short_plan, &d) & ALARM_PLAN_DEEPER, "40 m on a 30 m plan: deeper");
    CHECK(divplan_alarms(&short_plan, &d) & ALARM_PLAN_TIME, "25 min on a 20 min plan: over time");
    CHECK(!(divplan_alarms(&p, &d) & (ALARM_PLAN_DEEPER | ALARM_PLAN_DECO)), "on plan: no deeper/deco warning");

    /* Not enough gas: 12 L for the same dive. */
    s.gas[0].cylinder_l = 12;
    divplan_compute(&p, 40, 25, 20, &s, NULL);
    CHECK(!(p.gas_ok & 1), "12 L is short for 40 m 25 min (%u bar)", p.gas_bar[0]);

    /* Through the protocol: set, get, refused while diving. */
    proto_dev_t dev = {.settings = &s, .dive = &d, .plan = &r};
    uint8_t req[4 + DIVPLAN_BLOB], resp[256];
    req[0] = CMD_SET_PLAN; req[1] = 1; req[2] = DIVPLAN_BLOB; req[3] = 0;
    divplan_serialize(&p, req + 4, DIVPLAN_BLOB);
    proto_handle(&dev, req, sizeof(req), resp, sizeof(resp));
    CHECK(resp[2] == ST_BUSY_DIVING, "plan refused during a dive");
    dive_t surf;
    dive_init(&surf);
    dev.dive = &surf;
    proto_handle(&dev, req, sizeof(req), resp, sizeof(resp));
    CHECK(resp[2] == ST_OK && r.valid && r.gas_bar[0] == p.gas_bar[0], "plan stored from the phone");
}

static void test_predive(void)
{
    dc_settings_t s;
    settings_default(&s);
    s.gas[1].enabled = 1;
    dive_t d;
    dive_init(&d);
    settings_apply(&s, &d);
    dive_set_battery(&d, 80);
    int t = dive_tank_for_serial(&d, 104300, true);
    dive_tank_reading(&d, t, 215.0f);
    dive_tank_battery(&d, t, TX_BATT_OK);
    settings_take_serials(&s, &d);
    dc_gear_t g;
    gear_init(&g);
    g.n = 1;
    g.item[0] = (gear_item_t){.type = GEAR_CYLINDER, .flags = GEAR_ON_DIVE, .size_x10 = 120, .work_bar = 232, .tx_serial = 104300, .name = "Faber 12L"};
    g.gas_cyl[0] = 1;
    g.synced_unix = 1794490000u;
    predive_env_t env = {.depth_sensors = 2, .now_unix = 1794496500u};
    predive_t pd;
    predive_run(&d, &s, &g, NULL, &env, &pd);
    int found_t1 = 0, found_t2 = 0, found_gear = 0;
    for (int i = 0; i < pd.n; i++) {
        if (strncmp(pd.item[i].label, "T1", 2) == 0) found_t1 = pd.item[i].level == PD_OK;
        if (strncmp(pd.item[i].label, "T2", 2) == 0) found_t2 = pd.item[i].level == PD_WARN;
        if (strcmp(pd.item[i].label, "Gear") == 0) found_gear = pd.item[i].level == PD_WARN;   /* gas 2 has no cylinder */
    }
    CHECK(found_t1 && found_t2 && found_gear && pd.worst == PD_WARN && pd.n_fail == 0, "pre-dive: T1 OK, T2 not paired, gas 2 no cylinder (%d items)", pd.n);
    g.item[0].tx_serial = 999999;
    dive_set_battery(&d, 10);
    predive_run(&d, &s, &g, NULL, &env, &pd);
    CHECK(pd.worst == PD_FAIL && pd.n_fail == 2, "wrong transmitter on the cylinder and flat battery stop the dive (%d)", pd.n_fail);
    uint8_t b[2 + PREDIVE_MAX * 49];
    int n = predive_serialize(&pd, b, sizeof(b));
    CHECK(n == 2 + pd.n * 49 && b[1] == PD_FAIL && strcmp((char *)b + 3, "Battery") == 0, "pre-dive blob for the phone");

    menu_t m;
    menu_init(&m, &s);
    m.predive = &pd;
    menu_open(&m, false);
    menu_row_t rows[MENU_MAX_ROWS];
    char title[24];
    menu_rows(&m, rows, MENU_MAX_ROWS, title, sizeof(title));
    CHECK(strcmp(rows[0].label, "Pre-dive check") == 0 && strcmp(rows[0].value, "STOP: 2") == 0 && rows[0].level == 2, "menu starts with the check");
    menu_button(&m, BTN_SELECT);
    int nr = menu_rows(&m, rows, MENU_MAX_ROWS, title, sizeof(title));
    CHECK(nr == pd.n + 1 && rows[0].level == 2 && strcmp(rows[0].value, "10 %: charge first") == 0, "check page lists every line (%s)", rows[0].value);
}

static void test_battery(void)
{
    dive_t d;
    dive_init(&d);
    CHECK(d.battery_pct == -1 && dive_battery_ok_for_dive(&d), "battery unknown by default");
    dive_set_battery(&d, 25);
    dive_tick(&d, 1.0f, 0.0f, 10.0f);
    CHECK(!dive_battery_ok_for_dive(&d) && !(d.alarms & ALARM_BATTERY_LOW), "25 %%: charge before diving, no alarm yet");
    dive_set_battery(&d, 12);
    dive_tick(&d, 1.0f, 0.0f, 10.0f);
    CHECK(d.alarms & ALARM_BATTERY_LOW, "12 %%: battery alarm");
    dive_set_charging(&d, true);
    dive_tick(&d, 1.0f, 0.0f, 10.0f);
    CHECK(!(d.alarms & ALARM_BATTERY_LOW), "no battery alarm on the charger");

    /* Transmitter battery from the packet's nibble, through the alarms, the log and the protocol. */
    dive_init(&d);
    dive_set_battery(&d, 80);
    int t = dive_tank_for_serial(&d, 104300, true);
    dive_tank_reading(&d, t, 200.0f);
    dive_tank_battery(&d, t, pelagic_battery_state(3));
    dive_tick(&d, 1.0f, 0.0f, 10.0f);
    CHECK(!(d.alarms & ALARM_TX_BATTERY) && d.tanks[0].battery == TX_BATT_OK, "transmitter battery OK");
    divelog_writer_t w;
    uint8_t hdr[DIVELOG_HEADER], ftr[DIVELOG_FOOTER];
    divelog_begin(&w, &d, 1, 1794496500u, 2, hdr);
    dive_tank_battery(&d, t, pelagic_battery_state(1));
    dive_tick(&d, 1.0f, 0.0f, 10.0f);
    CHECK(d.alarms & ALARM_TX_BATTERY, "weak transmitter battery warns");
    dive_set_battery(&d, 71);
    divelog_end(&w, &d, hdr, ftr);
    divelog_header_t h;
    CHECK(divelog_parse_header(hdr, &h) && h.battery_start == 80 && h.battery_end == 71 && h.tx_low == 1, "log keeps battery start/end and weak transmitters");

    dc_settings_t s;
    settings_default(&s);
    proto_dev_t dev = {.settings = &s, .dive = &d, .battery_pct = 100};
    uint8_t req[4] = {CMD_TANKS, 5, 0, 0}, resp[128];
    int n = proto_handle(&dev, req, 4, resp, sizeof(resp));
    CHECK(n == 5 + 60 && resp[2] == ST_OK && resp[5] == 1 && resp[6] == TX_BATT_LOW && (resp[7] | resp[8] << 8 | resp[9] << 16) == 104300 &&
              (resp[11] | resp[12] << 8) == 2000, "CMD_TANKS reports pressure and transmitter battery");
    uint8_t ireq[4] = {CMD_INFO, 6, 0, 0};
    proto_handle(&dev, ireq, 4, resp, sizeof(resp));
    CHECK(resp[5 + 2] == 71, "CMD_INFO reports the fuel gauge battery");
}

static void test_dive_menu(void)
{
    dc_settings_t s;
    settings_default(&s);
    s.gas[0].o2_pct = 32;
    s.gas[1].enabled = 1;    /* EAN50 */
    s.gas[2].enabled = 1;    /* O2 */
    dive_t d;
    dive_init(&d);
    settings_apply(&s, &d);
    for (int t = 0; t < 400; t++) dive_tick(&d, 1.0f, t < 150 ? t / 5.0f : 30.0f, 10.0f);
    menu_t m;
    menu_init(&m, &s);
    m.dive = &d;
    menu_open(&m, true);
    menu_row_t rows[MENU_MAX_ROWS];
    char title[24];
    int n = menu_rows(&m, rows, MENU_MAX_ROWS, title, sizeof(title));
    CHECK(n == 5 && strcmp(title, "Dive menu") == 0 && strcmp(rows[0].label, "Switch to EAN50") == 0 && rows[0].disabled &&
              strcmp(rows[0].value, "too deep") == 0 && strcmp(rows[2].label, "Lock bearing") == 0,
          "dive menu: gases, lock, brightness, back (%d rows, %s %s)", n, rows[0].label, rows[0].value);
    for (int i = 0; i < n; i++) CHECK(strstr(rows[i].label, "GF") == NULL && strstr(rows[i].label, "Bluetooth") == NULL, "no deco or Bluetooth settings underwater: %s", rows[i].label);
    CHECK(menu_button(&m, BTN_SELECT) == MENU_EV_NONE && m.open, "EAN50 refused at 30 m");
    menu_button(&m, BTN_DOWN);
    menu_button(&m, BTN_DOWN);
    CHECK(menu_button(&m, BTN_SELECT) == MENU_EV_LOCK && !m.open, "lock bearing closes the menu");
    for (int t = 0; t < 200; t++) dive_tick(&d, 1.0f, 30.0f - t / 10.0f > 20.0f ? 30.0f - t / 10.0f : 20.0f, 10.0f);
    m.bearing_locked = true;
    menu_open(&m, true);
    menu_rows(&m, rows, MENU_MAX_ROWS, title, sizeof(title));
    CHECK(!rows[0].disabled && strcmp(rows[0].value, "MOD 21 m") == 0 && strcmp(rows[2].label, "Unlock bearing") == 0,
          "at 20 m EAN50 allowed (%s)", rows[0].value);
    CHECK(menu_button(&m, BTN_SELECT) == MENU_EV_SWITCH_GAS && m.ev_arg == 1 && dive_switch_gas(&d, 1), "switch to EAN50 from the menu");

    /* Surface menu: Bluetooth page, new alarm settings. */
    menu_open(&m, false);
    for (int i = 0; i < 8; i++) menu_button(&m, BTN_DOWN);   /* Bluetooth (Dive planner shows because m.dive is set) */
    menu_button(&m, BTN_SELECT);
    m.ble_status = "Connected";
    n = menu_rows(&m, rows, MENU_MAX_ROWS, title, sizeof(title));
    CHECK(strcmp(title, "Bluetooth") == 0 && strcmp(rows[0].value, "On") == 0 && strcmp(rows[1].value, "Connected") == 0 &&
              strcmp(rows[2].value, "always off") == 0, "Bluetooth page");
    CHECK(menu_button(&m, BTN_SELECT) == MENU_EV_CHANGED && s.bluetooth == 0, "Bluetooth off");
    menu_rows(&m, rows, MENU_MAX_ROWS, title, sizeof(title));
    CHECK(strcmp(rows[1].value, "Off") == 0, "phone status shows Off");

    /* Surface planner: NDLs from the tissues now, so a second dive gets shorter limits. */
    {
        settings_default(&s);
        s.gas[0].o2_pct = 32;
        dive_t fresh;
        dive_init(&fresh);
        settings_apply(&s, &fresh);
        menu_t pm;
        menu_init(&pm, &s);
        pm.dive = &fresh;
        menu_open(&pm, false);
        menu_button(&pm, BTN_DOWN);
        menu_button(&pm, BTN_DOWN);              /* Dive planner */
        menu_button(&pm, BTN_SELECT);
        n = menu_rows(&pm, rows, MENU_MAX_ROWS, title, sizeof(title));
        CHECK(strcmp(title, "Dive planner") == 0 && strcmp(rows[0].value, "clear") == 0 && strcmp(rows[n - 2].label, "33 m") == 0,
              "planner rows stop at the EAN32 MOD (last %s)", rows[n - 2].label);
        int ndl30_fresh = atoi(rows[2 + 6].value);   /* 12 15 18 21 24 27 30 */
        int sum_fresh = 0;
        for (int i = 2; i < n - 1; i++) sum_fresh += atoi(rows[i].value);
        CHECK(strcmp(rows[2 + 6].label, "30 m") == 0 && ndl30_fresh > 10 && ndl30_fresh < 40, "fresh NDL at 30 m %d min", ndl30_fresh);
        /* After a 30 min interval following the earlier 30 m dive's tissues, the same planner shows less. */
        dive_t rep = d;
        for (int t = 0; t < 1200; t++) dive_tick(&rep, 1.0f, rep.depth_m > 0.5f ? rep.depth_m - 0.15f : 0.0f, 10.0f);
        for (int t = 0; t < 1800; t++) dive_tick(&rep, 1.0f, 0.0f, 10.0f);
        settings_apply(&s, &rep);
        pm.dive = &rep;
        menu_rows(&pm, rows, MENU_MAX_ROWS, title, sizeof(title));
        int sum_rep = 0;
        for (int i = 2; i < n - 1; i++) sum_rep += atoi(rows[i].value);
        CHECK(sum_rep < sum_fresh && atoi(rows[2 + 2].value) < atoi("99") && rep.nofly_min > 0 && strcmp(rows[0].value, "clear") != 0,
              "repeat dive: NDLs shorter (sum %d < %d min, 18 m %s), no-fly %s", sum_rep, sum_fresh, rows[4].value, rows[0].value);
    }

    /* Version 1 settings (72 bytes) still load, with defaults for the new fields. */
    uint8_t v2[DC_SETTINGS_BLOB_SIZE], v1[DC_SETTINGS_BLOB_V1];
    settings_default(&s);
    s.gf_high = 75;
    settings_serialize(&s, v2, sizeof(v2));
    memset(v1, 0, sizeof(v1));
    memcpy(v1, v2, 65);
    v1[2] = 1;
    uint32_t crc = dc_crc32(v1, 68);
    v1[68] = (uint8_t)crc; v1[69] = (uint8_t)(crc >> 8); v1[70] = (uint8_t)(crc >> 16); v1[71] = (uint8_t)(crc >> 24);
    dc_settings_t r;
    CHECK(settings_deserialize(v1, sizeof(v1), &r) && r.gf_high == 75 && r.bluetooth == 1 && r.ndl_warn_min == 5 &&
              r.log_interval_s == 2, "version 1 settings load with defaults");
}

static void test_rock_bottom(void)
{
    /* 30 m, 12 L tank, no SAC measured yet -> 20 L/min. Ascent 30 -> 5 m at 9 m/min (avg 17.5 m),
     * 3 min at 5 m, 5 -> 0 m. Litres: 20*2.772*2.778 + 20*1.516*3 + 20*1.265*0.556 = 154.0 + 91.0 + 14.1 = 259.1
     * -> 21.6 bar + 50 bar reserve = 71.6 bar. */
    dive_t d;
    dive_init(&d);
    d.tanks[0].cylinder_l = 12.0f;
    for (int t = 0; t < 200; t++) dive_tick(&d, 1.0f, t < 100 ? t * 0.3f : 30.0f, 10.0f);
    dive_tank_reading(&d, 0, 200.0f);
    dive_tick(&d, 1.0f, 30.0f, 10.0f);
    CHECK(NEAR(d.gas_needed_bar, 71.6, 0.6), "gas needed to surface %.1f bar (hand calc 71.6)", d.gas_needed_bar);
    CHECK(!(d.alarms & (ALARM_GAS_TURN | ALARM_GAS_LOW)), "200 bar: no gas alarm");
    float tl = d.gas_time_min;
    CHECK(NEAR(tl, (200.0 - d.gas_needed_bar) / (20.0 * dc_ambient_bar(30.0f, &d.cfg) / 12.0), 0.1), "time left at depth %.1f min", tl);
    dive_tank_reading(&d, 0, 85.0f);
    dive_tick(&d, 1.0f, 30.0f, 10.0f);
    CHECK((d.alarms & ALARM_GAS_TURN) && !(d.alarms & ALARM_GAS_LOW), "85 bar: turn soon");
    dive_tank_reading(&d, 0, 70.0f);
    dive_tick(&d, 1.0f, 30.0f, 10.0f);
    CHECK((d.alarms & ALARM_GAS_LOW) && dive_alarm_critical(d.alarms), "70 bar: low gas, critical");
    /* The need shrinks as you come up. */
    float deep = d.gas_needed_bar;
    for (int t = 0; t < 120; t++) dive_tick(&d, 1.0f, 30.0f - t * 0.15f, 10.0f);
    CHECK(d.gas_needed_bar < deep - 5.0f, "need falls on the way up (%.1f -> %.1f)", deep, d.gas_needed_bar);
}

int main(void)
{
    test_rock_bottom();
    test_proto_and_alarms();
    test_divelog();
    test_settings_menu();
    test_dive_menu();
    test_logbook_menu();
    test_battery();
    test_magcal();
    test_nmea();
    test_persist();
    test_hw();
    test_plan();
    test_predive();
    test_txdsp();
    test_pelagic();
    test_ms5837();
    test_depth_check();
    test_oxygen();
    test_deco();
    test_dive_sm();
    test_nav();
    printf("%d checks, %d failed\n", checks, fails);
    return fails ? 1 : 0;
}
