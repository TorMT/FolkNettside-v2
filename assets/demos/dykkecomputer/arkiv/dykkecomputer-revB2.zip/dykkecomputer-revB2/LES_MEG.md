# Dykkecomputer 3.5 in, rev B2 (STEP, 114 deler)

Rev B-hybridhuset gjort ferdig til montering: alt som holder, tetter eller kobler noe er modellert.

- Toppring og bezel: 4 x M2,5 x 16 senkhodeskruer (ISO 10642, A4) flush i bezelen, inn i messinginnsatser i POM-hjørnebossene.
- Linse: O-ring i et spor i linsesetet; vanntrykket presser glasset ned på den. Bezelen klemmer.
- Bakplate: 10 x M2 x 6 knapphodeskruer (ISO 7380, A4) senket i bakplaten, inn i innsatser i POM-flensen.
- Kretskort: 4 x M2 x 4 inn i innsatser i standoffene.
- Dybdesensorer: rund gelhette med radiell O-ring i boringen, firkantsokkel i forsenkningen, L-port ut; lokal forsterkning innover
  (rev B hadde bare 0,2 mm POM mellom boringen og innsiden). Sensorkortet: 2 x M1,6 + 4 fjærkontakter opp til hovedkortet.
- Våtkontakter: M2 x 6 linsehodeskrue i A4 gjennom POM-endeveggen, O-ring under hodet, mutter og loddetunge inne.
- Knapper: spak hengslet på en Ø1,5 mm A4-stift i to POM-ører, Ø4 x 2 mm magnet mot TMAG5273, trykkfjær, 0,8 mm vandring, griperiller.
- GPS: 7 x 2 mm chipantenne (Johanson 1575AT43A0040) på kortkanten innenfor POM-veggen. Patchantennen i rev B vendte ned mot aluminiumsbakplaten.
- Lyssensor: VEML7700 på en tynn flex på skjermens svarte kant innenfor vinduet. I rev B lå den under skjermen.
- Skjerm: FPC brettet rundt enden inn i en 0,9 mm FPC-kontakt; batteri i JST-SH.

Kollisjonssjekk: 0 overlapp (114 deler, eksakt B-rep). Masse ca. 420 g, hvorav glasslinsen 110 g.
Mål i mm, bakplatens utside ved Z = 0. Ikke validert for dykking: FEA og trykktest gjenstår.

`gen_b2.py` lager geometrien (trenger `gen.py` fra 3D-zip-filen), `sect_b2.py` tegner snittene,
`bygg_b2.py` legger alt inn i Fusion (mappe "07 Rev B2 detaljert") med hengselledd på knappene.
Ekte komponentmodeller: Espressif KiCad Libraries og KiCads 3D-bibliotek, CC-BY-SA 4.0.
