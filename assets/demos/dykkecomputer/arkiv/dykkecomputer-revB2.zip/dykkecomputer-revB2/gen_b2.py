"""Dive computer 3.5 in, rev B2: rev B hybrid housing made buildable in detail. python gen_b2.py out
Changes from rev B: threaded inserts, socket and countersunk screws, lens O-ring, pivoting buttons with pin and spring,
sealed screw wet contacts, GNSS chip antenna at the POM edge, light sensor beside the active area, connectors and flex tails."""
import cadquery as cq, os, sys, json, math
HERE = os.path.dirname(os.path.abspath(__file__))
src = open(os.path.join(HERE, "..", "cad", "gen.py")).read().split("def build")[0].replace("OUT = sys.argv[1]", "OUT = None")
exec(src)
OUT = sys.argv[1] if len(sys.argv) > 1 else "out"

c = CFG["dc-3in5-forearm"]
W, L, R = c["W"], c["L"], c["R"]
iw, il = W - 7, L - 7                     # 3.5 mm walls
ww, wl = c["win"]
ALLOW["POM-C"] = 20.0
lens_t = up(plate_t(wl, ww, P_TEST, ALLOW[LENS_MATERIAL]))
BP = 5.0
WIN_D = 40.0
win_t = max(3.0, up(disc_t(WIN_D, P_TEST, ALLOW[WINDOW_MATERIAL])))
z0 = 3 - BP                               # outside face of the back plate
floor = max(4.0, z0 + win_t + 1.1)        # charging coil and ferrite under the battery
BAT = dict(w=48, l=60, t=6, y=-13)        # package A: shorter battery, tall parts beside it
PCB_T = 0.8
pcbZ = floor + BAT["t"] + 0.2
pcbTop = pcbZ + PCB_T
TOPSIDE = 1.0                              # only parts under 1.0 mm on the top side
dispZ = pcbTop + TOPSIDE + 0.2
d = c["disp"]
q_edge = P_TEST * ww / 2
arm = max(iw / 2 - (ww / 2 + c["lens"]["w"] / 2) / 2, il / 2 - (wl / 2 + c["lens"]["l"] / 2) / 2)
ledge_t = max(1.5, up(math.sqrt(6 * q_edge * arm / ALLOW[BACK_MATERIAL])))
lensZ = dispZ + d["t"] + 0.2 + ledge_t
ledgeZ = lensZ - ledge_t
frameTop = lensZ + lens_t
splitZ = ledgeZ - 1.0                      # aluminium top ring above, POM-C mid ring below
wall_min_pom = (splitZ - 7.0) * math.sqrt(0.75 * P_TEST / ALLOW["POM-C"])
lw, ll = c["lens"]["w"] + 0.4, c["lens"]["l"] + 0.4
corner = [(sx * (W / 2 - 5), sy * (L / 2 - 5)) for sx in (-1, 1) for sy in (-1, 1)]       # top ring bolts
PCBX = 32.8
pcb_mounts = [(sx * PCBX, sy * 40.0) for sx in (-1, 1) for sy in (-1, 1)]                  # outside the display
xs = edge_points(40, W / 2, SCREW_IN); ys = edge_points(40, L / 2, SCREW_IN)
back_screws = sorted({(round(x, 2), round(s * (L / 2 - SCREW_IN), 2)) for x in xs[1:-1] for s in (-1, 1)} |
                     {(round(s * (W / 2 - SCREW_IN), 2), round(y, 2)) for y in ys[1:-1] for s in (-1, 1)} |
                     {(round(sx * (W / 2 - 4.6), 2), round(sy * (L / 2 - 4.6), 2)) for sx in (-1, 1) for sy in (-1, 1)})
port_y = (-2, -10)
SX = -(W / 2) + FLANGE / 2 + 2.0          # sensor centre on the exposed top of the flange (x = -33)
FLT = 7.0                                  # top face of the sealing flange
parts = {}

def cone(d1, d2, h, x, y, z):
    """Cone/countersink from diameter d1 at z to d2 at z + h."""
    return cq.Workplane().add(cq.Solid.makeCone(d1 / 2, d2 / 2, h, cq.Vector(x, y, z)))

def hexz(s, h, x, y, z):
    return cq.Workplane("XY").polygon(6, s / math.cos(math.pi / 6)).extrude(h).translate((x, y, z))

def socket_screw(d, head_d, head_h, length, x, y, z_under_head, s_hex, up=True):
    """Button head screw (ISO 7380 style) with hex socket. Head sits on z_under_head; shank goes the other way.
    Shank modelled 0.05 under nominal so it never shares a face with the insert."""
    sg = 1 if up else -1
    hz = z_under_head if up else z_under_head - head_h
    head = cylz(head_d, head_h, x, y, hz)
    head = head.edges(">Z" if up else "<Z").fillet(min(head_h * 0.6, head_d * 0.2))
    sock = hexz(s_hex, head_h * 0.6, x, y, hz + head_h * 0.4 if up else hz)
    shank = cylz(d - 0.05, length, x, y, z_under_head - length if up else z_under_head)
    return head.cut(sock).union(shank)

def insert(od, idd, h, x, y, z):
    """Threaded brass insert envelope (knurled outside, thread inside)."""
    return cylz(od, h, x, y, z).cut(cylz(idd, h + 1, x, y, z - 0.5))

def rect_ring(w, l, r, inset, width, z, h):
    o, i = inset - width / 2, inset + width / 2
    return slab(w - 2 * o, l - 2 * o, h, max(r - o, 1.0), z).cut(slab(w - 2 * i, l - 2 * i, h + 0.2, max(r - i, 0.5), z - 0.1))

def ring_groove(z_face, inset, depth=1.1, width=2.0, down=True):
    """O-ring face groove following the outline, centre `inset` from the outer edge."""
    go, gi = inset - width / 2, inset + width / 2
    zz = z_face - depth if down else z_face
    return slab(W - 2 * go, L - 2 * go, depth + 0.01, max(R - go, 2.0), zz).cut(
        slab(W - 2 * gi, L - 2 * gi, depth + 0.2, max(R - gi, 1.0), zz - 0.1))

# ---------------- mid ring, POM-C: flange, walls, bosses, ports, strap lugs, button pivots
m = slab(W, L, splitZ - 3, R, 3).cut(slab(iw, il, splitZ - 3 + 1, R - 2.5, 2.5))
m = m.union(slab(W, L, 4, R, 3).cut(slab(W - 2 * FLANGE, L - 2 * FLANGE, 5, max(R - FLANGE, 1.5), 2.5)))
for (x, y) in corner:                       # bolt bosses for the top ring, brass M2.5 inserts from the top
    m = m.union(cylz(7, splitZ - 3, x, y, 3).intersect(slab(W - 0.2, L - 0.2, splitZ - 3, R, 3)))
    m = m.cut(cylz(3.5, 5.5, x, y, splitZ - 5.5))
for (x, y) in pcb_mounts:                   # PCB standoffs from the flange, M2 inserts from the top
    m = m.union(cylz(6, pcbZ - 3, x, y, 3)).union(box(2.8, 6, pcbZ - 3, math.copysign(iw / 2 - 1.2, x), y, 3))
    m = m.cut(cylz(3.2, 4.0, x, y, pcbZ - 4.0))
for (x, y) in back_screws:                  # M2 inserts for the back plate
    m = m.cut(cylz(3.2, 3.6, x, y, 3))
# local boss inward under the depth sensors: the free flange is only 5 mm wide, a 4.6 mm bore left 0.2 mm of POM to the inside
m = m.union(box(8.5, (max(port_y) + 4.5) - (min(port_y) - 4.5), FLT - 3, -(iw / 2) + 4.25 - 0.01, sum(port_y) / 2, 3))
for y in port_y:                            # depth sensor sits upside down in a bore in the flange top,
    m = m.cut(cylz(4.6, FLT - 3.7 + 0.01, SX, y, 3.7))              # radial O-ring on the round gel cap, L-shaped port to the outside
    m = m.cut(cylz(6.2, 1.0, SX, y, FLT - 1.0))
    m = m.cut(cylx(2.0, W / 2 + SX + 2.3, (-W / 2 + SX) / 2 - 1.0, y, 4.6))
for yy in (min(port_y) - 5.0, max(port_y) + 5.0):   # M1.6 inserts for the shared sensor board
    m = m.cut(cylz(2.2, 3.0, SX, yy, FLT - 3.0))
WZ = pcbZ - 2.1                             # wet contact axis
for x in (-8.5, 8.5):                       # wet contacts: M2 316L screws through the +y end wall (POM insulates them)
    m = m.cut(cyly(2.2, 8, x, L / 2 - 2, WZ))
    m = m.cut(cyly(4.2, 0.7, x, L / 2 - 0.35 + 0.01, WZ))           # O-ring counterbore under the screw head
    m = m.cut(box(5.0, 3.0, 2.0, x, il / 2 - 1.5, WZ - 2.4))       # pocket in the flange for the nut and tab
sw = 34
for s in (-1, 1):
    for yc in (-0.33 * L, 0.33 * L):          # moved out from 0.30 L to make room for two hinged buttons
        for dy in (-(sw / 2 - 2), sw / 2 - 2):
            m = m.union(box(7.5, 4, 6, s * (W / 2 + 3.5), yc + dy, 5))
        m = m.union(box(3, sw, 6, s * (W / 2 + 6), yc, 5))
by = 8.8                                    # two buttons on +x at +-8.8, one on -x at 0
bpos = [(1, -by), (1, by), (-1, 0)]
btn_z = pcbTop + 0.5                        # magnets level with the hall sensors on the PCB edge
MY, SY = -2.0, 3.2                          # magnet and spring offsets along the lever
PX, PZ = W / 2 + 2.8, btn_z - 3.0           # pivot pin axis (along y), lever hinges at its lower edge
for s, y in bpos:
    for dy in (-7.4, 7.4):
        m = m.union(box(5.0, 2.4, 3.5, s * (W / 2 + 2.3), y + dy, PZ - 2.0))
    m = m.cut(cyly(1.5, 17.4, s * PX, y, PZ))
parts["mid_ring_pom"] = (m, (232, 228, 214))

# ---------------- top ring, aluminium: lens ledge and seat, O-ring groove underneath
t = slab(W, L, frameTop - splitZ, R, splitZ)
t = t.cut(slab(iw, il, ledgeZ - splitZ + 0.01, R - 2.5, splitZ - 0.005))
t = t.cut(slab(ww, wl, frameTop - ledgeZ + 1, 5, ledgeZ))
t = t.cut(slab(lw, ll, frameTop - lensZ + 1, 5.2, lensZ))
t = t.cut(ring_groove(splitZ + 1.1, 1.6, down=True))     # groove opens downwards onto the POM face
LENS_RING = 3.2                                          # lens face seal: water pressure pushes the glass onto it
t = t.cut(rect_ring(c["lens"]["w"], c["lens"]["l"], 5, LENS_RING, 2.0, lensZ - 1.1, 1.11))
for (x, y) in corner:
    t = t.cut(cylz(2.8, frameTop - splitZ + 1, x, y, splitZ - 0.5))
parts["top_ring_al"] = (t, (154, 166, 176))

# ---------------- bezel, lens, back plate, charging window
bz = slab(W, L, 1.5, R, frameTop).faces(">Z").edges().chamfer(0.6).cut(slab(ww, wl, 2, 5, frameTop - 0.2))
for (x, y) in corner:                       # ISO 10642 countersunk M2.5, flush with the bezel
    bz = bz.cut(cylz(2.8, 2, x, y, frameTop - 0.2)).cut(cone(2.6, 5.4, 1.4, x, y, frameTop + 0.1)).cut(cylz(5.4, 0.2, x, y, frameTop + 1.49))
try:
    txt = cq.Workplane("XY").text("100 m", 3.2, 0.3, combine=False, halign="center", valign="center").translate((0, -(wl / 2 + 6.5), frameTop + 1.5 - 0.3))
    bz = bz.cut(txt)
except Exception as e:
    print("engraving skipped:", e)
parts["bezel"] = (bz, (95, 107, 118))
parts["lens"] = (slab(c["lens"]["w"], c["lens"]["l"], lens_t, 5, lensZ).faces(">Z").edges().chamfer(0.5), (156, 199, 232))
bp = slab(W, L, BP, R, z0).faces("<Z").edges().chamfer(0.8)
go, gi = RING_IN - 1.0, RING_IN + 1.0
bp = bp.cut(slab(W - 2 * go, L - 2 * go, 1.2, max(R - go, 3.0), 3 - 1.1).cut(slab(W - 2 * gi, L - 2 * gi, 1.4, max(R - gi, 1.5), 3 - 1.2)))
for (x, y) in back_screws:
    bp = bp.cut(cylz(2.2, BP + 1, x, y, z0 - 0.5)).cut(cylz(4.0, 1.5, x, y, z0 - 0.01))
fl = 2.0
bp = bp.cut(cylz(WIN_D + 0.2, BP + 1, 0, 0, z0 - 0.5)).cut(cylz(WIN_D + 8.2, fl + 0.05, 0, 0, z0 - 0.01))
seat_z = z0 + fl
bp = bp.cut(cylz(WIN_D + 5.6, 1.1, 0, 0, seat_z - 0.01).cut(cylz(WIN_D + 1.6, 1.3, 0, 0, seat_z - 0.1)))
parts["back_plate"] = (bp, (126, 138, 149))
parts["qi_window"] = (cylz(WIN_D + 8.0, fl, 0, 0, z0).union(cylz(WIN_D, win_t - fl, 0, 0, z0 + fl)), (222, 214, 190))

# ---------------- O-rings (modelled as rectangular-section stand-ins at the compressed height)
def oring_rect(z, inset, h, cord=1.5):
    o, i = inset - cord / 2, inset + cord / 2
    return slab(W - 2 * o, L - 2 * o, h, max(R - o, 2.0), z).cut(slab(W - 2 * i, L - 2 * i, h + 0.2, max(R - i, 1.0), z - 0.1))
parts["oring_back_plate"] = (oring_rect(3 - 1.1, RING_IN, 1.1), (20, 20, 20))
parts["oring_top_ring"] = (oring_rect(splitZ, 1.6, 1.1), (20, 20, 20))
parts["oring_lens"] = (rect_ring(c["lens"]["w"], c["lens"]["l"], 5, LENS_RING, 1.5, lensZ - 1.1, 1.1), (20, 20, 20))
parts["oring_qi_window"] = (cylz(WIN_D + 4.6, 1.05, 0, 0, seat_z + 0.01).cut(cylz(WIN_D + 2.6, 1.3, 0, 0, seat_z - 0.1)), (20, 20, 20))

# ---------------- buttons: lever hinged on a 316L pin in two POM lugs, magnet facing the hall sensor, return spring
for i, (s, y) in enumerate(bpos):
    xi = s * (W / 2 + 0.8)                  # inner face of the lever: 0.8 mm travel to the wall
    xc = s * (W / 2 + 2.8)
    lv = box(4, 12, (btn_z + 3) - (PZ - 1.5), xc, y, PZ - 1.5).edges("|Y").fillet(0.6)
    lv = lv.cut(cyly(1.6, 13, xc, y, PZ))                                   # pin hole, running fit
    lv = lv.cut(cylx(4.1, 2.0, xi + s * 1.0, y + MY, btn_z))                # magnet pocket
    lv = lv.cut(cylx(3.2, 1.5, xi + s * 0.75, y + SY, btn_z))              # spring pocket
    for gz in (btn_z + 0.2, btn_z + 1.3, btn_z + 2.4):                    # grip grooves
        lv = lv.cut(box(0.8, 13, 0.5, s * (W / 2 + 4.8), y, gz))
    parts[f"button_lever_{i+1}"] = (lv, (204, 58, 46))
    parts[f"button_magnet_{i+1}"] = (cylx(4.0, 2.0, xi + s * 1.0, y + MY, btn_z), (192, 198, 204))
    parts[f"button_pin_{i+1}"] = (cyly(1.45, 17.2, s * PX, y, PZ), (190, 190, 195))
    sp = cylx(3.0, 2.3, s * (W / 2 + 1.15), y + SY, btn_z).cut(cylx(2.2, 2.5, s * (W / 2 + 1.15), y + SY, btn_z))
    parts[f"button_spring_{i+1}"] = (sp, (160, 160, 165))

# ---------------- display and foam
parts["display_module"] = (slab(d["w"], d["l"], d["t"], 1.5, dispZ), (26, 29, 36))
parts["display_active_area"] = (box(d["aw"], d["al"], 0.02, 0, 0, dispZ + d["t"]), (60, 52, 137))
for i, (x, y) in enumerate([(-26, -42), (26, -42), (-26, 42), (26, 42)]):
    parts[f"foam_display_{i+1}"] = (box(6, 6, TOPSIDE + 0.2, x, y, pcbTop), (240, 240, 240))

# ---------------- PCB 70 x 96 x 0.8, M2 holes at the four mounts, notches at the corner bosses
pw, pl = 70, 96
pcb = slab(pw, pl, PCB_T, 4, pcbZ)
for (x, y) in pcb_mounts:
    pcb = pcb.cut(cylz(2.4, 2, x, y, pcbZ - 0.5))
for (x, y) in corner:
    pcb = pcb.cut(cylz(8, 2, x, y, pcbZ - 0.5))
for y in port_y:
    pass
parts["main_pcb"] = (pcb, (31, 94, 58))
for i, (x, y) in enumerate(pcb_mounts):
    parts[f"screw_pcb_m2x4_{i+1}"] = (socket_screw(2.0, 3.5, 1.0, 4.0, x, y, pcbTop, 1.3), (190, 190, 195))
    parts[f"insert_pcb_m2_{i+1}"] = (insert(3.2, 2.0, 4.0, x, y, pcbZ - 4.0), (205, 170, 80))

# ---------------- components: top side (all under 1 mm) ...
top = pcbTop
parts["imu_qmi8658"] = (box(2.5, 3, 0.86, -12, -16, top), (42, 47, 53))
parts["mag_mmc5603"] = (box(0.8, 0.8, 0.4, -6, -16, top), (42, 47, 53))
parts["fuel_gauge_max17048"] = (box(2, 2, 0.8, 6, 8, top), (42, 47, 53))
parts["rtc_pcf85063a"] = (box(2, 3, 0.8, 18, 8, top), (138, 147, 155))
# display FPC folds round the -y end of the display into a 1.0 mm FPC connector under it
dyE = -d["l"] / 2
parts["fpc_connector_display"] = (box(28, 3.0, 0.9, 0, dyE - 0.1 + 1.5, top), (235, 235, 230))
parts["display_fpc"] = (box(25, 0.1, dispZ + 0.4 - (top + 0.4), 0, dyE - 0.45, top + 0.4)
                        .union(box(25, 0.5, 0.1, 0, dyE - 0.25, dispZ + 0.3))
                        .union(box(25, 0.4, 0.1, 0, dyE - 0.3, top + 0.3)), (200, 130, 40))
# ambient light sensor on a thin flex on the display's black border, inside the window (the old spot was under the display)
LX, LY = 18.0, -(wl / 2) + 2.35 / 2
dtop = dispZ + d["t"]
parts["light_sensor_veml7700"] = (box(4.0, 2.35, 0.8, LX, LY, dtop + 0.1), (42, 47, 53))
parts["light_sensor_flex"] = (box(3.0, (LY + 1.0) - (dyE - 0.5), 0.1, LX, ((LY + 1.0) + (dyE - 0.5)) / 2, dtop)
                              .union(box(3.0, 0.1, dtop - top, LX, dyE - 0.55, top))
                              .union(box(3.0, 1.2, 0.1, LX, dyE - 1.1, top)), (200, 130, 40))
for i, (s, y) in enumerate(bpos):          # TMAG5273 hall sensors at the PCB edge, opposite each lever
    parts[f"hall_tmag5273_{i+1}"] = (box(1.6, 2.9, 0.9, s * 33.2, y + MY, top), (42, 47, 53))
# ... bottom side (hang below the PCB, beside the shorter battery)
bot = lambda h: pcbZ - h
parts["esp32_s3_wroom_1"] = (box(18, 25.5, 3.1, -19, 31.2, bot(3.1)), (196, 204, 211))
parts["microsd_socket"] = (box(14, 15, 1.9, 0, 37, bot(1.9)), (180, 180, 180))
parts["gnss_atgm336h"] = (box(9.7, 10.1, 2.4, 16, 27, bot(2.4)), (196, 204, 211))
parts["gnss_chip_antenna_7x2"] = (box(7, 2, 0.8, 20, 46.6, bot(0.8)), (230, 225, 210))   # at the POM edge, copper keep-out under it
parts["battery_connector_jst_sh2"] = (box(6.0, 4.25, 2.9, -28.3, -28, bot(2.9)), (238, 238, 232))
for k, yy in enumerate((-9.0, -7.0, -5.0, -3.0)):          # spring contacts from the main PCB down to the sensor board
    parts[f"pogo_sensor_{k+1}"] = (cylz(1.2, pcbZ - (FLT + 1.0), SX, yy, FLT + 1.0), (212, 175, 55))
parts["piezo_buzzer_9mm"] = (box(9, 9, 1.9, 28, 29.5, bot(1.9)), (30, 30, 30))
parts["vibration_motor_1027"] = (cylz(10, 2.7, 0, 23.6, bot(2.7)), (168, 175, 181))
parts["safety_mcu_ch32v003_tssop20"] = (box(4.4, 6.5, 1.2, 28, 21.6, bot(1.2)), (42, 47, 53))
parts["adc_pcm1808_tssop14"] = (box(4.4, 5.0, 1.2, 8, 22.0, bot(1.2)), (42, 47, 53))
parts["fram_mb85rc256_sop8"] = (box(4, 5, 1.5, 24.5, 41.5, bot(1.5)), (42, 47, 53))
parts["i2c_mux_tca9548a"] = (box(4.4, 7.8, 1.2, -29, 10, bot(1.2)), (42, 47, 53))
for i, x in enumerate((-8.5, 8.5)):        # M2x6 316L pan head outside (the contact), O-ring under the head, nut + solder tab inside
    yo = L / 2
    head = cyly(4.0, 1.3, x, yo + 0.65, WZ).faces(">Y").edges().fillet(0.5)
    head = head.cut(box(0.5, 0.6, 4.2, x, yo + 1.0, WZ - 2.1))
    parts[f"wet_contact_screw_{i+1}"] = (head.union(cyly(1.95, 6.0, x, yo - 3.0, WZ)), (200, 205, 210))
    parts[f"oring_wet_{i+1}"] = (cyly(4.0, 0.68, x, yo - 0.34, WZ).cut(cyly(2.0, 1, x, yo - 0.34, WZ)), (20, 20, 20))
    yi = il / 2
    parts[f"wet_tab_{i+1}"] = (box(4.0, 0.3, 4.0, x, yi - 0.15, WZ - 2.0).cut(cyly(2.2, 1, x, yi - 0.15, WZ)), (205, 170, 80))
    nut = cq.Workplane("XZ").polygon(6, 4.0 / math.cos(math.pi / 6)).extrude(1.6).translate((x, yi - 0.3, WZ))
    parts[f"wet_nut_{i+1}"] = (nut.cut(cyly(2.0, 3, x, yi - 1.1, WZ)), (190, 190, 195))

# ---------------- depth sensors: one small board lying on the flange top, both sensors hanging into sealed bores
yb0, yb1 = min(port_y) - 7.5, max(port_y) + 7.5
board = box(4.6, yb1 - yb0, 1.0, SX, (yb0 + yb1) / 2, FLT)
for yy in (min(port_y) - 5.0, max(port_y) + 5.0):
    board = board.cut(cylz(1.8, 2, SX, yy, FLT - 0.5))
    k = 'ab'[int(yy > 0)]
    parts[f"screw_sensor_m16_{k}"] = (socket_screw(1.6, 3.0, 0.9, 3.0, SX, yy, FLT + 1.0, 1.5 * 0.6 + 0.4), (190, 190, 195))
    parts[f"insert_sensor_m16_{k}"] = (insert(2.2, 1.6, 3.0, SX, yy, FLT - 3.0), (205, 170, 80))
parts["sensor_board"] = (board, (31, 94, 58))
for i, y in enumerate(port_y):
    k = "ab"[i]
    parts[f"depth_sensor_ms5837_{k}"] = (box(3.3, 3.3, 0.9, SX, y, FLT - 0.9).union(cylz(3.0, 1.85, SX, y, FLT - 2.75)), (217, 222, 226))
    parts[f"oring_sensor_{k}"] = (cylz(4.55, 1.0, SX, y, FLT - 2.4).cut(cylz(3.05, 1.2, SX, y, FLT - 2.5)), (20, 20, 20))

# ---------------- power and receiver: battery in a printed tray, ferrite rod beside it
b = BAT
parts["lipo_battery"] = (slab(b["w"], b["l"], b["t"], 3, floor).translate((0, b["y"], 0)), (79, 122, 168))
tray = slab(b["w"] + 2.4, b["l"] + 2.4, b["t"], 4, floor).cut(slab(b["w"] + 0.2, b["l"] + 0.2, b["t"] + 1, 3, floor - 0.5)).translate((0, b["y"], 0))
coilX = 27.8
tray = tray.union(box(5.0, 27, 3.0, coilX, -17, floor)).cut(cyly(5.0, 26, coilX, -17, floor + 3))
parts["battery_tray_pa12"] = (tray, (110, 110, 110))
parts["rx_ferrite_rod"] = (cyly(4, 25, coilX, -17, floor + 3), (58, 54, 51))
parts["rx_coil_winding"] = (cyly(4.8, 14, coilX, -17, floor + 3).cut(cyly(4, 15, coilX, -17, floor + 3)), (184, 115, 62))
wtop = z0 + win_t
parts["qi_coil"] = (cylz(36, 0.5, 0, 0, wtop + 0.05).cut(cylz(14, 1, 0, 0, wtop)), (184, 115, 62))
parts["qi_ferrite_sheet"] = (cylz(37, 0.35, 0, 0, wtop + 0.6), (44, 44, 42))

# ---------------- fasteners
for i, (x, y) in enumerate(corner):         # ISO 10642 M2.5x16 countersunk, into brass inserts in the POM bosses
    hd = cone(2.5, 5.0, 1.4, x, y, frameTop + 0.1)
    hd = hd.cut(hexz(1.5, 0.9, x, y, frameTop + 1.5 - 0.9))
    parts[f"screw_top_m25x16_{i+1}"] = (hd.union(cylz(2.45, 16 - 1.4, x, y, frameTop + 0.1 - (16 - 1.4))), (190, 190, 195))
    parts[f"insert_top_m25_{i+1}"] = (insert(3.5, 2.5, 5.5, x, y, splitZ - 5.5), (205, 170, 80))
for i, (x, y) in enumerate(back_screws):    # ISO 7380 M2x6 button head from below, into brass inserts
    parts[f"screw_back_m2x6_{i+1}"] = (socket_screw(2.0, 3.5, 1.0, 6.0, x, y, z0 + 1.49, 1.3, up=False).translate((0, 0, 0)), (190, 190, 195))
    parts[f"insert_back_m2_{i+1}"] = (insert(3.2, 2.0, 3.6, x, y, 3), (205, 170, 80))

os.makedirs(os.path.join(OUT, "step"), exist_ok=True)
info = dict(height_mm=round(frameTop + 1.5 - z0, 2), floor=floor, pcbZ=pcbZ, dispZ=dispZ, ledgeZ=ledgeZ, lensZ=lensZ, splitZ=splitZ,
            frameTop=frameTop, lens_mm=lens_t, ledge_mm=ledge_t, pom_wall_min_mm=round(wall_min_pom, 2), wall_mm=3.5,
            back_screws=len(back_screws), parts=len(parts), bat=BAT, pcb_t=PCB_T)
bad = []
for k, (wp, rgb) in parts.items():
    wp2 = wp.translate((0, 0, -z0))
    if not all(v.isValid() for v in wp2.vals()):
        bad.append(k)
    cq.exporters.export(wp2, os.path.join(OUT, "step", k + ".step"))
info["invalid"] = bad
json.dump(info, open(os.path.join(OUT, "sizing_hybrid.json"), "w"), indent=1)
print(json.dumps(info, indent=1))
