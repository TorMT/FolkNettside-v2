import cadquery as cq, trimesh, glob, os, sys, tempfile, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
col = {'mid_ring': '#e8e4d6', 'top_ring': '#9aa6b0', 'bezel': '#5f6b76', 'lens': '#9cc7e8', 'back': '#6f7b86', 'button_lever': '#cc3a2e', 'button_magnet': '#7d8590',
       'button_pin': '#c0c0c8', 'button_spring': '#a0a0a5', 'display': '#3c3489', 'main_pcb': '#1f5e3a', 'sensor_board': '#1f5e3a', 'lipo': '#4f7aa8',
       'battery_tray': '#888888', 'qi_window': '#d9cfae', 'qi': '#b8733e', 'rx': '#b8733e', 'oring': '#111111', 'screw': '#c0c0c8', 'wet_contact': '#c0c0c8',
       'wet_nut': '#c0c0c8', 'insert': '#cdaa50', 'wet_tab': '#cdaa50', 'pogo': '#d4af37', 'foam': '#f4f4f4', 'esp32': '#c4ccd3', 'gnss': '#ece6d6',
       'microsd': '#b4b4b4', 'fpc': '#e6e6e0', 'display_fpc': '#c8822a', 'light_sensor_flex': '#c8822a'}
meshes = {}
for f in sorted(glob.glob(sys.argv[1] + '/*.step')):
    n = os.path.basename(f)[:-5]
    tmp = tempfile.mktemp(suffix='.stl'); cq.exporters.export(cq.importers.importStep(f), tmp, tolerance=0.01, angularTolerance=0.1)
    meshes[n] = trimesh.load(tmp)
# title, origin, normal, axes, xlim, ylim
cuts = [('Hele huset, tverrsnitt y = -10 (dybdesensor)', [0, -10, 0], [0, 1, 0], (0, 2), None, None),
        ('Knapp: hengslet hendel, magnet mot hall-sensor (y = -10,8)', [0, -10.8, 0], [0, 1, 0], (0, 2), (28, 47), (3, 30)),
        ('Hjørneskrue M2,5 senket + innsats, O-ringer (x = 34)', [34, 0, 0], [1, 0, 0], (1, 2), (38, 54), (-2, 30)),
        ('Våtkontakt: M2-skrue, O-ring, mutter og loddetunge (x = 8,5)', [8.5, 0, 0], [1, 0, 0], (1, 2), (40, 56), (-2, 30)),
        ('Dybdesensor: radiell O-ring på gelhetta, L-port (y = -10)', [0, -10, 0], [0, 1, 0], (0, 2), (-42, -26), (-2, 14)),
        ('Linse: O-ring i setet, lyssensor på flex (x = 18)', [18, 0, 0], [1, 0, 0], (1, 2), (-54, -32), (8, 30))]
fig, axes = plt.subplots(3, 2, figsize=(14, 15))
for ax, (title, o, nrm, (a, b), xl, yl) in zip(axes.flat, cuts):
    for n, m in meshes.items():
        sec = m.section(plane_origin=o, plane_normal=nrm)
        if sec is None: continue
        c = next((v for k, v in sorted(col.items(), key=lambda kv: -len(kv[0])) if n.startswith(k)), '#2a2f35')
        for ent in sec.discrete:
            ax.fill(ent[:, a], ent[:, b], facecolor=c, edgecolor='black', linewidth=0.3)
    if xl: ax.set_xlim(*xl); ax.set_ylim(*yl)
    ax.set_aspect('equal'); ax.set_title('Rev B2 — ' + title + ' (mm)', fontsize=10); ax.grid(alpha=0.2)
plt.tight_layout(); plt.savefig(sys.argv[2], dpi=110)
