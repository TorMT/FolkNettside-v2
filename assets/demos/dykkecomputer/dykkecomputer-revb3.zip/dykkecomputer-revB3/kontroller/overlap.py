import cadquery as cq, glob, os, sys, itertools
d = sys.argv[1]
P = {os.path.basename(f)[:-5]: cq.importers.importStep(f).val() for f in sorted(glob.glob(d + "/*.step"))}
dens = {"top_ring":2.7,"back_plate":2.7,"bezel":2.7,"mid_ring":1.41,"lens":2.5,"qi_window":1.3,"lipo":2.0,"display":2.2,"main_pcb":1.85,"screw":8.0,"battery_tray":1.0,"button_lever":1.41,"button_magnet":7.5}
tot=0; rows=[]
for k,v in P.items():
    rho = next((r for p,r in dens.items() if k.startswith(p)), 2.0)
    m = v.Volume()/1000*rho; tot+=m; rows.append((round(m,1),k))
print("mass g", round(tot), sorted(rows)[-8:])
hits=[]
for (a,A),(b,B) in itertools.combinations(P.items(),2):
    if not A.BoundingBox().intersect(B.BoundingBox()) if hasattr(A.BoundingBox(),'intersect') else False: pass
    ba,bb=A.BoundingBox(),B.BoundingBox()
    if ba.xmax<bb.xmin or bb.xmax<ba.xmin or ba.ymax<bb.ymin or bb.ymax<ba.ymin or ba.zmax<bb.zmin or bb.zmax<ba.zmin: continue
    try: v=A.intersect(B).Volume()
    except Exception as e: v=-1
    if v>0.05 or v<0: hits.append((a,b,round(v,3)))
thread = lambda a, b: (a == "back_plate" and b.startswith("screw_window")) or (b == "back_plate" and a.startswith("screw_window")) or \
                      any(a.startswith(p) for p in ("insert", "wet_nut")) and b.startswith(("screw", "wet_contact_screw")) or \
                      any(b.startswith(p) for p in ("insert", "wet_nut")) and a.startswith(("screw", "wet_contact_screw"))
eng = [h for h in hits if thread(h[0], h[1])]
print("thread engagement (screw in tap-drill bore, threads cut in Fusion):", len(eng), sorted({h[2] for h in eng}))
print("overlaps", [h for h in hits if not thread(h[0], h[1])])
