"""Pre-order mechanical checks for rev B3: O-ring glands, bolt loads, inserts, fits, buoyancy. Prints a table and writes JSON."""
import math, json, sys
P = 1.5          # test pressure, MPa (10 bar ~ 100 m x 1.5)
rows = []
def oring(name, cord, depth, width, inner_d=None, groove_id=None, kind="face"):
    sq = (cord - depth) / cord * 100
    fill = math.pi * (cord / 2) ** 2 / (depth * width) * 100
    st = (groove_id - inner_d) / inner_d * 100 if inner_d and groove_id else None
    ok = 15 <= sq <= 30 and fill <= 85 and (st is None or 0 <= st <= 5)
    rows.append(dict(del_=name, snor=cord, dybde=depth, bredde=width, klem_pct=round(sq), fylling_pct=round(fill),
                     strekk_pct=None if st is None else round(st, 1), ok=ok))
# B3 glands (mm). Face seals: depth from the mating face; width of the groove.
oring("Toppring/midtring (snor 1,5)", 1.5, 1.1, 2.2)
oring("Bakplate/midtring (snor 1,5)", 1.5, 1.1, 2.2)
oring("Linse i setet (snor 1,5)", 1.5, 1.1, 2.2)
oring("Qi-vindu (1,5 snor, ID ca. 43)", 1.5, 1.11, 2.2, inner_d=43.0, groove_id=41.6 + 0.0 + 1.6 - 0.2)
oring("Dybdesensor, radiell (3,0 × 1,0)", 1.0, 0.8, 1.25, inner_d=3.0, groove_id=3.0)
oring("Våtkontakt under skruehode (2,0 × 0,8)", 0.8, 0.65, 0.975, inner_d=2.0, groove_id=2.0)
# bolt loads
k_or = 1.2                                       # N per mm of 1.5 mm NBR70 cord at ~27 % squeeze (Parker load chart, upper end of the band)
L_top = 2 * (78 - 2 * 1.8) + 2 * (106 - 2 * 1.8) - (8 - 2 * math.pi) * (8 - 1.8)
L_lens = 2 * (66 - 2 * 3.2) + 2 * (96 - 2 * 3.2) - (8 - 2 * math.pi) * (5 - 3.2)
L_back = 2 * (78 - 2 * 6.3) + 2 * (106 - 2 * 6.3) - (8 - 2 * math.pi) * (8 - 6.3)
F_top = k_or * (L_top + L_lens); F_back = k_or * L_back
heat = 0.014 * 70 * 98                           # internal overpressure at 50 C after closing at 10 C, on the inner area, N
loads = [dict(ledd="4 × M2,5 topp", kraft_N=round(F_top), per_skrue_N=round(F_top / 4), kapasitet_N=2370, innsats_uttrekk_N=400),
         dict(ledd="10 × M2 bak", kraft_N=round(F_back + heat), per_skrue_N=round((F_back + heat) / 10), kapasitet_N=1450, innsats_uttrekk_N=250)]
for l in loads:
    l["ok"] = l["per_skrue_N"] * 2 < min(l["kapasitet_N"], l["innsats_uttrekk_N"])
# pressure loads go into compression: lens on its seat, back plate on the POM flange
lens_F = P * 52 * 78; flange_bearing = P * 70 * 98 / (2 * (78 + 106) * 3.0)
fits = [("Linse 66 × 96 ±0,2 i sete 66,4 × 96,4", "0,0–0,4 mm klaring", True),
        ("Skjerm 55,5 × 84,96 ±0,2 i åpning 71 × 99", "> 7 mm", True),
        ("Kretskort 70 × 96 ±0,1 i åpning 71 × 99", "0,4–0,6 mm per side", True),
        ("Ladevindu Ø48 i forsenkning Ø48,2", "0,1 mm per side", True),
        ("M2,5 i Ø2,8, M2 i Ø2,2 (ISO fin/middels)", "OK", True),
        ("Hengselstift Ø1,5 i Ø1,5 POM-ører", "Presspasning: bor Ø1,45 og rives, eller lim", True),
        ("Toppring mot midtring", "Bare skruene styrer: ±0,15 mm sideveis. O-ringsporet tåler det", True)]
outer_V = (78 * 106 - (4 - math.pi) * 8 ** 2) * 28.5 / 1000 + 4 * 7.5 * 4 * 6 / 1000 + 2 * 3 * 34 * 6 / 1000 * 2
mass = float(sys.argv[1]) if len(sys.argv) > 1 else 401
res = dict(orings=rows, bolts=loads, lens_force_N=round(lens_F), flange_bearing_MPa=round(flange_bearing, 2), fits=fits,
           volume_cm3=round(outer_V), mass_g=mass, in_seawater_g=round(mass - 1.025 * outer_V))
for r in rows: print(("OK  " if r["ok"] else "SJEKK ") + f"{r['del_']}: klem {r['klem_pct']} %, fylling {r['fylling_pct']} %" + ("" if r["strekk_pct"] is None else f", strekk {r['strekk_pct']} %"))
for l in loads: print(("OK  " if l["ok"] else "SJEKK ") + f"{l['ledd']}: {l['per_skrue_N']} N per skrue (kapasitet {l['kapasitet_N']} N, innsats {l['innsats_uttrekk_N']} N)")
print(f"linsekraft ved {P} MPa: {res['lens_force_N']} N på setet; flensflate {res['flange_bearing_MPa']} MPa (POM-C tåler ca. 20)")
print(f"volum {res['volume_cm3']} cm3, masse {mass} g, i sjøvann {res['in_seawater_g']} g")
json.dump(res, open("out/b3_checks.json", "w"), ensure_ascii=False, indent=1)
