"""Assembly-order check: every part or sub-assembly must travel in from outside along its direction without
running into what is already installed. Meshes are shrunk 0.03 mm so parts that only touch do not count.
Screws may pass their own threaded bores (screw shank vs insert/nut/tapped plate is thread engagement)."""
import cadquery as cq, trimesh, fcl, glob, os, sys, tempfile, numpy as np, json
D = sys.argv[1]
M = {}
for f in sorted(glob.glob(D + "/*.step")):
    n = os.path.basename(f)[:-5]
    tmp = tempfile.mktemp(suffix=".stl"); cq.exporters.export(cq.importers.importStep(f), tmp, tolerance=0.03, angularTolerance=0.15)
    m = trimesh.load(tmp); m.vertices = m.vertices - m.vertex_normals * 0.03; M[n] = m
def obj(m, off):
    b = fcl.BVHModel(); b.beginModel(len(m.vertices), len(m.faces)); b.addSubModel(m.vertices + off, m.faces); b.endModel()
    return fcl.CollisionObject(b, fcl.Transform())
S = lambda *p: [n for n in M if n.startswith(p)]
UP, DN = (0, 0, 1), (0, 0, -1)
pcb_sub = [n for n in M if n not in S("mid_ring", "insert", "depth_sensor", "oring", "sensor_board", "screw", "wet", "button", "top_ring",
           "lens", "bezel", "display", "foam", "light_sensor", "back_plate", "qi_", "lipo", "battery_tray", "rx_")] + S("display_fpc") * 0
pcb_sub = [n for n in pcb_sub if not n.startswith(("display_", "pogo")) ] + S("pogo")
steps = [("Innsatser ovenfra", S("insert_top", "insert_pcb", "insert_sensor"), UP),
         ("Innsatser for bakplaten nedenfra", S("insert_back"), DN),
         ("Dybdesensorer med O-ring", S("depth_sensor", "oring_sensor"), UP),
         ("Sensorkort", S("sensor_board"), UP), ("Sensorskruer", S("screw_sensor"), UP),
         ("Mutter og loddetunge til våtkontakt", S("wet_nut", "wet_tab"), UP),
         ("O-ring og våtkontaktskrue utenfra", S("oring_wet", "wet_contact_screw"), (0, 1, 0)),
         ("Knappefjærer", [n for n in S("button_spring") if n.endswith(("1", "2"))], (1, 0, 0)),
         ("Knappefjær venstre", S("button_spring_3"), (-1, 0, 0)),
         ("Spak + magnet høyre", S("button_lever_1", "button_magnet_1", "button_lever_2", "button_magnet_2"), (1, 0, 0)),
         ("Spak + magnet venstre", S("button_lever_3", "button_magnet_3"), (-1, 0, 0)),
         ("Hengselstift 1 (fra -y)", S("button_pin_1"), (0, -1, 0)),
         ("Hengselstift 2 (fra +y)", S("button_pin_2"), (0, 1, 0)),
         ("Hengselstift 3 (fra -y)", S("button_pin_3"), (0, -1, 0)),
         ("Kretskort med alle komponenter", pcb_sub, UP),
         ("Kortskruer", S("screw_pcb"), UP),
         ("Skumputer", S("foam"), UP),
         ("Skjerm med FPC", S("display_"), UP),
         ("Pakning og lyssensor på flex", S("display_gasket", "light_sensor"), UP),
         ("Toppring med linse, O-ringer og bezel", S("top_ring", "oring_top", "lens", "oring_lens", "bezel"), UP),
         ("Toppskruer", S("screw_top"), UP),
         ("Batteriholder med batteri og mottakerspole", S("battery_tray", "lipo", "rx_"), DN),
         ("Bakplate med ladevindu, spole, holdering og O-ring", S("back_plate", "qi_", "oring_qi", "oring_back", "screw_window"), DN),
         ("Bakskruer", S("screw_back"), DN)]
done = set(sum([g for _, g, _ in steps], []))
missing = [n for n in M if n not in done and n != "mid_ring_pom"]
thread = lambda a, b: (a.startswith(("screw", "wet_contact_screw")) and b.startswith(("insert", "wet_nut", "back_plate"))) or \
                      (b.startswith(("screw", "wet_contact_screw")) and a.startswith(("insert", "wet_nut", "back_plate")))
installed = ["mid_ring_pom"]
report = []
for title, grp, v in steps:
    v = np.array(v, float); hits = set()
    inst = [(n, obj(M[n], 0)) for n in installed]
    for d in np.arange(0.0, (20.01 if title.startswith("Hengsel") else 45.01), 0.2):
        for g in grp:
            og = obj(M[g], v * d)
            for n, o in inst:
                if thread(g, n):
                    continue
                if fcl.collide(og, o, fcl.CollisionRequest(), fcl.CollisionResult()):
                    hits.add((g, n, round(float(d), 1)))
    first = {}
    for g, n, d in sorted(hits, key=lambda h: h[2]):
        first.setdefault((g, n), d)
    report.append((title, len(grp), sorted(first.items(), key=lambda kv: kv[1])[:6]))
    print(f"{'OK ' if not hits else 'KOLLISJON'} {title} ({len(grp)} deler)" + ("" if not hits else ": " + "; ".join(f"{a} mot {b} ved {d} mm" for (a, b), d in report[-1][2])), flush=True)
    installed += grp
print("ikke med i rekkefølgen:", missing)
json.dump([dict(steg=t, deler=k, kollisjoner=[[a, b, d] for (a, b), d in h]) for t, k, h in report], open(os.path.join(D, "..", "montering.json"), "w"), ensure_ascii=False, indent=1)
