# Dykkecomputer 3.5 in, rev B3 (STEP, 120 deler)

Rev B2 med ekte delemål, O-ringspor regnet etter og en montering som er sjekket steg for steg.

- Skjerm: bart 3,5" IPS-panel (ST7796, 55,5 x 84,96 x 2,5 mm) med bakbelysningsramme og glass. Rev B2 brukte feil mål (61 x 92,4).
- Batteri: poselcelle med kapton-pakket beskyttelseskort og røde og svarte ledninger gjennom et spor i holderen til JST-SH-kontakten.
- O-ringer modellert sammenklemte. Spor: snor 1,5 i spor 2,2 x 1,1 (27 % klem, 73 % fylling); Qi-vindu nå med klem (rev B2 hadde ingen);
  dybdesensor 3,0 x 1,0 radielt (20 %); våtkontakt 2,0 x 0,8 (19 %).
- Hjørneskruene flyttet 0,5 mm inn så toppring-O-ringen går klar av dem.
- Hengselstiftene kunne ikke settes inn i rev B2 (stroppørene og naboknappen sperret). Nå bores det Ø1,6 gjennom de indre stroppørene.
- 6 fjærkontakter til sensorkortet (J7) og VEML6030 (2 x 2 mm) på flexen, som koblingsskjema rev C.
- Messinginnsatser med rifler; skruene får ekte ISO-gjenger når `bygg_b3.py` legger dem inn i Fusion (modellerte gjenger).

Kontroller (mappen `kontroller/`):
- `overlap.py`: 0 overlapp mellom 120 deler (eksakt B-rep).
- `asm_b3.py`: 24 monteringssteg; hver del trekkes ut langs sin monteringsretning uten å treffe noe (`b3_asm.txt`).
- `glands.py`: O-ringspor, skruelast, innsatser, flatetrykk og oppdrift (`b3_checks.json`).

Fusion: kjør `bygg_b3.py` fra Text Commands (Py); den lager mappen "08 Rev B3", setter gjenger på skruene,
bygger sammenstillingen med hengselledd og kjører kollisjonssjekk. Ikke validert for dykking: trykktest gjenstår.
Ekte komponentmodeller: Espressif KiCad Libraries og KiCads 3D-bibliotek, CC-BY-SA 4.0.
