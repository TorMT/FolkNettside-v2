# Dykkecomputer, koblingsskjema rev C (passer til hus rev B3)

| Fil | Hva |
| --- | --- |
| `dykkecomputer.sch` | Koblingsskjema (EAGLE 9-format). Last opp i Fusion: blir et elektronikkdesign med fire ark |
| `dykkecomputer-skjema.pdf` | De fire arkene som PDF (A3) |
| `netliste.csv`, `komponentliste.csv` | Alle nett med pinner, og alle komponenter |
| `circuit.py`, `gen_sch.py` | Kilden: endre `circuit.py`, kjør `python gen_sch.py` |
| `fusion/bygg_dykkecomputer.py` | Lager prosjektet «Dykkecomputer» på en Fusion-hub: deler, materialer, opplasting og full sammenstilling med ledd og kollisjonssjekk |

## Kjøre Fusion-skriptet

Endre `HUB` øverst i skriptet til navnet på huben din. I Fusion, Text Commands (Py):

```
BASE_DIR = r'<mappen fusion>'; AUTO_RUN = True; exec(open(BASE_DIR + r'\bygg_dykkecomputer.py', encoding='utf-8').read())
```

Skriptet henter 3D-modellene selv: husdelene fra FolkNettside, ESP32-S3-WROOM-1 fra Espressifs KiCad-bibliotek og IC-pakker, microSD og summer fra KiCads 3D-bibliotek (begge CC-BY-SA 4.0). Det tar 10–15 min; kjøres det på nytt, hopper det over det som allerede finnes.

Pinner som `main/board.h` i fastvaren. Rev B (etter kontroll av alle kretser, se prosjektloggen på nettsiden): ikke gjennomgått av en annen person. Ikke validert for dykking.
