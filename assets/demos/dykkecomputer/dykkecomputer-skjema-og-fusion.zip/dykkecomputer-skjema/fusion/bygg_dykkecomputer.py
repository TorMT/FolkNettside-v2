"""Builds the dive computer (3.5 in build) as a Fusion project on a hub.

Run it in Fusion: Utilities > Scripts and Add-Ins, or paste into the Text Commands
window (Py mode):  exec(open(r'<this file>', encoding='utf-8').read())

It is safe to run again: files that already exist in the project are kept, and the
assembly is only built when it is missing.

Stages (each logs to bygg_logg.txt next to this file):
  1. project "Dykkecomputer" on HUB, with folders 01-05
  2. every part imported from step/, given a material and saved as its own design
  3. schematic, netlist, parts list and documents uploaded
  4. the full assembly: every part inserted by reference, in place, grouped into
     Hus / Elektronikk / Kraft / Knapper, joints, interference check and mass
"""
import adsk.core, adsk.fusion, os, time, json, math, traceback

HUB = "TorHub"
PROJECT = "Dykkecomputer"
BASE = globals().get("BASE_DIR") or os.path.dirname(os.path.abspath(__file__))
CAD_ZIPS = ["https://raw.githubusercontent.com/TorMT/FolkNettside-v2/main/assets/demos/dykkecomputer/dykkecomputer-3d-modeller.zip",
            "https://raw.githubusercontent.com/TorMT/FolkNettside-v2/dive-demo-cad-models/assets/demos/dykkecomputer/dykkecomputer-3d-modeller.zip"]
VENDOR = {"espressif.3dshapes": "https://raw.githubusercontent.com/espressif/kicad-libraries/main/3dmodels/espressif.3dshapes/",
          "*": "https://raw.githubusercontent.com/KiCad/kicad-packages3D/master/"}
ASSEMBLY = "Dykkecomputer 3.5 - sammenstilling"

F_HUS, F_KOMP, F_ELEK, F_SAM, F_DOK = "01 Hus", "02 Innkjøpte komponenter", "03 Elektronikk", "04 Sammenstilling", "05 Dokumentasjon"

# part -> (folder, group in the assembly, materials to try, description)
HUS = ("housing_frame", "bezel", "back_plate", "lens", "qi_window", "wet_contact_pin_1", "wet_contact_pin_2")
KNAPP = ("button_lever_1", "button_lever_2", "button_lever_3", "button_magnet_1", "button_magnet_2", "button_magnet_3")
KRAFT = ("lipo_battery", "qi_coil", "qi_ferrite_sheet")
TRANSFORMS = json.load(open(os.path.join(BASE, "transforms.json"), encoding="utf-8"))

MAT = {
    "housing_frame": ["Aluminum 6061", "Aluminum"], "bezel": ["Aluminum 6061", "Aluminum"], "back_plate": ["Aluminum 6061", "Aluminum"],
    "lens": ["Glass, Clear Glazing, Tempered", "Glass"], "display_module": ["Glass"], "display_active_area": ["Glass"],
    "qi_window": ["PEEK", "Nylon 6/6"],
    "wet_contact_pin": ["Stainless Steel 316L", "Stainless Steel"],
    "button_lever": ["Acetal Resin, Black", "ABS Plastic"],
    "button_magnet": ["Neodymium", "Iron", "Steel"],
    "main_pcb": ["FR4", "Epoxy Resin"],
    "qi_coil": ["Copper"], "rx_coil_winding": ["Copper"],
    "qi_ferrite_sheet": ["Ferrite", "Ceramic", "Iron"], "rx_ferrite_rod": ["Ferrite", "Ceramic", "Iron"],
    "lipo_battery": ["Aluminum", "ABS Plastic"],
    "vibration_motor_1027": ["Steel"], "wet": ["Steel"],
}
DEFAULT_MAT = ["Epoxy Resin", "ABS Plastic"]

app = adsk.core.Application.get()
ui = app.userInterface
LOG = os.path.join(BASE, "bygg_logg.txt")


def log(msg):
    line = time.strftime("%H:%M:%S ") + str(msg)
    try:
        app.log(line)
    except Exception:
        pass
    with open(LOG, "a", encoding="utf-8") as f:
        f.write(line + "\n")


def wait(sec):
    t = time.time()
    while time.time() - t < sec:
        adsk.doEvents()
        time.sleep(0.05)


def folder_of(name):
    if name in HUS or name.startswith("button_lever"):
        return F_HUS
    if name == "main_pcb":
        return F_ELEK
    return F_KOMP


def group_of(name):
    if name in HUS:
        return "Hus"
    if name in KNAPP:
        return "Knapper"
    if name in KRAFT:
        return "Kraft"
    return "Elektronikk"


def nice(name):
    return name.replace("_", " ")


def files_in(folder):
    out = {}
    for i in range(folder.dataFiles.count):
        f = folder.dataFiles.item(i)
        out[f.name] = f
    return out


def subfolder(root, name):
    f = root.dataFolders.itemByName(name)
    return f if f else root.dataFolders.add(name)


# ---------------------------------------------------------------- materials
_mats = None


def material(cands):
    global _mats
    if _mats is None:
        _mats = {}
        for li in range(app.materialLibraries.count):
            lib = app.materialLibraries.item(li)
            if "Material" not in lib.name:
                continue
            for mi in range(lib.materials.count):
                m = lib.materials.item(mi)
                _mats.setdefault(m.name.lower(), m)
    for c in cands:
        if c.lower() in _mats:
            return _mats[c.lower()]
    for c in cands:
        for k, m in _mats.items():
            if c.lower() in k:
                return m
    return None


def mat_for(name):
    for k, v in MAT.items():
        if name.startswith(k):
            return material(v) or material(DEFAULT_MAT)
    return material(DEFAULT_MAT)


# ---------------------------------------------------------------- stage 0: fetch models
def stage0_fetch():
    import urllib.request, zipfile, subprocess, sys
    cad = os.path.join(BASE, "cad")
    if not os.path.isdir(os.path.join(cad, "dc-3in5-forearm", "step")):
        z = os.path.join(BASE, "cad.zip")
        for url in CAD_ZIPS:
            try:
                urllib.request.urlretrieve(url, z)
                break
            except Exception as e:
                log(f"Kunne ikke hente {url}: {e}")
        zipfile.ZipFile(z).extractall(cad)
        log("Hentet CAD-pakken")
    vd = os.path.join(BASE, "vendor")
    os.makedirs(vd, exist_ok=True)
    for n, t in TRANSFORMS.items():
        p = os.path.join(vd, t["file"])
        if not os.path.exists(p) or os.path.getsize(p) < 1000:
            url = VENDOR.get(t["dir"], VENDOR["*"] + t["dir"] + "/") + t["file"]
            urllib.request.urlretrieve(url, p)
            log(f"Hentet {t['file']} ({os.path.getsize(p) // 1024} kB)")
    # schematic, netlist and sheets from the circuit description
    ed = os.path.join(BASE, "elektronikk")
    if not os.path.isdir(ed) and os.path.exists(os.path.join(BASE, "..", "circuit.py")):
        ed = os.path.normpath(os.path.join(BASE, ".."))
    if not os.path.exists(os.path.join(ed, "dykkecomputer.sch")):
        g = {"__name__": "__main__"}
        cwd = os.getcwd()
        sys.path.insert(0, ed)
        os.chdir(ed)
        try:
            exec(open(os.path.join(ed, "gen_sch.py"), encoding="utf-8").read(), g)
        finally:
            os.chdir(cwd)
            sys.path.remove(ed)
        log("Laget koblingsskjema og netliste")
    return sorted(os.listdir(os.path.join(cad, "dc-3in5-forearm", "step")))


def part_path(n):
    if n in TRANSFORMS:
        return os.path.join(BASE, "vendor", TRANSFORMS[n]["file"])
    return os.path.join(BASE, "cad", "dc-3in5-forearm", "step", n + ".step")


def placement(n):
    m = adsk.core.Matrix3D.create()
    t = TRANSFORMS.get(n)
    if not t:
        return m
    if t["rot"]:
        m.setToRotation(math.radians(t["rot"]), adsk.core.Vector3D.create(0, 0, 1), adsk.core.Point3D.create(0, 0, 0))
    tr = adsk.core.Matrix3D.create()
    tr.translation = adsk.core.Vector3D.create(t["t"][0] / 10, t["t"][1] / 10, t["t"][2] / 10)
    m.transformBy(tr)
    return m


# ---------------------------------------------------------------- stages
def stage1_project():
    hub = None
    for i in range(app.data.dataHubs.count):
        h = app.data.dataHubs.item(i)
        if h.name.replace(" ", "").lower() == HUB.replace(" ", "").lower():
            hub = h
    if not hub:
        raise RuntimeError("Fant ikke huben " + HUB)
    app.data.activeHub = hub
    proj = None
    for i in range(hub.dataProjects.count):
        if hub.dataProjects.item(i).name == PROJECT:
            proj = hub.dataProjects.item(i)
    if not proj:
        proj = hub.dataProjects.add(PROJECT)
        log("Laget prosjektet " + PROJECT)
        wait(3)
    root = proj.rootFolder
    folders = {n: subfolder(root, n) for n in (F_HUS, F_KOMP, F_ELEK, F_SAM, F_DOK)}
    app.data.activeProject = proj
    return proj, folders


def part_names():
    d = os.path.join(BASE, "cad", "dc-3in5-forearm", "step")
    return sorted(f[:-5] for f in os.listdir(d) if f.endswith(".step"))


def stage2_parts(folders, limit=99):
    names = part_names()
    done = {}
    for fn in folders.values():
        done.update(files_in(fn))
    made = 0
    for n in names:
        title = nice(n)
        if title in done:
            continue
        if made >= limit:
            break
        opts = app.importManager.createSTEPImportOptions(part_path(n))
        doc = app.importManager.importToNewDocument(opts)
        des = adsk.fusion.Design.cast(doc.products.itemByProductType("DesignProductType"))
        root = des.rootComponent
        m = mat_for(n)
        if m:
            root.material = m
        src = TRANSFORMS.get(n, {}).get("file")
        desc = ("Innkjøpt del, 3D-modell fra " + src + " (CC-BY-SA 4.0)") if src else ("Del av dykkecomputeren, " + group_of(n))
        root.description = desc
        try:
            root.partNumber = n
        except Exception:
            pass
        if not doc.saveAs(title, folders[folder_of(n)], desc, ""):
            log("Kunne ikke lagre " + title)
        wait(1.5)
        doc.close(False)
        made += 1
        log(f"Del lagret: {title} -> {folder_of(n)} ({m.name if m else 'uten materiale'})")
    left = len([n for n in names if nice(n) not in done]) - made
    log(f"Deler: {made} nye denne runden, {left} igjen")
    return left


def upload(folder, path):
    have = files_in(folder)
    base = os.path.splitext(os.path.basename(path))[0]
    if base in have or os.path.basename(path) in have:
        return
    fut = folder.uploadFile(path)
    t = time.time()
    while fut.uploadState == adsk.core.UploadStates.UploadProcessing and time.time() - t < 120:
        wait(0.5)
    log(f"Lastet opp {os.path.basename(path)} -> {folder.name}: {fut.uploadState}")


def stage3_docs(folders):
    ed = os.path.join(BASE, "elektronikk")
    if not os.path.isdir(ed):
        ed = os.path.normpath(os.path.join(BASE, ".."))
    for f in ("dykkecomputer.sch", "dykkecomputer-skjema.pdf"):
        p = os.path.join(ed, f)
        if os.path.exists(p):
            upload(folders[F_ELEK], p)
    cad = os.path.join(BASE, "cad")
    for p in (os.path.join(cad, "section.png"),):
        if os.path.exists(p):
            upload(folders[F_DOK], p)


def find_file(folders, title, tries=60):
    for _ in range(tries):
        for fd in folders.values():
            f = files_in(fd).get(title)
            if f:
                return f
        wait(2)
    return None


def stage4_assembly(folders, names=None):
    names = names or part_names()
    if ASSEMBLY in files_in(folders[F_SAM]):
        log("Sammenstillingen finnes allerede: åpne den fra " + F_SAM)
        return
    doc = app.documents.add(adsk.core.DocumentTypes.FusionDesignDocumentType)
    des = adsk.fusion.Design.cast(app.activeProduct)
    des.designType = adsk.fusion.DesignTypes.ParametricDesignType
    root = des.rootComponent
    root.description = "Full sammenstilling, 3.5 in underarmsbygg. Alle deler er referanser til egne design i prosjektet."
    doc.saveAs(ASSEMBLY, folders[F_SAM], "Dykkecomputer, full sammenstilling", "")
    wait(3)
    groups = {}
    for g in ("Hus", "Elektronikk", "Kraft", "Knapper"):
        occ = root.occurrences.addNewComponent(adsk.core.Matrix3D.create())
        occ.component.name = g
        groups[g] = occ
    occs = {}
    for n in names:
        df = find_file(folders, nice(n))
        if not df:
            log("Mangler fil for " + n)
            continue
        target = groups[group_of(n)].component
        for attempt in range(20):
            try:
                o = target.occurrences.addByInsert(df, placement(n), True)
                occs[n] = o.createForAssemblyContext(groups[group_of(n)])
                break
            except Exception as e:
                if attempt == 19:
                    log(f"Kunne ikke sette inn {n}: {e}")
                wait(3)
        adsk.doEvents()
    log(f"Satt inn {len(occs)} av {len(names)} deler")

    # joints: housing grounded, the rest held in place by rigid groups; buttons slide 1.5 mm inwards
    groups["Hus"].isGrounded = True
    try:
        col = adsk.core.ObjectCollection.create()
        for g in ("Hus", "Elektronikk", "Kraft"):
            col.add(groups[g])
        root.rigidGroups.add(col, True)
        log("Stiv gruppe: Hus + Elektronikk + Kraft")
    except Exception as e:
        log("Stiv gruppe feilet: " + str(e))
    for i in (1, 2, 3):
        lev, mag = occs.get(f"button_lever_{i}"), occs.get(f"button_magnet_{i}")
        if not lev:
            continue
        try:
            if mag:
                c = adsk.core.ObjectCollection.create()
                c.add(lev)
                c.add(mag)
                root.rigidGroups.add(c, False)
            face = None
            for b in lev.bRepBodies:
                for f in b.faces:
                    if f.geometry.surfaceType == adsk.core.SurfaceTypes.CylinderSurfaceType:
                        face = f
                        break
            geo = adsk.fusion.JointGeometry.createByNonPlanarFace(face, adsk.fusion.JointKeyPointTypes.MiddleKeyPoint)
            ji = root.asBuiltJoints.createInput(lev, groups["Hus"], geo)
            ji.setAsSliderJointMotion(adsk.fusion.JointDirections.ZAxisJointDirection)
            j = root.asBuiltJoints.add(ji)
            j.name = f"Knapp {i}"
            lim = j.jointMotion.slideLimits
            lim.isMinimumValueEnabled = True
            lim.minimumValue = -0.15
            lim.isMaximumValueEnabled = True
            lim.maximumValue = 0.15
            log(f"Glideledd for knapp {i}, ±1.5 mm vandring")
        except Exception as e:
            log(f"Knapp {i}: ledd feilet ({e}); spaken er låst")

    # interference
    try:
        col = adsk.core.ObjectCollection.create()
        for o in occs.values():
            col.add(o)
        ii = des.createInterferenceInput(col)
        ii.areCoincidentFacesIncluded = False
        res = des.analyzeInterference(ii)
        lines = []
        for k in range(res.count):
            r = res.item(k)
            lines.append(f"{r.entityOne.assemblyContext.name if r.entityOne.assemblyContext else '?'} / {r.entityTwo.assemblyContext.name if r.entityTwo.assemblyContext else '?'}: {r.interferenceBody.volume * 1000:.3f} mm3")
        log(f"Kollisjonssjekk: {res.count} overlapp" + ("" if not lines else "\n  " + "\n  ".join(lines)))
    except Exception as e:
        log("Kollisjonssjekk feilet: " + str(e))
    try:
        pp = root.getPhysicalProperties(adsk.fusion.CalculationAccuracy.MediumCalculationAccuracy)
        log(f"Masse (med bibliotekmaterialer): {pp.mass * 1000:.0f} g")
    except Exception as e:
        log("Masse feilet: " + str(e))
    app.activeViewport.fit()
    doc.save("Deler satt inn, ledd og kollisjonssjekk")
    log("Sammenstilling lagret i " + F_SAM)


def run():
    log("Start. Mappe: " + BASE)
    stage0_fetch()
    proj, folders = stage1_project()
    while stage2_parts(folders, 10) > 0:
        pass
    stage3_docs(folders)
    stage4_assembly(folders)
    log("Ferdig.")


if globals().get("AUTO_RUN", False):
    try:
        run()
    except Exception:
        log("FEIL:\n" + traceback.format_exc())
