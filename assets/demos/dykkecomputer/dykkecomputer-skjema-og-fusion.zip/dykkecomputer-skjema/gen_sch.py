"""Writes the dive computer schematic as an EAGLE 9 .sch (opens in Fusion Electronics) and as SVG sheets."""
import math, html, json, sys
from xml.sax.saxutils import escape as _esc
X = lambda t: _esc(t, {'"': '&quot;'})
from circuit import PARTS, SHEETS

G = 2.54
def snap(v): return round(v / G) * G
LBL = 1.778          # label text size (mm)
CH = 1.27 * 0.9      # approx char width at that size... used for layout only
STUB = 2 * G

def body_size(p):
    ref, val, kind, sh, L, R, desc = p
    n = max(len(L), len(R), 1)
    if kind in ("ic", "conn") and (len(L) + len(R) > 2 or kind == "conn"):
        names = [x[0] for x in L + R]
        w = max(8 * G, snap((max(len(a) for a in names) * 2 + 4) * 1.1) + 2 * G) if names else 8 * G
        if not R or not L: w = max(6 * G, snap(max(len(a) for a in names) * 1.25 + 3 * G))
        h = (n + 1) * G
        return w, h, True
    return 4 * G, 2 * G, False      # two-pin part

def pin_points(p):
    """(name, net, dir, x, y, side) relative to the part origin (body centre). x,y is the connection point."""
    w, h, big = body_size(p)
    out = []
    L, R = p[4], p[5]
    if big:
        n = max(len(L), len(R), 1)
        top = (n - 1) * G / 2
        for i, (nm, net, d) in enumerate(L):
            out.append((nm, net, d, -w / 2 - G, round(top - i * G, 3), "L"))
        for i, (nm, net, d) in enumerate(R):
            out.append((nm, net, d, w / 2 + G, round(top - i * G, 3), "R"))
    else:
        out.append((L[0][0], L[0][1], L[0][2], -w / 2 - G, 0, "L"))
        if R: out.append((R[0][0], R[0][1], R[0][2], w / 2 + G, 0, "R"))
    return out

def label_len(net): return len(net) * 1.5 + 2
def footprint(p):
    w, h, big = body_size(p)
    ln = max([label_len(n) for (_, n, *_r) in p[4]] + [6])
    rn = max([label_len(n) for (_, n, *_r) in p[5]] + [0])
    lw = G + STUB + ln
    rw = (G + STUB + rn) if p[5] else 0
    top = 5 * G      # name, value
    bottom = 2 * G + (G * 1.6 if p[6] else 0)
    return lw, rw, w, h, top, bottom

def layout(sheet):
    parts = [p for p in PARTS if p[3] == sheet]
    MAXH = 240.0
    cols, col, ch = [], [], 0
    for p in parts:
        lw, rw, w, h, t, b = footprint(p)
        ph = h + t + b
        if col and ch + ph > MAXH:
            cols.append(col); col, ch = [], 0
        col.append(p); ch += ph
    if col: cols.append(col)
    pos = {}
    x = 25.0
    for col in cols:
        cw = max(footprint(p)[0] + footprint(p)[2] + footprint(p)[1] for p in col)
        lmax = max(footprint(p)[0] for p in col)
        y = 255.0
        for p in col:
            lw, rw, w, h, t, b = footprint(p)
            y -= t
            cx = snap(x + lmax + w / 2); cy = snap(y - h / 2)
            pos[p[0]] = (cx, cy)
            y -= h + b
        x += cw + 4 * G
    width = max(420.0, x + 10); height = 297.0
    return parts, pos, width, height

# ---------------------------------------------------------------- EAGLE
def symbol_xml(p):
    w, h, big = body_size(p)
    kind = p[2]
    s = [f'<symbol name="SYM_{p[0]}">']
    wl = lambda x1, y1, x2, y2, lay=94, wd=0.254: s.append(f'<wire x1="{x1:.3f}" y1="{y1:.3f}" x2="{x2:.3f}" y2="{y2:.3f}" width="{wd}" layer="{lay}"/>')
    if big:
        for a, b in (((-w/2, -h/2), (w/2, -h/2)), ((w/2, -h/2), (w/2, h/2)), ((w/2, h/2), (-w/2, h/2)), ((-w/2, h/2), (-w/2, -h/2))):
            wl(*a, *b)
    elif kind == "c":
        wl(-w/2, 0, -0.6, 0, 94, 0.1524); wl(0.6, 0, w/2, 0, 94, 0.1524)
        wl(-0.6, -1.6, -0.6, 1.6, 94, 0.4064); wl(0.6, -1.6, 0.6, 1.6, 94, 0.4064)
    elif kind == "d":
        wl(-w/2, 0, w/2, 0, 94, 0.1524); wl(-1, -1.2, -1, 1.2); wl(-1, 1.2, 1, 0); wl(-1, -1.2, 1, 0); wl(1, -1.2, 1, 1.2)
    else:
        for a, b in (((-w/2, -0.9), (w/2, -0.9)), ((w/2, -0.9), (w/2, 0.9)), ((w/2, 0.9), (-w/2, 0.9)), ((-w/2, 0.9), (-w/2, -0.9))):
            wl(*a, *b)
    for (nm, net, d, x, y, side) in pin_points(p):
        rot = "R0" if side == "L" else "R180"
        vis = "pin" if big else "off"
        pnm = X(nm)
        s.append(f'<pin name="{pnm}" x="{x:.3f}" y="{y:.3f}" visible="{vis}" length="short" direction="{d}" rot="{rot}"/>')
    s.append(f'<text x="{-w/2:.3f}" y="{h/2 + 2.8:.3f}" size="1.778" layer="95">&gt;NAME</text>')
    s.append(f'<text x="{-w/2:.3f}" y="{h/2 + 0.6:.3f}" size="1.27" layer="96">&gt;VALUE</text>')
    s.append('</symbol>')
    return "".join(s)

def eagle():
    layers = [(91, "Nets", 2), (92, "Busses", 1), (93, "Pins", 2), (94, "Symbols", 4), (95, "Names", 7), (96, "Values", 7), (97, "Info", 7), (98, "Guide", 6)]
    o = ['<?xml version="1.0" encoding="utf-8"?>\n<!DOCTYPE eagle SYSTEM "eagle.dtd">\n<eagle version="9.6.2">\n<drawing>\n',
         '<settings><setting alwaysvectorfont="no"/><setting verticaltext="up"/></settings>\n',
         '<grid distance="0.1" unitdist="inch" unit="inch" style="lines" multiple="1" display="no" altdistance="0.01" altunitdist="inch" altunit="inch"/>\n<layers>\n']
    for n, nm, c in layers:
        o.append(f'<layer number="{n}" name="{nm}" color="{c}" fill="1" visible="yes" active="yes"/>\n')
    o.append('</layers>\n<schematic xreflabel="%F%N/%S.%C%R" xrefpart="/%S.%C%R">\n<description>Dykkecomputer 3.5 in — koblingsskjema. Generert fra circuit.py; pinner som i main/board.h.</description>\n')
    o.append('<libraries>\n<library name="dykkecomputer">\n<description>Symboler for dykkecomputeren (kun skjema; fotavtrykk velges i PCB-steget).</description>\n<packages>\n</packages>\n<symbols>\n')
    for p in PARTS: o.append(symbol_xml(p) + "\n")
    o.append('</symbols>\n<devicesets>\n')
    for p in PARTS:
        pre = ''.join(ch for ch in p[0] if ch.isalpha())
        o.append(f'<deviceset name="DS_{p[0]}" prefix="{pre}" uservalue="yes"><description>{X(p[1])}. {X(p[6])}</description><gates><gate name="G$1" symbol="SYM_{p[0]}" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>\n')
    o.append('</devicesets>\n</library>\n</libraries>\n<attributes>\n</attributes>\n<variantdefs>\n</variantdefs>\n<classes>\n<class number="0" name="default" width="0" drill="0">\n</class>\n</classes>\n<parts>\n')
    for p in PARTS:
        o.append(f'<part name="{p[0]}" library="dykkecomputer" deviceset="DS_{p[0]}" device="" value="{X(p[1])}"/>\n')
    o.append('</parts>\n<sheets>\n')
    for si, (title, sub) in enumerate(SHEETS, 1):
        parts, pos, W, H = layout(si)
        o.append(f'<sheet>\n<description>{X(title)}</description>\n<plain>\n')
        for a, b in (((0, 0), (W, 0)), ((W, 0), (W, H)), ((W, H), (0, H)), ((0, H), (0, 0)), ((5, 5), (W-5, 5)), ((W-5, 5), (W-5, H-5)), ((W-5, H-5), (5, H-5)), ((5, H-5), (5, 5)), ((W-150, 25), (W-5, 25)), ((W-150, 5), (W-150, 25))):
            o.append(f'<wire x1="{a[0]}" y1="{a[1]}" x2="{b[0]}" y2="{b[1]}" width="0.254" layer="97"/>\n')
        o.append(f'<text x="{W-147}" y="17" size="3.81" layer="97">Dykkecomputer 3.5 in — {X(title)}</text>\n')
        o.append(f'<text x="{W-147}" y="11" size="1.778" layer="97">{X(sub)}</text>\n')
        o.append(f'<text x="{W-147}" y="7" size="1.524" layer="97">Ark {si} av {len(SHEETS)} · rev C · 2026-11-21 · ikke validert for dykking</text>\n')
        o.append(f'<text x="10" y="{H-12}" size="3.81" layer="97">{X(title)}</text>\n')
        o.append('</plain>\n<instances>\n')
        for p in parts:
            x, y = pos[p[0]]
            o.append(f'<instance part="{p[0]}" gate="G$1" x="{x:.3f}" y="{y:.3f}"/>\n')
        o.append('</instances>\n<busses>\n</busses>\n<nets>\n')
        nets = {}
        for p in parts:
            x0, y0 = pos[p[0]]
            for (nm, net, d, x, y, side) in pin_points(p):
                nets.setdefault(net, []).append((p[0], nm, x0 + x, y0 + y, side))
        for net in sorted(nets):
            o.append(f'<net name="{X(net)}" class="0">\n')
            for (ref, nm, x, y, side) in nets[net]:
                xe = x - STUB if side == "L" else x + STUB
                rot = ' rot="R180"' if side == "L" else ''
                o.append(f'<segment>\n<pinref part="{ref}" gate="G$1" pin="{X(nm)}"/>\n<wire x1="{x:.3f}" y1="{y:.3f}" x2="{xe:.3f}" y2="{y:.3f}" width="0.1524" layer="91"/>\n<label x="{xe:.3f}" y="{y:.3f}" size="1.778" layer="95"{rot}/>\n</segment>\n')
            o.append('</net>\n')
        o.append('</nets>\n</sheet>\n')
    o.append('</sheets>\n</schematic>\n</drawing>\n</eagle>\n')
    return "".join(o)

# ---------------------------------------------------------------- SVG
NETC = {"GND": "#2e7d32", "3V3": "#c62828", "VBAT": "#ad1457", "5V_A": "#6a1b9a"}
def svg(si):
    title, sub = SHEETS[si - 1]
    parts, pos, W, H = layout(si)
    k = 4.0   # px per mm
    Y = lambda y: (H - y) * k
    s = [f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W*k:.0f} {H*k:.0f}" width="{W*k:.0f}" height="{H*k:.0f}" font-family="Inter, Helvetica, Arial, sans-serif">',
         f'<rect width="100%" height="100%" fill="#fffdf8"/>',
         f'<rect x="{5*k}" y="{5*k}" width="{(W-10)*k}" height="{(H-10)*k}" fill="none" stroke="#7a6f5c" stroke-width="2"/>',
         f'<text x="{10*k}" y="{16*k}" font-size="{6*k}" font-weight="700" fill="#2b2620">{html.escape(title)}</text>',
         f'<text x="{10*k}" y="{22*k}" font-size="{2.6*k}" fill="#5b5346">{html.escape(sub)}</text>',
         f'<rect x="{(W-150)*k}" y="{(H-25)*k}" width="{145*k}" height="{20*k}" fill="#f4efe4" stroke="#7a6f5c" stroke-width="2"/>',
         f'<text x="{(W-147)*k}" y="{(H-17)*k}" font-size="{3.6*k}" font-weight="700" fill="#2b2620">Dykkecomputer 3.5 in</text>',
         f'<text x="{(W-147)*k}" y="{(H-11)*k}" font-size="{2.2*k}" fill="#5b5346">Ark {si} av {len(SHEETS)} · rev C · 2026-11-21 · pinner som main/board.h</text>',
         f'<text x="{(W-147)*k}" y="{(H-7)*k}" font-size="{2.0*k}" fill="#a33">Ikke validert for dykking</text>']
    for p in parts:
        x0, y0 = pos[p[0]]
        w, h, big = body_size(p)
        kind = p[2]
        if big:
            s.append(f'<rect x="{(x0-w/2)*k:.1f}" y="{Y(y0+h/2):.1f}" width="{w*k:.1f}" height="{h*k:.1f}" fill="#fff6dc" stroke="#3b3326" stroke-width="2"/>')
        elif kind == "c":
            s.append(f'<line x1="{(x0-0.6)*k}" y1="{Y(y0+1.6)}" x2="{(x0-0.6)*k}" y2="{Y(y0-1.6)}" stroke="#3b3326" stroke-width="3"/><line x1="{(x0+0.6)*k}" y1="{Y(y0+1.6)}" x2="{(x0+0.6)*k}" y2="{Y(y0-1.6)}" stroke="#3b3326" stroke-width="3"/>')
            s.append(f'<line x1="{(x0-w/2)*k}" y1="{Y(y0)}" x2="{(x0-0.6)*k}" y2="{Y(y0)}" stroke="#3b3326" stroke-width="1.5"/><line x1="{(x0+0.6)*k}" y1="{Y(y0)}" x2="{(x0+w/2)*k}" y2="{Y(y0)}" stroke="#3b3326" stroke-width="1.5"/>')
        elif kind == "d":
            s.append(f'<line x1="{(x0-w/2)*k}" y1="{Y(y0)}" x2="{(x0+w/2)*k}" y2="{Y(y0)}" stroke="#3b3326" stroke-width="1.5"/><polygon points="{(x0-1)*k},{Y(y0+1.2)} {(x0+1)*k},{Y(y0)} {(x0-1)*k},{Y(y0-1.2)}" fill="#3b3326"/><line x1="{(x0+1)*k}" y1="{Y(y0+1.2)}" x2="{(x0+1)*k}" y2="{Y(y0-1.2)}" stroke="#3b3326" stroke-width="2"/>')
        elif kind == "coil":
            s.append(f'<line x1="{(x0-w/2)*k}" y1="{Y(y0)}" x2="{(x0+w/2)*k}" y2="{Y(y0)}" stroke="#fffdf8" stroke-width="1"/>')
            for i in range(4):
                cx = x0 - 3 + 1 + i * 2
                s.append(f'<path d="M {(cx-1)*k} {Y(y0)} A {k} {k} 0 0 1 {(cx+1)*k} {Y(y0)}" fill="none" stroke="#3b3326" stroke-width="2"/>')
            s.append(f'<line x1="{(x0-w/2)*k}" y1="{Y(y0)}" x2="{(x0-3)*k}" y2="{Y(y0)}" stroke="#3b3326" stroke-width="1.5"/><line x1="{(x0+3)*k}" y1="{Y(y0)}" x2="{(x0+w/2)*k}" y2="{Y(y0)}" stroke="#3b3326" stroke-width="1.5"/>')
        else:
            s.append(f'<rect x="{(x0-w/2)*k:.1f}" y="{Y(y0+0.9):.1f}" width="{w*k:.1f}" height="{1.8*k:.1f}" fill="#fff6dc" stroke="#3b3326" stroke-width="2"/>')
        s.append(f'<text x="{(x0-w/2)*k:.1f}" y="{Y(y0+h/2+2.8):.1f}" font-size="{2.2*k}" font-weight="700" fill="#2b2620">{p[0]}</text>')
        s.append(f'<text x="{(x0-w/2)*k:.1f}" y="{Y(y0+h/2+0.7):.1f}" font-size="{1.7*k}" fill="#5b5346">{html.escape(p[1])}</text>')
        if p[6]:
            s.append(f'<text x="{(x0-w/2)*k:.1f}" y="{Y(y0-h/2-2.6):.1f}" font-size="{1.45*k}" font-style="italic" fill="#7a6f5c">{html.escape(p[6])}</text>')
        for (nm, net, d, x, y, side) in pin_points(p):
            px, py = x0 + x, y0 + y
            inner = px + G if side == "L" else px - G
            xe = px - STUB if side == "L" else px + STUB
            col = NETC.get(net, "#1f4e79")
            s.append(f'<line x1="{inner*k:.1f}" y1="{Y(py):.1f}" x2="{px*k:.1f}" y2="{Y(py):.1f}" stroke="#3b3326" stroke-width="1.5"/>')
            s.append(f'<line x1="{px*k:.1f}" y1="{Y(py):.1f}" x2="{xe*k:.1f}" y2="{Y(py):.1f}" stroke="{col}" stroke-width="1.5"/>')
            s.append(f'<circle cx="{px*k:.1f}" cy="{Y(py):.1f}" r="2" fill="{col}"/>')
            anc = "end" if side == "L" else "start"
            tx = (xe - 0.6) if side == "L" else (xe + 0.6)
            s.append(f'<text x="{tx*k:.1f}" y="{Y(py)+5:.1f}" font-size="{1.6*k}" text-anchor="{anc}" fill="{col}" font-weight="600">{html.escape(net)}</text>')
            if big:
                ia = "start" if side == "L" else "end"
                ix = (px + G + 0.7) if side == "L" else (px - G - 0.7)
                s.append(f'<text x="{ix*k:.1f}" y="{Y(py)+5:.1f}" font-size="{1.5*k}" text-anchor="{ia}" fill="#2b2620">{html.escape(nm)}</text>')
    s.append('</svg>')
    return "\n".join(s)

if __name__ == "__main__":
    open("dykkecomputer.sch", "w", encoding="utf-8", newline="\n").write(eagle())
    for i in range(1, len(SHEETS) + 1):
        open(f"ark{i}.svg", "w", encoding="utf-8").write(svg(i))
    # netlist for reference
    nets = {}
    for p in PARTS:
        for (nm, net, d) in p[4] + p[5]:
            nets.setdefault(net, []).append(f"{p[0]}.{nm}")
    with open("netliste.csv", "w", encoding="utf-8-sig") as f:
        f.write("Nett;Pinner\n")
        for n in sorted(nets): f.write(f"{n};{' '.join(nets[n])}\n")
    with open("komponentliste.csv", "w", encoding="utf-8-sig") as f:
        f.write("Ref;Verdi/del;Ark;Funksjon\n")
        for p in PARTS: f.write(f"{p[0]};{p[1]};{p[3]};{p[6]}\n")
    for i in range(1, len(SHEETS)+1):
        print(i, layout(i)[2:])
