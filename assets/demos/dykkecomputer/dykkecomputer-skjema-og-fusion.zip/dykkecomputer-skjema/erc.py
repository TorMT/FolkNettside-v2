"""Electrical rule check on circuit.py: floating nets, undriven inputs, output conflicts, ESP32-S3 pins to avoid, decoupling."""
import collections, re, runpy, sys
C = runpy.run_path(sys.argv[1] if len(sys.argv) > 1 else "circuit.py")
PARTS = C["PARTS"]
nets = collections.defaultdict(list)
refs = collections.Counter()
for ref, val, kind, sheet, left, right, desc in PARTS:
    refs[ref] += 1
    for name, net, d in list(left) + list(right):
        nets[net].append((ref, name, d, kind))
out = []
dup = [r for r, n in refs.items() if n > 1]
if dup: out.append(("FEIL", "Doble referanser", ", ".join(dup)))
for net, pins in sorted(nets.items()):
    if net in ("NC", "-", ""): continue
    if len(pins) == 1:
        out.append(("ADVARSEL", "Nett med bare én pinne", f"{net}: {pins[0][0]}.{pins[0][1]}"))
    dirs = [p[2] for p in pins]
    if "in" in dirs and not any(d in ("out", "io", "pwr", "pas", "oc") for d in dirs):
        out.append(("FEIL", "Inngang uten driver", f"{net}: " + ", ".join(f"{p[0]}.{p[1]}" for p in pins)))
    outs = [p for p in pins if p[2] == "out"]
    if len(outs) > 1:
        out.append(("FEIL", "To utganger på samme nett", f"{net}: " + ", ".join(f"{p[0]}.{p[1]}" for p in outs)))
# ESP32-S3-WROOM-1 N16R8: GPIO26-32 flash, GPIO33-37 octal PSRAM, strapping 0/3/45/46
u1 = [p for p in PARTS if p[0] == "U1"][0]
gp = {}
for name, net, d in list(u1[4]) + list(u1[5]):
    m = re.match(r"IO(\d+)$", name)
    if m: gp[int(m.group(1))] = net
for g in sorted(gp):
    if 26 <= g <= 37:
        out.append(("FEIL", "Pinne brukt av flash/PSRAM i N16R8", f"GPIO{g} = {gp[g]}"))
    if g in (0, 3, 45, 46):
        out.append(("MERKNAD", "Strapping-pinne", f"GPIO{g} = {gp[g]}: må ikke trekkes feil vei ved oppstart"))
dupnet = [n for n, c in collections.Counter(gp.values()).items() if c > 1]
if dupnet: out.append(("FEIL", "Samme nett på flere ESP32-pinner", ", ".join(dupnet)))
# decoupling: every IC power net should have at least one capacitor
caps = {net for ref, val, kind, sh, l, r, d in PARTS if kind == "c" for _, net, _ in list(l) + list(r)}
for ref, val, kind, sh, l, r, d in PARTS:
    if kind != "ic": continue
    for name, net, dd in list(l) + list(r):
        if dd == "pwr" and net not in ("GND",) and net not in caps:
            out.append(("ADVARSEL", "Strømpinne uten kondensator på nettet", f"{ref}.{name} på {net}"))
print(f"{len(PARTS)} komponenter, {len(nets)} nett, ESP32-pinner i bruk: {len(gp)}")
for row in out:
    print(" | ".join(row))
print(f"FEIL: {sum(r[0] == 'FEIL' for r in out)}, ADVARSEL: {sum(r[0] == 'ADVARSEL' for r in out)}, MERKNAD: {sum(r[0] == 'MERKNAD' for r in out)}")
