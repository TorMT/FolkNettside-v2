<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE eagle SYSTEM "eagle.dtd">
<eagle version="9.6.2">
<drawing>
<settings><setting alwaysvectorfont="no"/><setting verticaltext="up"/></settings>
<grid distance="0.1" unitdist="inch" unit="inch" style="lines" multiple="1" display="no" altdistance="0.01" altunitdist="inch" altunit="inch"/>
<layers>
<layer number="91" name="Nets" color="2" fill="1" visible="yes" active="yes"/>
<layer number="92" name="Busses" color="1" fill="1" visible="yes" active="yes"/>
<layer number="93" name="Pins" color="2" fill="1" visible="yes" active="yes"/>
<layer number="94" name="Symbols" color="4" fill="1" visible="yes" active="yes"/>
<layer number="95" name="Names" color="7" fill="1" visible="yes" active="yes"/>
<layer number="96" name="Values" color="7" fill="1" visible="yes" active="yes"/>
<layer number="97" name="Info" color="7" fill="1" visible="yes" active="yes"/>
<layer number="98" name="Guide" color="6" fill="1" visible="yes" active="yes"/>
</layers>
<schematic xreflabel="%F%N/%S.%C%R" xrefpart="/%S.%C%R">
<description>Dykkecomputer 3.5 in — koblingsskjema. Generert fra circuit.py; pinner som i main/board.h.</description>
<libraries>
<library name="dykkecomputer">
<description>Symboler for dykkecomputeren (kun skjema; fotavtrykk velges i PCB-steget).</description>
<packages>
</packages>
<symbols>
<symbol name="SYM_U1"><wire x1="-10.160" y1="-25.400" x2="10.160" y2="-25.400" width="0.254" layer="94"/><wire x1="10.160" y1="-25.400" x2="10.160" y2="25.400" width="0.254" layer="94"/><wire x1="10.160" y1="25.400" x2="-10.160" y2="25.400" width="0.254" layer="94"/><wire x1="-10.160" y1="25.400" x2="-10.160" y2="-25.400" width="0.254" layer="94"/><pin name="3V3" x="-12.700" y="22.860" visible="pin" length="short" direction="pwr" rot="R0"/><pin name="EN" x="-12.700" y="20.320" visible="pin" length="short" direction="in" rot="R0"/><pin name="IO0" x="-12.700" y="17.780" visible="pin" length="short" direction="io" rot="R0"/><pin name="IO19" x="-12.700" y="15.240" visible="pin" length="short" direction="io" rot="R0"/><pin name="IO20" x="-12.700" y="12.700" visible="pin" length="short" direction="io" rot="R0"/><pin name="TXD0" x="-12.700" y="10.160" visible="pin" length="short" direction="out" rot="R0"/><pin name="RXD0" x="-12.700" y="7.620" visible="pin" length="short" direction="in" rot="R0"/><pin name="IO1" x="-12.700" y="5.080" visible="pin" length="short" direction="out" rot="R0"/><pin name="IO2" x="-12.700" y="2.540" visible="pin" length="short" direction="in" rot="R0"/><pin name="IO3" x="-12.700" y="0.000" visible="pin" length="short" direction="io" rot="R0"/><pin name="IO17" x="-12.700" y="-2.540" visible="pin" length="short" direction="out" rot="R0"/><pin name="IO18" x="-12.700" y="-5.080" visible="pin" length="short" direction="in" rot="R0"/><pin name="IO38" x="-12.700" y="-7.620" visible="pin" length="short" direction="in" rot="R0"/><pin name="IO48" x="-12.700" y="-10.160" visible="pin" length="short" direction="in" rot="R0"/><pin name="GND" x="-12.700" y="-12.700" visible="pin" length="short" direction="pwr" rot="R0"/><pin name="IO8" x="12.700" y="22.860" visible="pin" length="short" direction="io" rot="R180"/><pin name="IO9" x="12.700" y="20.320" visible="pin" length="short" direction="io" rot="R180"/><pin name="IO12" x="12.700" y="17.780" visible="pin" length="short" direction="out" rot="R180"/><pin name="IO11" x="12.700" y="15.240" visible="pin" length="short" direction="out" rot="R180"/><pin name="IO13" x="12.700" y="12.700" visible="pin" length="short" direction="in" rot="R180"/><pin name="IO10" x="12.700" y="10.160" visible="pin" length="short" direction="out" rot="R180"/><pin name="IO14" x="12.700" y="7.620" visible="pin" length="short" direction="out" rot="R180"/><pin name="IO21" x="12.700" y="5.080" visible="pin" length="short" direction="out" rot="R180"/><pin name="IO16" x="12.700" y="2.540" visible="pin" length="short" direction="out" rot="R180"/><pin name="IO15" x="12.700" y="0.000" visible="pin" length="short" direction="out" rot="R180"/><pin name="IO7" x="12.700" y="-2.540" visible="pin" length="short" direction="out" rot="R180"/><pin name="IO4" x="12.700" y="-5.080" visible="pin" length="short" direction="out" rot="R180"/><pin name="IO5" x="12.700" y="-7.620" visible="pin" length="short" direction="out" rot="R180"/><pin name="IO6" x="12.700" y="-10.160" visible="pin" length="short" direction="in" rot="R180"/><pin name="IO39" x="12.700" y="-12.700" visible="pin" length="short" direction="in" rot="R180"/><pin name="IO41" x="12.700" y="-15.240" visible="pin" length="short" direction="in" rot="R180"/><pin name="IO42" x="12.700" y="-17.780" visible="pin" length="short" direction="in" rot="R180"/><pin name="IO40" x="12.700" y="-20.320" visible="pin" length="short" direction="out" rot="R180"/><pin name="IO47" x="12.700" y="-22.860" visible="pin" length="short" direction="out" rot="R180"/><text x="-10.160" y="28.200" size="1.778" layer="95">&gt;NAME</text><text x="-10.160" y="26.000" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_R1"><wire x1="-5.080" y1="-0.900" x2="5.080" y2="-0.900" width="0.254" layer="94"/><wire x1="5.080" y1="-0.900" x2="5.080" y2="0.900" width="0.254" layer="94"/><wire x1="5.080" y1="0.900" x2="-5.080" y2="0.900" width="0.254" layer="94"/><wire x1="-5.080" y1="0.900" x2="-5.080" y2="-0.900" width="0.254" layer="94"/><pin name="1" x="-7.620" y="0.000" visible="off" length="short" direction="pas" rot="R0"/><pin name="2" x="7.620" y="0.000" visible="off" length="short" direction="pas" rot="R180"/><text x="-5.080" y="5.340" size="1.778" layer="95">&gt;NAME</text><text x="-5.080" y="3.140" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_C1"><wire x1="-5.080" y1="0.000" x2="-0.600" y2="0.000" width="0.1524" layer="94"/><wire x1="0.600" y1="0.000" x2="5.080" y2="0.000" width="0.1524" layer="94"/><wire x1="-0.600" y1="-1.600" x2="-0.600" y2="1.600" width="0.4064" layer="94"/><wire x1="0.600" y1="-1.600" x2="0.600" y2="1.600" width="0.4064" layer="94"/><pin name="1" x="-7.620" y="0.000" visible="off" length="short" direction="pas" rot="R0"/><pin name="2" x="7.620" y="0.000" visible="off" length="short" direction="pas" rot="R180"/><text x="-5.080" y="5.340" size="1.778" layer="95">&gt;NAME</text><text x="-5.080" y="3.140" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_C2"><wire x1="-5.080" y1="0.000" x2="-0.600" y2="0.000" width="0.1524" layer="94"/><wire x1="0.600" y1="0.000" x2="5.080" y2="0.000" width="0.1524" layer="94"/><wire x1="-0.600" y1="-1.600" x2="-0.600" y2="1.600" width="0.4064" layer="94"/><wire x1="0.600" y1="-1.600" x2="0.600" y2="1.600" width="0.4064" layer="94"/><pin name="1" x="-7.620" y="0.000" visible="off" length="short" direction="pas" rot="R0"/><pin name="2" x="7.620" y="0.000" visible="off" length="short" direction="pas" rot="R180"/><text x="-5.080" y="5.340" size="1.778" layer="95">&gt;NAME</text><text x="-5.080" y="3.140" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_C3"><wire x1="-5.080" y1="0.000" x2="-0.600" y2="0.000" width="0.1524" layer="94"/><wire x1="0.600" y1="0.000" x2="5.080" y2="0.000" width="0.1524" layer="94"/><wire x1="-0.600" y1="-1.600" x2="-0.600" y2="1.600" width="0.4064" layer="94"/><wire x1="0.600" y1="-1.600" x2="0.600" y2="1.600" width="0.4064" layer="94"/><pin name="1" x="-7.620" y="0.000" visible="off" length="short" direction="pas" rot="R0"/><pin name="2" x="7.620" y="0.000" visible="off" length="short" direction="pas" rot="R180"/><text x="-5.080" y="5.340" size="1.778" layer="95">&gt;NAME</text><text x="-5.080" y="3.140" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_J1"><wire x1="-7.620" y1="-11.430" x2="7.620" y2="-11.430" width="0.254" layer="94"/><wire x1="7.620" y1="-11.430" x2="7.620" y2="11.430" width="0.254" layer="94"/><wire x1="7.620" y1="11.430" x2="-7.620" y2="11.430" width="0.254" layer="94"/><wire x1="-7.620" y1="11.430" x2="-7.620" y2="-11.430" width="0.254" layer="94"/><pin name="1" x="-10.160" y="8.890" visible="pin" length="short" direction="pwr" rot="R0"/><pin name="2" x="-10.160" y="6.350" visible="pin" length="short" direction="pwr" rot="R0"/><pin name="3" x="-10.160" y="3.810" visible="pin" length="short" direction="io" rot="R0"/><pin name="4" x="-10.160" y="1.270" visible="pin" length="short" direction="io" rot="R0"/><pin name="5" x="-10.160" y="-1.270" visible="pin" length="short" direction="in" rot="R0"/><pin name="6" x="-10.160" y="-3.810" visible="pin" length="short" direction="out" rot="R0"/><pin name="7" x="-10.160" y="-6.350" visible="pin" length="short" direction="io" rot="R0"/><pin name="8" x="-10.160" y="-8.890" visible="pin" length="short" direction="io" rot="R0"/><text x="-7.620" y="14.230" size="1.778" layer="95">&gt;NAME</text><text x="-7.620" y="12.030" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_L1"><wire x1="-5.080" y1="-0.900" x2="5.080" y2="-0.900" width="0.254" layer="94"/><wire x1="5.080" y1="-0.900" x2="5.080" y2="0.900" width="0.254" layer="94"/><wire x1="5.080" y1="0.900" x2="-5.080" y2="0.900" width="0.254" layer="94"/><wire x1="-5.080" y1="0.900" x2="-5.080" y2="-0.900" width="0.254" layer="94"/><pin name="1" x="-7.620" y="0.000" visible="off" length="short" direction="pas" rot="R0"/><pin name="2" x="7.620" y="0.000" visible="off" length="short" direction="pas" rot="R180"/><text x="-5.080" y="5.340" size="1.778" layer="95">&gt;NAME</text><text x="-5.080" y="3.140" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_U20"><wire x1="-10.160" y1="-3.810" x2="10.160" y2="-3.810" width="0.254" layer="94"/><wire x1="10.160" y1="-3.810" x2="10.160" y2="3.810" width="0.254" layer="94"/><wire x1="10.160" y1="3.810" x2="-10.160" y2="3.810" width="0.254" layer="94"/><wire x1="-10.160" y1="3.810" x2="-10.160" y2="-3.810" width="0.254" layer="94"/><pin name="AC1" x="-12.700" y="1.270" visible="pin" length="short" direction="pas" rot="R0"/><pin name="AC2" x="-12.700" y="-1.270" visible="pin" length="short" direction="pas" rot="R0"/><pin name="VOUT" x="12.700" y="1.270" visible="pin" length="short" direction="pwr" rot="R180"/><pin name="GND" x="12.700" y="-1.270" visible="pin" length="short" direction="pwr" rot="R180"/><text x="-10.160" y="6.610" size="1.778" layer="95">&gt;NAME</text><text x="-10.160" y="4.410" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_U21"><wire x1="-10.160" y1="-5.080" x2="10.160" y2="-5.080" width="0.254" layer="94"/><wire x1="10.160" y1="-5.080" x2="10.160" y2="5.080" width="0.254" layer="94"/><wire x1="10.160" y1="5.080" x2="-10.160" y2="5.080" width="0.254" layer="94"/><wire x1="-10.160" y1="5.080" x2="-10.160" y2="-5.080" width="0.254" layer="94"/><pin name="VDD" x="-12.700" y="2.540" visible="pin" length="short" direction="pwr" rot="R0"/><pin name="PROG" x="-12.700" y="0.000" visible="pin" length="short" direction="pas" rot="R0"/><pin name="VSS" x="-12.700" y="-2.540" visible="pin" length="short" direction="pwr" rot="R0"/><pin name="VBAT" x="12.700" y="2.540" visible="pin" length="short" direction="pwr" rot="R180"/><pin name="STAT" x="12.700" y="0.000" visible="pin" length="short" direction="out" rot="R180"/><text x="-10.160" y="7.880" size="1.778" layer="95">&gt;NAME</text><text x="-10.160" y="5.680" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_R2"><wire x1="-5.080" y1="-0.900" x2="5.080" y2="-0.900" width="0.254" layer="94"/><wire x1="5.080" y1="-0.900" x2="5.080" y2="0.900" width="0.254" layer="94"/><wire x1="5.080" y1="0.900" x2="-5.080" y2="0.900" width="0.254" layer="94"/><wire x1="-5.080" y1="0.900" x2="-5.080" y2="-0.900" width="0.254" layer="94"/><pin name="1" x="-7.620" y="0.000" visible="off" length="short" direction="pas" rot="R0"/><pin name="2" x="7.620" y="0.000" visible="off" length="short" direction="pas" rot="R180"/><text x="-5.080" y="5.340" size="1.778" layer="95">&gt;NAME</text><text x="-5.080" y="3.140" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_R3"><wire x1="-5.080" y1="-0.900" x2="5.080" y2="-0.900" width="0.254" layer="94"/><wire x1="5.080" y1="-0.900" x2="5.080" y2="0.900" width="0.254" layer="94"/><wire x1="5.080" y1="0.900" x2="-5.080" y2="0.900" width="0.254" layer="94"/><wire x1="-5.080" y1="0.900" x2="-5.080" y2="-0.900" width="0.254" layer="94"/><pin name="1" x="-7.620" y="0.000" visible="off" length="short" direction="pas" rot="R0"/><pin name="2" x="7.620" y="0.000" visible="off" length="short" direction="pas" rot="R180"/><text x="-5.080" y="5.340" size="1.778" layer="95">&gt;NAME</text><text x="-5.080" y="3.140" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_R4"><wire x1="-5.080" y1="-0.900" x2="5.080" y2="-0.900" width="0.254" layer="94"/><wire x1="5.080" y1="-0.900" x2="5.080" y2="0.900" width="0.254" layer="94"/><wire x1="5.080" y1="0.900" x2="-5.080" y2="0.900" width="0.254" layer="94"/><wire x1="-5.080" y1="0.900" x2="-5.080" y2="-0.900" width="0.254" layer="94"/><pin name="1" x="-7.620" y="0.000" visible="off" length="short" direction="pas" rot="R0"/><pin name="2" x="7.620" y="0.000" visible="off" length="short" direction="pas" rot="R180"/><text x="-5.080" y="5.340" size="1.778" layer="95">&gt;NAME</text><text x="-5.080" y="3.140" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_C4"><wire x1="-5.080" y1="0.000" x2="-0.600" y2="0.000" width="0.1524" layer="94"/><wire x1="0.600" y1="0.000" x2="5.080" y2="0.000" width="0.1524" layer="94"/><wire x1="-0.600" y1="-1.600" x2="-0.600" y2="1.600" width="0.4064" layer="94"/><wire x1="0.600" y1="-1.600" x2="0.600" y2="1.600" width="0.4064" layer="94"/><pin name="1" x="-7.620" y="0.000" visible="off" length="short" direction="pas" rot="R0"/><pin name="2" x="7.620" y="0.000" visible="off" length="short" direction="pas" rot="R180"/><text x="-5.080" y="5.340" size="1.778" layer="95">&gt;NAME</text><text x="-5.080" y="3.140" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_C5"><wire x1="-5.080" y1="0.000" x2="-0.600" y2="0.000" width="0.1524" layer="94"/><wire x1="0.600" y1="0.000" x2="5.080" y2="0.000" width="0.1524" layer="94"/><wire x1="-0.600" y1="-1.600" x2="-0.600" y2="1.600" width="0.4064" layer="94"/><wire x1="0.600" y1="-1.600" x2="0.600" y2="1.600" width="0.4064" layer="94"/><pin name="1" x="-7.620" y="0.000" visible="off" length="short" direction="pas" rot="R0"/><pin name="2" x="7.620" y="0.000" visible="off" length="short" direction="pas" rot="R180"/><text x="-5.080" y="5.340" size="1.778" layer="95">&gt;NAME</text><text x="-5.080" y="3.140" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_BT1"><wire x1="-5.080" y1="-0.900" x2="5.080" y2="-0.900" width="0.254" layer="94"/><wire x1="5.080" y1="-0.900" x2="5.080" y2="0.900" width="0.254" layer="94"/><wire x1="5.080" y1="0.900" x2="-5.080" y2="0.900" width="0.254" layer="94"/><wire x1="-5.080" y1="0.900" x2="-5.080" y2="-0.900" width="0.254" layer="94"/><pin name="+" x="-7.620" y="0.000" visible="off" length="short" direction="pwr" rot="R0"/><pin name="-" x="7.620" y="0.000" visible="off" length="short" direction="pwr" rot="R180"/><text x="-5.080" y="5.340" size="1.778" layer="95">&gt;NAME</text><text x="-5.080" y="3.140" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_U23"><wire x1="-10.160" y1="-5.080" x2="10.160" y2="-5.080" width="0.254" layer="94"/><wire x1="10.160" y1="-5.080" x2="10.160" y2="5.080" width="0.254" layer="94"/><wire x1="10.160" y1="5.080" x2="-10.160" y2="5.080" width="0.254" layer="94"/><wire x1="-10.160" y1="5.080" x2="-10.160" y2="-5.080" width="0.254" layer="94"/><pin name="IN" x="-12.700" y="2.540" visible="pin" length="short" direction="pwr" rot="R0"/><pin name="EN" x="-12.700" y="0.000" visible="pin" length="short" direction="in" rot="R0"/><pin name="GND" x="-12.700" y="-2.540" visible="pin" length="short" direction="pwr" rot="R0"/><pin name="OUT" x="12.700" y="2.540" visible="pin" length="short" direction="pwr" rot="R180"/><text x="-10.160" y="7.880" size="1.778" layer="95">&gt;NAME</text><text x="-10.160" y="5.680" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_C6"><wire x1="-5.080" y1="0.000" x2="-0.600" y2="0.000" width="0.1524" layer="94"/><wire x1="0.600" y1="0.000" x2="5.080" y2="0.000" width="0.1524" layer="94"/><wire x1="-0.600" y1="-1.600" x2="-0.600" y2="1.600" width="0.4064" layer="94"/><wire x1="0.600" y1="-1.600" x2="0.600" y2="1.600" width="0.4064" layer="94"/><pin name="1" x="-7.620" y="0.000" visible="off" length="short" direction="pas" rot="R0"/><pin name="2" x="7.620" y="0.000" visible="off" length="short" direction="pas" rot="R180"/><text x="-5.080" y="5.340" size="1.778" layer="95">&gt;NAME</text><text x="-5.080" y="3.140" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_C7"><wire x1="-5.080" y1="0.000" x2="-0.600" y2="0.000" width="0.1524" layer="94"/><wire x1="0.600" y1="0.000" x2="5.080" y2="0.000" width="0.1524" layer="94"/><wire x1="-0.600" y1="-1.600" x2="-0.600" y2="1.600" width="0.4064" layer="94"/><wire x1="0.600" y1="-1.600" x2="0.600" y2="1.600" width="0.4064" layer="94"/><pin name="1" x="-7.620" y="0.000" visible="off" length="short" direction="pas" rot="R0"/><pin name="2" x="7.620" y="0.000" visible="off" length="short" direction="pas" rot="R180"/><text x="-5.080" y="5.340" size="1.778" layer="95">&gt;NAME</text><text x="-5.080" y="3.140" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_U9"><wire x1="-10.160" y1="-7.620" x2="10.160" y2="-7.620" width="0.254" layer="94"/><wire x1="10.160" y1="-7.620" x2="10.160" y2="7.620" width="0.254" layer="94"/><wire x1="10.160" y1="7.620" x2="-10.160" y2="7.620" width="0.254" layer="94"/><wire x1="-10.160" y1="7.620" x2="-10.160" y2="-7.620" width="0.254" layer="94"/><pin name="VDD" x="-12.700" y="5.080" visible="pin" length="short" direction="pwr" rot="R0"/><pin name="CELL" x="-12.700" y="2.540" visible="pin" length="short" direction="in" rot="R0"/><pin name="CTG" x="-12.700" y="0.000" visible="pin" length="short" direction="in" rot="R0"/><pin name="QSTRT" x="-12.700" y="-2.540" visible="pin" length="short" direction="in" rot="R0"/><pin name="GND" x="-12.700" y="-5.080" visible="pin" length="short" direction="pwr" rot="R0"/><pin name="SDA" x="12.700" y="5.080" visible="pin" length="short" direction="io" rot="R180"/><pin name="SCL" x="12.700" y="2.540" visible="pin" length="short" direction="in" rot="R180"/><pin name="ALRT" x="12.700" y="0.000" visible="pin" length="short" direction="oc" rot="R180"/><text x="-10.160" y="10.420" size="1.778" layer="95">&gt;NAME</text><text x="-10.160" y="8.220" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_U2"><wire x1="-10.160" y1="-11.430" x2="10.160" y2="-11.430" width="0.254" layer="94"/><wire x1="10.160" y1="-11.430" x2="10.160" y2="11.430" width="0.254" layer="94"/><wire x1="10.160" y1="11.430" x2="-10.160" y2="11.430" width="0.254" layer="94"/><wire x1="-10.160" y1="11.430" x2="-10.160" y2="-11.430" width="0.254" layer="94"/><pin name="VCC" x="-12.700" y="8.890" visible="pin" length="short" direction="pwr" rot="R0"/><pin name="SDA" x="-12.700" y="6.350" visible="pin" length="short" direction="io" rot="R0"/><pin name="SCL" x="-12.700" y="3.810" visible="pin" length="short" direction="in" rot="R0"/><pin name="RESET" x="-12.700" y="1.270" visible="pin" length="short" direction="in" rot="R0"/><pin name="A0" x="-12.700" y="-1.270" visible="pin" length="short" direction="in" rot="R0"/><pin name="A1" x="-12.700" y="-3.810" visible="pin" length="short" direction="in" rot="R0"/><pin name="A2" x="-12.700" y="-6.350" visible="pin" length="short" direction="in" rot="R0"/><pin name="GND" x="-12.700" y="-8.890" visible="pin" length="short" direction="pwr" rot="R0"/><pin name="SD0" x="12.700" y="8.890" visible="pin" length="short" direction="io" rot="R180"/><pin name="SC0" x="12.700" y="6.350" visible="pin" length="short" direction="io" rot="R180"/><pin name="SD1" x="12.700" y="3.810" visible="pin" length="short" direction="io" rot="R180"/><pin name="SC1" x="12.700" y="1.270" visible="pin" length="short" direction="io" rot="R180"/><text x="-10.160" y="14.230" size="1.778" layer="95">&gt;NAME</text><text x="-10.160" y="12.030" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_U3"><wire x1="-10.160" y1="-3.810" x2="10.160" y2="-3.810" width="0.254" layer="94"/><wire x1="10.160" y1="-3.810" x2="10.160" y2="3.810" width="0.254" layer="94"/><wire x1="10.160" y1="3.810" x2="-10.160" y2="3.810" width="0.254" layer="94"/><wire x1="-10.160" y1="3.810" x2="-10.160" y2="-3.810" width="0.254" layer="94"/><pin name="VDD" x="-12.700" y="1.270" visible="pin" length="short" direction="pwr" rot="R0"/><pin name="GND" x="-12.700" y="-1.270" visible="pin" length="short" direction="pwr" rot="R0"/><pin name="SDA" x="12.700" y="1.270" visible="pin" length="short" direction="io" rot="R180"/><pin name="SCL" x="12.700" y="-1.270" visible="pin" length="short" direction="in" rot="R180"/><text x="-10.160" y="6.610" size="1.778" layer="95">&gt;NAME</text><text x="-10.160" y="4.410" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_U4"><wire x1="-10.160" y1="-3.810" x2="10.160" y2="-3.810" width="0.254" layer="94"/><wire x1="10.160" y1="-3.810" x2="10.160" y2="3.810" width="0.254" layer="94"/><wire x1="10.160" y1="3.810" x2="-10.160" y2="3.810" width="0.254" layer="94"/><wire x1="-10.160" y1="3.810" x2="-10.160" y2="-3.810" width="0.254" layer="94"/><pin name="VDD" x="-12.700" y="1.270" visible="pin" length="short" direction="pwr" rot="R0"/><pin name="GND" x="-12.700" y="-1.270" visible="pin" length="short" direction="pwr" rot="R0"/><pin name="SDA" x="12.700" y="1.270" visible="pin" length="short" direction="io" rot="R180"/><pin name="SCL" x="12.700" y="-1.270" visible="pin" length="short" direction="in" rot="R180"/><text x="-10.160" y="6.610" size="1.778" layer="95">&gt;NAME</text><text x="-10.160" y="4.410" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_R10"><wire x1="-5.080" y1="-0.900" x2="5.080" y2="-0.900" width="0.254" layer="94"/><wire x1="5.080" y1="-0.900" x2="5.080" y2="0.900" width="0.254" layer="94"/><wire x1="5.080" y1="0.900" x2="-5.080" y2="0.900" width="0.254" layer="94"/><wire x1="-5.080" y1="0.900" x2="-5.080" y2="-0.900" width="0.254" layer="94"/><pin name="1" x="-7.620" y="0.000" visible="off" length="short" direction="pas" rot="R0"/><pin name="2" x="7.620" y="0.000" visible="off" length="short" direction="pas" rot="R180"/><text x="-5.080" y="5.340" size="1.778" layer="95">&gt;NAME</text><text x="-5.080" y="3.140" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_R11"><wire x1="-5.080" y1="-0.900" x2="5.080" y2="-0.900" width="0.254" layer="94"/><wire x1="5.080" y1="-0.900" x2="5.080" y2="0.900" width="0.254" layer="94"/><wire x1="5.080" y1="0.900" x2="-5.080" y2="0.900" width="0.254" layer="94"/><wire x1="-5.080" y1="0.900" x2="-5.080" y2="-0.900" width="0.254" layer="94"/><pin name="1" x="-7.620" y="0.000" visible="off" length="short" direction="pas" rot="R0"/><pin name="2" x="7.620" y="0.000" visible="off" length="short" direction="pas" rot="R180"/><text x="-5.080" y="5.340" size="1.778" layer="95">&gt;NAME</text><text x="-5.080" y="3.140" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_R12"><wire x1="-5.080" y1="-0.900" x2="5.080" y2="-0.900" width="0.254" layer="94"/><wire x1="5.080" y1="-0.900" x2="5.080" y2="0.900" width="0.254" layer="94"/><wire x1="5.080" y1="0.900" x2="-5.080" y2="0.900" width="0.254" layer="94"/><wire x1="-5.080" y1="0.900" x2="-5.080" y2="-0.900" width="0.254" layer="94"/><pin name="1" x="-7.620" y="0.000" visible="off" length="short" direction="pas" rot="R0"/><pin name="2" x="7.620" y="0.000" visible="off" length="short" direction="pas" rot="R180"/><text x="-5.080" y="5.340" size="1.778" layer="95">&gt;NAME</text><text x="-5.080" y="3.140" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_R13"><wire x1="-5.080" y1="-0.900" x2="5.080" y2="-0.900" width="0.254" layer="94"/><wire x1="5.080" y1="-0.900" x2="5.080" y2="0.900" width="0.254" layer="94"/><wire x1="5.080" y1="0.900" x2="-5.080" y2="0.900" width="0.254" layer="94"/><wire x1="-5.080" y1="0.900" x2="-5.080" y2="-0.900" width="0.254" layer="94"/><pin name="1" x="-7.620" y="0.000" visible="off" length="short" direction="pas" rot="R0"/><pin name="2" x="7.620" y="0.000" visible="off" length="short" direction="pas" rot="R180"/><text x="-5.080" y="5.340" size="1.778" layer="95">&gt;NAME</text><text x="-5.080" y="3.140" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_R14"><wire x1="-5.080" y1="-0.900" x2="5.080" y2="-0.900" width="0.254" layer="94"/><wire x1="5.080" y1="-0.900" x2="5.080" y2="0.900" width="0.254" layer="94"/><wire x1="5.080" y1="0.900" x2="-5.080" y2="0.900" width="0.254" layer="94"/><wire x1="-5.080" y1="0.900" x2="-5.080" y2="-0.900" width="0.254" layer="94"/><pin name="1" x="-7.620" y="0.000" visible="off" length="short" direction="pas" rot="R0"/><pin name="2" x="7.620" y="0.000" visible="off" length="short" direction="pas" rot="R180"/><text x="-5.080" y="5.340" size="1.778" layer="95">&gt;NAME</text><text x="-5.080" y="3.140" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_R15"><wire x1="-5.080" y1="-0.900" x2="5.080" y2="-0.900" width="0.254" layer="94"/><wire x1="5.080" y1="-0.900" x2="5.080" y2="0.900" width="0.254" layer="94"/><wire x1="5.080" y1="0.900" x2="-5.080" y2="0.900" width="0.254" layer="94"/><wire x1="-5.080" y1="0.900" x2="-5.080" y2="-0.900" width="0.254" layer="94"/><pin name="1" x="-7.620" y="0.000" visible="off" length="short" direction="pas" rot="R0"/><pin name="2" x="7.620" y="0.000" visible="off" length="short" direction="pas" rot="R180"/><text x="-5.080" y="5.340" size="1.778" layer="95">&gt;NAME</text><text x="-5.080" y="3.140" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_U5"><wire x1="-10.160" y1="-6.350" x2="10.160" y2="-6.350" width="0.254" layer="94"/><wire x1="10.160" y1="-6.350" x2="10.160" y2="6.350" width="0.254" layer="94"/><wire x1="10.160" y1="6.350" x2="-10.160" y2="6.350" width="0.254" layer="94"/><wire x1="-10.160" y1="6.350" x2="-10.160" y2="-6.350" width="0.254" layer="94"/><pin name="VDD" x="-12.700" y="3.810" visible="pin" length="short" direction="pwr" rot="R0"/><pin name="VDDIO" x="-12.700" y="1.270" visible="pin" length="short" direction="pwr" rot="R0"/><pin name="SA0" x="-12.700" y="-1.270" visible="pin" length="short" direction="in" rot="R0"/><pin name="GND" x="-12.700" y="-3.810" visible="pin" length="short" direction="pwr" rot="R0"/><pin name="SDA" x="12.700" y="3.810" visible="pin" length="short" direction="io" rot="R180"/><pin name="SCL" x="12.700" y="1.270" visible="pin" length="short" direction="in" rot="R180"/><pin name="INT1" x="12.700" y="-1.270" visible="pin" length="short" direction="out" rot="R180"/><text x="-10.160" y="9.150" size="1.778" layer="95">&gt;NAME</text><text x="-10.160" y="6.950" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_R16"><wire x1="-5.080" y1="-0.900" x2="5.080" y2="-0.900" width="0.254" layer="94"/><wire x1="5.080" y1="-0.900" x2="5.080" y2="0.900" width="0.254" layer="94"/><wire x1="5.080" y1="0.900" x2="-5.080" y2="0.900" width="0.254" layer="94"/><wire x1="-5.080" y1="0.900" x2="-5.080" y2="-0.900" width="0.254" layer="94"/><pin name="1" x="-7.620" y="0.000" visible="off" length="short" direction="pas" rot="R0"/><pin name="2" x="7.620" y="0.000" visible="off" length="short" direction="pas" rot="R180"/><text x="-5.080" y="5.340" size="1.778" layer="95">&gt;NAME</text><text x="-5.080" y="3.140" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_R17"><wire x1="-5.080" y1="-0.900" x2="5.080" y2="-0.900" width="0.254" layer="94"/><wire x1="5.080" y1="-0.900" x2="5.080" y2="0.900" width="0.254" layer="94"/><wire x1="5.080" y1="0.900" x2="-5.080" y2="0.900" width="0.254" layer="94"/><wire x1="-5.080" y1="0.900" x2="-5.080" y2="-0.900" width="0.254" layer="94"/><pin name="1" x="-7.620" y="0.000" visible="off" length="short" direction="pas" rot="R0"/><pin name="2" x="7.620" y="0.000" visible="off" length="short" direction="pas" rot="R180"/><text x="-5.080" y="5.340" size="1.778" layer="95">&gt;NAME</text><text x="-5.080" y="3.140" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_U6"><wire x1="-10.160" y1="-5.080" x2="10.160" y2="-5.080" width="0.254" layer="94"/><wire x1="10.160" y1="-5.080" x2="10.160" y2="5.080" width="0.254" layer="94"/><wire x1="10.160" y1="5.080" x2="-10.160" y2="5.080" width="0.254" layer="94"/><wire x1="-10.160" y1="5.080" x2="-10.160" y2="-5.080" width="0.254" layer="94"/><pin name="VDD" x="-12.700" y="2.540" visible="pin" length="short" direction="pwr" rot="R0"/><pin name="CAP" x="-12.700" y="0.000" visible="pin" length="short" direction="pas" rot="R0"/><pin name="GND" x="-12.700" y="-2.540" visible="pin" length="short" direction="pwr" rot="R0"/><pin name="SDA" x="12.700" y="2.540" visible="pin" length="short" direction="io" rot="R180"/><pin name="SCL" x="12.700" y="0.000" visible="pin" length="short" direction="in" rot="R180"/><text x="-10.160" y="7.880" size="1.778" layer="95">&gt;NAME</text><text x="-10.160" y="5.680" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_C10"><wire x1="-5.080" y1="0.000" x2="-0.600" y2="0.000" width="0.1524" layer="94"/><wire x1="0.600" y1="0.000" x2="5.080" y2="0.000" width="0.1524" layer="94"/><wire x1="-0.600" y1="-1.600" x2="-0.600" y2="1.600" width="0.4064" layer="94"/><wire x1="0.600" y1="-1.600" x2="0.600" y2="1.600" width="0.4064" layer="94"/><pin name="1" x="-7.620" y="0.000" visible="off" length="short" direction="pas" rot="R0"/><pin name="2" x="7.620" y="0.000" visible="off" length="short" direction="pas" rot="R180"/><text x="-5.080" y="5.340" size="1.778" layer="95">&gt;NAME</text><text x="-5.080" y="3.140" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_U7"><wire x1="-10.160" y1="-3.810" x2="10.160" y2="-3.810" width="0.254" layer="94"/><wire x1="10.160" y1="-3.810" x2="10.160" y2="3.810" width="0.254" layer="94"/><wire x1="10.160" y1="3.810" x2="-10.160" y2="3.810" width="0.254" layer="94"/><wire x1="-10.160" y1="3.810" x2="-10.160" y2="-3.810" width="0.254" layer="94"/><pin name="VDD" x="-12.700" y="1.270" visible="pin" length="short" direction="pwr" rot="R0"/><pin name="GND" x="-12.700" y="-1.270" visible="pin" length="short" direction="pwr" rot="R0"/><pin name="SDA" x="12.700" y="1.270" visible="pin" length="short" direction="io" rot="R180"/><pin name="SCL" x="12.700" y="-1.270" visible="pin" length="short" direction="in" rot="R180"/><text x="-10.160" y="6.610" size="1.778" layer="95">&gt;NAME</text><text x="-10.160" y="4.410" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_U8"><wire x1="-10.160" y1="-8.890" x2="10.160" y2="-8.890" width="0.254" layer="94"/><wire x1="10.160" y1="-8.890" x2="10.160" y2="8.890" width="0.254" layer="94"/><wire x1="10.160" y1="8.890" x2="-10.160" y2="8.890" width="0.254" layer="94"/><wire x1="-10.160" y1="8.890" x2="-10.160" y2="-8.890" width="0.254" layer="94"/><pin name="VDD" x="-12.700" y="6.350" visible="pin" length="short" direction="pwr" rot="R0"/><pin name="A0" x="-12.700" y="3.810" visible="pin" length="short" direction="in" rot="R0"/><pin name="A1" x="-12.700" y="1.270" visible="pin" length="short" direction="in" rot="R0"/><pin name="A2" x="-12.700" y="-1.270" visible="pin" length="short" direction="in" rot="R0"/><pin name="WP" x="-12.700" y="-3.810" visible="pin" length="short" direction="in" rot="R0"/><pin name="VSS" x="-12.700" y="-6.350" visible="pin" length="short" direction="pwr" rot="R0"/><pin name="SDA" x="12.700" y="6.350" visible="pin" length="short" direction="io" rot="R180"/><pin name="SCL" x="12.700" y="3.810" visible="pin" length="short" direction="in" rot="R180"/><text x="-10.160" y="11.690" size="1.778" layer="95">&gt;NAME</text><text x="-10.160" y="9.490" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_U10"><wire x1="-11.430" y1="-6.350" x2="11.430" y2="-6.350" width="0.254" layer="94"/><wire x1="11.430" y1="-6.350" x2="11.430" y2="6.350" width="0.254" layer="94"/><wire x1="11.430" y1="6.350" x2="-11.430" y2="6.350" width="0.254" layer="94"/><wire x1="-11.430" y1="6.350" x2="-11.430" y2="-6.350" width="0.254" layer="94"/><pin name="VDD" x="-13.970" y="3.810" visible="pin" length="short" direction="pwr" rot="R0"/><pin name="OSCI" x="-13.970" y="1.270" visible="pin" length="short" direction="in" rot="R0"/><pin name="OSCO" x="-13.970" y="-1.270" visible="pin" length="short" direction="out" rot="R0"/><pin name="VSS" x="-13.970" y="-3.810" visible="pin" length="short" direction="pwr" rot="R0"/><pin name="SDA" x="13.970" y="3.810" visible="pin" length="short" direction="io" rot="R180"/><pin name="SCL" x="13.970" y="1.270" visible="pin" length="short" direction="in" rot="R180"/><pin name="INT" x="13.970" y="-1.270" visible="pin" length="short" direction="oc" rot="R180"/><pin name="CLKOUT" x="13.970" y="-3.810" visible="pin" length="short" direction="out" rot="R180"/><text x="-11.430" y="9.150" size="1.778" layer="95">&gt;NAME</text><text x="-11.430" y="6.950" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_Y1"><wire x1="-5.080" y1="-0.900" x2="5.080" y2="-0.900" width="0.254" layer="94"/><wire x1="5.080" y1="-0.900" x2="5.080" y2="0.900" width="0.254" layer="94"/><wire x1="5.080" y1="0.900" x2="-5.080" y2="0.900" width="0.254" layer="94"/><wire x1="-5.080" y1="0.900" x2="-5.080" y2="-0.900" width="0.254" layer="94"/><pin name="1" x="-7.620" y="0.000" visible="off" length="short" direction="pas" rot="R0"/><pin name="2" x="7.620" y="0.000" visible="off" length="short" direction="pas" rot="R180"/><text x="-5.080" y="5.340" size="1.778" layer="95">&gt;NAME</text><text x="-5.080" y="3.140" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_C11"><wire x1="-5.080" y1="0.000" x2="-0.600" y2="0.000" width="0.1524" layer="94"/><wire x1="0.600" y1="0.000" x2="5.080" y2="0.000" width="0.1524" layer="94"/><wire x1="-0.600" y1="-1.600" x2="-0.600" y2="1.600" width="0.4064" layer="94"/><wire x1="0.600" y1="-1.600" x2="0.600" y2="1.600" width="0.4064" layer="94"/><pin name="1" x="-7.620" y="0.000" visible="off" length="short" direction="pas" rot="R0"/><pin name="2" x="7.620" y="0.000" visible="off" length="short" direction="pas" rot="R180"/><text x="-5.080" y="5.340" size="1.778" layer="95">&gt;NAME</text><text x="-5.080" y="3.140" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_C12"><wire x1="-5.080" y1="0.000" x2="-0.600" y2="0.000" width="0.1524" layer="94"/><wire x1="0.600" y1="0.000" x2="5.080" y2="0.000" width="0.1524" layer="94"/><wire x1="-0.600" y1="-1.600" x2="-0.600" y2="1.600" width="0.4064" layer="94"/><wire x1="0.600" y1="-1.600" x2="0.600" y2="1.600" width="0.4064" layer="94"/><pin name="1" x="-7.620" y="0.000" visible="off" length="short" direction="pas" rot="R0"/><pin name="2" x="7.620" y="0.000" visible="off" length="short" direction="pas" rot="R180"/><text x="-5.080" y="5.340" size="1.778" layer="95">&gt;NAME</text><text x="-5.080" y="3.140" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_C13"><wire x1="-5.080" y1="0.000" x2="-0.600" y2="0.000" width="0.1524" layer="94"/><wire x1="0.600" y1="0.000" x2="5.080" y2="0.000" width="0.1524" layer="94"/><wire x1="-0.600" y1="-1.600" x2="-0.600" y2="1.600" width="0.4064" layer="94"/><wire x1="0.600" y1="-1.600" x2="0.600" y2="1.600" width="0.4064" layer="94"/><pin name="1" x="-7.620" y="0.000" visible="off" length="short" direction="pas" rot="R0"/><pin name="2" x="7.620" y="0.000" visible="off" length="short" direction="pas" rot="R180"/><text x="-5.080" y="5.340" size="1.778" layer="95">&gt;NAME</text><text x="-5.080" y="3.140" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_L2"><wire x1="-5.080" y1="-0.900" x2="5.080" y2="-0.900" width="0.254" layer="94"/><wire x1="5.080" y1="-0.900" x2="5.080" y2="0.900" width="0.254" layer="94"/><wire x1="5.080" y1="0.900" x2="-5.080" y2="0.900" width="0.254" layer="94"/><wire x1="-5.080" y1="0.900" x2="-5.080" y2="-0.900" width="0.254" layer="94"/><pin name="1" x="-7.620" y="0.000" visible="off" length="short" direction="pas" rot="R0"/><pin name="2" x="7.620" y="0.000" visible="off" length="short" direction="pas" rot="R180"/><text x="-5.080" y="5.340" size="1.778" layer="95">&gt;NAME</text><text x="-5.080" y="3.140" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_C20"><wire x1="-5.080" y1="0.000" x2="-0.600" y2="0.000" width="0.1524" layer="94"/><wire x1="0.600" y1="0.000" x2="5.080" y2="0.000" width="0.1524" layer="94"/><wire x1="-0.600" y1="-1.600" x2="-0.600" y2="1.600" width="0.4064" layer="94"/><wire x1="0.600" y1="-1.600" x2="0.600" y2="1.600" width="0.4064" layer="94"/><pin name="1" x="-7.620" y="0.000" visible="off" length="short" direction="pas" rot="R0"/><pin name="2" x="7.620" y="0.000" visible="off" length="short" direction="pas" rot="R180"/><text x="-5.080" y="5.340" size="1.778" layer="95">&gt;NAME</text><text x="-5.080" y="3.140" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_R20"><wire x1="-5.080" y1="-0.900" x2="5.080" y2="-0.900" width="0.254" layer="94"/><wire x1="5.080" y1="-0.900" x2="5.080" y2="0.900" width="0.254" layer="94"/><wire x1="5.080" y1="0.900" x2="-5.080" y2="0.900" width="0.254" layer="94"/><wire x1="-5.080" y1="0.900" x2="-5.080" y2="-0.900" width="0.254" layer="94"/><pin name="1" x="-7.620" y="0.000" visible="off" length="short" direction="pas" rot="R0"/><pin name="2" x="7.620" y="0.000" visible="off" length="short" direction="pas" rot="R180"/><text x="-5.080" y="5.340" size="1.778" layer="95">&gt;NAME</text><text x="-5.080" y="3.140" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_U11"><wire x1="-10.160" y1="-8.890" x2="10.160" y2="-8.890" width="0.254" layer="94"/><wire x1="10.160" y1="-8.890" x2="10.160" y2="8.890" width="0.254" layer="94"/><wire x1="10.160" y1="8.890" x2="-10.160" y2="8.890" width="0.254" layer="94"/><wire x1="-10.160" y1="8.890" x2="-10.160" y2="-8.890" width="0.254" layer="94"/><pin name="VDD" x="-12.700" y="6.350" visible="pin" length="short" direction="pwr" rot="R0"/><pin name="INA+" x="-12.700" y="3.810" visible="pin" length="short" direction="in" rot="R0"/><pin name="INA-" x="-12.700" y="1.270" visible="pin" length="short" direction="in" rot="R0"/><pin name="INB+" x="-12.700" y="-1.270" visible="pin" length="short" direction="in" rot="R0"/><pin name="INB-" x="-12.700" y="-3.810" visible="pin" length="short" direction="in" rot="R0"/><pin name="VSS" x="-12.700" y="-6.350" visible="pin" length="short" direction="pwr" rot="R0"/><pin name="OUTA" x="12.700" y="6.350" visible="pin" length="short" direction="out" rot="R180"/><pin name="OUTB" x="12.700" y="3.810" visible="pin" length="short" direction="out" rot="R180"/><text x="-10.160" y="11.690" size="1.778" layer="95">&gt;NAME</text><text x="-10.160" y="9.490" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_R21"><wire x1="-5.080" y1="-0.900" x2="5.080" y2="-0.900" width="0.254" layer="94"/><wire x1="5.080" y1="-0.900" x2="5.080" y2="0.900" width="0.254" layer="94"/><wire x1="5.080" y1="0.900" x2="-5.080" y2="0.900" width="0.254" layer="94"/><wire x1="-5.080" y1="0.900" x2="-5.080" y2="-0.900" width="0.254" layer="94"/><pin name="1" x="-7.620" y="0.000" visible="off" length="short" direction="pas" rot="R0"/><pin name="2" x="7.620" y="0.000" visible="off" length="short" direction="pas" rot="R180"/><text x="-5.080" y="5.340" size="1.778" layer="95">&gt;NAME</text><text x="-5.080" y="3.140" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_C27"><wire x1="-5.080" y1="0.000" x2="-0.600" y2="0.000" width="0.1524" layer="94"/><wire x1="0.600" y1="0.000" x2="5.080" y2="0.000" width="0.1524" layer="94"/><wire x1="-0.600" y1="-1.600" x2="-0.600" y2="1.600" width="0.4064" layer="94"/><wire x1="0.600" y1="-1.600" x2="0.600" y2="1.600" width="0.4064" layer="94"/><pin name="1" x="-7.620" y="0.000" visible="off" length="short" direction="pas" rot="R0"/><pin name="2" x="7.620" y="0.000" visible="off" length="short" direction="pas" rot="R180"/><text x="-5.080" y="5.340" size="1.778" layer="95">&gt;NAME</text><text x="-5.080" y="3.140" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_R22"><wire x1="-5.080" y1="-0.900" x2="5.080" y2="-0.900" width="0.254" layer="94"/><wire x1="5.080" y1="-0.900" x2="5.080" y2="0.900" width="0.254" layer="94"/><wire x1="5.080" y1="0.900" x2="-5.080" y2="0.900" width="0.254" layer="94"/><wire x1="-5.080" y1="0.900" x2="-5.080" y2="-0.900" width="0.254" layer="94"/><pin name="1" x="-7.620" y="0.000" visible="off" length="short" direction="pas" rot="R0"/><pin name="2" x="7.620" y="0.000" visible="off" length="short" direction="pas" rot="R180"/><text x="-5.080" y="5.340" size="1.778" layer="95">&gt;NAME</text><text x="-5.080" y="3.140" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_R23"><wire x1="-5.080" y1="-0.900" x2="5.080" y2="-0.900" width="0.254" layer="94"/><wire x1="5.080" y1="-0.900" x2="5.080" y2="0.900" width="0.254" layer="94"/><wire x1="5.080" y1="0.900" x2="-5.080" y2="0.900" width="0.254" layer="94"/><wire x1="-5.080" y1="0.900" x2="-5.080" y2="-0.900" width="0.254" layer="94"/><pin name="1" x="-7.620" y="0.000" visible="off" length="short" direction="pas" rot="R0"/><pin name="2" x="7.620" y="0.000" visible="off" length="short" direction="pas" rot="R180"/><text x="-5.080" y="5.340" size="1.778" layer="95">&gt;NAME</text><text x="-5.080" y="3.140" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_C28"><wire x1="-5.080" y1="0.000" x2="-0.600" y2="0.000" width="0.1524" layer="94"/><wire x1="0.600" y1="0.000" x2="5.080" y2="0.000" width="0.1524" layer="94"/><wire x1="-0.600" y1="-1.600" x2="-0.600" y2="1.600" width="0.4064" layer="94"/><wire x1="0.600" y1="-1.600" x2="0.600" y2="1.600" width="0.4064" layer="94"/><pin name="1" x="-7.620" y="0.000" visible="off" length="short" direction="pas" rot="R0"/><pin name="2" x="7.620" y="0.000" visible="off" length="short" direction="pas" rot="R180"/><text x="-5.080" y="5.340" size="1.778" layer="95">&gt;NAME</text><text x="-5.080" y="3.140" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_R24"><wire x1="-5.080" y1="-0.900" x2="5.080" y2="-0.900" width="0.254" layer="94"/><wire x1="5.080" y1="-0.900" x2="5.080" y2="0.900" width="0.254" layer="94"/><wire x1="5.080" y1="0.900" x2="-5.080" y2="0.900" width="0.254" layer="94"/><wire x1="-5.080" y1="0.900" x2="-5.080" y2="-0.900" width="0.254" layer="94"/><pin name="1" x="-7.620" y="0.000" visible="off" length="short" direction="pas" rot="R0"/><pin name="2" x="7.620" y="0.000" visible="off" length="short" direction="pas" rot="R180"/><text x="-5.080" y="5.340" size="1.778" layer="95">&gt;NAME</text><text x="-5.080" y="3.140" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_R25"><wire x1="-5.080" y1="-0.900" x2="5.080" y2="-0.900" width="0.254" layer="94"/><wire x1="5.080" y1="-0.900" x2="5.080" y2="0.900" width="0.254" layer="94"/><wire x1="5.080" y1="0.900" x2="-5.080" y2="0.900" width="0.254" layer="94"/><wire x1="-5.080" y1="0.900" x2="-5.080" y2="-0.900" width="0.254" layer="94"/><pin name="1" x="-7.620" y="0.000" visible="off" length="short" direction="pas" rot="R0"/><pin name="2" x="7.620" y="0.000" visible="off" length="short" direction="pas" rot="R180"/><text x="-5.080" y="5.340" size="1.778" layer="95">&gt;NAME</text><text x="-5.080" y="3.140" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_R26"><wire x1="-5.080" y1="-0.900" x2="5.080" y2="-0.900" width="0.254" layer="94"/><wire x1="5.080" y1="-0.900" x2="5.080" y2="0.900" width="0.254" layer="94"/><wire x1="5.080" y1="0.900" x2="-5.080" y2="0.900" width="0.254" layer="94"/><wire x1="-5.080" y1="0.900" x2="-5.080" y2="-0.900" width="0.254" layer="94"/><pin name="1" x="-7.620" y="0.000" visible="off" length="short" direction="pas" rot="R0"/><pin name="2" x="7.620" y="0.000" visible="off" length="short" direction="pas" rot="R180"/><text x="-5.080" y="5.340" size="1.778" layer="95">&gt;NAME</text><text x="-5.080" y="3.140" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_C21"><wire x1="-5.080" y1="0.000" x2="-0.600" y2="0.000" width="0.1524" layer="94"/><wire x1="0.600" y1="0.000" x2="5.080" y2="0.000" width="0.1524" layer="94"/><wire x1="-0.600" y1="-1.600" x2="-0.600" y2="1.600" width="0.4064" layer="94"/><wire x1="0.600" y1="-1.600" x2="0.600" y2="1.600" width="0.4064" layer="94"/><pin name="1" x="-7.620" y="0.000" visible="off" length="short" direction="pas" rot="R0"/><pin name="2" x="7.620" y="0.000" visible="off" length="short" direction="pas" rot="R180"/><text x="-5.080" y="5.340" size="1.778" layer="95">&gt;NAME</text><text x="-5.080" y="3.140" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_C22"><wire x1="-5.080" y1="0.000" x2="-0.600" y2="0.000" width="0.1524" layer="94"/><wire x1="0.600" y1="0.000" x2="5.080" y2="0.000" width="0.1524" layer="94"/><wire x1="-0.600" y1="-1.600" x2="-0.600" y2="1.600" width="0.4064" layer="94"/><wire x1="0.600" y1="-1.600" x2="0.600" y2="1.600" width="0.4064" layer="94"/><pin name="1" x="-7.620" y="0.000" visible="off" length="short" direction="pas" rot="R0"/><pin name="2" x="7.620" y="0.000" visible="off" length="short" direction="pas" rot="R180"/><text x="-5.080" y="5.340" size="1.778" layer="95">&gt;NAME</text><text x="-5.080" y="3.140" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_U12"><wire x1="-10.160" y1="-10.160" x2="10.160" y2="-10.160" width="0.254" layer="94"/><wire x1="10.160" y1="-10.160" x2="10.160" y2="10.160" width="0.254" layer="94"/><wire x1="10.160" y1="10.160" x2="-10.160" y2="10.160" width="0.254" layer="94"/><wire x1="-10.160" y1="10.160" x2="-10.160" y2="-10.160" width="0.254" layer="94"/><pin name="VINL" x="-12.700" y="7.620" visible="pin" length="short" direction="in" rot="R0"/><pin name="VINR" x="-12.700" y="5.080" visible="pin" length="short" direction="in" rot="R0"/><pin name="VREF" x="-12.700" y="2.540" visible="pin" length="short" direction="pas" rot="R0"/><pin name="VCC" x="-12.700" y="0.000" visible="pin" length="short" direction="pwr" rot="R0"/><pin name="AGND" x="-12.700" y="-2.540" visible="pin" length="short" direction="pwr" rot="R0"/><pin name="VDD" x="-12.700" y="-5.080" visible="pin" length="short" direction="pwr" rot="R0"/><pin name="DGND" x="-12.700" y="-7.620" visible="pin" length="short" direction="pwr" rot="R0"/><pin name="SCKI" x="12.700" y="7.620" visible="pin" length="short" direction="in" rot="R180"/><pin name="BCK" x="12.700" y="5.080" visible="pin" length="short" direction="in" rot="R180"/><pin name="LRCK" x="12.700" y="2.540" visible="pin" length="short" direction="in" rot="R180"/><pin name="DOUT" x="12.700" y="0.000" visible="pin" length="short" direction="out" rot="R180"/><pin name="FMT" x="12.700" y="-2.540" visible="pin" length="short" direction="in" rot="R180"/><pin name="MD0" x="12.700" y="-5.080" visible="pin" length="short" direction="in" rot="R180"/><pin name="MD1" x="12.700" y="-7.620" visible="pin" length="short" direction="in" rot="R180"/><text x="-10.160" y="12.960" size="1.778" layer="95">&gt;NAME</text><text x="-10.160" y="10.760" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_C29"><wire x1="-5.080" y1="0.000" x2="-0.600" y2="0.000" width="0.1524" layer="94"/><wire x1="0.600" y1="0.000" x2="5.080" y2="0.000" width="0.1524" layer="94"/><wire x1="-0.600" y1="-1.600" x2="-0.600" y2="1.600" width="0.4064" layer="94"/><wire x1="0.600" y1="-1.600" x2="0.600" y2="1.600" width="0.4064" layer="94"/><pin name="1" x="-7.620" y="0.000" visible="off" length="short" direction="pas" rot="R0"/><pin name="2" x="7.620" y="0.000" visible="off" length="short" direction="pas" rot="R180"/><text x="-5.080" y="5.340" size="1.778" layer="95">&gt;NAME</text><text x="-5.080" y="3.140" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_C23"><wire x1="-5.080" y1="0.000" x2="-0.600" y2="0.000" width="0.1524" layer="94"/><wire x1="0.600" y1="0.000" x2="5.080" y2="0.000" width="0.1524" layer="94"/><wire x1="-0.600" y1="-1.600" x2="-0.600" y2="1.600" width="0.4064" layer="94"/><wire x1="0.600" y1="-1.600" x2="0.600" y2="1.600" width="0.4064" layer="94"/><pin name="1" x="-7.620" y="0.000" visible="off" length="short" direction="pas" rot="R0"/><pin name="2" x="7.620" y="0.000" visible="off" length="short" direction="pas" rot="R180"/><text x="-5.080" y="5.340" size="1.778" layer="95">&gt;NAME</text><text x="-5.080" y="3.140" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_U24"><wire x1="-10.160" y1="-6.350" x2="10.160" y2="-6.350" width="0.254" layer="94"/><wire x1="10.160" y1="-6.350" x2="10.160" y2="6.350" width="0.254" layer="94"/><wire x1="10.160" y1="6.350" x2="-10.160" y2="6.350" width="0.254" layer="94"/><wire x1="-10.160" y1="6.350" x2="-10.160" y2="-6.350" width="0.254" layer="94"/><pin name="VIN" x="-12.700" y="3.810" visible="pin" length="short" direction="pwr" rot="R0"/><pin name="EN" x="-12.700" y="1.270" visible="pin" length="short" direction="in" rot="R0"/><pin name="SW" x="-12.700" y="-1.270" visible="pin" length="short" direction="pas" rot="R0"/><pin name="GND" x="-12.700" y="-3.810" visible="pin" length="short" direction="pwr" rot="R0"/><pin name="VOUT" x="12.700" y="3.810" visible="pin" length="short" direction="pwr" rot="R180"/><pin name="FB" x="12.700" y="1.270" visible="pin" length="short" direction="in" rot="R180"/><text x="-10.160" y="9.150" size="1.778" layer="95">&gt;NAME</text><text x="-10.160" y="6.950" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_R33"><wire x1="-5.080" y1="-0.900" x2="5.080" y2="-0.900" width="0.254" layer="94"/><wire x1="5.080" y1="-0.900" x2="5.080" y2="0.900" width="0.254" layer="94"/><wire x1="5.080" y1="0.900" x2="-5.080" y2="0.900" width="0.254" layer="94"/><wire x1="-5.080" y1="0.900" x2="-5.080" y2="-0.900" width="0.254" layer="94"/><pin name="1" x="-7.620" y="0.000" visible="off" length="short" direction="pas" rot="R0"/><pin name="2" x="7.620" y="0.000" visible="off" length="short" direction="pas" rot="R180"/><text x="-5.080" y="5.340" size="1.778" layer="95">&gt;NAME</text><text x="-5.080" y="3.140" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_L4"><wire x1="-5.080" y1="-0.900" x2="5.080" y2="-0.900" width="0.254" layer="94"/><wire x1="5.080" y1="-0.900" x2="5.080" y2="0.900" width="0.254" layer="94"/><wire x1="5.080" y1="0.900" x2="-5.080" y2="0.900" width="0.254" layer="94"/><wire x1="-5.080" y1="0.900" x2="-5.080" y2="-0.900" width="0.254" layer="94"/><pin name="1" x="-7.620" y="0.000" visible="off" length="short" direction="pas" rot="R0"/><pin name="2" x="7.620" y="0.000" visible="off" length="short" direction="pas" rot="R180"/><text x="-5.080" y="5.340" size="1.778" layer="95">&gt;NAME</text><text x="-5.080" y="3.140" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_R27"><wire x1="-5.080" y1="-0.900" x2="5.080" y2="-0.900" width="0.254" layer="94"/><wire x1="5.080" y1="-0.900" x2="5.080" y2="0.900" width="0.254" layer="94"/><wire x1="5.080" y1="0.900" x2="-5.080" y2="0.900" width="0.254" layer="94"/><wire x1="-5.080" y1="0.900" x2="-5.080" y2="-0.900" width="0.254" layer="94"/><pin name="1" x="-7.620" y="0.000" visible="off" length="short" direction="pas" rot="R0"/><pin name="2" x="7.620" y="0.000" visible="off" length="short" direction="pas" rot="R180"/><text x="-5.080" y="5.340" size="1.778" layer="95">&gt;NAME</text><text x="-5.080" y="3.140" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_R28"><wire x1="-5.080" y1="-0.900" x2="5.080" y2="-0.900" width="0.254" layer="94"/><wire x1="5.080" y1="-0.900" x2="5.080" y2="0.900" width="0.254" layer="94"/><wire x1="5.080" y1="0.900" x2="-5.080" y2="0.900" width="0.254" layer="94"/><wire x1="-5.080" y1="0.900" x2="-5.080" y2="-0.900" width="0.254" layer="94"/><pin name="1" x="-7.620" y="0.000" visible="off" length="short" direction="pas" rot="R0"/><pin name="2" x="7.620" y="0.000" visible="off" length="short" direction="pas" rot="R180"/><text x="-5.080" y="5.340" size="1.778" layer="95">&gt;NAME</text><text x="-5.080" y="3.140" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_FB1"><wire x1="-5.080" y1="-0.900" x2="5.080" y2="-0.900" width="0.254" layer="94"/><wire x1="5.080" y1="-0.900" x2="5.080" y2="0.900" width="0.254" layer="94"/><wire x1="5.080" y1="0.900" x2="-5.080" y2="0.900" width="0.254" layer="94"/><wire x1="-5.080" y1="0.900" x2="-5.080" y2="-0.900" width="0.254" layer="94"/><pin name="1" x="-7.620" y="0.000" visible="off" length="short" direction="pas" rot="R0"/><pin name="2" x="7.620" y="0.000" visible="off" length="short" direction="pas" rot="R180"/><text x="-5.080" y="5.340" size="1.778" layer="95">&gt;NAME</text><text x="-5.080" y="3.140" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_C24"><wire x1="-5.080" y1="0.000" x2="-0.600" y2="0.000" width="0.1524" layer="94"/><wire x1="0.600" y1="0.000" x2="5.080" y2="0.000" width="0.1524" layer="94"/><wire x1="-0.600" y1="-1.600" x2="-0.600" y2="1.600" width="0.4064" layer="94"/><wire x1="0.600" y1="-1.600" x2="0.600" y2="1.600" width="0.4064" layer="94"/><pin name="1" x="-7.620" y="0.000" visible="off" length="short" direction="pas" rot="R0"/><pin name="2" x="7.620" y="0.000" visible="off" length="short" direction="pas" rot="R180"/><text x="-5.080" y="5.340" size="1.778" layer="95">&gt;NAME</text><text x="-5.080" y="3.140" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_L3"><wire x1="-5.080" y1="-0.900" x2="5.080" y2="-0.900" width="0.254" layer="94"/><wire x1="5.080" y1="-0.900" x2="5.080" y2="0.900" width="0.254" layer="94"/><wire x1="5.080" y1="0.900" x2="-5.080" y2="0.900" width="0.254" layer="94"/><wire x1="-5.080" y1="0.900" x2="-5.080" y2="-0.900" width="0.254" layer="94"/><pin name="1" x="-7.620" y="0.000" visible="off" length="short" direction="pas" rot="R0"/><pin name="2" x="7.620" y="0.000" visible="off" length="short" direction="pas" rot="R180"/><text x="-5.080" y="5.340" size="1.778" layer="95">&gt;NAME</text><text x="-5.080" y="3.140" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_C25"><wire x1="-5.080" y1="0.000" x2="-0.600" y2="0.000" width="0.1524" layer="94"/><wire x1="0.600" y1="0.000" x2="5.080" y2="0.000" width="0.1524" layer="94"/><wire x1="-0.600" y1="-1.600" x2="-0.600" y2="1.600" width="0.4064" layer="94"/><wire x1="0.600" y1="-1.600" x2="0.600" y2="1.600" width="0.4064" layer="94"/><pin name="1" x="-7.620" y="0.000" visible="off" length="short" direction="pas" rot="R0"/><pin name="2" x="7.620" y="0.000" visible="off" length="short" direction="pas" rot="R180"/><text x="-5.080" y="5.340" size="1.778" layer="95">&gt;NAME</text><text x="-5.080" y="3.140" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_D1"><wire x1="-5.080" y1="0.000" x2="5.080" y2="0.000" width="0.1524" layer="94"/><wire x1="-1.000" y1="-1.200" x2="-1.000" y2="1.200" width="0.254" layer="94"/><wire x1="-1.000" y1="1.200" x2="1.000" y2="0.000" width="0.254" layer="94"/><wire x1="-1.000" y1="-1.200" x2="1.000" y2="0.000" width="0.254" layer="94"/><wire x1="1.000" y1="-1.200" x2="1.000" y2="1.200" width="0.254" layer="94"/><pin name="A" x="-7.620" y="0.000" visible="off" length="short" direction="pas" rot="R0"/><pin name="K" x="7.620" y="0.000" visible="off" length="short" direction="pas" rot="R180"/><text x="-5.080" y="5.340" size="1.778" layer="95">&gt;NAME</text><text x="-5.080" y="3.140" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_C26"><wire x1="-5.080" y1="0.000" x2="-0.600" y2="0.000" width="0.1524" layer="94"/><wire x1="0.600" y1="0.000" x2="5.080" y2="0.000" width="0.1524" layer="94"/><wire x1="-0.600" y1="-1.600" x2="-0.600" y2="1.600" width="0.4064" layer="94"/><wire x1="0.600" y1="-1.600" x2="0.600" y2="1.600" width="0.4064" layer="94"/><pin name="1" x="-7.620" y="0.000" visible="off" length="short" direction="pas" rot="R0"/><pin name="2" x="7.620" y="0.000" visible="off" length="short" direction="pas" rot="R180"/><text x="-5.080" y="5.340" size="1.778" layer="95">&gt;NAME</text><text x="-5.080" y="3.140" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_R29"><wire x1="-5.080" y1="-0.900" x2="5.080" y2="-0.900" width="0.254" layer="94"/><wire x1="5.080" y1="-0.900" x2="5.080" y2="0.900" width="0.254" layer="94"/><wire x1="5.080" y1="0.900" x2="-5.080" y2="0.900" width="0.254" layer="94"/><wire x1="-5.080" y1="0.900" x2="-5.080" y2="-0.900" width="0.254" layer="94"/><pin name="1" x="-7.620" y="0.000" visible="off" length="short" direction="pas" rot="R0"/><pin name="2" x="7.620" y="0.000" visible="off" length="short" direction="pas" rot="R180"/><text x="-5.080" y="5.340" size="1.778" layer="95">&gt;NAME</text><text x="-5.080" y="3.140" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_U13"><wire x1="-10.160" y1="-6.350" x2="10.160" y2="-6.350" width="0.254" layer="94"/><wire x1="10.160" y1="-6.350" x2="10.160" y2="6.350" width="0.254" layer="94"/><wire x1="10.160" y1="6.350" x2="-10.160" y2="6.350" width="0.254" layer="94"/><wire x1="-10.160" y1="6.350" x2="-10.160" y2="-6.350" width="0.254" layer="94"/><pin name="VCC" x="-12.700" y="3.810" visible="pin" length="short" direction="pwr" rot="R0"/><pin name="IN+" x="-12.700" y="1.270" visible="pin" length="short" direction="in" rot="R0"/><pin name="IN-" x="-12.700" y="-1.270" visible="pin" length="short" direction="in" rot="R0"/><pin name="GND" x="-12.700" y="-3.810" visible="pin" length="short" direction="pwr" rot="R0"/><pin name="OUT" x="12.700" y="3.810" visible="pin" length="short" direction="oc" rot="R180"/><text x="-10.160" y="9.150" size="1.778" layer="95">&gt;NAME</text><text x="-10.160" y="6.950" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_R30"><wire x1="-5.080" y1="-0.900" x2="5.080" y2="-0.900" width="0.254" layer="94"/><wire x1="5.080" y1="-0.900" x2="5.080" y2="0.900" width="0.254" layer="94"/><wire x1="5.080" y1="0.900" x2="-5.080" y2="0.900" width="0.254" layer="94"/><wire x1="-5.080" y1="0.900" x2="-5.080" y2="-0.900" width="0.254" layer="94"/><pin name="1" x="-7.620" y="0.000" visible="off" length="short" direction="pas" rot="R0"/><pin name="2" x="7.620" y="0.000" visible="off" length="short" direction="pas" rot="R180"/><text x="-5.080" y="5.340" size="1.778" layer="95">&gt;NAME</text><text x="-5.080" y="3.140" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_R31"><wire x1="-5.080" y1="-0.900" x2="5.080" y2="-0.900" width="0.254" layer="94"/><wire x1="5.080" y1="-0.900" x2="5.080" y2="0.900" width="0.254" layer="94"/><wire x1="5.080" y1="0.900" x2="-5.080" y2="0.900" width="0.254" layer="94"/><wire x1="-5.080" y1="0.900" x2="-5.080" y2="-0.900" width="0.254" layer="94"/><pin name="1" x="-7.620" y="0.000" visible="off" length="short" direction="pas" rot="R0"/><pin name="2" x="7.620" y="0.000" visible="off" length="short" direction="pas" rot="R180"/><text x="-5.080" y="5.340" size="1.778" layer="95">&gt;NAME</text><text x="-5.080" y="3.140" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_R32"><wire x1="-5.080" y1="-0.900" x2="5.080" y2="-0.900" width="0.254" layer="94"/><wire x1="5.080" y1="-0.900" x2="5.080" y2="0.900" width="0.254" layer="94"/><wire x1="5.080" y1="0.900" x2="-5.080" y2="0.900" width="0.254" layer="94"/><wire x1="-5.080" y1="0.900" x2="-5.080" y2="-0.900" width="0.254" layer="94"/><pin name="1" x="-7.620" y="0.000" visible="off" length="short" direction="pas" rot="R0"/><pin name="2" x="7.620" y="0.000" visible="off" length="short" direction="pas" rot="R180"/><text x="-5.080" y="5.340" size="1.778" layer="95">&gt;NAME</text><text x="-5.080" y="3.140" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_U14"><wire x1="-11.430" y1="-6.350" x2="11.430" y2="-6.350" width="0.254" layer="94"/><wire x1="11.430" y1="-6.350" x2="11.430" y2="6.350" width="0.254" layer="94"/><wire x1="11.430" y1="6.350" x2="-11.430" y2="6.350" width="0.254" layer="94"/><wire x1="-11.430" y1="6.350" x2="-11.430" y2="-6.350" width="0.254" layer="94"/><pin name="VCC" x="-13.970" y="3.810" visible="pin" length="short" direction="pwr" rot="R0"/><pin name="V_BCKP" x="-13.970" y="1.270" visible="pin" length="short" direction="pwr" rot="R0"/><pin name="RF_IN" x="-13.970" y="-1.270" visible="pin" length="short" direction="in" rot="R0"/><pin name="GND" x="-13.970" y="-3.810" visible="pin" length="short" direction="pwr" rot="R0"/><pin name="TXD" x="13.970" y="3.810" visible="pin" length="short" direction="out" rot="R180"/><pin name="RXD" x="13.970" y="1.270" visible="pin" length="short" direction="in" rot="R180"/><pin name="1PPS" x="13.970" y="-1.270" visible="pin" length="short" direction="out" rot="R180"/><text x="-11.430" y="9.150" size="1.778" layer="95">&gt;NAME</text><text x="-11.430" y="6.950" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_U25"><wire x1="-10.160" y1="-5.080" x2="10.160" y2="-5.080" width="0.254" layer="94"/><wire x1="10.160" y1="-5.080" x2="10.160" y2="5.080" width="0.254" layer="94"/><wire x1="10.160" y1="5.080" x2="-10.160" y2="5.080" width="0.254" layer="94"/><wire x1="-10.160" y1="5.080" x2="-10.160" y2="-5.080" width="0.254" layer="94"/><pin name="VIN" x="-12.700" y="2.540" visible="pin" length="short" direction="pwr" rot="R0"/><pin name="ON" x="-12.700" y="0.000" visible="pin" length="short" direction="in" rot="R0"/><pin name="GND" x="-12.700" y="-2.540" visible="pin" length="short" direction="pwr" rot="R0"/><pin name="VOUT" x="12.700" y="2.540" visible="pin" length="short" direction="pwr" rot="R180"/><text x="-10.160" y="7.880" size="1.778" layer="95">&gt;NAME</text><text x="-10.160" y="5.680" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_R34"><wire x1="-5.080" y1="-0.900" x2="5.080" y2="-0.900" width="0.254" layer="94"/><wire x1="5.080" y1="-0.900" x2="5.080" y2="0.900" width="0.254" layer="94"/><wire x1="5.080" y1="0.900" x2="-5.080" y2="0.900" width="0.254" layer="94"/><wire x1="-5.080" y1="0.900" x2="-5.080" y2="-0.900" width="0.254" layer="94"/><pin name="1" x="-7.620" y="0.000" visible="off" length="short" direction="pas" rot="R0"/><pin name="2" x="7.620" y="0.000" visible="off" length="short" direction="pas" rot="R180"/><text x="-5.080" y="5.340" size="1.778" layer="95">&gt;NAME</text><text x="-5.080" y="3.140" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_C30"><wire x1="-5.080" y1="0.000" x2="-0.600" y2="0.000" width="0.1524" layer="94"/><wire x1="0.600" y1="0.000" x2="5.080" y2="0.000" width="0.1524" layer="94"/><wire x1="-0.600" y1="-1.600" x2="-0.600" y2="1.600" width="0.4064" layer="94"/><wire x1="0.600" y1="-1.600" x2="0.600" y2="1.600" width="0.4064" layer="94"/><pin name="1" x="-7.620" y="0.000" visible="off" length="short" direction="pas" rot="R0"/><pin name="2" x="7.620" y="0.000" visible="off" length="short" direction="pas" rot="R180"/><text x="-5.080" y="5.340" size="1.778" layer="95">&gt;NAME</text><text x="-5.080" y="3.140" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_ANT1"><wire x1="-7.620" y1="-2.540" x2="7.620" y2="-2.540" width="0.254" layer="94"/><wire x1="7.620" y1="-2.540" x2="7.620" y2="2.540" width="0.254" layer="94"/><wire x1="7.620" y1="2.540" x2="-7.620" y2="2.540" width="0.254" layer="94"/><wire x1="-7.620" y1="2.540" x2="-7.620" y2="-2.540" width="0.254" layer="94"/><pin name="1" x="-10.160" y="0.000" visible="pin" length="short" direction="pas" rot="R0"/><text x="-7.620" y="5.340" size="1.778" layer="95">&gt;NAME</text><text x="-7.620" y="3.140" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_J2"><wire x1="-7.620" y1="-13.970" x2="7.620" y2="-13.970" width="0.254" layer="94"/><wire x1="7.620" y1="-13.970" x2="7.620" y2="13.970" width="0.254" layer="94"/><wire x1="7.620" y1="13.970" x2="-7.620" y2="13.970" width="0.254" layer="94"/><wire x1="-7.620" y1="13.970" x2="-7.620" y2="-13.970" width="0.254" layer="94"/><pin name="VCC" x="-10.160" y="11.430" visible="pin" length="short" direction="pwr" rot="R0"/><pin name="GND" x="-10.160" y="8.890" visible="pin" length="short" direction="pwr" rot="R0"/><pin name="CS" x="-10.160" y="6.350" visible="pin" length="short" direction="in" rot="R0"/><pin name="DC" x="-10.160" y="3.810" visible="pin" length="short" direction="in" rot="R0"/><pin name="RST" x="-10.160" y="1.270" visible="pin" length="short" direction="in" rot="R0"/><pin name="SCK" x="-10.160" y="-1.270" visible="pin" length="short" direction="in" rot="R0"/><pin name="SDI" x="-10.160" y="-3.810" visible="pin" length="short" direction="in" rot="R0"/><pin name="SDO" x="-10.160" y="-6.350" visible="pin" length="short" direction="out" rot="R0"/><pin name="LEDA" x="-10.160" y="-8.890" visible="pin" length="short" direction="pwr" rot="R0"/><pin name="LEDK" x="-10.160" y="-11.430" visible="pin" length="short" direction="pwr" rot="R0"/><text x="-7.620" y="16.770" size="1.778" layer="95">&gt;NAME</text><text x="-7.620" y="14.570" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_R40"><wire x1="-5.080" y1="-0.900" x2="5.080" y2="-0.900" width="0.254" layer="94"/><wire x1="5.080" y1="-0.900" x2="5.080" y2="0.900" width="0.254" layer="94"/><wire x1="5.080" y1="0.900" x2="-5.080" y2="0.900" width="0.254" layer="94"/><wire x1="-5.080" y1="0.900" x2="-5.080" y2="-0.900" width="0.254" layer="94"/><pin name="1" x="-7.620" y="0.000" visible="off" length="short" direction="pas" rot="R0"/><pin name="2" x="7.620" y="0.000" visible="off" length="short" direction="pas" rot="R180"/><text x="-5.080" y="5.340" size="1.778" layer="95">&gt;NAME</text><text x="-5.080" y="3.140" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_Q1"><wire x1="-5.080" y1="-0.900" x2="5.080" y2="-0.900" width="0.254" layer="94"/><wire x1="5.080" y1="-0.900" x2="5.080" y2="0.900" width="0.254" layer="94"/><wire x1="5.080" y1="0.900" x2="-5.080" y2="0.900" width="0.254" layer="94"/><wire x1="-5.080" y1="0.900" x2="-5.080" y2="-0.900" width="0.254" layer="94"/><pin name="G" x="-7.620" y="0.000" visible="off" length="short" direction="in" rot="R0"/><pin name="D" x="7.620" y="0.000" visible="off" length="short" direction="pas" rot="R180"/><text x="-5.080" y="5.340" size="1.778" layer="95">&gt;NAME</text><text x="-5.080" y="3.140" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_R41"><wire x1="-5.080" y1="-0.900" x2="5.080" y2="-0.900" width="0.254" layer="94"/><wire x1="5.080" y1="-0.900" x2="5.080" y2="0.900" width="0.254" layer="94"/><wire x1="5.080" y1="0.900" x2="-5.080" y2="0.900" width="0.254" layer="94"/><wire x1="-5.080" y1="0.900" x2="-5.080" y2="-0.900" width="0.254" layer="94"/><pin name="1" x="-7.620" y="0.000" visible="off" length="short" direction="pas" rot="R0"/><pin name="2" x="7.620" y="0.000" visible="off" length="short" direction="pas" rot="R180"/><text x="-5.080" y="5.340" size="1.778" layer="95">&gt;NAME</text><text x="-5.080" y="3.140" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_J3"><wire x1="-7.620" y1="-11.430" x2="7.620" y2="-11.430" width="0.254" layer="94"/><wire x1="7.620" y1="-11.430" x2="7.620" y2="11.430" width="0.254" layer="94"/><wire x1="7.620" y1="11.430" x2="-7.620" y2="11.430" width="0.254" layer="94"/><wire x1="-7.620" y1="11.430" x2="-7.620" y2="-11.430" width="0.254" layer="94"/><pin name="DAT3/CS" x="-10.160" y="8.890" visible="pin" length="short" direction="in" rot="R0"/><pin name="CMD/DI" x="-10.160" y="6.350" visible="pin" length="short" direction="in" rot="R0"/><pin name="VDD" x="-10.160" y="3.810" visible="pin" length="short" direction="pwr" rot="R0"/><pin name="CLK" x="-10.160" y="1.270" visible="pin" length="short" direction="in" rot="R0"/><pin name="VSS" x="-10.160" y="-1.270" visible="pin" length="short" direction="pwr" rot="R0"/><pin name="DAT0/DO" x="-10.160" y="-3.810" visible="pin" length="short" direction="out" rot="R0"/><pin name="DAT1" x="-10.160" y="-6.350" visible="pin" length="short" direction="pas" rot="R0"/><pin name="DAT2" x="-10.160" y="-8.890" visible="pin" length="short" direction="pas" rot="R0"/><text x="-7.620" y="14.230" size="1.778" layer="95">&gt;NAME</text><text x="-7.620" y="12.030" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_R42"><wire x1="-5.080" y1="-0.900" x2="5.080" y2="-0.900" width="0.254" layer="94"/><wire x1="5.080" y1="-0.900" x2="5.080" y2="0.900" width="0.254" layer="94"/><wire x1="5.080" y1="0.900" x2="-5.080" y2="0.900" width="0.254" layer="94"/><wire x1="-5.080" y1="0.900" x2="-5.080" y2="-0.900" width="0.254" layer="94"/><pin name="1" x="-7.620" y="0.000" visible="off" length="short" direction="pas" rot="R0"/><pin name="2" x="7.620" y="0.000" visible="off" length="short" direction="pas" rot="R180"/><text x="-5.080" y="5.340" size="1.778" layer="95">&gt;NAME</text><text x="-5.080" y="3.140" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_R43"><wire x1="-5.080" y1="-0.900" x2="5.080" y2="-0.900" width="0.254" layer="94"/><wire x1="5.080" y1="-0.900" x2="5.080" y2="0.900" width="0.254" layer="94"/><wire x1="5.080" y1="0.900" x2="-5.080" y2="0.900" width="0.254" layer="94"/><wire x1="-5.080" y1="0.900" x2="-5.080" y2="-0.900" width="0.254" layer="94"/><pin name="1" x="-7.620" y="0.000" visible="off" length="short" direction="pas" rot="R0"/><pin name="2" x="7.620" y="0.000" visible="off" length="short" direction="pas" rot="R180"/><text x="-5.080" y="5.340" size="1.778" layer="95">&gt;NAME</text><text x="-5.080" y="3.140" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_R44"><wire x1="-5.080" y1="-0.900" x2="5.080" y2="-0.900" width="0.254" layer="94"/><wire x1="5.080" y1="-0.900" x2="5.080" y2="0.900" width="0.254" layer="94"/><wire x1="5.080" y1="0.900" x2="-5.080" y2="0.900" width="0.254" layer="94"/><wire x1="-5.080" y1="0.900" x2="-5.080" y2="-0.900" width="0.254" layer="94"/><pin name="1" x="-7.620" y="0.000" visible="off" length="short" direction="pas" rot="R0"/><pin name="2" x="7.620" y="0.000" visible="off" length="short" direction="pas" rot="R180"/><text x="-5.080" y="5.340" size="1.778" layer="95">&gt;NAME</text><text x="-5.080" y="3.140" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_U15"><wire x1="-13.970" y1="-7.620" x2="13.970" y2="-7.620" width="0.254" layer="94"/><wire x1="13.970" y1="-7.620" x2="13.970" y2="7.620" width="0.254" layer="94"/><wire x1="13.970" y1="7.620" x2="-13.970" y2="7.620" width="0.254" layer="94"/><wire x1="-13.970" y1="7.620" x2="-13.970" y2="-7.620" width="0.254" layer="94"/><pin name="VDD" x="-16.510" y="5.080" visible="pin" length="short" direction="pwr" rot="R0"/><pin name="PD6/URX" x="-16.510" y="2.540" visible="pin" length="short" direction="in" rot="R0"/><pin name="PD5/UTX" x="-16.510" y="0.000" visible="pin" length="short" direction="out" rot="R0"/><pin name="PD1/SWIO" x="-16.510" y="-2.540" visible="pin" length="short" direction="io" rot="R0"/><pin name="VSS" x="-16.510" y="-5.080" visible="pin" length="short" direction="pwr" rot="R0"/><pin name="PC1/SDA" x="16.510" y="5.080" visible="pin" length="short" direction="io" rot="R180"/><pin name="PC2/SCL" x="16.510" y="2.540" visible="pin" length="short" direction="io" rot="R180"/><pin name="PC4" x="16.510" y="0.000" visible="pin" length="short" direction="out" rot="R180"/><pin name="PC0" x="16.510" y="-2.540" visible="pin" length="short" direction="out" rot="R180"/><pin name="PC3" x="16.510" y="-5.080" visible="pin" length="short" direction="out" rot="R180"/><text x="-13.970" y="10.420" size="1.778" layer="95">&gt;NAME</text><text x="-13.970" y="8.220" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_TP1"><wire x1="-7.620" y1="-2.540" x2="7.620" y2="-2.540" width="0.254" layer="94"/><wire x1="7.620" y1="-2.540" x2="7.620" y2="2.540" width="0.254" layer="94"/><wire x1="7.620" y1="2.540" x2="-7.620" y2="2.540" width="0.254" layer="94"/><wire x1="-7.620" y1="2.540" x2="-7.620" y2="-2.540" width="0.254" layer="94"/><pin name="1" x="-10.160" y="0.000" visible="pin" length="short" direction="pas" rot="R0"/><text x="-7.620" y="5.340" size="1.778" layer="95">&gt;NAME</text><text x="-7.620" y="3.140" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_D2"><wire x1="-5.080" y1="0.000" x2="5.080" y2="0.000" width="0.1524" layer="94"/><wire x1="-1.000" y1="-1.200" x2="-1.000" y2="1.200" width="0.254" layer="94"/><wire x1="-1.000" y1="1.200" x2="1.000" y2="0.000" width="0.254" layer="94"/><wire x1="-1.000" y1="-1.200" x2="1.000" y2="0.000" width="0.254" layer="94"/><wire x1="1.000" y1="-1.200" x2="1.000" y2="1.200" width="0.254" layer="94"/><pin name="A" x="-7.620" y="0.000" visible="off" length="short" direction="pas" rot="R0"/><pin name="K" x="7.620" y="0.000" visible="off" length="short" direction="pas" rot="R180"/><text x="-5.080" y="5.340" size="1.778" layer="95">&gt;NAME</text><text x="-5.080" y="3.140" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_D3"><wire x1="-5.080" y1="0.000" x2="5.080" y2="0.000" width="0.1524" layer="94"/><wire x1="-1.000" y1="-1.200" x2="-1.000" y2="1.200" width="0.254" layer="94"/><wire x1="-1.000" y1="1.200" x2="1.000" y2="0.000" width="0.254" layer="94"/><wire x1="-1.000" y1="-1.200" x2="1.000" y2="0.000" width="0.254" layer="94"/><wire x1="1.000" y1="-1.200" x2="1.000" y2="1.200" width="0.254" layer="94"/><pin name="A" x="-7.620" y="0.000" visible="off" length="short" direction="pas" rot="R0"/><pin name="K" x="7.620" y="0.000" visible="off" length="short" direction="pas" rot="R180"/><text x="-5.080" y="5.340" size="1.778" layer="95">&gt;NAME</text><text x="-5.080" y="3.140" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_R45"><wire x1="-5.080" y1="-0.900" x2="5.080" y2="-0.900" width="0.254" layer="94"/><wire x1="5.080" y1="-0.900" x2="5.080" y2="0.900" width="0.254" layer="94"/><wire x1="5.080" y1="0.900" x2="-5.080" y2="0.900" width="0.254" layer="94"/><wire x1="-5.080" y1="0.900" x2="-5.080" y2="-0.900" width="0.254" layer="94"/><pin name="1" x="-7.620" y="0.000" visible="off" length="short" direction="pas" rot="R0"/><pin name="2" x="7.620" y="0.000" visible="off" length="short" direction="pas" rot="R180"/><text x="-5.080" y="5.340" size="1.778" layer="95">&gt;NAME</text><text x="-5.080" y="3.140" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_Q2"><wire x1="-5.080" y1="-0.900" x2="5.080" y2="-0.900" width="0.254" layer="94"/><wire x1="5.080" y1="-0.900" x2="5.080" y2="0.900" width="0.254" layer="94"/><wire x1="5.080" y1="0.900" x2="-5.080" y2="0.900" width="0.254" layer="94"/><wire x1="-5.080" y1="0.900" x2="-5.080" y2="-0.900" width="0.254" layer="94"/><pin name="G" x="-7.620" y="0.000" visible="off" length="short" direction="in" rot="R0"/><pin name="D" x="7.620" y="0.000" visible="off" length="short" direction="pas" rot="R180"/><text x="-5.080" y="5.340" size="1.778" layer="95">&gt;NAME</text><text x="-5.080" y="3.140" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_BZ1"><wire x1="-5.080" y1="-0.900" x2="5.080" y2="-0.900" width="0.254" layer="94"/><wire x1="5.080" y1="-0.900" x2="5.080" y2="0.900" width="0.254" layer="94"/><wire x1="5.080" y1="0.900" x2="-5.080" y2="0.900" width="0.254" layer="94"/><wire x1="-5.080" y1="0.900" x2="-5.080" y2="-0.900" width="0.254" layer="94"/><pin name="+" x="-7.620" y="0.000" visible="off" length="short" direction="pas" rot="R0"/><pin name="-" x="7.620" y="0.000" visible="off" length="short" direction="pas" rot="R180"/><text x="-5.080" y="5.340" size="1.778" layer="95">&gt;NAME</text><text x="-5.080" y="3.140" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_R46"><wire x1="-5.080" y1="-0.900" x2="5.080" y2="-0.900" width="0.254" layer="94"/><wire x1="5.080" y1="-0.900" x2="5.080" y2="0.900" width="0.254" layer="94"/><wire x1="5.080" y1="0.900" x2="-5.080" y2="0.900" width="0.254" layer="94"/><wire x1="-5.080" y1="0.900" x2="-5.080" y2="-0.900" width="0.254" layer="94"/><pin name="1" x="-7.620" y="0.000" visible="off" length="short" direction="pas" rot="R0"/><pin name="2" x="7.620" y="0.000" visible="off" length="short" direction="pas" rot="R180"/><text x="-5.080" y="5.340" size="1.778" layer="95">&gt;NAME</text><text x="-5.080" y="3.140" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_Q3"><wire x1="-5.080" y1="-0.900" x2="5.080" y2="-0.900" width="0.254" layer="94"/><wire x1="5.080" y1="-0.900" x2="5.080" y2="0.900" width="0.254" layer="94"/><wire x1="5.080" y1="0.900" x2="-5.080" y2="0.900" width="0.254" layer="94"/><wire x1="-5.080" y1="0.900" x2="-5.080" y2="-0.900" width="0.254" layer="94"/><pin name="G" x="-7.620" y="0.000" visible="off" length="short" direction="in" rot="R0"/><pin name="D" x="7.620" y="0.000" visible="off" length="short" direction="pas" rot="R180"/><text x="-5.080" y="5.340" size="1.778" layer="95">&gt;NAME</text><text x="-5.080" y="3.140" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_R47"><wire x1="-5.080" y1="-0.900" x2="5.080" y2="-0.900" width="0.254" layer="94"/><wire x1="5.080" y1="-0.900" x2="5.080" y2="0.900" width="0.254" layer="94"/><wire x1="5.080" y1="0.900" x2="-5.080" y2="0.900" width="0.254" layer="94"/><wire x1="-5.080" y1="0.900" x2="-5.080" y2="-0.900" width="0.254" layer="94"/><pin name="1" x="-7.620" y="0.000" visible="off" length="short" direction="pas" rot="R0"/><pin name="2" x="7.620" y="0.000" visible="off" length="short" direction="pas" rot="R180"/><text x="-5.080" y="5.340" size="1.778" layer="95">&gt;NAME</text><text x="-5.080" y="3.140" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_R48"><wire x1="-5.080" y1="-0.900" x2="5.080" y2="-0.900" width="0.254" layer="94"/><wire x1="5.080" y1="-0.900" x2="5.080" y2="0.900" width="0.254" layer="94"/><wire x1="5.080" y1="0.900" x2="-5.080" y2="0.900" width="0.254" layer="94"/><wire x1="-5.080" y1="0.900" x2="-5.080" y2="-0.900" width="0.254" layer="94"/><pin name="1" x="-7.620" y="0.000" visible="off" length="short" direction="pas" rot="R0"/><pin name="2" x="7.620" y="0.000" visible="off" length="short" direction="pas" rot="R180"/><text x="-5.080" y="5.340" size="1.778" layer="95">&gt;NAME</text><text x="-5.080" y="3.140" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_M1"><wire x1="-5.080" y1="-0.900" x2="5.080" y2="-0.900" width="0.254" layer="94"/><wire x1="5.080" y1="-0.900" x2="5.080" y2="0.900" width="0.254" layer="94"/><wire x1="5.080" y1="0.900" x2="-5.080" y2="0.900" width="0.254" layer="94"/><wire x1="-5.080" y1="0.900" x2="-5.080" y2="-0.900" width="0.254" layer="94"/><pin name="+" x="-7.620" y="0.000" visible="off" length="short" direction="pas" rot="R0"/><pin name="-" x="7.620" y="0.000" visible="off" length="short" direction="pas" rot="R180"/><text x="-5.080" y="5.340" size="1.778" layer="95">&gt;NAME</text><text x="-5.080" y="3.140" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_D4"><wire x1="-5.080" y1="0.000" x2="5.080" y2="0.000" width="0.1524" layer="94"/><wire x1="-1.000" y1="-1.200" x2="-1.000" y2="1.200" width="0.254" layer="94"/><wire x1="-1.000" y1="1.200" x2="1.000" y2="0.000" width="0.254" layer="94"/><wire x1="-1.000" y1="-1.200" x2="1.000" y2="0.000" width="0.254" layer="94"/><wire x1="1.000" y1="-1.200" x2="1.000" y2="1.200" width="0.254" layer="94"/><pin name="A" x="-7.620" y="0.000" visible="off" length="short" direction="pas" rot="R0"/><pin name="K" x="7.620" y="0.000" visible="off" length="short" direction="pas" rot="R180"/><text x="-5.080" y="5.340" size="1.778" layer="95">&gt;NAME</text><text x="-5.080" y="3.140" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_U16"><wire x1="-10.160" y1="-5.080" x2="10.160" y2="-5.080" width="0.254" layer="94"/><wire x1="10.160" y1="-5.080" x2="10.160" y2="5.080" width="0.254" layer="94"/><wire x1="10.160" y1="5.080" x2="-10.160" y2="5.080" width="0.254" layer="94"/><wire x1="-10.160" y1="5.080" x2="-10.160" y2="-5.080" width="0.254" layer="94"/><pin name="VCC" x="-12.700" y="2.540" visible="pin" length="short" direction="pwr" rot="R0"/><pin name="GND" x="-12.700" y="0.000" visible="pin" length="short" direction="pwr" rot="R0"/><pin name="SDA" x="12.700" y="2.540" visible="pin" length="short" direction="io" rot="R180"/><pin name="SCL" x="12.700" y="0.000" visible="pin" length="short" direction="in" rot="R180"/><pin name="INT" x="12.700" y="-2.540" visible="pin" length="short" direction="oc" rot="R180"/><text x="-10.160" y="7.880" size="1.778" layer="95">&gt;NAME</text><text x="-10.160" y="5.680" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_U17"><wire x1="-10.160" y1="-5.080" x2="10.160" y2="-5.080" width="0.254" layer="94"/><wire x1="10.160" y1="-5.080" x2="10.160" y2="5.080" width="0.254" layer="94"/><wire x1="10.160" y1="5.080" x2="-10.160" y2="5.080" width="0.254" layer="94"/><wire x1="-10.160" y1="5.080" x2="-10.160" y2="-5.080" width="0.254" layer="94"/><pin name="VCC" x="-12.700" y="2.540" visible="pin" length="short" direction="pwr" rot="R0"/><pin name="GND" x="-12.700" y="0.000" visible="pin" length="short" direction="pwr" rot="R0"/><pin name="SDA" x="12.700" y="2.540" visible="pin" length="short" direction="io" rot="R180"/><pin name="SCL" x="12.700" y="0.000" visible="pin" length="short" direction="in" rot="R180"/><pin name="INT" x="12.700" y="-2.540" visible="pin" length="short" direction="oc" rot="R180"/><text x="-10.160" y="7.880" size="1.778" layer="95">&gt;NAME</text><text x="-10.160" y="5.680" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_U18"><wire x1="-10.160" y1="-5.080" x2="10.160" y2="-5.080" width="0.254" layer="94"/><wire x1="10.160" y1="-5.080" x2="10.160" y2="5.080" width="0.254" layer="94"/><wire x1="10.160" y1="5.080" x2="-10.160" y2="5.080" width="0.254" layer="94"/><wire x1="-10.160" y1="5.080" x2="-10.160" y2="-5.080" width="0.254" layer="94"/><pin name="VCC" x="-12.700" y="2.540" visible="pin" length="short" direction="pwr" rot="R0"/><pin name="GND" x="-12.700" y="0.000" visible="pin" length="short" direction="pwr" rot="R0"/><pin name="SDA" x="12.700" y="2.540" visible="pin" length="short" direction="io" rot="R180"/><pin name="SCL" x="12.700" y="0.000" visible="pin" length="short" direction="in" rot="R180"/><pin name="INT" x="12.700" y="-2.540" visible="pin" length="short" direction="oc" rot="R180"/><text x="-10.160" y="7.880" size="1.778" layer="95">&gt;NAME</text><text x="-10.160" y="5.680" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_E1"><wire x1="-7.620" y1="-2.540" x2="7.620" y2="-2.540" width="0.254" layer="94"/><wire x1="7.620" y1="-2.540" x2="7.620" y2="2.540" width="0.254" layer="94"/><wire x1="7.620" y1="2.540" x2="-7.620" y2="2.540" width="0.254" layer="94"/><wire x1="-7.620" y1="2.540" x2="-7.620" y2="-2.540" width="0.254" layer="94"/><pin name="1" x="-10.160" y="0.000" visible="pin" length="short" direction="pas" rot="R0"/><text x="-7.620" y="5.340" size="1.778" layer="95">&gt;NAME</text><text x="-7.620" y="3.140" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_E2"><wire x1="-7.620" y1="-2.540" x2="7.620" y2="-2.540" width="0.254" layer="94"/><wire x1="7.620" y1="-2.540" x2="7.620" y2="2.540" width="0.254" layer="94"/><wire x1="7.620" y1="2.540" x2="-7.620" y2="2.540" width="0.254" layer="94"/><wire x1="-7.620" y1="2.540" x2="-7.620" y2="-2.540" width="0.254" layer="94"/><pin name="1" x="-10.160" y="0.000" visible="pin" length="short" direction="pas" rot="R0"/><text x="-7.620" y="5.340" size="1.778" layer="95">&gt;NAME</text><text x="-7.620" y="3.140" size="1.27" layer="96">&gt;VALUE</text></symbol>
<symbol name="SYM_R49"><wire x1="-5.080" y1="-0.900" x2="5.080" y2="-0.900" width="0.254" layer="94"/><wire x1="5.080" y1="-0.900" x2="5.080" y2="0.900" width="0.254" layer="94"/><wire x1="5.080" y1="0.900" x2="-5.080" y2="0.900" width="0.254" layer="94"/><wire x1="-5.080" y1="0.900" x2="-5.080" y2="-0.900" width="0.254" layer="94"/><pin name="1" x="-7.620" y="0.000" visible="off" length="short" direction="pas" rot="R0"/><pin name="2" x="7.620" y="0.000" visible="off" length="short" direction="pas" rot="R180"/><text x="-5.080" y="5.340" size="1.778" layer="95">&gt;NAME</text><text x="-5.080" y="3.140" size="1.27" layer="96">&gt;VALUE</text></symbol>
</symbols>
<devicesets>
<deviceset name="DS_U1" prefix="U" uservalue="yes"><description>ESP32-S3-WROOM-1-N16R8. Hovedprosessor og Bluetooth. Pinner som i main/board.h</description><gates><gate name="G$1" symbol="SYM_U1" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_R1" prefix="R" uservalue="yes"><description>10k. EN pull-up</description><gates><gate name="G$1" symbol="SYM_R1" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_C1" prefix="C" uservalue="yes"><description>1uF. EN forsinkelse</description><gates><gate name="G$1" symbol="SYM_C1" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_C2" prefix="C" uservalue="yes"><description>22uF. Bulk ved modulen</description><gates><gate name="G$1" symbol="SYM_C2" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_C3" prefix="C" uservalue="yes"><description>100nF. Avkobling</description><gates><gate name="G$1" symbol="SYM_C3" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_J1" prefix="J" uservalue="yes"><description>Service 8-pol (pogo-pads). Flashing og konsoll innenfor huset (åpnes kun på benken)</description><gates><gate name="G$1" symbol="SYM_J1" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_L1" prefix="L" uservalue="yes"><description>Qi-mottakerspole 36 mm. Ligger på PEEK-vinduet i bakplaten</description><gates><gate name="G$1" symbol="SYM_L1" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_U20" prefix="U" uservalue="yes"><description>Qi-mottakermodul 5 V. Ferdig mottakermodul</description><gates><gate name="G$1" symbol="SYM_U20" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_U21" prefix="U" uservalue="yes"><description>MCP73831T-2ACI. 1-celle LiPo-lader, 500 mA</description><gates><gate name="G$1" symbol="SYM_U21" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_R2" prefix="R" uservalue="yes"><description>2k. Ladestrøm 500 mA</description><gates><gate name="G$1" symbol="SYM_R2" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_R3" prefix="R" uservalue="yes"><description>10k. STAT er 5 V: deler ned til 3,2 V</description><gates><gate name="G$1" symbol="SYM_R3" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_R4" prefix="R" uservalue="yes"><description>18k. Spenningsdeler STAT</description><gates><gate name="G$1" symbol="SYM_R4" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_C4" prefix="C" uservalue="yes"><description>4.7uF. Laderinngang</description><gates><gate name="G$1" symbol="SYM_C4" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_C5" prefix="C" uservalue="yes"><description>4.7uF. Laderutgang</description><gates><gate name="G$1" symbol="SYM_C5" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_BT1" prefix="BT" uservalue="yes"><description>LiPo 1S 2000 mAh m/beskyttelse. </description><gates><gate name="G$1" symbol="SYM_BT1" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_U23" prefix="U" uservalue="yes"><description>TLV75733P (1 A). LDO 3.3 V 1 A: ESP32 trekker opptil ca. 0,5 A ved oppstart</description><gates><gate name="G$1" symbol="SYM_U23" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_C6" prefix="C" uservalue="yes"><description>1uF. LDO inn</description><gates><gate name="G$1" symbol="SYM_C6" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_C7" prefix="C" uservalue="yes"><description>10uF. LDO ut</description><gates><gate name="G$1" symbol="SYM_C7" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_U9" prefix="U" uservalue="yes"><description>MAX17048G+T10. Batterimåler, 0x36</description><gates><gate name="G$1" symbol="SYM_U9" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_U2" prefix="U" uservalue="yes"><description>TCA9548APWR. I2C-multiplekser 0x70: begge MS5837 har adresse 0x76</description><gates><gate name="G$1" symbol="SYM_U2" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_U3" prefix="U" uservalue="yes"><description>MS5837-30BA. Dybdesensor A (port 1 i venstre vegg)</description><gates><gate name="G$1" symbol="SYM_U3" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_U4" prefix="U" uservalue="yes"><description>MS5837-30BA. Dybdesensor B (port 2), også lest av sikkerhets-MCU</description><gates><gate name="G$1" symbol="SYM_U4" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_R10" prefix="R" uservalue="yes"><description>2.2k. Hovedbuss</description><gates><gate name="G$1" symbol="SYM_R10" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_R11" prefix="R" uservalue="yes"><description>2.2k. Hovedbuss</description><gates><gate name="G$1" symbol="SYM_R11" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_R12" prefix="R" uservalue="yes"><description>4.7k. </description><gates><gate name="G$1" symbol="SYM_R12" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_R13" prefix="R" uservalue="yes"><description>4.7k. </description><gates><gate name="G$1" symbol="SYM_R13" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_R14" prefix="R" uservalue="yes"><description>4.7k. </description><gates><gate name="G$1" symbol="SYM_R14" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_R15" prefix="R" uservalue="yes"><description>4.7k. </description><gates><gate name="G$1" symbol="SYM_R15" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_U5" prefix="U" uservalue="yes"><description>QMI8658C. Akselerometer/gyro, 0x6B (sjekk SA0 mot databladet)</description><gates><gate name="G$1" symbol="SYM_U5" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_R16" prefix="R" uservalue="yes"><description>0R (DNP). Adressevalg IMU: monter én av R16/R17</description><gates><gate name="G$1" symbol="SYM_R16" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_R17" prefix="R" uservalue="yes"><description>0R (DNP). Adressevalg IMU</description><gates><gate name="G$1" symbol="SYM_R17" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_U6" prefix="U" uservalue="yes"><description>MMC5603NJ. Magnetometer 0x30, minst 20 mm fra magneter og motor</description><gates><gate name="G$1" symbol="SYM_U6" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_C10" prefix="C" uservalue="yes"><description>1uF. SET/RESET-kondensator</description><gates><gate name="G$1" symbol="SYM_C10" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_U7" prefix="U" uservalue="yes"><description>VEML7700. Lyssensor 0x10, bak glasset</description><gates><gate name="G$1" symbol="SYM_U7" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_U8" prefix="U" uservalue="yes"><description>MB85RC256V. FRAM 0x50: vevsmetning overlever strømbrudd</description><gates><gate name="G$1" symbol="SYM_U8" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_U10" prefix="U" uservalue="yes"><description>PCF85063ATT. Sanntidsklokke 0x51</description><gates><gate name="G$1" symbol="SYM_U10" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_Y1" prefix="Y" uservalue="yes"><description>32.768 kHz. </description><gates><gate name="G$1" symbol="SYM_Y1" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_C11" prefix="C" uservalue="yes"><description>100nF. Avkobling U2</description><gates><gate name="G$1" symbol="SYM_C11" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_C12" prefix="C" uservalue="yes"><description>100nF. Avkobling U3/U4</description><gates><gate name="G$1" symbol="SYM_C12" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_C13" prefix="C" uservalue="yes"><description>100nF. Avkobling U5-U10</description><gates><gate name="G$1" symbol="SYM_C13" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_L2" prefix="L" uservalue="yes"><description>Ferrittstav 25 mm, 38/5.3 kHz. Mottakerspole for tanksendere</description><gates><gate name="G$1" symbol="SYM_L2" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_C20" prefix="C" uservalue="yes"><description>Demping/avstemming (måles). Lav Q: både 5,3 og 38 kHz</description><gates><gate name="G$1" symbol="SYM_C20" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_R20" prefix="R" uservalue="yes"><description>10k. Demper spolen (lav Q)</description><gates><gate name="G$1" symbol="SYM_R20" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_U11" prefix="U" uservalue="yes"><description>MCP6022 (A+B). Forforsterker, 2 trinn, ca. 40 dB</description><gates><gate name="G$1" symbol="SYM_U11" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_R21" prefix="R" uservalue="yes"><description>1k. Trinn 1</description><gates><gate name="G$1" symbol="SYM_R21" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_C27" prefix="C" uservalue="yes"><description>1uF. DC-forsterkning 1, knekk 160 Hz</description><gates><gate name="G$1" symbol="SYM_C27" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_R22" prefix="R" uservalue="yes"><description>10k. Trinn 1</description><gates><gate name="G$1" symbol="SYM_R22" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_R23" prefix="R" uservalue="yes"><description>1k. Trinn 2</description><gates><gate name="G$1" symbol="SYM_R23" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_C28" prefix="C" uservalue="yes"><description>1uF. DC-forsterkning 1</description><gates><gate name="G$1" symbol="SYM_C28" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_R24" prefix="R" uservalue="yes"><description>10k. Trinn 2</description><gates><gate name="G$1" symbol="SYM_R24" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_R25" prefix="R" uservalue="yes"><description>10k. Midtspenning</description><gates><gate name="G$1" symbol="SYM_R25" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_R26" prefix="R" uservalue="yes"><description>10k. Midtspenning</description><gates><gate name="G$1" symbol="SYM_R26" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_C21" prefix="C" uservalue="yes"><description>10uF. </description><gates><gate name="G$1" symbol="SYM_C21" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_C22" prefix="C" uservalue="yes"><description>1uF. AC-kobling til ADC</description><gates><gate name="G$1" symbol="SYM_C22" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_U12" prefix="U" uservalue="yes"><description>PCM1808PWR. 96 kHz I2S-ADC, slave, I2S-format</description><gates><gate name="G$1" symbol="SYM_U12" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_C29" prefix="C" uservalue="yes"><description>1uF. Ubrukt inngang til AC-jord</description><gates><gate name="G$1" symbol="SYM_C29" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_C23" prefix="C" uservalue="yes"><description>10uF. VREF</description><gates><gate name="G$1" symbol="SYM_C23" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_U24" prefix="U" uservalue="yes"><description>TPS61023 5 V. Boost til analog 5 V, av utenom dykk</description><gates><gate name="G$1" symbol="SYM_U24" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_R33" prefix="R" uservalue="yes"><description>100k. Boost av som standard</description><gates><gate name="G$1" symbol="SYM_R33" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_L4" prefix="L" uservalue="yes"><description>1uH. </description><gates><gate name="G$1" symbol="SYM_L4" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_R27" prefix="R" uservalue="yes"><description>732k. </description><gates><gate name="G$1" symbol="SYM_R27" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_R28" prefix="R" uservalue="yes"><description>100k. </description><gates><gate name="G$1" symbol="SYM_R28" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_FB1" prefix="FB" uservalue="yes"><description>Ferrittperle 600R. Støyfilter analog 5 V</description><gates><gate name="G$1" symbol="SYM_FB1" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_C24" prefix="C" uservalue="yes"><description>22uF. </description><gates><gate name="G$1" symbol="SYM_C24" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_L3" prefix="L" uservalue="yes"><description>Ferrittstav 123 kHz. Suunto Tank POD-kanal</description><gates><gate name="G$1" symbol="SYM_L3" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_C25" prefix="C" uservalue="yes"><description>Avstemming 123 kHz. </description><gates><gate name="G$1" symbol="SYM_C25" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_D1" prefix="D" uservalue="yes"><description>BAT54. Omhyllingsdetektor</description><gates><gate name="G$1" symbol="SYM_D1" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_C26" prefix="C" uservalue="yes"><description>1nF. </description><gates><gate name="G$1" symbol="SYM_C26" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_R29" prefix="R" uservalue="yes"><description>100k. </description><gates><gate name="G$1" symbol="SYM_R29" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_U13" prefix="U" uservalue="yes"><description>LM393 (A). Komparator til GPIO 48</description><gates><gate name="G$1" symbol="SYM_U13" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_R30" prefix="R" uservalue="yes"><description>1M. </description><gates><gate name="G$1" symbol="SYM_R30" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_R31" prefix="R" uservalue="yes"><description>33k. Terskel ca. 100 mV</description><gates><gate name="G$1" symbol="SYM_R31" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_R32" prefix="R" uservalue="yes"><description>10k. </description><gates><gate name="G$1" symbol="SYM_R32" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_U14" prefix="U" uservalue="yes"><description>ATGM336H-5N. GNSS, 9600 baud, posisjon på overflaten</description><gates><gate name="G$1" symbol="SYM_U14" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_U25" prefix="U" uservalue="yes"><description>TPS22916C. Bryter GNSS (25 mA) av og på</description><gates><gate name="G$1" symbol="SYM_U25" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_R34" prefix="R" uservalue="yes"><description>100k. GNSS av som standard</description><gates><gate name="G$1" symbol="SYM_R34" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_C30" prefix="C" uservalue="yes"><description>1uF. </description><gates><gate name="G$1" symbol="SYM_C30" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_ANT1" prefix="ANT" uservalue="yes"><description>Keramisk patch 18 mm. Under linsen, kun overflate</description><gates><gate name="G$1" symbol="SYM_ANT1" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_J2" prefix="J" uservalue="yes"><description>ST7796 3.5&quot; FPC. Skjerm, SPI</description><gates><gate name="G$1" symbol="SYM_J2" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_R40" prefix="R" uservalue="yes"><description>15R. Bakgrunnslys fra batteriet: 33-73 mA, PWM kompenserer</description><gates><gate name="G$1" symbol="SYM_R40" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_Q1" prefix="Q" uservalue="yes"><description>AO3400A. Bakgrunnslys PWM 5 kHz</description><gates><gate name="G$1" symbol="SYM_Q1" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_R41" prefix="R" uservalue="yes"><description>100R. </description><gates><gate name="G$1" symbol="SYM_R41" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_J3" prefix="J" uservalue="yes"><description>Hirose DM3D-SF microSD. Logger og kart, SPI-modus</description><gates><gate name="G$1" symbol="SYM_J3" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_R42" prefix="R" uservalue="yes"><description>10k. </description><gates><gate name="G$1" symbol="SYM_R42" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_R43" prefix="R" uservalue="yes"><description>10k. </description><gates><gate name="G$1" symbol="SYM_R43" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_R44" prefix="R" uservalue="yes"><description>10k. </description><gates><gate name="G$1" symbol="SYM_R44" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_U15" prefix="U" uservalue="yes"><description>CH32V003F4P6. Sikkerhets-MCU: hjerteslag, dybde B, summer; slår boost og GNSS av og på etter beskjed fra ESP32</description><gates><gate name="G$1" symbol="SYM_U15" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_TP1" prefix="TP" uservalue="yes"><description>SWIO testpunkt. Programmering CH32V003</description><gates><gate name="G$1" symbol="SYM_TP1" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_D2" prefix="D" uservalue="yes"><description>BAT54. Diode-OR</description><gates><gate name="G$1" symbol="SYM_D2" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_D3" prefix="D" uservalue="yes"><description>BAT54. Diode-OR</description><gates><gate name="G$1" symbol="SYM_D3" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_R45" prefix="R" uservalue="yes"><description>4.7k. </description><gates><gate name="G$1" symbol="SYM_R45" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_Q2" prefix="Q" uservalue="yes"><description>AO3400A. Summerdriver</description><gates><gate name="G$1" symbol="SYM_Q2" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_BZ1" prefix="BZ" uservalue="yes"><description>Murata PKMCS0909E4000. Piezo 9 mm, drives med 4 kHz PWM</description><gates><gate name="G$1" symbol="SYM_BZ1" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_R46" prefix="R" uservalue="yes"><description>1k. Utlading piezo</description><gates><gate name="G$1" symbol="SYM_R46" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_Q3" prefix="Q" uservalue="yes"><description>AO3400A. Vibrasjonsdriver</description><gates><gate name="G$1" symbol="SYM_Q3" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_R47" prefix="R" uservalue="yes"><description>100R. </description><gates><gate name="G$1" symbol="SYM_R47" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_R48" prefix="R" uservalue="yes"><description>100k. </description><gates><gate name="G$1" symbol="SYM_R48" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_M1" prefix="M" uservalue="yes"><description>Vibrasjonsmotor 1027. </description><gates><gate name="G$1" symbol="SYM_M1" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_D4" prefix="D" uservalue="yes"><description>1N4148W. Frihjulsdiode</description><gates><gate name="G$1" symbol="SYM_D4" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_U16" prefix="U" uservalue="yes"><description>TMAG5273A1. Knapp OPP, 0x35: målende hall-sensor, terskel i fastvaren</description><gates><gate name="G$1" symbol="SYM_U16" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_U17" prefix="U" uservalue="yes"><description>TMAG5273B1. Knapp VELG, 0x22: målende hall-sensor, terskel i fastvaren</description><gates><gate name="G$1" symbol="SYM_U17" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_U18" prefix="U" uservalue="yes"><description>TMAG5273C1. Knapp NED, 0x78: målende hall-sensor, terskel i fastvaren</description><gates><gate name="G$1" symbol="SYM_U18" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_E1" prefix="E" uservalue="yes"><description>Våtkontakt 1 (A4-pinne). Gjennom endeveggen</description><gates><gate name="G$1" symbol="SYM_E1" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_E2" prefix="E" uservalue="yes"><description>Våtkontakt 2 (A4-pinne). </description><gates><gate name="G$1" symbol="SYM_E2" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
<deviceset name="DS_R49" prefix="R" uservalue="yes"><description>1k. ESD/seriemotstand, berøringskanal 3</description><gates><gate name="G$1" symbol="SYM_R49" x="0" y="0"/></gates><devices><device name=""><technologies><technology name=""/></technologies></device></devices></deviceset>
</devicesets>
</library>
</libraries>
<attributes>
</attributes>
<variantdefs>
</variantdefs>
<classes>
<class number="0" name="default" width="0" drill="0">
</class>
</classes>
<parts>
<part name="U1" library="dykkecomputer" deviceset="DS_U1" device="" value="ESP32-S3-WROOM-1-N16R8"/>
<part name="R1" library="dykkecomputer" deviceset="DS_R1" device="" value="10k"/>
<part name="C1" library="dykkecomputer" deviceset="DS_C1" device="" value="1uF"/>
<part name="C2" library="dykkecomputer" deviceset="DS_C2" device="" value="22uF"/>
<part name="C3" library="dykkecomputer" deviceset="DS_C3" device="" value="100nF"/>
<part name="J1" library="dykkecomputer" deviceset="DS_J1" device="" value="Service 8-pol (pogo-pads)"/>
<part name="L1" library="dykkecomputer" deviceset="DS_L1" device="" value="Qi-mottakerspole 36 mm"/>
<part name="U20" library="dykkecomputer" deviceset="DS_U20" device="" value="Qi-mottakermodul 5 V"/>
<part name="U21" library="dykkecomputer" deviceset="DS_U21" device="" value="MCP73831T-2ACI"/>
<part name="R2" library="dykkecomputer" deviceset="DS_R2" device="" value="2k"/>
<part name="R3" library="dykkecomputer" deviceset="DS_R3" device="" value="10k"/>
<part name="R4" library="dykkecomputer" deviceset="DS_R4" device="" value="18k"/>
<part name="C4" library="dykkecomputer" deviceset="DS_C4" device="" value="4.7uF"/>
<part name="C5" library="dykkecomputer" deviceset="DS_C5" device="" value="4.7uF"/>
<part name="BT1" library="dykkecomputer" deviceset="DS_BT1" device="" value="LiPo 1S 2000 mAh m/beskyttelse"/>
<part name="U23" library="dykkecomputer" deviceset="DS_U23" device="" value="TLV75733P (1 A)"/>
<part name="C6" library="dykkecomputer" deviceset="DS_C6" device="" value="1uF"/>
<part name="C7" library="dykkecomputer" deviceset="DS_C7" device="" value="10uF"/>
<part name="U9" library="dykkecomputer" deviceset="DS_U9" device="" value="MAX17048G+T10"/>
<part name="U2" library="dykkecomputer" deviceset="DS_U2" device="" value="TCA9548APWR"/>
<part name="U3" library="dykkecomputer" deviceset="DS_U3" device="" value="MS5837-30BA"/>
<part name="U4" library="dykkecomputer" deviceset="DS_U4" device="" value="MS5837-30BA"/>
<part name="R10" library="dykkecomputer" deviceset="DS_R10" device="" value="2.2k"/>
<part name="R11" library="dykkecomputer" deviceset="DS_R11" device="" value="2.2k"/>
<part name="R12" library="dykkecomputer" deviceset="DS_R12" device="" value="4.7k"/>
<part name="R13" library="dykkecomputer" deviceset="DS_R13" device="" value="4.7k"/>
<part name="R14" library="dykkecomputer" deviceset="DS_R14" device="" value="4.7k"/>
<part name="R15" library="dykkecomputer" deviceset="DS_R15" device="" value="4.7k"/>
<part name="U5" library="dykkecomputer" deviceset="DS_U5" device="" value="QMI8658C"/>
<part name="R16" library="dykkecomputer" deviceset="DS_R16" device="" value="0R (DNP)"/>
<part name="R17" library="dykkecomputer" deviceset="DS_R17" device="" value="0R (DNP)"/>
<part name="U6" library="dykkecomputer" deviceset="DS_U6" device="" value="MMC5603NJ"/>
<part name="C10" library="dykkecomputer" deviceset="DS_C10" device="" value="1uF"/>
<part name="U7" library="dykkecomputer" deviceset="DS_U7" device="" value="VEML7700"/>
<part name="U8" library="dykkecomputer" deviceset="DS_U8" device="" value="MB85RC256V"/>
<part name="U10" library="dykkecomputer" deviceset="DS_U10" device="" value="PCF85063ATT"/>
<part name="Y1" library="dykkecomputer" deviceset="DS_Y1" device="" value="32.768 kHz"/>
<part name="C11" library="dykkecomputer" deviceset="DS_C11" device="" value="100nF"/>
<part name="C12" library="dykkecomputer" deviceset="DS_C12" device="" value="100nF"/>
<part name="C13" library="dykkecomputer" deviceset="DS_C13" device="" value="100nF"/>
<part name="L2" library="dykkecomputer" deviceset="DS_L2" device="" value="Ferrittstav 25 mm, 38/5.3 kHz"/>
<part name="C20" library="dykkecomputer" deviceset="DS_C20" device="" value="Demping/avstemming (måles)"/>
<part name="R20" library="dykkecomputer" deviceset="DS_R20" device="" value="10k"/>
<part name="U11" library="dykkecomputer" deviceset="DS_U11" device="" value="MCP6022 (A+B)"/>
<part name="R21" library="dykkecomputer" deviceset="DS_R21" device="" value="1k"/>
<part name="C27" library="dykkecomputer" deviceset="DS_C27" device="" value="1uF"/>
<part name="R22" library="dykkecomputer" deviceset="DS_R22" device="" value="10k"/>
<part name="R23" library="dykkecomputer" deviceset="DS_R23" device="" value="1k"/>
<part name="C28" library="dykkecomputer" deviceset="DS_C28" device="" value="1uF"/>
<part name="R24" library="dykkecomputer" deviceset="DS_R24" device="" value="10k"/>
<part name="R25" library="dykkecomputer" deviceset="DS_R25" device="" value="10k"/>
<part name="R26" library="dykkecomputer" deviceset="DS_R26" device="" value="10k"/>
<part name="C21" library="dykkecomputer" deviceset="DS_C21" device="" value="10uF"/>
<part name="C22" library="dykkecomputer" deviceset="DS_C22" device="" value="1uF"/>
<part name="U12" library="dykkecomputer" deviceset="DS_U12" device="" value="PCM1808PWR"/>
<part name="C29" library="dykkecomputer" deviceset="DS_C29" device="" value="1uF"/>
<part name="C23" library="dykkecomputer" deviceset="DS_C23" device="" value="10uF"/>
<part name="U24" library="dykkecomputer" deviceset="DS_U24" device="" value="TPS61023 5 V"/>
<part name="R33" library="dykkecomputer" deviceset="DS_R33" device="" value="100k"/>
<part name="L4" library="dykkecomputer" deviceset="DS_L4" device="" value="1uH"/>
<part name="R27" library="dykkecomputer" deviceset="DS_R27" device="" value="732k"/>
<part name="R28" library="dykkecomputer" deviceset="DS_R28" device="" value="100k"/>
<part name="FB1" library="dykkecomputer" deviceset="DS_FB1" device="" value="Ferrittperle 600R"/>
<part name="C24" library="dykkecomputer" deviceset="DS_C24" device="" value="22uF"/>
<part name="L3" library="dykkecomputer" deviceset="DS_L3" device="" value="Ferrittstav 123 kHz"/>
<part name="C25" library="dykkecomputer" deviceset="DS_C25" device="" value="Avstemming 123 kHz"/>
<part name="D1" library="dykkecomputer" deviceset="DS_D1" device="" value="BAT54"/>
<part name="C26" library="dykkecomputer" deviceset="DS_C26" device="" value="1nF"/>
<part name="R29" library="dykkecomputer" deviceset="DS_R29" device="" value="100k"/>
<part name="U13" library="dykkecomputer" deviceset="DS_U13" device="" value="LM393 (A)"/>
<part name="R30" library="dykkecomputer" deviceset="DS_R30" device="" value="1M"/>
<part name="R31" library="dykkecomputer" deviceset="DS_R31" device="" value="33k"/>
<part name="R32" library="dykkecomputer" deviceset="DS_R32" device="" value="10k"/>
<part name="U14" library="dykkecomputer" deviceset="DS_U14" device="" value="ATGM336H-5N"/>
<part name="U25" library="dykkecomputer" deviceset="DS_U25" device="" value="TPS22916C"/>
<part name="R34" library="dykkecomputer" deviceset="DS_R34" device="" value="100k"/>
<part name="C30" library="dykkecomputer" deviceset="DS_C30" device="" value="1uF"/>
<part name="ANT1" library="dykkecomputer" deviceset="DS_ANT1" device="" value="Keramisk patch 18 mm"/>
<part name="J2" library="dykkecomputer" deviceset="DS_J2" device="" value="ST7796 3.5&quot; FPC"/>
<part name="R40" library="dykkecomputer" deviceset="DS_R40" device="" value="15R"/>
<part name="Q1" library="dykkecomputer" deviceset="DS_Q1" device="" value="AO3400A"/>
<part name="R41" library="dykkecomputer" deviceset="DS_R41" device="" value="100R"/>
<part name="J3" library="dykkecomputer" deviceset="DS_J3" device="" value="Hirose DM3D-SF microSD"/>
<part name="R42" library="dykkecomputer" deviceset="DS_R42" device="" value="10k"/>
<part name="R43" library="dykkecomputer" deviceset="DS_R43" device="" value="10k"/>
<part name="R44" library="dykkecomputer" deviceset="DS_R44" device="" value="10k"/>
<part name="U15" library="dykkecomputer" deviceset="DS_U15" device="" value="CH32V003F4P6"/>
<part name="TP1" library="dykkecomputer" deviceset="DS_TP1" device="" value="SWIO testpunkt"/>
<part name="D2" library="dykkecomputer" deviceset="DS_D2" device="" value="BAT54"/>
<part name="D3" library="dykkecomputer" deviceset="DS_D3" device="" value="BAT54"/>
<part name="R45" library="dykkecomputer" deviceset="DS_R45" device="" value="4.7k"/>
<part name="Q2" library="dykkecomputer" deviceset="DS_Q2" device="" value="AO3400A"/>
<part name="BZ1" library="dykkecomputer" deviceset="DS_BZ1" device="" value="Murata PKMCS0909E4000"/>
<part name="R46" library="dykkecomputer" deviceset="DS_R46" device="" value="1k"/>
<part name="Q3" library="dykkecomputer" deviceset="DS_Q3" device="" value="AO3400A"/>
<part name="R47" library="dykkecomputer" deviceset="DS_R47" device="" value="100R"/>
<part name="R48" library="dykkecomputer" deviceset="DS_R48" device="" value="100k"/>
<part name="M1" library="dykkecomputer" deviceset="DS_M1" device="" value="Vibrasjonsmotor 1027"/>
<part name="D4" library="dykkecomputer" deviceset="DS_D4" device="" value="1N4148W"/>
<part name="U16" library="dykkecomputer" deviceset="DS_U16" device="" value="TMAG5273A1"/>
<part name="U17" library="dykkecomputer" deviceset="DS_U17" device="" value="TMAG5273B1"/>
<part name="U18" library="dykkecomputer" deviceset="DS_U18" device="" value="TMAG5273C1"/>
<part name="E1" library="dykkecomputer" deviceset="DS_E1" device="" value="Våtkontakt 1 (A4-pinne)"/>
<part name="E2" library="dykkecomputer" deviceset="DS_E2" device="" value="Våtkontakt 2 (A4-pinne)"/>
<part name="R49" library="dykkecomputer" deviceset="DS_R49" device="" value="1k"/>
</parts>
<sheets>
<sheet>
<description>1 MCU og strøm</description>
<plain>
<wire x1="0" y1="0" x2="420.0" y2="0" width="0.254" layer="97"/>
<wire x1="420.0" y1="0" x2="420.0" y2="297.0" width="0.254" layer="97"/>
<wire x1="420.0" y1="297.0" x2="0" y2="297.0" width="0.254" layer="97"/>
<wire x1="0" y1="297.0" x2="0" y2="0" width="0.254" layer="97"/>
<wire x1="5" y1="5" x2="415.0" y2="5" width="0.254" layer="97"/>
<wire x1="415.0" y1="5" x2="415.0" y2="292.0" width="0.254" layer="97"/>
<wire x1="415.0" y1="292.0" x2="5" y2="292.0" width="0.254" layer="97"/>
<wire x1="5" y1="292.0" x2="5" y2="5" width="0.254" layer="97"/>
<wire x1="270.0" y1="25" x2="415.0" y2="25" width="0.254" layer="97"/>
<wire x1="270.0" y1="5" x2="270.0" y2="25" width="0.254" layer="97"/>
<text x="273.0" y="17" size="3.81" layer="97">Dykkecomputer 3.5 in — 1 MCU og strøm</text>
<text x="273.0" y="11" size="1.778" layer="97">ESP32-S3-modul, service-kontakt, trådløs lading, lader, LDO og batterimåler</text>
<text x="273.0" y="7" size="1.524" layer="97">Ark 1 av 4 · rev B · 2026-11-20 · ikke validert for dykking</text>
<text x="10" y="285.0" size="3.81" layer="97">1 MCU og strøm</text>
</plain>
<instances>
<instance part="U1" gate="G$1" x="58.420" y="215.900"/>
<instance part="R1" gate="G$1" x="53.340" y="167.640"/>
<instance part="C1" gate="G$1" x="53.340" y="139.700"/>
<instance part="C2" gate="G$1" x="53.340" y="114.300"/>
<instance part="C3" gate="G$1" x="53.340" y="86.360"/>
<instance part="J1" gate="G$1" x="55.880" y="50.800"/>
<instance part="L1" gate="G$1" x="129.540" y="238.760"/>
<instance part="U20" gate="G$1" x="134.620" y="210.820"/>
<instance part="U21" gate="G$1" x="134.620" y="180.340"/>
<instance part="R2" gate="G$1" x="129.540" y="152.400"/>
<instance part="R3" gate="G$1" x="129.540" y="124.460"/>
<instance part="R4" gate="G$1" x="129.540" y="96.520"/>
<instance part="C4" gate="G$1" x="129.540" y="71.120"/>
<instance part="C5" gate="G$1" x="129.540" y="43.180"/>
<instance part="BT1" gate="G$1" x="190.500" y="238.760"/>
<instance part="U23" gate="G$1" x="195.580" y="213.360"/>
<instance part="C6" gate="G$1" x="190.500" y="185.420"/>
<instance part="C7" gate="G$1" x="190.500" y="157.480"/>
<instance part="U9" gate="G$1" x="195.580" y="127.000"/>
</instances>
<busses>
</busses>
<nets>
<net name="3V3" class="0">
<segment>
<pinref part="U1" gate="G$1" pin="3V3"/>
<wire x1="45.720" y1="238.760" x2="40.640" y2="238.760" width="0.1524" layer="91"/>
<label x="40.640" y="238.760" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="R1" gate="G$1" pin="1"/>
<wire x1="45.720" y1="167.640" x2="40.640" y2="167.640" width="0.1524" layer="91"/>
<label x="40.640" y="167.640" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="C2" gate="G$1" pin="1"/>
<wire x1="45.720" y1="114.300" x2="40.640" y2="114.300" width="0.1524" layer="91"/>
<label x="40.640" y="114.300" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="C3" gate="G$1" pin="1"/>
<wire x1="45.720" y1="86.360" x2="40.640" y2="86.360" width="0.1524" layer="91"/>
<label x="40.640" y="86.360" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="U23" gate="G$1" pin="OUT"/>
<wire x1="208.280" y1="215.900" x2="213.360" y2="215.900" width="0.1524" layer="91"/>
<label x="213.360" y="215.900" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="C7" gate="G$1" pin="1"/>
<wire x1="182.880" y1="157.480" x2="177.800" y2="157.480" width="0.1524" layer="91"/>
<label x="177.800" y="157.480" size="1.778" layer="95" rot="R180"/>
</segment>
</net>
<net name="BOOT" class="0">
<segment>
<pinref part="U1" gate="G$1" pin="IO0"/>
<wire x1="45.720" y1="233.680" x2="40.640" y2="233.680" width="0.1524" layer="91"/>
<label x="40.640" y="233.680" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="J1" gate="G$1" pin="8"/>
<wire x1="45.720" y1="41.910" x2="40.640" y2="41.910" width="0.1524" layer="91"/>
<label x="40.640" y="41.910" size="1.778" layer="95" rot="R180"/>
</segment>
</net>
<net name="BTN_DN" class="0">
<segment>
<pinref part="U1" gate="G$1" pin="IO42"/>
<wire x1="71.120" y1="198.120" x2="76.200" y2="198.120" width="0.1524" layer="91"/>
<label x="76.200" y="198.120" size="1.778" layer="95"/>
</segment>
</net>
<net name="BTN_SEL" class="0">
<segment>
<pinref part="U1" gate="G$1" pin="IO41"/>
<wire x1="71.120" y1="200.660" x2="76.200" y2="200.660" width="0.1524" layer="91"/>
<label x="76.200" y="200.660" size="1.778" layer="95"/>
</segment>
</net>
<net name="BTN_UP" class="0">
<segment>
<pinref part="U1" gate="G$1" pin="IO39"/>
<wire x1="71.120" y1="203.200" x2="76.200" y2="203.200" width="0.1524" layer="91"/>
<label x="76.200" y="203.200" size="1.778" layer="95"/>
</segment>
</net>
<net name="BUZZER" class="0">
<segment>
<pinref part="U1" gate="G$1" pin="IO40"/>
<wire x1="71.120" y1="195.580" x2="76.200" y2="195.580" width="0.1524" layer="91"/>
<label x="76.200" y="195.580" size="1.778" layer="95"/>
</segment>
</net>
<net name="CHG_STAT" class="0">
<segment>
<pinref part="U1" gate="G$1" pin="IO38"/>
<wire x1="45.720" y1="208.280" x2="40.640" y2="208.280" width="0.1524" layer="91"/>
<label x="40.640" y="208.280" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="R3" gate="G$1" pin="2"/>
<wire x1="137.160" y1="124.460" x2="142.240" y2="124.460" width="0.1524" layer="91"/>
<label x="142.240" y="124.460" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="R4" gate="G$1" pin="1"/>
<wire x1="121.920" y1="96.520" x2="116.840" y2="96.520" width="0.1524" layer="91"/>
<label x="116.840" y="96.520" size="1.778" layer="95" rot="R180"/>
</segment>
</net>
<net name="CHG_STAT5" class="0">
<segment>
<pinref part="U21" gate="G$1" pin="STAT"/>
<wire x1="147.320" y1="180.340" x2="152.400" y2="180.340" width="0.1524" layer="91"/>
<label x="152.400" y="180.340" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="R3" gate="G$1" pin="1"/>
<wire x1="121.920" y1="124.460" x2="116.840" y2="124.460" width="0.1524" layer="91"/>
<label x="116.840" y="124.460" size="1.778" layer="95" rot="R180"/>
</segment>
</net>
<net name="EN" class="0">
<segment>
<pinref part="U1" gate="G$1" pin="EN"/>
<wire x1="45.720" y1="236.220" x2="40.640" y2="236.220" width="0.1524" layer="91"/>
<label x="40.640" y="236.220" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="R1" gate="G$1" pin="2"/>
<wire x1="60.960" y1="167.640" x2="66.040" y2="167.640" width="0.1524" layer="91"/>
<label x="66.040" y="167.640" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="C1" gate="G$1" pin="1"/>
<wire x1="45.720" y1="139.700" x2="40.640" y2="139.700" width="0.1524" layer="91"/>
<label x="40.640" y="139.700" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="J1" gate="G$1" pin="7"/>
<wire x1="45.720" y1="44.450" x2="40.640" y2="44.450" width="0.1524" layer="91"/>
<label x="40.640" y="44.450" size="1.778" layer="95" rot="R180"/>
</segment>
</net>
<net name="FG_ALRT" class="0">
<segment>
<pinref part="U9" gate="G$1" pin="ALRT"/>
<wire x1="208.280" y1="127.000" x2="213.360" y2="127.000" width="0.1524" layer="91"/>
<label x="213.360" y="127.000" size="1.778" layer="95"/>
</segment>
</net>
<net name="GND" class="0">
<segment>
<pinref part="U1" gate="G$1" pin="GND"/>
<wire x1="45.720" y1="203.200" x2="40.640" y2="203.200" width="0.1524" layer="91"/>
<label x="40.640" y="203.200" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="C1" gate="G$1" pin="2"/>
<wire x1="60.960" y1="139.700" x2="66.040" y2="139.700" width="0.1524" layer="91"/>
<label x="66.040" y="139.700" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="C2" gate="G$1" pin="2"/>
<wire x1="60.960" y1="114.300" x2="66.040" y2="114.300" width="0.1524" layer="91"/>
<label x="66.040" y="114.300" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="C3" gate="G$1" pin="2"/>
<wire x1="60.960" y1="86.360" x2="66.040" y2="86.360" width="0.1524" layer="91"/>
<label x="66.040" y="86.360" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="J1" gate="G$1" pin="2"/>
<wire x1="45.720" y1="57.150" x2="40.640" y2="57.150" width="0.1524" layer="91"/>
<label x="40.640" y="57.150" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="U20" gate="G$1" pin="GND"/>
<wire x1="147.320" y1="209.550" x2="152.400" y2="209.550" width="0.1524" layer="91"/>
<label x="152.400" y="209.550" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="U21" gate="G$1" pin="VSS"/>
<wire x1="121.920" y1="177.800" x2="116.840" y2="177.800" width="0.1524" layer="91"/>
<label x="116.840" y="177.800" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="R2" gate="G$1" pin="2"/>
<wire x1="137.160" y1="152.400" x2="142.240" y2="152.400" width="0.1524" layer="91"/>
<label x="142.240" y="152.400" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="R4" gate="G$1" pin="2"/>
<wire x1="137.160" y1="96.520" x2="142.240" y2="96.520" width="0.1524" layer="91"/>
<label x="142.240" y="96.520" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="C4" gate="G$1" pin="2"/>
<wire x1="137.160" y1="71.120" x2="142.240" y2="71.120" width="0.1524" layer="91"/>
<label x="142.240" y="71.120" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="C5" gate="G$1" pin="2"/>
<wire x1="137.160" y1="43.180" x2="142.240" y2="43.180" width="0.1524" layer="91"/>
<label x="142.240" y="43.180" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="BT1" gate="G$1" pin="-"/>
<wire x1="198.120" y1="238.760" x2="203.200" y2="238.760" width="0.1524" layer="91"/>
<label x="203.200" y="238.760" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="U23" gate="G$1" pin="GND"/>
<wire x1="182.880" y1="210.820" x2="177.800" y2="210.820" width="0.1524" layer="91"/>
<label x="177.800" y="210.820" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="C6" gate="G$1" pin="2"/>
<wire x1="198.120" y1="185.420" x2="203.200" y2="185.420" width="0.1524" layer="91"/>
<label x="203.200" y="185.420" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="C7" gate="G$1" pin="2"/>
<wire x1="198.120" y1="157.480" x2="203.200" y2="157.480" width="0.1524" layer="91"/>
<label x="203.200" y="157.480" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="U9" gate="G$1" pin="CTG"/>
<wire x1="182.880" y1="127.000" x2="177.800" y2="127.000" width="0.1524" layer="91"/>
<label x="177.800" y="127.000" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="U9" gate="G$1" pin="QSTRT"/>
<wire x1="182.880" y1="124.460" x2="177.800" y2="124.460" width="0.1524" layer="91"/>
<label x="177.800" y="124.460" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="U9" gate="G$1" pin="GND"/>
<wire x1="182.880" y1="121.920" x2="177.800" y2="121.920" width="0.1524" layer="91"/>
<label x="177.800" y="121.920" size="1.778" layer="95" rot="R180"/>
</segment>
</net>
<net name="GNSS_RX" class="0">
<segment>
<pinref part="U1" gate="G$1" pin="IO18"/>
<wire x1="45.720" y1="210.820" x2="40.640" y2="210.820" width="0.1524" layer="91"/>
<label x="40.640" y="210.820" size="1.778" layer="95" rot="R180"/>
</segment>
</net>
<net name="GNSS_TX" class="0">
<segment>
<pinref part="U1" gate="G$1" pin="IO17"/>
<wire x1="45.720" y1="213.360" x2="40.640" y2="213.360" width="0.1524" layer="91"/>
<label x="40.640" y="213.360" size="1.778" layer="95" rot="R180"/>
</segment>
</net>
<net name="I2S_BCK" class="0">
<segment>
<pinref part="U1" gate="G$1" pin="IO4"/>
<wire x1="71.120" y1="210.820" x2="76.200" y2="210.820" width="0.1524" layer="91"/>
<label x="76.200" y="210.820" size="1.778" layer="95"/>
</segment>
</net>
<net name="I2S_DIN" class="0">
<segment>
<pinref part="U1" gate="G$1" pin="IO6"/>
<wire x1="71.120" y1="205.740" x2="76.200" y2="205.740" width="0.1524" layer="91"/>
<label x="76.200" y="205.740" size="1.778" layer="95"/>
</segment>
</net>
<net name="I2S_LRCK" class="0">
<segment>
<pinref part="U1" gate="G$1" pin="IO5"/>
<wire x1="71.120" y1="208.280" x2="76.200" y2="208.280" width="0.1524" layer="91"/>
<label x="76.200" y="208.280" size="1.778" layer="95"/>
</segment>
</net>
<net name="I2S_MCLK" class="0">
<segment>
<pinref part="U1" gate="G$1" pin="IO7"/>
<wire x1="71.120" y1="213.360" x2="76.200" y2="213.360" width="0.1524" layer="91"/>
<label x="76.200" y="213.360" size="1.778" layer="95"/>
</segment>
</net>
<net name="LCD_BL" class="0">
<segment>
<pinref part="U1" gate="G$1" pin="IO16"/>
<wire x1="71.120" y1="218.440" x2="76.200" y2="218.440" width="0.1524" layer="91"/>
<label x="76.200" y="218.440" size="1.778" layer="95"/>
</segment>
</net>
<net name="LCD_CS" class="0">
<segment>
<pinref part="U1" gate="G$1" pin="IO10"/>
<wire x1="71.120" y1="226.060" x2="76.200" y2="226.060" width="0.1524" layer="91"/>
<label x="76.200" y="226.060" size="1.778" layer="95"/>
</segment>
</net>
<net name="LCD_DC" class="0">
<segment>
<pinref part="U1" gate="G$1" pin="IO14"/>
<wire x1="71.120" y1="223.520" x2="76.200" y2="223.520" width="0.1524" layer="91"/>
<label x="76.200" y="223.520" size="1.778" layer="95"/>
</segment>
</net>
<net name="LCD_RST" class="0">
<segment>
<pinref part="U1" gate="G$1" pin="IO21"/>
<wire x1="71.120" y1="220.980" x2="76.200" y2="220.980" width="0.1524" layer="91"/>
<label x="76.200" y="220.980" size="1.778" layer="95"/>
</segment>
</net>
<net name="PROG" class="0">
<segment>
<pinref part="U21" gate="G$1" pin="PROG"/>
<wire x1="121.920" y1="180.340" x2="116.840" y2="180.340" width="0.1524" layer="91"/>
<label x="116.840" y="180.340" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="R2" gate="G$1" pin="1"/>
<wire x1="121.920" y1="152.400" x2="116.840" y2="152.400" width="0.1524" layer="91"/>
<label x="116.840" y="152.400" size="1.778" layer="95" rot="R180"/>
</segment>
</net>
<net name="QI_AC1" class="0">
<segment>
<pinref part="L1" gate="G$1" pin="1"/>
<wire x1="121.920" y1="238.760" x2="116.840" y2="238.760" width="0.1524" layer="91"/>
<label x="116.840" y="238.760" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="U20" gate="G$1" pin="AC1"/>
<wire x1="121.920" y1="212.090" x2="116.840" y2="212.090" width="0.1524" layer="91"/>
<label x="116.840" y="212.090" size="1.778" layer="95" rot="R180"/>
</segment>
</net>
<net name="QI_AC2" class="0">
<segment>
<pinref part="L1" gate="G$1" pin="2"/>
<wire x1="137.160" y1="238.760" x2="142.240" y2="238.760" width="0.1524" layer="91"/>
<label x="142.240" y="238.760" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="U20" gate="G$1" pin="AC2"/>
<wire x1="121.920" y1="209.550" x2="116.840" y2="209.550" width="0.1524" layer="91"/>
<label x="116.840" y="209.550" size="1.778" layer="95" rot="R180"/>
</segment>
</net>
<net name="RXD0" class="0">
<segment>
<pinref part="U1" gate="G$1" pin="RXD0"/>
<wire x1="45.720" y1="223.520" x2="40.640" y2="223.520" width="0.1524" layer="91"/>
<label x="40.640" y="223.520" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="J1" gate="G$1" pin="6"/>
<wire x1="45.720" y1="46.990" x2="40.640" y2="46.990" width="0.1524" layer="91"/>
<label x="40.640" y="46.990" size="1.778" layer="95" rot="R180"/>
</segment>
</net>
<net name="SAFE_RX" class="0">
<segment>
<pinref part="U1" gate="G$1" pin="IO2"/>
<wire x1="45.720" y1="218.440" x2="40.640" y2="218.440" width="0.1524" layer="91"/>
<label x="40.640" y="218.440" size="1.778" layer="95" rot="R180"/>
</segment>
</net>
<net name="SAFE_TX" class="0">
<segment>
<pinref part="U1" gate="G$1" pin="IO1"/>
<wire x1="45.720" y1="220.980" x2="40.640" y2="220.980" width="0.1524" layer="91"/>
<label x="40.640" y="220.980" size="1.778" layer="95" rot="R180"/>
</segment>
</net>
<net name="SCL" class="0">
<segment>
<pinref part="U1" gate="G$1" pin="IO9"/>
<wire x1="71.120" y1="236.220" x2="76.200" y2="236.220" width="0.1524" layer="91"/>
<label x="76.200" y="236.220" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="U9" gate="G$1" pin="SCL"/>
<wire x1="208.280" y1="129.540" x2="213.360" y2="129.540" width="0.1524" layer="91"/>
<label x="213.360" y="129.540" size="1.778" layer="95"/>
</segment>
</net>
<net name="SDA" class="0">
<segment>
<pinref part="U1" gate="G$1" pin="IO8"/>
<wire x1="71.120" y1="238.760" x2="76.200" y2="238.760" width="0.1524" layer="91"/>
<label x="76.200" y="238.760" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="U9" gate="G$1" pin="SDA"/>
<wire x1="208.280" y1="132.080" x2="213.360" y2="132.080" width="0.1524" layer="91"/>
<label x="213.360" y="132.080" size="1.778" layer="95"/>
</segment>
</net>
<net name="SD_CS" class="0">
<segment>
<pinref part="U1" gate="G$1" pin="IO15"/>
<wire x1="71.120" y1="215.900" x2="76.200" y2="215.900" width="0.1524" layer="91"/>
<label x="76.200" y="215.900" size="1.778" layer="95"/>
</segment>
</net>
<net name="SPI_MISO" class="0">
<segment>
<pinref part="U1" gate="G$1" pin="IO13"/>
<wire x1="71.120" y1="228.600" x2="76.200" y2="228.600" width="0.1524" layer="91"/>
<label x="76.200" y="228.600" size="1.778" layer="95"/>
</segment>
</net>
<net name="SPI_MOSI" class="0">
<segment>
<pinref part="U1" gate="G$1" pin="IO11"/>
<wire x1="71.120" y1="231.140" x2="76.200" y2="231.140" width="0.1524" layer="91"/>
<label x="76.200" y="231.140" size="1.778" layer="95"/>
</segment>
</net>
<net name="SPI_SCK" class="0">
<segment>
<pinref part="U1" gate="G$1" pin="IO12"/>
<wire x1="71.120" y1="233.680" x2="76.200" y2="233.680" width="0.1524" layer="91"/>
<label x="76.200" y="233.680" size="1.778" layer="95"/>
</segment>
</net>
<net name="TX123_ENV" class="0">
<segment>
<pinref part="U1" gate="G$1" pin="IO48"/>
<wire x1="45.720" y1="205.740" x2="40.640" y2="205.740" width="0.1524" layer="91"/>
<label x="40.640" y="205.740" size="1.778" layer="95" rot="R180"/>
</segment>
</net>
<net name="TXD0" class="0">
<segment>
<pinref part="U1" gate="G$1" pin="TXD0"/>
<wire x1="45.720" y1="226.060" x2="40.640" y2="226.060" width="0.1524" layer="91"/>
<label x="40.640" y="226.060" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="J1" gate="G$1" pin="5"/>
<wire x1="45.720" y1="49.530" x2="40.640" y2="49.530" width="0.1524" layer="91"/>
<label x="40.640" y="49.530" size="1.778" layer="95" rot="R180"/>
</segment>
</net>
<net name="USB_DM" class="0">
<segment>
<pinref part="U1" gate="G$1" pin="IO19"/>
<wire x1="45.720" y1="231.140" x2="40.640" y2="231.140" width="0.1524" layer="91"/>
<label x="40.640" y="231.140" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="J1" gate="G$1" pin="3"/>
<wire x1="45.720" y1="54.610" x2="40.640" y2="54.610" width="0.1524" layer="91"/>
<label x="40.640" y="54.610" size="1.778" layer="95" rot="R180"/>
</segment>
</net>
<net name="USB_DP" class="0">
<segment>
<pinref part="U1" gate="G$1" pin="IO20"/>
<wire x1="45.720" y1="228.600" x2="40.640" y2="228.600" width="0.1524" layer="91"/>
<label x="40.640" y="228.600" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="J1" gate="G$1" pin="4"/>
<wire x1="45.720" y1="52.070" x2="40.640" y2="52.070" width="0.1524" layer="91"/>
<label x="40.640" y="52.070" size="1.778" layer="95" rot="R180"/>
</segment>
</net>
<net name="VBAT" class="0">
<segment>
<pinref part="J1" gate="G$1" pin="1"/>
<wire x1="45.720" y1="59.690" x2="40.640" y2="59.690" width="0.1524" layer="91"/>
<label x="40.640" y="59.690" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="U21" gate="G$1" pin="VBAT"/>
<wire x1="147.320" y1="182.880" x2="152.400" y2="182.880" width="0.1524" layer="91"/>
<label x="152.400" y="182.880" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="C5" gate="G$1" pin="1"/>
<wire x1="121.920" y1="43.180" x2="116.840" y2="43.180" width="0.1524" layer="91"/>
<label x="116.840" y="43.180" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="BT1" gate="G$1" pin="+"/>
<wire x1="182.880" y1="238.760" x2="177.800" y2="238.760" width="0.1524" layer="91"/>
<label x="177.800" y="238.760" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="U23" gate="G$1" pin="IN"/>
<wire x1="182.880" y1="215.900" x2="177.800" y2="215.900" width="0.1524" layer="91"/>
<label x="177.800" y="215.900" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="U23" gate="G$1" pin="EN"/>
<wire x1="182.880" y1="213.360" x2="177.800" y2="213.360" width="0.1524" layer="91"/>
<label x="177.800" y="213.360" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="C6" gate="G$1" pin="1"/>
<wire x1="182.880" y1="185.420" x2="177.800" y2="185.420" width="0.1524" layer="91"/>
<label x="177.800" y="185.420" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="U9" gate="G$1" pin="VDD"/>
<wire x1="182.880" y1="132.080" x2="177.800" y2="132.080" width="0.1524" layer="91"/>
<label x="177.800" y="132.080" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="U9" gate="G$1" pin="CELL"/>
<wire x1="182.880" y1="129.540" x2="177.800" y2="129.540" width="0.1524" layer="91"/>
<label x="177.800" y="129.540" size="1.778" layer="95" rot="R180"/>
</segment>
</net>
<net name="VIB" class="0">
<segment>
<pinref part="U1" gate="G$1" pin="IO47"/>
<wire x1="71.120" y1="193.040" x2="76.200" y2="193.040" width="0.1524" layer="91"/>
<label x="76.200" y="193.040" size="1.778" layer="95"/>
</segment>
</net>
<net name="VQI" class="0">
<segment>
<pinref part="U20" gate="G$1" pin="VOUT"/>
<wire x1="147.320" y1="212.090" x2="152.400" y2="212.090" width="0.1524" layer="91"/>
<label x="152.400" y="212.090" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="U21" gate="G$1" pin="VDD"/>
<wire x1="121.920" y1="182.880" x2="116.840" y2="182.880" width="0.1524" layer="91"/>
<label x="116.840" y="182.880" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="C4" gate="G$1" pin="1"/>
<wire x1="121.920" y1="71.120" x2="116.840" y2="71.120" width="0.1524" layer="91"/>
<label x="116.840" y="71.120" size="1.778" layer="95" rot="R180"/>
</segment>
</net>
<net name="WET" class="0">
<segment>
<pinref part="U1" gate="G$1" pin="IO3"/>
<wire x1="45.720" y1="215.900" x2="40.640" y2="215.900" width="0.1524" layer="91"/>
<label x="40.640" y="215.900" size="1.778" layer="95" rot="R180"/>
</segment>
</net>
</nets>
</sheet>
<sheet>
<description>2 Sensorer</description>
<plain>
<wire x1="0" y1="0" x2="420.0" y2="0" width="0.254" layer="97"/>
<wire x1="420.0" y1="0" x2="420.0" y2="297.0" width="0.254" layer="97"/>
<wire x1="420.0" y1="297.0" x2="0" y2="297.0" width="0.254" layer="97"/>
<wire x1="0" y1="297.0" x2="0" y2="0" width="0.254" layer="97"/>
<wire x1="5" y1="5" x2="415.0" y2="5" width="0.254" layer="97"/>
<wire x1="415.0" y1="5" x2="415.0" y2="292.0" width="0.254" layer="97"/>
<wire x1="415.0" y1="292.0" x2="5" y2="292.0" width="0.254" layer="97"/>
<wire x1="5" y1="292.0" x2="5" y2="5" width="0.254" layer="97"/>
<wire x1="270.0" y1="25" x2="415.0" y2="25" width="0.254" layer="97"/>
<wire x1="270.0" y1="5" x2="270.0" y2="25" width="0.254" layer="97"/>
<text x="273.0" y="17" size="3.81" layer="97">Dykkecomputer 3.5 in — 2 Sensorer</text>
<text x="273.0" y="11" size="1.778" layer="97">I2C: dybdesensorer bak multiplekser, IMU, magnetometer, lyssensor, FRAM og klokke</text>
<text x="273.0" y="7" size="1.524" layer="97">Ark 2 av 4 · rev B · 2026-11-20 · ikke validert for dykking</text>
<text x="10" y="285.0" size="3.81" layer="97">2 Sensorer</text>
</plain>
<instances>
<instance part="U2" gate="G$1" x="48.260" y="231.140"/>
<instance part="U3" gate="G$1" x="48.260" y="193.040"/>
<instance part="U4" gate="G$1" x="48.260" y="165.100"/>
<instance part="R10" gate="G$1" x="43.180" y="137.160"/>
<instance part="R11" gate="G$1" x="43.180" y="109.220"/>
<instance part="R12" gate="G$1" x="43.180" y="81.280"/>
<instance part="R13" gate="G$1" x="43.180" y="58.420"/>
<instance part="R14" gate="G$1" x="43.180" y="35.560"/>
<instance part="R15" gate="G$1" x="111.760" y="238.760"/>
<instance part="U5" gate="G$1" x="116.840" y="213.360"/>
<instance part="R16" gate="G$1" x="111.760" y="182.880"/>
<instance part="R17" gate="G$1" x="111.760" y="154.940"/>
<instance part="U6" gate="G$1" x="116.840" y="127.000"/>
<instance part="C10" gate="G$1" x="111.760" y="96.520"/>
<instance part="U7" gate="G$1" x="116.840" y="68.580"/>
<instance part="U8" gate="G$1" x="116.840" y="33.020"/>
<instance part="U10" gate="G$1" x="182.880" y="236.220"/>
<instance part="Y1" gate="G$1" x="177.800" y="205.740"/>
<instance part="C11" gate="G$1" x="177.800" y="182.880"/>
<instance part="C12" gate="G$1" x="177.800" y="154.940"/>
<instance part="C13" gate="G$1" x="177.800" y="129.540"/>
</instances>
<busses>
</busses>
<nets>
<net name="3V3" class="0">
<segment>
<pinref part="U2" gate="G$1" pin="VCC"/>
<wire x1="35.560" y1="240.030" x2="30.480" y2="240.030" width="0.1524" layer="91"/>
<label x="30.480" y="240.030" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="U2" gate="G$1" pin="RESET"/>
<wire x1="35.560" y1="232.410" x2="30.480" y2="232.410" width="0.1524" layer="91"/>
<label x="30.480" y="232.410" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="U3" gate="G$1" pin="VDD"/>
<wire x1="35.560" y1="194.310" x2="30.480" y2="194.310" width="0.1524" layer="91"/>
<label x="30.480" y="194.310" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="U4" gate="G$1" pin="VDD"/>
<wire x1="35.560" y1="166.370" x2="30.480" y2="166.370" width="0.1524" layer="91"/>
<label x="30.480" y="166.370" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="R10" gate="G$1" pin="1"/>
<wire x1="35.560" y1="137.160" x2="30.480" y2="137.160" width="0.1524" layer="91"/>
<label x="30.480" y="137.160" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="R11" gate="G$1" pin="1"/>
<wire x1="35.560" y1="109.220" x2="30.480" y2="109.220" width="0.1524" layer="91"/>
<label x="30.480" y="109.220" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="R12" gate="G$1" pin="1"/>
<wire x1="35.560" y1="81.280" x2="30.480" y2="81.280" width="0.1524" layer="91"/>
<label x="30.480" y="81.280" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="R13" gate="G$1" pin="1"/>
<wire x1="35.560" y1="58.420" x2="30.480" y2="58.420" width="0.1524" layer="91"/>
<label x="30.480" y="58.420" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="R14" gate="G$1" pin="1"/>
<wire x1="35.560" y1="35.560" x2="30.480" y2="35.560" width="0.1524" layer="91"/>
<label x="30.480" y="35.560" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="R15" gate="G$1" pin="1"/>
<wire x1="104.140" y1="238.760" x2="99.060" y2="238.760" width="0.1524" layer="91"/>
<label x="99.060" y="238.760" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="U5" gate="G$1" pin="VDD"/>
<wire x1="104.140" y1="217.170" x2="99.060" y2="217.170" width="0.1524" layer="91"/>
<label x="99.060" y="217.170" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="U5" gate="G$1" pin="VDDIO"/>
<wire x1="104.140" y1="214.630" x2="99.060" y2="214.630" width="0.1524" layer="91"/>
<label x="99.060" y="214.630" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="R17" gate="G$1" pin="1"/>
<wire x1="104.140" y1="154.940" x2="99.060" y2="154.940" width="0.1524" layer="91"/>
<label x="99.060" y="154.940" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="U6" gate="G$1" pin="VDD"/>
<wire x1="104.140" y1="129.540" x2="99.060" y2="129.540" width="0.1524" layer="91"/>
<label x="99.060" y="129.540" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="U7" gate="G$1" pin="VDD"/>
<wire x1="104.140" y1="69.850" x2="99.060" y2="69.850" width="0.1524" layer="91"/>
<label x="99.060" y="69.850" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="U8" gate="G$1" pin="VDD"/>
<wire x1="104.140" y1="39.370" x2="99.060" y2="39.370" width="0.1524" layer="91"/>
<label x="99.060" y="39.370" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="U10" gate="G$1" pin="VDD"/>
<wire x1="168.910" y1="240.030" x2="163.830" y2="240.030" width="0.1524" layer="91"/>
<label x="163.830" y="240.030" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="C11" gate="G$1" pin="1"/>
<wire x1="170.180" y1="182.880" x2="165.100" y2="182.880" width="0.1524" layer="91"/>
<label x="165.100" y="182.880" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="C12" gate="G$1" pin="1"/>
<wire x1="170.180" y1="154.940" x2="165.100" y2="154.940" width="0.1524" layer="91"/>
<label x="165.100" y="154.940" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="C13" gate="G$1" pin="1"/>
<wire x1="170.180" y1="129.540" x2="165.100" y2="129.540" width="0.1524" layer="91"/>
<label x="165.100" y="129.540" size="1.778" layer="95" rot="R180"/>
</segment>
</net>
<net name="GND" class="0">
<segment>
<pinref part="U2" gate="G$1" pin="A0"/>
<wire x1="35.560" y1="229.870" x2="30.480" y2="229.870" width="0.1524" layer="91"/>
<label x="30.480" y="229.870" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="U2" gate="G$1" pin="A1"/>
<wire x1="35.560" y1="227.330" x2="30.480" y2="227.330" width="0.1524" layer="91"/>
<label x="30.480" y="227.330" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="U2" gate="G$1" pin="A2"/>
<wire x1="35.560" y1="224.790" x2="30.480" y2="224.790" width="0.1524" layer="91"/>
<label x="30.480" y="224.790" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="U2" gate="G$1" pin="GND"/>
<wire x1="35.560" y1="222.250" x2="30.480" y2="222.250" width="0.1524" layer="91"/>
<label x="30.480" y="222.250" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="U3" gate="G$1" pin="GND"/>
<wire x1="35.560" y1="191.770" x2="30.480" y2="191.770" width="0.1524" layer="91"/>
<label x="30.480" y="191.770" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="U4" gate="G$1" pin="GND"/>
<wire x1="35.560" y1="163.830" x2="30.480" y2="163.830" width="0.1524" layer="91"/>
<label x="30.480" y="163.830" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="U5" gate="G$1" pin="GND"/>
<wire x1="104.140" y1="209.550" x2="99.060" y2="209.550" width="0.1524" layer="91"/>
<label x="99.060" y="209.550" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="R16" gate="G$1" pin="2"/>
<wire x1="119.380" y1="182.880" x2="124.460" y2="182.880" width="0.1524" layer="91"/>
<label x="124.460" y="182.880" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="U6" gate="G$1" pin="GND"/>
<wire x1="104.140" y1="124.460" x2="99.060" y2="124.460" width="0.1524" layer="91"/>
<label x="99.060" y="124.460" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="C10" gate="G$1" pin="2"/>
<wire x1="119.380" y1="96.520" x2="124.460" y2="96.520" width="0.1524" layer="91"/>
<label x="124.460" y="96.520" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="U7" gate="G$1" pin="GND"/>
<wire x1="104.140" y1="67.310" x2="99.060" y2="67.310" width="0.1524" layer="91"/>
<label x="99.060" y="67.310" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="U8" gate="G$1" pin="A0"/>
<wire x1="104.140" y1="36.830" x2="99.060" y2="36.830" width="0.1524" layer="91"/>
<label x="99.060" y="36.830" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="U8" gate="G$1" pin="A1"/>
<wire x1="104.140" y1="34.290" x2="99.060" y2="34.290" width="0.1524" layer="91"/>
<label x="99.060" y="34.290" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="U8" gate="G$1" pin="A2"/>
<wire x1="104.140" y1="31.750" x2="99.060" y2="31.750" width="0.1524" layer="91"/>
<label x="99.060" y="31.750" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="U8" gate="G$1" pin="WP"/>
<wire x1="104.140" y1="29.210" x2="99.060" y2="29.210" width="0.1524" layer="91"/>
<label x="99.060" y="29.210" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="U8" gate="G$1" pin="VSS"/>
<wire x1="104.140" y1="26.670" x2="99.060" y2="26.670" width="0.1524" layer="91"/>
<label x="99.060" y="26.670" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="U10" gate="G$1" pin="VSS"/>
<wire x1="168.910" y1="232.410" x2="163.830" y2="232.410" width="0.1524" layer="91"/>
<label x="163.830" y="232.410" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="C11" gate="G$1" pin="2"/>
<wire x1="185.420" y1="182.880" x2="190.500" y2="182.880" width="0.1524" layer="91"/>
<label x="190.500" y="182.880" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="C12" gate="G$1" pin="2"/>
<wire x1="185.420" y1="154.940" x2="190.500" y2="154.940" width="0.1524" layer="91"/>
<label x="190.500" y="154.940" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="C13" gate="G$1" pin="2"/>
<wire x1="185.420" y1="129.540" x2="190.500" y2="129.540" width="0.1524" layer="91"/>
<label x="190.500" y="129.540" size="1.778" layer="95"/>
</segment>
</net>
<net name="IMU_INT" class="0">
<segment>
<pinref part="U5" gate="G$1" pin="INT1"/>
<wire x1="129.540" y1="212.090" x2="134.620" y2="212.090" width="0.1524" layer="91"/>
<label x="134.620" y="212.090" size="1.778" layer="95"/>
</segment>
</net>
<net name="IMU_SA0" class="0">
<segment>
<pinref part="U5" gate="G$1" pin="SA0"/>
<wire x1="104.140" y1="212.090" x2="99.060" y2="212.090" width="0.1524" layer="91"/>
<label x="99.060" y="212.090" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="R16" gate="G$1" pin="1"/>
<wire x1="104.140" y1="182.880" x2="99.060" y2="182.880" width="0.1524" layer="91"/>
<label x="99.060" y="182.880" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="R17" gate="G$1" pin="2"/>
<wire x1="119.380" y1="154.940" x2="124.460" y2="154.940" width="0.1524" layer="91"/>
<label x="124.460" y="154.940" size="1.778" layer="95"/>
</segment>
</net>
<net name="MAG_CAP" class="0">
<segment>
<pinref part="U6" gate="G$1" pin="CAP"/>
<wire x1="104.140" y1="127.000" x2="99.060" y2="127.000" width="0.1524" layer="91"/>
<label x="99.060" y="127.000" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="C10" gate="G$1" pin="1"/>
<wire x1="104.140" y1="96.520" x2="99.060" y2="96.520" width="0.1524" layer="91"/>
<label x="99.060" y="96.520" size="1.778" layer="95" rot="R180"/>
</segment>
</net>
<net name="RTC_CLK" class="0">
<segment>
<pinref part="U10" gate="G$1" pin="CLKOUT"/>
<wire x1="196.850" y1="232.410" x2="201.930" y2="232.410" width="0.1524" layer="91"/>
<label x="201.930" y="232.410" size="1.778" layer="95"/>
</segment>
</net>
<net name="RTC_INT" class="0">
<segment>
<pinref part="U10" gate="G$1" pin="INT"/>
<wire x1="196.850" y1="234.950" x2="201.930" y2="234.950" width="0.1524" layer="91"/>
<label x="201.930" y="234.950" size="1.778" layer="95"/>
</segment>
</net>
<net name="SCL" class="0">
<segment>
<pinref part="U2" gate="G$1" pin="SCL"/>
<wire x1="35.560" y1="234.950" x2="30.480" y2="234.950" width="0.1524" layer="91"/>
<label x="30.480" y="234.950" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="R11" gate="G$1" pin="2"/>
<wire x1="50.800" y1="109.220" x2="55.880" y2="109.220" width="0.1524" layer="91"/>
<label x="55.880" y="109.220" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="U5" gate="G$1" pin="SCL"/>
<wire x1="129.540" y1="214.630" x2="134.620" y2="214.630" width="0.1524" layer="91"/>
<label x="134.620" y="214.630" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="U6" gate="G$1" pin="SCL"/>
<wire x1="129.540" y1="127.000" x2="134.620" y2="127.000" width="0.1524" layer="91"/>
<label x="134.620" y="127.000" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="U7" gate="G$1" pin="SCL"/>
<wire x1="129.540" y1="67.310" x2="134.620" y2="67.310" width="0.1524" layer="91"/>
<label x="134.620" y="67.310" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="U8" gate="G$1" pin="SCL"/>
<wire x1="129.540" y1="36.830" x2="134.620" y2="36.830" width="0.1524" layer="91"/>
<label x="134.620" y="36.830" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="U10" gate="G$1" pin="SCL"/>
<wire x1="196.850" y1="237.490" x2="201.930" y2="237.490" width="0.1524" layer="91"/>
<label x="201.930" y="237.490" size="1.778" layer="95"/>
</segment>
</net>
<net name="SCL_A" class="0">
<segment>
<pinref part="U2" gate="G$1" pin="SC0"/>
<wire x1="60.960" y1="237.490" x2="66.040" y2="237.490" width="0.1524" layer="91"/>
<label x="66.040" y="237.490" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="U3" gate="G$1" pin="SCL"/>
<wire x1="60.960" y1="191.770" x2="66.040" y2="191.770" width="0.1524" layer="91"/>
<label x="66.040" y="191.770" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="R13" gate="G$1" pin="2"/>
<wire x1="50.800" y1="58.420" x2="55.880" y2="58.420" width="0.1524" layer="91"/>
<label x="55.880" y="58.420" size="1.778" layer="95"/>
</segment>
</net>
<net name="SCL_B" class="0">
<segment>
<pinref part="U2" gate="G$1" pin="SC1"/>
<wire x1="60.960" y1="232.410" x2="66.040" y2="232.410" width="0.1524" layer="91"/>
<label x="66.040" y="232.410" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="U4" gate="G$1" pin="SCL"/>
<wire x1="60.960" y1="163.830" x2="66.040" y2="163.830" width="0.1524" layer="91"/>
<label x="66.040" y="163.830" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="R15" gate="G$1" pin="2"/>
<wire x1="119.380" y1="238.760" x2="124.460" y2="238.760" width="0.1524" layer="91"/>
<label x="124.460" y="238.760" size="1.778" layer="95"/>
</segment>
</net>
<net name="SDA" class="0">
<segment>
<pinref part="U2" gate="G$1" pin="SDA"/>
<wire x1="35.560" y1="237.490" x2="30.480" y2="237.490" width="0.1524" layer="91"/>
<label x="30.480" y="237.490" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="R10" gate="G$1" pin="2"/>
<wire x1="50.800" y1="137.160" x2="55.880" y2="137.160" width="0.1524" layer="91"/>
<label x="55.880" y="137.160" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="U5" gate="G$1" pin="SDA"/>
<wire x1="129.540" y1="217.170" x2="134.620" y2="217.170" width="0.1524" layer="91"/>
<label x="134.620" y="217.170" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="U6" gate="G$1" pin="SDA"/>
<wire x1="129.540" y1="129.540" x2="134.620" y2="129.540" width="0.1524" layer="91"/>
<label x="134.620" y="129.540" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="U7" gate="G$1" pin="SDA"/>
<wire x1="129.540" y1="69.850" x2="134.620" y2="69.850" width="0.1524" layer="91"/>
<label x="134.620" y="69.850" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="U8" gate="G$1" pin="SDA"/>
<wire x1="129.540" y1="39.370" x2="134.620" y2="39.370" width="0.1524" layer="91"/>
<label x="134.620" y="39.370" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="U10" gate="G$1" pin="SDA"/>
<wire x1="196.850" y1="240.030" x2="201.930" y2="240.030" width="0.1524" layer="91"/>
<label x="201.930" y="240.030" size="1.778" layer="95"/>
</segment>
</net>
<net name="SDA_A" class="0">
<segment>
<pinref part="U2" gate="G$1" pin="SD0"/>
<wire x1="60.960" y1="240.030" x2="66.040" y2="240.030" width="0.1524" layer="91"/>
<label x="66.040" y="240.030" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="U3" gate="G$1" pin="SDA"/>
<wire x1="60.960" y1="194.310" x2="66.040" y2="194.310" width="0.1524" layer="91"/>
<label x="66.040" y="194.310" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="R12" gate="G$1" pin="2"/>
<wire x1="50.800" y1="81.280" x2="55.880" y2="81.280" width="0.1524" layer="91"/>
<label x="55.880" y="81.280" size="1.778" layer="95"/>
</segment>
</net>
<net name="SDA_B" class="0">
<segment>
<pinref part="U2" gate="G$1" pin="SD1"/>
<wire x1="60.960" y1="234.950" x2="66.040" y2="234.950" width="0.1524" layer="91"/>
<label x="66.040" y="234.950" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="U4" gate="G$1" pin="SDA"/>
<wire x1="60.960" y1="166.370" x2="66.040" y2="166.370" width="0.1524" layer="91"/>
<label x="66.040" y="166.370" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="R14" gate="G$1" pin="2"/>
<wire x1="50.800" y1="35.560" x2="55.880" y2="35.560" width="0.1524" layer="91"/>
<label x="55.880" y="35.560" size="1.778" layer="95"/>
</segment>
</net>
<net name="XI" class="0">
<segment>
<pinref part="U10" gate="G$1" pin="OSCI"/>
<wire x1="168.910" y1="237.490" x2="163.830" y2="237.490" width="0.1524" layer="91"/>
<label x="163.830" y="237.490" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="Y1" gate="G$1" pin="1"/>
<wire x1="170.180" y1="205.740" x2="165.100" y2="205.740" width="0.1524" layer="91"/>
<label x="165.100" y="205.740" size="1.778" layer="95" rot="R180"/>
</segment>
</net>
<net name="XO" class="0">
<segment>
<pinref part="U10" gate="G$1" pin="OSCO"/>
<wire x1="168.910" y1="234.950" x2="163.830" y2="234.950" width="0.1524" layer="91"/>
<label x="163.830" y="234.950" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="Y1" gate="G$1" pin="2"/>
<wire x1="185.420" y1="205.740" x2="190.500" y2="205.740" width="0.1524" layer="91"/>
<label x="190.500" y="205.740" size="1.778" layer="95"/>
</segment>
</net>
</nets>
</sheet>
<sheet>
<description>3 Tankmottaker og GNSS</description>
<plain>
<wire x1="0" y1="0" x2="420.0" y2="0" width="0.254" layer="97"/>
<wire x1="420.0" y1="0" x2="420.0" y2="297.0" width="0.254" layer="97"/>
<wire x1="420.0" y1="297.0" x2="0" y2="297.0" width="0.254" layer="97"/>
<wire x1="0" y1="297.0" x2="0" y2="0" width="0.254" layer="97"/>
<wire x1="5" y1="5" x2="415.0" y2="5" width="0.254" layer="97"/>
<wire x1="415.0" y1="5" x2="415.0" y2="292.0" width="0.254" layer="97"/>
<wire x1="415.0" y1="292.0" x2="5" y2="292.0" width="0.254" layer="97"/>
<wire x1="5" y1="292.0" x2="5" y2="5" width="0.254" layer="97"/>
<wire x1="270.0" y1="25" x2="415.0" y2="25" width="0.254" layer="97"/>
<wire x1="270.0" y1="5" x2="270.0" y2="25" width="0.254" layer="97"/>
<text x="273.0" y="17" size="3.81" layer="97">Dykkecomputer 3.5 in — 3 Tankmottaker og GNSS</text>
<text x="273.0" y="11" size="1.778" layer="97">38/5.3 kHz-spole med forforsterker og 96 kHz ADC, 123 kHz-kanal, GNSS</text>
<text x="273.0" y="7" size="1.524" layer="97">Ark 3 av 4 · rev B · 2026-11-20 · ikke validert for dykking</text>
<text x="10" y="285.0" size="3.81" layer="97">3 Tankmottaker og GNSS</text>
</plain>
<instances>
<instance part="L2" gate="G$1" x="50.800" y="238.760"/>
<instance part="C20" gate="G$1" x="50.800" y="213.360"/>
<instance part="R20" gate="G$1" x="50.800" y="185.420"/>
<instance part="U11" gate="G$1" x="55.880" y="152.400"/>
<instance part="R21" gate="G$1" x="50.800" y="119.380"/>
<instance part="C27" gate="G$1" x="50.800" y="91.440"/>
<instance part="R22" gate="G$1" x="50.800" y="66.040"/>
<instance part="R23" gate="G$1" x="50.800" y="38.100"/>
<instance part="C28" gate="G$1" x="121.920" y="238.760"/>
<instance part="R24" gate="G$1" x="121.920" y="213.360"/>
<instance part="R25" gate="G$1" x="121.920" y="185.420"/>
<instance part="R26" gate="G$1" x="121.920" y="160.020"/>
<instance part="C21" gate="G$1" x="121.920" y="132.080"/>
<instance part="C22" gate="G$1" x="121.920" y="109.220"/>
<instance part="U12" gate="G$1" x="127.000" y="73.660"/>
<instance part="C29" gate="G$1" x="121.920" y="40.640"/>
<instance part="C23" gate="G$1" x="195.580" y="238.760"/>
<instance part="U24" gate="G$1" x="200.660" y="208.280"/>
<instance part="R33" gate="G$1" x="195.580" y="177.800"/>
<instance part="L4" gate="G$1" x="195.580" y="152.400"/>
<instance part="R27" gate="G$1" x="195.580" y="129.540"/>
<instance part="R28" gate="G$1" x="195.580" y="106.680"/>
<instance part="FB1" gate="G$1" x="195.580" y="83.820"/>
<instance part="C24" gate="G$1" x="195.580" y="55.880"/>
<instance part="L3" gate="G$1" x="195.580" y="33.020"/>
<instance part="C25" gate="G$1" x="266.700" y="238.760"/>
<instance part="D1" gate="G$1" x="266.700" y="215.900"/>
<instance part="C26" gate="G$1" x="266.700" y="190.500"/>
<instance part="R29" gate="G$1" x="266.700" y="167.640"/>
<instance part="U13" gate="G$1" x="271.780" y="139.700"/>
<instance part="R30" gate="G$1" x="266.700" y="109.220"/>
<instance part="R31" gate="G$1" x="266.700" y="86.360"/>
<instance part="R32" gate="G$1" x="266.700" y="60.960"/>
<instance part="U14" gate="G$1" x="274.320" y="33.020"/>
<instance part="U25" gate="G$1" x="347.980" y="236.220"/>
<instance part="R34" gate="G$1" x="342.900" y="208.280"/>
<instance part="C30" gate="G$1" x="342.900" y="180.340"/>
<instance part="ANT1" gate="G$1" x="345.440" y="157.480"/>
</instances>
<busses>
</busses>
<nets>
<net name="3V3" class="0">
<segment>
<pinref part="U12" gate="G$1" pin="VDD"/>
<wire x1="114.300" y1="68.580" x2="109.220" y2="68.580" width="0.1524" layer="91"/>
<label x="109.220" y="68.580" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="U13" gate="G$1" pin="VCC"/>
<wire x1="259.080" y1="143.510" x2="254.000" y2="143.510" width="0.1524" layer="91"/>
<label x="254.000" y="143.510" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="R30" gate="G$1" pin="1"/>
<wire x1="259.080" y1="109.220" x2="254.000" y2="109.220" width="0.1524" layer="91"/>
<label x="254.000" y="109.220" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="R32" gate="G$1" pin="1"/>
<wire x1="259.080" y1="60.960" x2="254.000" y2="60.960" width="0.1524" layer="91"/>
<label x="254.000" y="60.960" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="U14" gate="G$1" pin="V_BCKP"/>
<wire x1="260.350" y1="34.290" x2="255.270" y2="34.290" width="0.1524" layer="91"/>
<label x="255.270" y="34.290" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="U25" gate="G$1" pin="VIN"/>
<wire x1="335.280" y1="238.760" x2="330.200" y2="238.760" width="0.1524" layer="91"/>
<label x="330.200" y="238.760" size="1.778" layer="95" rot="R180"/>
</segment>
</net>
<net name="3V3_GNSS" class="0">
<segment>
<pinref part="U14" gate="G$1" pin="VCC"/>
<wire x1="260.350" y1="36.830" x2="255.270" y2="36.830" width="0.1524" layer="91"/>
<label x="255.270" y="36.830" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="U25" gate="G$1" pin="VOUT"/>
<wire x1="360.680" y1="238.760" x2="365.760" y2="238.760" width="0.1524" layer="91"/>
<label x="365.760" y="238.760" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="C30" gate="G$1" pin="1"/>
<wire x1="335.280" y1="180.340" x2="330.200" y2="180.340" width="0.1524" layer="91"/>
<label x="330.200" y="180.340" size="1.778" layer="95" rot="R180"/>
</segment>
</net>
<net name="5V_A" class="0">
<segment>
<pinref part="U11" gate="G$1" pin="VDD"/>
<wire x1="43.180" y1="158.750" x2="38.100" y2="158.750" width="0.1524" layer="91"/>
<label x="38.100" y="158.750" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="R25" gate="G$1" pin="1"/>
<wire x1="114.300" y1="185.420" x2="109.220" y2="185.420" width="0.1524" layer="91"/>
<label x="109.220" y="185.420" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="U12" gate="G$1" pin="VCC"/>
<wire x1="114.300" y1="73.660" x2="109.220" y2="73.660" width="0.1524" layer="91"/>
<label x="109.220" y="73.660" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="FB1" gate="G$1" pin="2"/>
<wire x1="203.200" y1="83.820" x2="208.280" y2="83.820" width="0.1524" layer="91"/>
<label x="208.280" y="83.820" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="C24" gate="G$1" pin="1"/>
<wire x1="187.960" y1="55.880" x2="182.880" y2="55.880" width="0.1524" layer="91"/>
<label x="182.880" y="55.880" size="1.778" layer="95" rot="R180"/>
</segment>
</net>
<net name="5V_RAW" class="0">
<segment>
<pinref part="U24" gate="G$1" pin="VOUT"/>
<wire x1="213.360" y1="212.090" x2="218.440" y2="212.090" width="0.1524" layer="91"/>
<label x="218.440" y="212.090" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="R27" gate="G$1" pin="1"/>
<wire x1="187.960" y1="129.540" x2="182.880" y2="129.540" width="0.1524" layer="91"/>
<label x="182.880" y="129.540" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="FB1" gate="G$1" pin="1"/>
<wire x1="187.960" y1="83.820" x2="182.880" y2="83.820" width="0.1524" layer="91"/>
<label x="182.880" y="83.820" size="1.778" layer="95" rot="R180"/>
</segment>
</net>
<net name="ADC_INL" class="0">
<segment>
<pinref part="C22" gate="G$1" pin="2"/>
<wire x1="129.540" y1="109.220" x2="134.620" y2="109.220" width="0.1524" layer="91"/>
<label x="134.620" y="109.220" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="U12" gate="G$1" pin="VINL"/>
<wire x1="114.300" y1="81.280" x2="109.220" y2="81.280" width="0.1524" layer="91"/>
<label x="109.220" y="81.280" size="1.778" layer="95" rot="R180"/>
</segment>
</net>
<net name="ADC_INR" class="0">
<segment>
<pinref part="U12" gate="G$1" pin="VINR"/>
<wire x1="114.300" y1="78.740" x2="109.220" y2="78.740" width="0.1524" layer="91"/>
<label x="109.220" y="78.740" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="C29" gate="G$1" pin="1"/>
<wire x1="114.300" y1="40.640" x2="109.220" y2="40.640" width="0.1524" layer="91"/>
<label x="109.220" y="40.640" size="1.778" layer="95" rot="R180"/>
</segment>
</net>
<net name="ADC_VREF" class="0">
<segment>
<pinref part="U12" gate="G$1" pin="VREF"/>
<wire x1="114.300" y1="76.200" x2="109.220" y2="76.200" width="0.1524" layer="91"/>
<label x="109.220" y="76.200" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="C23" gate="G$1" pin="1"/>
<wire x1="187.960" y1="238.760" x2="182.880" y2="238.760" width="0.1524" layer="91"/>
<label x="182.880" y="238.760" size="1.778" layer="95" rot="R180"/>
</segment>
</net>
<net name="BOOST_EN" class="0">
<segment>
<pinref part="U24" gate="G$1" pin="EN"/>
<wire x1="187.960" y1="209.550" x2="182.880" y2="209.550" width="0.1524" layer="91"/>
<label x="182.880" y="209.550" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="R33" gate="G$1" pin="1"/>
<wire x1="187.960" y1="177.800" x2="182.880" y2="177.800" width="0.1524" layer="91"/>
<label x="182.880" y="177.800" size="1.778" layer="95" rot="R180"/>
</segment>
</net>
<net name="BST_FB" class="0">
<segment>
<pinref part="U24" gate="G$1" pin="FB"/>
<wire x1="213.360" y1="209.550" x2="218.440" y2="209.550" width="0.1524" layer="91"/>
<label x="218.440" y="209.550" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="R27" gate="G$1" pin="2"/>
<wire x1="203.200" y1="129.540" x2="208.280" y2="129.540" width="0.1524" layer="91"/>
<label x="208.280" y="129.540" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="R28" gate="G$1" pin="1"/>
<wire x1="187.960" y1="106.680" x2="182.880" y2="106.680" width="0.1524" layer="91"/>
<label x="182.880" y="106.680" size="1.778" layer="95" rot="R180"/>
</segment>
</net>
<net name="BST_SW" class="0">
<segment>
<pinref part="U24" gate="G$1" pin="SW"/>
<wire x1="187.960" y1="207.010" x2="182.880" y2="207.010" width="0.1524" layer="91"/>
<label x="182.880" y="207.010" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="L4" gate="G$1" pin="2"/>
<wire x1="203.200" y1="152.400" x2="208.280" y2="152.400" width="0.1524" layer="91"/>
<label x="208.280" y="152.400" size="1.778" layer="95"/>
</segment>
</net>
<net name="C123_P" class="0">
<segment>
<pinref part="L3" gate="G$1" pin="1"/>
<wire x1="187.960" y1="33.020" x2="182.880" y2="33.020" width="0.1524" layer="91"/>
<label x="182.880" y="33.020" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="C25" gate="G$1" pin="1"/>
<wire x1="259.080" y1="238.760" x2="254.000" y2="238.760" width="0.1524" layer="91"/>
<label x="254.000" y="238.760" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="D1" gate="G$1" pin="A"/>
<wire x1="259.080" y1="215.900" x2="254.000" y2="215.900" width="0.1524" layer="91"/>
<label x="254.000" y="215.900" size="1.778" layer="95" rot="R180"/>
</segment>
</net>
<net name="CMP_REF" class="0">
<segment>
<pinref part="U13" gate="G$1" pin="IN-"/>
<wire x1="259.080" y1="138.430" x2="254.000" y2="138.430" width="0.1524" layer="91"/>
<label x="254.000" y="138.430" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="R30" gate="G$1" pin="2"/>
<wire x1="274.320" y1="109.220" x2="279.400" y2="109.220" width="0.1524" layer="91"/>
<label x="279.400" y="109.220" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="R31" gate="G$1" pin="1"/>
<wire x1="259.080" y1="86.360" x2="254.000" y2="86.360" width="0.1524" layer="91"/>
<label x="254.000" y="86.360" size="1.778" layer="95" rot="R180"/>
</segment>
</net>
<net name="COIL_P" class="0">
<segment>
<pinref part="L2" gate="G$1" pin="1"/>
<wire x1="43.180" y1="238.760" x2="38.100" y2="238.760" width="0.1524" layer="91"/>
<label x="38.100" y="238.760" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="C20" gate="G$1" pin="1"/>
<wire x1="43.180" y1="213.360" x2="38.100" y2="213.360" width="0.1524" layer="91"/>
<label x="38.100" y="213.360" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="R20" gate="G$1" pin="1"/>
<wire x1="43.180" y1="185.420" x2="38.100" y2="185.420" width="0.1524" layer="91"/>
<label x="38.100" y="185.420" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="U11" gate="G$1" pin="INA+"/>
<wire x1="43.180" y1="156.210" x2="38.100" y2="156.210" width="0.1524" layer="91"/>
<label x="38.100" y="156.210" size="1.778" layer="95" rot="R180"/>
</segment>
</net>
<net name="ENV" class="0">
<segment>
<pinref part="D1" gate="G$1" pin="K"/>
<wire x1="274.320" y1="215.900" x2="279.400" y2="215.900" width="0.1524" layer="91"/>
<label x="279.400" y="215.900" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="C26" gate="G$1" pin="1"/>
<wire x1="259.080" y1="190.500" x2="254.000" y2="190.500" width="0.1524" layer="91"/>
<label x="254.000" y="190.500" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="R29" gate="G$1" pin="1"/>
<wire x1="259.080" y1="167.640" x2="254.000" y2="167.640" width="0.1524" layer="91"/>
<label x="254.000" y="167.640" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="U13" gate="G$1" pin="IN+"/>
<wire x1="259.080" y1="140.970" x2="254.000" y2="140.970" width="0.1524" layer="91"/>
<label x="254.000" y="140.970" size="1.778" layer="95" rot="R180"/>
</segment>
</net>
<net name="GND" class="0">
<segment>
<pinref part="U11" gate="G$1" pin="VSS"/>
<wire x1="43.180" y1="146.050" x2="38.100" y2="146.050" width="0.1524" layer="91"/>
<label x="38.100" y="146.050" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="R26" gate="G$1" pin="2"/>
<wire x1="129.540" y1="160.020" x2="134.620" y2="160.020" width="0.1524" layer="91"/>
<label x="134.620" y="160.020" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="C21" gate="G$1" pin="2"/>
<wire x1="129.540" y1="132.080" x2="134.620" y2="132.080" width="0.1524" layer="91"/>
<label x="134.620" y="132.080" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="U12" gate="G$1" pin="AGND"/>
<wire x1="114.300" y1="71.120" x2="109.220" y2="71.120" width="0.1524" layer="91"/>
<label x="109.220" y="71.120" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="U12" gate="G$1" pin="DGND"/>
<wire x1="114.300" y1="66.040" x2="109.220" y2="66.040" width="0.1524" layer="91"/>
<label x="109.220" y="66.040" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="U12" gate="G$1" pin="FMT"/>
<wire x1="139.700" y1="71.120" x2="144.780" y2="71.120" width="0.1524" layer="91"/>
<label x="144.780" y="71.120" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="U12" gate="G$1" pin="MD0"/>
<wire x1="139.700" y1="68.580" x2="144.780" y2="68.580" width="0.1524" layer="91"/>
<label x="144.780" y="68.580" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="U12" gate="G$1" pin="MD1"/>
<wire x1="139.700" y1="66.040" x2="144.780" y2="66.040" width="0.1524" layer="91"/>
<label x="144.780" y="66.040" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="C29" gate="G$1" pin="2"/>
<wire x1="129.540" y1="40.640" x2="134.620" y2="40.640" width="0.1524" layer="91"/>
<label x="134.620" y="40.640" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="C23" gate="G$1" pin="2"/>
<wire x1="203.200" y1="238.760" x2="208.280" y2="238.760" width="0.1524" layer="91"/>
<label x="208.280" y="238.760" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="U24" gate="G$1" pin="GND"/>
<wire x1="187.960" y1="204.470" x2="182.880" y2="204.470" width="0.1524" layer="91"/>
<label x="182.880" y="204.470" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="R33" gate="G$1" pin="2"/>
<wire x1="203.200" y1="177.800" x2="208.280" y2="177.800" width="0.1524" layer="91"/>
<label x="208.280" y="177.800" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="R28" gate="G$1" pin="2"/>
<wire x1="203.200" y1="106.680" x2="208.280" y2="106.680" width="0.1524" layer="91"/>
<label x="208.280" y="106.680" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="C24" gate="G$1" pin="2"/>
<wire x1="203.200" y1="55.880" x2="208.280" y2="55.880" width="0.1524" layer="91"/>
<label x="208.280" y="55.880" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="L3" gate="G$1" pin="2"/>
<wire x1="203.200" y1="33.020" x2="208.280" y2="33.020" width="0.1524" layer="91"/>
<label x="208.280" y="33.020" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="C25" gate="G$1" pin="2"/>
<wire x1="274.320" y1="238.760" x2="279.400" y2="238.760" width="0.1524" layer="91"/>
<label x="279.400" y="238.760" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="C26" gate="G$1" pin="2"/>
<wire x1="274.320" y1="190.500" x2="279.400" y2="190.500" width="0.1524" layer="91"/>
<label x="279.400" y="190.500" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="R29" gate="G$1" pin="2"/>
<wire x1="274.320" y1="167.640" x2="279.400" y2="167.640" width="0.1524" layer="91"/>
<label x="279.400" y="167.640" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="U13" gate="G$1" pin="GND"/>
<wire x1="259.080" y1="135.890" x2="254.000" y2="135.890" width="0.1524" layer="91"/>
<label x="254.000" y="135.890" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="R31" gate="G$1" pin="2"/>
<wire x1="274.320" y1="86.360" x2="279.400" y2="86.360" width="0.1524" layer="91"/>
<label x="279.400" y="86.360" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="U14" gate="G$1" pin="GND"/>
<wire x1="260.350" y1="29.210" x2="255.270" y2="29.210" width="0.1524" layer="91"/>
<label x="255.270" y="29.210" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="U25" gate="G$1" pin="GND"/>
<wire x1="335.280" y1="233.680" x2="330.200" y2="233.680" width="0.1524" layer="91"/>
<label x="330.200" y="233.680" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="R34" gate="G$1" pin="2"/>
<wire x1="350.520" y1="208.280" x2="355.600" y2="208.280" width="0.1524" layer="91"/>
<label x="355.600" y="208.280" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="C30" gate="G$1" pin="2"/>
<wire x1="350.520" y1="180.340" x2="355.600" y2="180.340" width="0.1524" layer="91"/>
<label x="355.600" y="180.340" size="1.778" layer="95"/>
</segment>
</net>
<net name="GNSS_EN" class="0">
<segment>
<pinref part="U25" gate="G$1" pin="ON"/>
<wire x1="335.280" y1="236.220" x2="330.200" y2="236.220" width="0.1524" layer="91"/>
<label x="330.200" y="236.220" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="R34" gate="G$1" pin="1"/>
<wire x1="335.280" y1="208.280" x2="330.200" y2="208.280" width="0.1524" layer="91"/>
<label x="330.200" y="208.280" size="1.778" layer="95" rot="R180"/>
</segment>
</net>
<net name="GNSS_PPS" class="0">
<segment>
<pinref part="U14" gate="G$1" pin="1PPS"/>
<wire x1="288.290" y1="31.750" x2="293.370" y2="31.750" width="0.1524" layer="91"/>
<label x="293.370" y="31.750" size="1.778" layer="95"/>
</segment>
</net>
<net name="GNSS_RF" class="0">
<segment>
<pinref part="U14" gate="G$1" pin="RF_IN"/>
<wire x1="260.350" y1="31.750" x2="255.270" y2="31.750" width="0.1524" layer="91"/>
<label x="255.270" y="31.750" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="ANT1" gate="G$1" pin="1"/>
<wire x1="335.280" y1="157.480" x2="330.200" y2="157.480" width="0.1524" layer="91"/>
<label x="330.200" y="157.480" size="1.778" layer="95" rot="R180"/>
</segment>
</net>
<net name="GNSS_RX" class="0">
<segment>
<pinref part="U14" gate="G$1" pin="TXD"/>
<wire x1="288.290" y1="36.830" x2="293.370" y2="36.830" width="0.1524" layer="91"/>
<label x="293.370" y="36.830" size="1.778" layer="95"/>
</segment>
</net>
<net name="GNSS_TX" class="0">
<segment>
<pinref part="U14" gate="G$1" pin="RXD"/>
<wire x1="288.290" y1="34.290" x2="293.370" y2="34.290" width="0.1524" layer="91"/>
<label x="293.370" y="34.290" size="1.778" layer="95"/>
</segment>
</net>
<net name="I2S_BCK" class="0">
<segment>
<pinref part="U12" gate="G$1" pin="BCK"/>
<wire x1="139.700" y1="78.740" x2="144.780" y2="78.740" width="0.1524" layer="91"/>
<label x="144.780" y="78.740" size="1.778" layer="95"/>
</segment>
</net>
<net name="I2S_DIN" class="0">
<segment>
<pinref part="U12" gate="G$1" pin="DOUT"/>
<wire x1="139.700" y1="73.660" x2="144.780" y2="73.660" width="0.1524" layer="91"/>
<label x="144.780" y="73.660" size="1.778" layer="95"/>
</segment>
</net>
<net name="I2S_LRCK" class="0">
<segment>
<pinref part="U12" gate="G$1" pin="LRCK"/>
<wire x1="139.700" y1="76.200" x2="144.780" y2="76.200" width="0.1524" layer="91"/>
<label x="144.780" y="76.200" size="1.778" layer="95"/>
</segment>
</net>
<net name="I2S_MCLK" class="0">
<segment>
<pinref part="U12" gate="G$1" pin="SCKI"/>
<wire x1="139.700" y1="81.280" x2="144.780" y2="81.280" width="0.1524" layer="91"/>
<label x="144.780" y="81.280" size="1.778" layer="95"/>
</segment>
</net>
<net name="PA_AC1" class="0">
<segment>
<pinref part="R21" gate="G$1" pin="2"/>
<wire x1="58.420" y1="119.380" x2="63.500" y2="119.380" width="0.1524" layer="91"/>
<label x="63.500" y="119.380" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="C27" gate="G$1" pin="1"/>
<wire x1="43.180" y1="91.440" x2="38.100" y2="91.440" width="0.1524" layer="91"/>
<label x="38.100" y="91.440" size="1.778" layer="95" rot="R180"/>
</segment>
</net>
<net name="PA_AC2" class="0">
<segment>
<pinref part="R23" gate="G$1" pin="2"/>
<wire x1="58.420" y1="38.100" x2="63.500" y2="38.100" width="0.1524" layer="91"/>
<label x="63.500" y="38.100" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="C28" gate="G$1" pin="1"/>
<wire x1="114.300" y1="238.760" x2="109.220" y2="238.760" width="0.1524" layer="91"/>
<label x="109.220" y="238.760" size="1.778" layer="95" rot="R180"/>
</segment>
</net>
<net name="PA_FB1" class="0">
<segment>
<pinref part="U11" gate="G$1" pin="INA-"/>
<wire x1="43.180" y1="153.670" x2="38.100" y2="153.670" width="0.1524" layer="91"/>
<label x="38.100" y="153.670" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="R21" gate="G$1" pin="1"/>
<wire x1="43.180" y1="119.380" x2="38.100" y2="119.380" width="0.1524" layer="91"/>
<label x="38.100" y="119.380" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="R22" gate="G$1" pin="1"/>
<wire x1="43.180" y1="66.040" x2="38.100" y2="66.040" width="0.1524" layer="91"/>
<label x="38.100" y="66.040" size="1.778" layer="95" rot="R180"/>
</segment>
</net>
<net name="PA_FB2" class="0">
<segment>
<pinref part="U11" gate="G$1" pin="INB-"/>
<wire x1="43.180" y1="148.590" x2="38.100" y2="148.590" width="0.1524" layer="91"/>
<label x="38.100" y="148.590" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="R23" gate="G$1" pin="1"/>
<wire x1="43.180" y1="38.100" x2="38.100" y2="38.100" width="0.1524" layer="91"/>
<label x="38.100" y="38.100" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="R24" gate="G$1" pin="1"/>
<wire x1="114.300" y1="213.360" x2="109.220" y2="213.360" width="0.1524" layer="91"/>
<label x="109.220" y="213.360" size="1.778" layer="95" rot="R180"/>
</segment>
</net>
<net name="PA_OUT1" class="0">
<segment>
<pinref part="U11" gate="G$1" pin="INB+"/>
<wire x1="43.180" y1="151.130" x2="38.100" y2="151.130" width="0.1524" layer="91"/>
<label x="38.100" y="151.130" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="U11" gate="G$1" pin="OUTA"/>
<wire x1="68.580" y1="158.750" x2="73.660" y2="158.750" width="0.1524" layer="91"/>
<label x="73.660" y="158.750" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="R22" gate="G$1" pin="2"/>
<wire x1="58.420" y1="66.040" x2="63.500" y2="66.040" width="0.1524" layer="91"/>
<label x="63.500" y="66.040" size="1.778" layer="95"/>
</segment>
</net>
<net name="PA_OUT2" class="0">
<segment>
<pinref part="U11" gate="G$1" pin="OUTB"/>
<wire x1="68.580" y1="156.210" x2="73.660" y2="156.210" width="0.1524" layer="91"/>
<label x="73.660" y="156.210" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="R24" gate="G$1" pin="2"/>
<wire x1="129.540" y1="213.360" x2="134.620" y2="213.360" width="0.1524" layer="91"/>
<label x="134.620" y="213.360" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="C22" gate="G$1" pin="1"/>
<wire x1="114.300" y1="109.220" x2="109.220" y2="109.220" width="0.1524" layer="91"/>
<label x="109.220" y="109.220" size="1.778" layer="95" rot="R180"/>
</segment>
</net>
<net name="TX123_ENV" class="0">
<segment>
<pinref part="U13" gate="G$1" pin="OUT"/>
<wire x1="284.480" y1="143.510" x2="289.560" y2="143.510" width="0.1524" layer="91"/>
<label x="289.560" y="143.510" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="R32" gate="G$1" pin="2"/>
<wire x1="274.320" y1="60.960" x2="279.400" y2="60.960" width="0.1524" layer="91"/>
<label x="279.400" y="60.960" size="1.778" layer="95"/>
</segment>
</net>
<net name="VBAT" class="0">
<segment>
<pinref part="U24" gate="G$1" pin="VIN"/>
<wire x1="187.960" y1="212.090" x2="182.880" y2="212.090" width="0.1524" layer="91"/>
<label x="182.880" y="212.090" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="L4" gate="G$1" pin="1"/>
<wire x1="187.960" y1="152.400" x2="182.880" y2="152.400" width="0.1524" layer="91"/>
<label x="182.880" y="152.400" size="1.778" layer="95" rot="R180"/>
</segment>
</net>
<net name="VMID" class="0">
<segment>
<pinref part="L2" gate="G$1" pin="2"/>
<wire x1="58.420" y1="238.760" x2="63.500" y2="238.760" width="0.1524" layer="91"/>
<label x="63.500" y="238.760" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="C20" gate="G$1" pin="2"/>
<wire x1="58.420" y1="213.360" x2="63.500" y2="213.360" width="0.1524" layer="91"/>
<label x="63.500" y="213.360" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="R20" gate="G$1" pin="2"/>
<wire x1="58.420" y1="185.420" x2="63.500" y2="185.420" width="0.1524" layer="91"/>
<label x="63.500" y="185.420" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="C27" gate="G$1" pin="2"/>
<wire x1="58.420" y1="91.440" x2="63.500" y2="91.440" width="0.1524" layer="91"/>
<label x="63.500" y="91.440" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="C28" gate="G$1" pin="2"/>
<wire x1="129.540" y1="238.760" x2="134.620" y2="238.760" width="0.1524" layer="91"/>
<label x="134.620" y="238.760" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="R25" gate="G$1" pin="2"/>
<wire x1="129.540" y1="185.420" x2="134.620" y2="185.420" width="0.1524" layer="91"/>
<label x="134.620" y="185.420" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="R26" gate="G$1" pin="1"/>
<wire x1="114.300" y1="160.020" x2="109.220" y2="160.020" width="0.1524" layer="91"/>
<label x="109.220" y="160.020" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="C21" gate="G$1" pin="1"/>
<wire x1="114.300" y1="132.080" x2="109.220" y2="132.080" width="0.1524" layer="91"/>
<label x="109.220" y="132.080" size="1.778" layer="95" rot="R180"/>
</segment>
</net>
</nets>
</sheet>
<sheet>
<description>4 Skjerm, alarmer og knapper</description>
<plain>
<wire x1="0" y1="0" x2="420.0" y2="0" width="0.254" layer="97"/>
<wire x1="420.0" y1="0" x2="420.0" y2="297.0" width="0.254" layer="97"/>
<wire x1="420.0" y1="297.0" x2="0" y2="297.0" width="0.254" layer="97"/>
<wire x1="0" y1="297.0" x2="0" y2="0" width="0.254" layer="97"/>
<wire x1="5" y1="5" x2="415.0" y2="5" width="0.254" layer="97"/>
<wire x1="415.0" y1="5" x2="415.0" y2="292.0" width="0.254" layer="97"/>
<wire x1="415.0" y1="292.0" x2="5" y2="292.0" width="0.254" layer="97"/>
<wire x1="5" y1="292.0" x2="5" y2="5" width="0.254" layer="97"/>
<wire x1="270.0" y1="25" x2="415.0" y2="25" width="0.254" layer="97"/>
<wire x1="270.0" y1="5" x2="270.0" y2="25" width="0.254" layer="97"/>
<text x="273.0" y="17" size="3.81" layer="97">Dykkecomputer 3.5 in — 4 Skjerm, alarmer og knapper</text>
<text x="273.0" y="11" size="1.778" layer="97">ST7796-skjerm, microSD, sikkerhets-MCU, summer, vibrasjon, hall-knapper og våtkontakter</text>
<text x="273.0" y="7" size="1.524" layer="97">Ark 4 av 4 · rev B · 2026-11-20 · ikke validert for dykking</text>
<text x="10" y="285.0" size="3.81" layer="97">4 Skjerm, alarmer og knapper</text>
</plain>
<instances>
<instance part="J2" gate="G$1" x="53.340" y="228.600"/>
<instance part="R40" gate="G$1" x="50.800" y="190.500"/>
<instance part="Q1" gate="G$1" x="50.800" y="162.560"/>
<instance part="R41" gate="G$1" x="50.800" y="137.160"/>
<instance part="J3" gate="G$1" x="53.340" y="104.140"/>
<instance part="R42" gate="G$1" x="50.800" y="68.580"/>
<instance part="R43" gate="G$1" x="50.800" y="45.720"/>
<instance part="R44" gate="G$1" x="50.800" y="22.860"/>
<instance part="U15" gate="G$1" x="114.300" y="233.680"/>
<instance part="TP1" gate="G$1" x="109.220" y="203.200"/>
<instance part="D2" gate="G$1" x="106.680" y="175.260"/>
<instance part="D3" gate="G$1" x="106.680" y="149.860"/>
<instance part="R45" gate="G$1" x="106.680" y="121.920"/>
<instance part="Q2" gate="G$1" x="106.680" y="99.060"/>
<instance part="BZ1" gate="G$1" x="106.680" y="71.120"/>
<instance part="R46" gate="G$1" x="106.680" y="45.720"/>
<instance part="Q3" gate="G$1" x="180.340" y="238.760"/>
<instance part="R47" gate="G$1" x="180.340" y="213.360"/>
<instance part="R48" gate="G$1" x="180.340" y="190.500"/>
<instance part="M1" gate="G$1" x="180.340" y="167.640"/>
<instance part="D4" gate="G$1" x="180.340" y="144.780"/>
<instance part="U16" gate="G$1" x="185.420" y="114.300"/>
<instance part="U17" gate="G$1" x="185.420" y="83.820"/>
<instance part="U18" gate="G$1" x="185.420" y="50.800"/>
<instance part="E1" gate="G$1" x="251.460" y="238.760"/>
<instance part="E2" gate="G$1" x="251.460" y="213.360"/>
<instance part="R49" gate="G$1" x="248.920" y="190.500"/>
</instances>
<busses>
</busses>
<nets>
<net name="3V3" class="0">
<segment>
<pinref part="J2" gate="G$1" pin="VCC"/>
<wire x1="43.180" y1="240.030" x2="38.100" y2="240.030" width="0.1524" layer="91"/>
<label x="38.100" y="240.030" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="J3" gate="G$1" pin="VDD"/>
<wire x1="43.180" y1="107.950" x2="38.100" y2="107.950" width="0.1524" layer="91"/>
<label x="38.100" y="107.950" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="R42" gate="G$1" pin="1"/>
<wire x1="43.180" y1="68.580" x2="38.100" y2="68.580" width="0.1524" layer="91"/>
<label x="38.100" y="68.580" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="R43" gate="G$1" pin="1"/>
<wire x1="43.180" y1="45.720" x2="38.100" y2="45.720" width="0.1524" layer="91"/>
<label x="38.100" y="45.720" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="R44" gate="G$1" pin="1"/>
<wire x1="43.180" y1="22.860" x2="38.100" y2="22.860" width="0.1524" layer="91"/>
<label x="38.100" y="22.860" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="U15" gate="G$1" pin="VDD"/>
<wire x1="97.790" y1="238.760" x2="92.710" y2="238.760" width="0.1524" layer="91"/>
<label x="92.710" y="238.760" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="U16" gate="G$1" pin="VCC"/>
<wire x1="172.720" y1="116.840" x2="167.640" y2="116.840" width="0.1524" layer="91"/>
<label x="167.640" y="116.840" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="U17" gate="G$1" pin="VCC"/>
<wire x1="172.720" y1="86.360" x2="167.640" y2="86.360" width="0.1524" layer="91"/>
<label x="167.640" y="86.360" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="U18" gate="G$1" pin="VCC"/>
<wire x1="172.720" y1="53.340" x2="167.640" y2="53.340" width="0.1524" layer="91"/>
<label x="167.640" y="53.340" size="1.778" layer="95" rot="R180"/>
</segment>
</net>
<net name="BL_A" class="0">
<segment>
<pinref part="J2" gate="G$1" pin="LEDA"/>
<wire x1="43.180" y1="219.710" x2="38.100" y2="219.710" width="0.1524" layer="91"/>
<label x="38.100" y="219.710" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="R40" gate="G$1" pin="2"/>
<wire x1="58.420" y1="190.500" x2="63.500" y2="190.500" width="0.1524" layer="91"/>
<label x="63.500" y="190.500" size="1.778" layer="95"/>
</segment>
</net>
<net name="BL_G" class="0">
<segment>
<pinref part="Q1" gate="G$1" pin="G"/>
<wire x1="43.180" y1="162.560" x2="38.100" y2="162.560" width="0.1524" layer="91"/>
<label x="38.100" y="162.560" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="R41" gate="G$1" pin="2"/>
<wire x1="58.420" y1="137.160" x2="63.500" y2="137.160" width="0.1524" layer="91"/>
<label x="63.500" y="137.160" size="1.778" layer="95"/>
</segment>
</net>
<net name="BL_K" class="0">
<segment>
<pinref part="J2" gate="G$1" pin="LEDK"/>
<wire x1="43.180" y1="217.170" x2="38.100" y2="217.170" width="0.1524" layer="91"/>
<label x="38.100" y="217.170" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="Q1" gate="G$1" pin="D"/>
<wire x1="58.420" y1="162.560" x2="63.500" y2="162.560" width="0.1524" layer="91"/>
<label x="63.500" y="162.560" size="1.778" layer="95"/>
</segment>
</net>
<net name="BOOST_EN" class="0">
<segment>
<pinref part="U15" gate="G$1" pin="PC0"/>
<wire x1="130.810" y1="231.140" x2="135.890" y2="231.140" width="0.1524" layer="91"/>
<label x="135.890" y="231.140" size="1.778" layer="95"/>
</segment>
</net>
<net name="BTN_DN" class="0">
<segment>
<pinref part="U18" gate="G$1" pin="INT"/>
<wire x1="198.120" y1="48.260" x2="203.200" y2="48.260" width="0.1524" layer="91"/>
<label x="203.200" y="48.260" size="1.778" layer="95"/>
</segment>
</net>
<net name="BTN_SEL" class="0">
<segment>
<pinref part="U17" gate="G$1" pin="INT"/>
<wire x1="198.120" y1="81.280" x2="203.200" y2="81.280" width="0.1524" layer="91"/>
<label x="203.200" y="81.280" size="1.778" layer="95"/>
</segment>
</net>
<net name="BTN_UP" class="0">
<segment>
<pinref part="U16" gate="G$1" pin="INT"/>
<wire x1="198.120" y1="111.760" x2="203.200" y2="111.760" width="0.1524" layer="91"/>
<label x="203.200" y="111.760" size="1.778" layer="95"/>
</segment>
</net>
<net name="BUZZER" class="0">
<segment>
<pinref part="D2" gate="G$1" pin="A"/>
<wire x1="99.060" y1="175.260" x2="93.980" y2="175.260" width="0.1524" layer="91"/>
<label x="93.980" y="175.260" size="1.778" layer="95" rot="R180"/>
</segment>
</net>
<net name="BUZ_G" class="0">
<segment>
<pinref part="D2" gate="G$1" pin="K"/>
<wire x1="114.300" y1="175.260" x2="119.380" y2="175.260" width="0.1524" layer="91"/>
<label x="119.380" y="175.260" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="D3" gate="G$1" pin="K"/>
<wire x1="114.300" y1="149.860" x2="119.380" y2="149.860" width="0.1524" layer="91"/>
<label x="119.380" y="149.860" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="R45" gate="G$1" pin="1"/>
<wire x1="99.060" y1="121.920" x2="93.980" y2="121.920" width="0.1524" layer="91"/>
<label x="93.980" y="121.920" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="Q2" gate="G$1" pin="G"/>
<wire x1="99.060" y1="99.060" x2="93.980" y2="99.060" width="0.1524" layer="91"/>
<label x="93.980" y="99.060" size="1.778" layer="95" rot="R180"/>
</segment>
</net>
<net name="BUZ_K" class="0">
<segment>
<pinref part="Q2" gate="G$1" pin="D"/>
<wire x1="114.300" y1="99.060" x2="119.380" y2="99.060" width="0.1524" layer="91"/>
<label x="119.380" y="99.060" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="BZ1" gate="G$1" pin="-"/>
<wire x1="114.300" y1="71.120" x2="119.380" y2="71.120" width="0.1524" layer="91"/>
<label x="119.380" y="71.120" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="R46" gate="G$1" pin="2"/>
<wire x1="114.300" y1="45.720" x2="119.380" y2="45.720" width="0.1524" layer="91"/>
<label x="119.380" y="45.720" size="1.778" layer="95"/>
</segment>
</net>
<net name="BUZ_SAFE" class="0">
<segment>
<pinref part="U15" gate="G$1" pin="PC4"/>
<wire x1="130.810" y1="233.680" x2="135.890" y2="233.680" width="0.1524" layer="91"/>
<label x="135.890" y="233.680" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="D3" gate="G$1" pin="A"/>
<wire x1="99.060" y1="149.860" x2="93.980" y2="149.860" width="0.1524" layer="91"/>
<label x="93.980" y="149.860" size="1.778" layer="95" rot="R180"/>
</segment>
</net>
<net name="GND" class="0">
<segment>
<pinref part="J2" gate="G$1" pin="GND"/>
<wire x1="43.180" y1="237.490" x2="38.100" y2="237.490" width="0.1524" layer="91"/>
<label x="38.100" y="237.490" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="J3" gate="G$1" pin="VSS"/>
<wire x1="43.180" y1="102.870" x2="38.100" y2="102.870" width="0.1524" layer="91"/>
<label x="38.100" y="102.870" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="U15" gate="G$1" pin="VSS"/>
<wire x1="97.790" y1="228.600" x2="92.710" y2="228.600" width="0.1524" layer="91"/>
<label x="92.710" y="228.600" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="R45" gate="G$1" pin="2"/>
<wire x1="114.300" y1="121.920" x2="119.380" y2="121.920" width="0.1524" layer="91"/>
<label x="119.380" y="121.920" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="R48" gate="G$1" pin="2"/>
<wire x1="187.960" y1="190.500" x2="193.040" y2="190.500" width="0.1524" layer="91"/>
<label x="193.040" y="190.500" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="U16" gate="G$1" pin="GND"/>
<wire x1="172.720" y1="114.300" x2="167.640" y2="114.300" width="0.1524" layer="91"/>
<label x="167.640" y="114.300" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="U17" gate="G$1" pin="GND"/>
<wire x1="172.720" y1="83.820" x2="167.640" y2="83.820" width="0.1524" layer="91"/>
<label x="167.640" y="83.820" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="U18" gate="G$1" pin="GND"/>
<wire x1="172.720" y1="50.800" x2="167.640" y2="50.800" width="0.1524" layer="91"/>
<label x="167.640" y="50.800" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="E2" gate="G$1" pin="1"/>
<wire x1="241.300" y1="213.360" x2="236.220" y2="213.360" width="0.1524" layer="91"/>
<label x="236.220" y="213.360" size="1.778" layer="95" rot="R180"/>
</segment>
</net>
<net name="GNSS_EN" class="0">
<segment>
<pinref part="U15" gate="G$1" pin="PC3"/>
<wire x1="130.810" y1="228.600" x2="135.890" y2="228.600" width="0.1524" layer="91"/>
<label x="135.890" y="228.600" size="1.778" layer="95"/>
</segment>
</net>
<net name="LCD_BL" class="0">
<segment>
<pinref part="R41" gate="G$1" pin="1"/>
<wire x1="43.180" y1="137.160" x2="38.100" y2="137.160" width="0.1524" layer="91"/>
<label x="38.100" y="137.160" size="1.778" layer="95" rot="R180"/>
</segment>
</net>
<net name="LCD_CS" class="0">
<segment>
<pinref part="J2" gate="G$1" pin="CS"/>
<wire x1="43.180" y1="234.950" x2="38.100" y2="234.950" width="0.1524" layer="91"/>
<label x="38.100" y="234.950" size="1.778" layer="95" rot="R180"/>
</segment>
</net>
<net name="LCD_DC" class="0">
<segment>
<pinref part="J2" gate="G$1" pin="DC"/>
<wire x1="43.180" y1="232.410" x2="38.100" y2="232.410" width="0.1524" layer="91"/>
<label x="38.100" y="232.410" size="1.778" layer="95" rot="R180"/>
</segment>
</net>
<net name="LCD_RST" class="0">
<segment>
<pinref part="J2" gate="G$1" pin="RST"/>
<wire x1="43.180" y1="229.870" x2="38.100" y2="229.870" width="0.1524" layer="91"/>
<label x="38.100" y="229.870" size="1.778" layer="95" rot="R180"/>
</segment>
</net>
<net name="SAFE_RX" class="0">
<segment>
<pinref part="U15" gate="G$1" pin="PD5/UTX"/>
<wire x1="97.790" y1="233.680" x2="92.710" y2="233.680" width="0.1524" layer="91"/>
<label x="92.710" y="233.680" size="1.778" layer="95" rot="R180"/>
</segment>
</net>
<net name="SAFE_TX" class="0">
<segment>
<pinref part="U15" gate="G$1" pin="PD6/URX"/>
<wire x1="97.790" y1="236.220" x2="92.710" y2="236.220" width="0.1524" layer="91"/>
<label x="92.710" y="236.220" size="1.778" layer="95" rot="R180"/>
</segment>
</net>
<net name="SCL" class="0">
<segment>
<pinref part="U16" gate="G$1" pin="SCL"/>
<wire x1="198.120" y1="114.300" x2="203.200" y2="114.300" width="0.1524" layer="91"/>
<label x="203.200" y="114.300" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="U17" gate="G$1" pin="SCL"/>
<wire x1="198.120" y1="83.820" x2="203.200" y2="83.820" width="0.1524" layer="91"/>
<label x="203.200" y="83.820" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="U18" gate="G$1" pin="SCL"/>
<wire x1="198.120" y1="50.800" x2="203.200" y2="50.800" width="0.1524" layer="91"/>
<label x="203.200" y="50.800" size="1.778" layer="95"/>
</segment>
</net>
<net name="SCL_B" class="0">
<segment>
<pinref part="U15" gate="G$1" pin="PC2/SCL"/>
<wire x1="130.810" y1="236.220" x2="135.890" y2="236.220" width="0.1524" layer="91"/>
<label x="135.890" y="236.220" size="1.778" layer="95"/>
</segment>
</net>
<net name="SDA" class="0">
<segment>
<pinref part="U16" gate="G$1" pin="SDA"/>
<wire x1="198.120" y1="116.840" x2="203.200" y2="116.840" width="0.1524" layer="91"/>
<label x="203.200" y="116.840" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="U17" gate="G$1" pin="SDA"/>
<wire x1="198.120" y1="86.360" x2="203.200" y2="86.360" width="0.1524" layer="91"/>
<label x="203.200" y="86.360" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="U18" gate="G$1" pin="SDA"/>
<wire x1="198.120" y1="53.340" x2="203.200" y2="53.340" width="0.1524" layer="91"/>
<label x="203.200" y="53.340" size="1.778" layer="95"/>
</segment>
</net>
<net name="SDA_B" class="0">
<segment>
<pinref part="U15" gate="G$1" pin="PC1/SDA"/>
<wire x1="130.810" y1="238.760" x2="135.890" y2="238.760" width="0.1524" layer="91"/>
<label x="135.890" y="238.760" size="1.778" layer="95"/>
</segment>
</net>
<net name="SD_CS" class="0">
<segment>
<pinref part="J3" gate="G$1" pin="DAT3/CS"/>
<wire x1="43.180" y1="113.030" x2="38.100" y2="113.030" width="0.1524" layer="91"/>
<label x="38.100" y="113.030" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="R42" gate="G$1" pin="2"/>
<wire x1="58.420" y1="68.580" x2="63.500" y2="68.580" width="0.1524" layer="91"/>
<label x="63.500" y="68.580" size="1.778" layer="95"/>
</segment>
</net>
<net name="SD_D1" class="0">
<segment>
<pinref part="J3" gate="G$1" pin="DAT1"/>
<wire x1="43.180" y1="97.790" x2="38.100" y2="97.790" width="0.1524" layer="91"/>
<label x="38.100" y="97.790" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="R43" gate="G$1" pin="2"/>
<wire x1="58.420" y1="45.720" x2="63.500" y2="45.720" width="0.1524" layer="91"/>
<label x="63.500" y="45.720" size="1.778" layer="95"/>
</segment>
</net>
<net name="SD_D2" class="0">
<segment>
<pinref part="J3" gate="G$1" pin="DAT2"/>
<wire x1="43.180" y1="95.250" x2="38.100" y2="95.250" width="0.1524" layer="91"/>
<label x="38.100" y="95.250" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="R44" gate="G$1" pin="2"/>
<wire x1="58.420" y1="22.860" x2="63.500" y2="22.860" width="0.1524" layer="91"/>
<label x="63.500" y="22.860" size="1.778" layer="95"/>
</segment>
</net>
<net name="SPI_MISO" class="0">
<segment>
<pinref part="J2" gate="G$1" pin="SDO"/>
<wire x1="43.180" y1="222.250" x2="38.100" y2="222.250" width="0.1524" layer="91"/>
<label x="38.100" y="222.250" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="J3" gate="G$1" pin="DAT0/DO"/>
<wire x1="43.180" y1="100.330" x2="38.100" y2="100.330" width="0.1524" layer="91"/>
<label x="38.100" y="100.330" size="1.778" layer="95" rot="R180"/>
</segment>
</net>
<net name="SPI_MOSI" class="0">
<segment>
<pinref part="J2" gate="G$1" pin="SDI"/>
<wire x1="43.180" y1="224.790" x2="38.100" y2="224.790" width="0.1524" layer="91"/>
<label x="38.100" y="224.790" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="J3" gate="G$1" pin="CMD/DI"/>
<wire x1="43.180" y1="110.490" x2="38.100" y2="110.490" width="0.1524" layer="91"/>
<label x="38.100" y="110.490" size="1.778" layer="95" rot="R180"/>
</segment>
</net>
<net name="SPI_SCK" class="0">
<segment>
<pinref part="J2" gate="G$1" pin="SCK"/>
<wire x1="43.180" y1="227.330" x2="38.100" y2="227.330" width="0.1524" layer="91"/>
<label x="38.100" y="227.330" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="J3" gate="G$1" pin="CLK"/>
<wire x1="43.180" y1="105.410" x2="38.100" y2="105.410" width="0.1524" layer="91"/>
<label x="38.100" y="105.410" size="1.778" layer="95" rot="R180"/>
</segment>
</net>
<net name="SWIO" class="0">
<segment>
<pinref part="U15" gate="G$1" pin="PD1/SWIO"/>
<wire x1="97.790" y1="231.140" x2="92.710" y2="231.140" width="0.1524" layer="91"/>
<label x="92.710" y="231.140" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="TP1" gate="G$1" pin="1"/>
<wire x1="99.060" y1="203.200" x2="93.980" y2="203.200" width="0.1524" layer="91"/>
<label x="93.980" y="203.200" size="1.778" layer="95" rot="R180"/>
</segment>
</net>
<net name="VBAT" class="0">
<segment>
<pinref part="R40" gate="G$1" pin="1"/>
<wire x1="43.180" y1="190.500" x2="38.100" y2="190.500" width="0.1524" layer="91"/>
<label x="38.100" y="190.500" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="BZ1" gate="G$1" pin="+"/>
<wire x1="99.060" y1="71.120" x2="93.980" y2="71.120" width="0.1524" layer="91"/>
<label x="93.980" y="71.120" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="R46" gate="G$1" pin="1"/>
<wire x1="99.060" y1="45.720" x2="93.980" y2="45.720" width="0.1524" layer="91"/>
<label x="93.980" y="45.720" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="M1" gate="G$1" pin="+"/>
<wire x1="172.720" y1="167.640" x2="167.640" y2="167.640" width="0.1524" layer="91"/>
<label x="167.640" y="167.640" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="D4" gate="G$1" pin="K"/>
<wire x1="187.960" y1="144.780" x2="193.040" y2="144.780" width="0.1524" layer="91"/>
<label x="193.040" y="144.780" size="1.778" layer="95"/>
</segment>
</net>
<net name="VIB" class="0">
<segment>
<pinref part="R47" gate="G$1" pin="1"/>
<wire x1="172.720" y1="213.360" x2="167.640" y2="213.360" width="0.1524" layer="91"/>
<label x="167.640" y="213.360" size="1.778" layer="95" rot="R180"/>
</segment>
</net>
<net name="VIB_G" class="0">
<segment>
<pinref part="Q3" gate="G$1" pin="G"/>
<wire x1="172.720" y1="238.760" x2="167.640" y2="238.760" width="0.1524" layer="91"/>
<label x="167.640" y="238.760" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="R47" gate="G$1" pin="2"/>
<wire x1="187.960" y1="213.360" x2="193.040" y2="213.360" width="0.1524" layer="91"/>
<label x="193.040" y="213.360" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="R48" gate="G$1" pin="1"/>
<wire x1="172.720" y1="190.500" x2="167.640" y2="190.500" width="0.1524" layer="91"/>
<label x="167.640" y="190.500" size="1.778" layer="95" rot="R180"/>
</segment>
</net>
<net name="VIB_K" class="0">
<segment>
<pinref part="Q3" gate="G$1" pin="D"/>
<wire x1="187.960" y1="238.760" x2="193.040" y2="238.760" width="0.1524" layer="91"/>
<label x="193.040" y="238.760" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="M1" gate="G$1" pin="-"/>
<wire x1="187.960" y1="167.640" x2="193.040" y2="167.640" width="0.1524" layer="91"/>
<label x="193.040" y="167.640" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="D4" gate="G$1" pin="A"/>
<wire x1="172.720" y1="144.780" x2="167.640" y2="144.780" width="0.1524" layer="91"/>
<label x="167.640" y="144.780" size="1.778" layer="95" rot="R180"/>
</segment>
</net>
<net name="WET" class="0">
<segment>
<pinref part="R49" gate="G$1" pin="2"/>
<wire x1="256.540" y1="190.500" x2="261.620" y2="190.500" width="0.1524" layer="91"/>
<label x="261.620" y="190.500" size="1.778" layer="95"/>
</segment>
</net>
<net name="WET_PIN" class="0">
<segment>
<pinref part="E1" gate="G$1" pin="1"/>
<wire x1="241.300" y1="238.760" x2="236.220" y2="238.760" width="0.1524" layer="91"/>
<label x="236.220" y="238.760" size="1.778" layer="95" rot="R180"/>
</segment>
<segment>
<pinref part="R49" gate="G$1" pin="1"/>
<wire x1="241.300" y1="190.500" x2="236.220" y2="190.500" width="0.1524" layer="91"/>
<label x="236.220" y="190.500" size="1.778" layer="95" rot="R180"/>
</segment>
</net>
</nets>
</sheet>
</sheets>
</schematic>
</drawing>
</eagle>
